/**
 * background.js — Service Worker
 * Boss AI 招聘助手
 * 负责：AI API 调用 | 任务状态管理 | 消息路由 | 日志记录
 */

// ─── PDF.js（用于从附件简历提取文字）────────────────────────────────────────
import * as pdfjsLib from './libs/pdf.min.mjs';
pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('libs/pdf.worker.min.mjs');

/** 从 PDF URL 提取纯文本（最多前 10 页 / 5000 字符） */
async function extractPdfText(url) {
  try {
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const buffer = await resp.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: buffer }).promise;
    let text = '';
    const maxPages = Math.min(pdf.numPages, 10);
    for (let i = 1; i <= maxPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      text += content.items.map(item => item.str).join(' ') + '\n';
    }
    return text.slice(0, 5000);
  } catch (e) {
    console.warn('[PDF] 提取失败:', e.message);
    return '';
  }
}

// ─── 默认配置 ────────────────────────────────────────────────────────────────
const DEFAULT_CONFIG = {
  claudeApiKey: '',
  claudeApiBase: 'https://api.anthropic.com',
  claudeModel: 'claude-sonnet-4-6',
  claudeMaxTokens: 1024,

  searchKeywords: '',
  jobTitle: '',
  jobDescription: '',
  filterCriteria: {
    companyTier: 'any',
    targetCompanies: '',
    minEducation: 'any',
    school: 'any',
    minExpYears: 0,
    maxExpYears: 0,
    minAvgTenure: 0,
    minLastTenure: 0,
    keywords: [],
    keywordsLogic: 'any',
    gender: 'any',
    notes: '',
  },

  friendMessage: '你好{name}，我们正在招聘{jobTitle}，您在{company}的经历很符合需求，方便聊聊吗？',
  addFriendMessage: '你好{name}！我们招聘{jobTitle}，您的背景很匹配，期待进一步交流！',

  maxCandidates: 30,
  actionDelay: 2500,
  pageDelay: 3000,
  scoreThreshold: 70,

  // DOM 选择器（根据 Boss直聘实际页面结构配置，可在配置页覆盖应对改版）
  selectors: {
    // 推荐牛人入口
    recommendTab: 'span',                   // 文字匹配「推荐牛人」
    recommendTabText: '推荐牛人',

    // 候选人卡片
    profileCard: '[class*="boss-job-recommend"] [class*="card"], [class*="recommend-list"] [class*="item"]',

    // 卡片内元素
    cardName: '[class*="name"]',
    cardTitle: '[class*="job-name"], [class*="position"]',
    cardCompany: '[class*="company-name"], [class*="company"]',

    // 立即沟通按钮
    chatBtnText: '立即沟通',
    greetBtnText: '打招呼',

    // 消息输入框
    messageInputBox: '[contenteditable="true"], textarea, [class*="chat-input"]',
    messageSendBtn: 'button',
    messageSendBtnText: '发送',
  },

  debugMode: false,

  humanBehavior: {
    typingSpeedMin: 80,
    typingSpeedMax: 200,
    typingErrorRate: 0.03,
    readingSpeedCharsPerSec: 8,
    readingMinMs: 3000,
    readingMaxMs: 15000,
    hoverMinMs: 300,
    hoverMaxMs: 1200,
    reviewMinMs: 1500,
    reviewMaxMs: 5000,
    breakAfterN: 8,
    breakMinMs: 15000,
    breakMaxMs: 40000,
    longBreakAfterN: 25,
    longBreakMinMs: 120000,
    longBreakMaxMs: 300000,
    skipProbability: 0.08,
    workHoursEnabled: false,
    workHoursStart: 9,
    workHoursEnd: 18,
    dailyContactLimit: 50,
    scrollProfileEnabled: true,
    scrollSteps: 3,
    jitterPercent: 30,
  },
};

// ─── 运行时状态 ───────────────────────────────────────────────────────────────
let taskState = {
  running: false,
  paused: false,
  processed: 0,
  matched: 0,
  messaged: 0,
  added: 0,
  failed: 0,
  currentKeyword: '',
  startTime: null,
  logs: [],
  automationTabId: null,
  automationWindowId: null,
  panelWindowId: null,
  jobProfiles: [],
  activeProfileId: null,
};

let recruitTaskState = {
  running: false,
  paused: false,
  processed: 0,
  matched: 0,
  messaged: 0,
  failed: 0,
  currentKeyword: '',
  startTime: null,
  automationTabId: null,
  automationWindowId: null,
  jobProfiles: [],
  activeProfileId: null,
};

let inboxTaskState = {
  running: false,
  paused: false,
  processed: 0,
  matched: 0,
  messaged: 0,
  failed: 0,
  startTime: null,
  automationTabId: null,
  jobProfiles: [],
  activeProfileId: null,
};

function getModeForTab(senderTabId) {
  if (senderTabId && recruitTaskState.automationTabId === senderTabId) return 'recruit';
  if (senderTabId && inboxTaskState.automationTabId === senderTabId) return 'inbox';
  return 'social';
}
function getStateForMode(mode) {
  if (mode === 'recruit') return recruitTaskState;
  if (mode === 'inbox') return inboxTaskState;
  return taskState;
}

// ─── 工具函数 ─────────────────────────────────────────────────────────────────
function timestamp() {
  return new Date().toLocaleTimeString('zh-CN');
}

function addLog(level, message, data = null, mode = 'social') {
  const entry = { time: timestamp(), level, message, data, mode };
  taskState.logs.unshift(entry);
  if (taskState.logs.length > 200) taskState.logs.pop();
  chrome.storage.local.set({ taskLogs: taskState.logs.slice(0, 100) });
  broadcastStatus();
}

function broadcastStatus() {
  const social = {
    running: taskState.running,
    paused: taskState.paused,
    processed: taskState.processed,
    matched: taskState.matched,
    messaged: taskState.messaged,
    added: taskState.added,
    failed: taskState.failed,
    currentKeyword: taskState.currentKeyword,
    activeProfileId: taskState.activeProfileId,
  };
  const recruit = {
    running: recruitTaskState.running,
    paused: recruitTaskState.paused,
    processed: recruitTaskState.processed,
    matched: recruitTaskState.matched,
    messaged: recruitTaskState.messaged,
    failed: recruitTaskState.failed,
    currentKeyword: recruitTaskState.currentKeyword,
    activeProfileId: recruitTaskState.activeProfileId,
  };
  const inbox = {
    running: inboxTaskState.running,
    paused: inboxTaskState.paused,
    processed: inboxTaskState.processed,
    matched: inboxTaskState.matched,
    messaged: inboxTaskState.messaged,
    failed: inboxTaskState.failed,
    activeProfileId: inboxTaskState.activeProfileId,
  };
  const status = { social, recruit, inbox, recentLogs: taskState.logs.slice(0, 50) };
  chrome.runtime.sendMessage({ type: 'STATUS_UPDATE', status }).catch(() => {});
  if (taskState.automationTabId) {
    chrome.tabs.sendMessage(taskState.automationTabId, { type: 'STATUS_UPDATE', status }).catch(() => {});
  }
  if (recruitTaskState.automationTabId && recruitTaskState.automationTabId !== taskState.automationTabId) {
    chrome.tabs.sendMessage(recruitTaskState.automationTabId, { type: 'STATUS_UPDATE', status }).catch(() => {});
  }
  if (taskState.running || recruitTaskState.running) {
    chrome.storage.local.set({ __boss_live_stats: { ...status, savedAt: Date.now() } }).catch(() => {});
  }
}

// ─── 大模型 API 调用（Claude / OpenAI 兼容） ─────────────────────────────────
function isClaudeModel(model) {
  return model && String(model).startsWith('claude-');
}

async function callLLM(prompt, config) {
  const apiKey = config.claudeApiKey;
  const model  = config.claudeModel;
  const maxTokens = config.claudeMaxTokens || 1024;
  if (!apiKey) throw new Error('未配置 API Key');

  const base = (config.claudeApiBase || 'https://api.anthropic.com').replace(/\/$/, '');
  const TIMEOUT_MS = 60000;
  const MAX_RETRIES = 1;
  let response;
  let requestUrl = '';

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
      if (isClaudeModel(model)) {
        requestUrl = `${base}/v1/messages`;
        response = await fetch(requestUrl, {
          signal: controller.signal,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': apiKey,
            'anthropic-version': '2023-06-01',
          },
          body: JSON.stringify({
            model,
            max_tokens: maxTokens,
            messages: [{ role: 'user', content: prompt }],
          }),
        });
      } else {
        const oaiBase = /\/v\d|\/openai/.test(base) ? base : base + '/v1';
        requestUrl = `${oaiBase}/chat/completions`;
        response = await fetch(requestUrl, {
          signal: controller.signal,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            model,
            ...(/^o\d/.test(model)
              ? { max_completion_tokens: maxTokens }
              : { max_tokens: maxTokens }),
            messages: [{ role: 'user', content: prompt }],
          }),
        });
      }
      clearTimeout(timeoutId);
      break; // 请求成功，跳出重试循环
    } catch (e) {
      clearTimeout(timeoutId);
      if (e.name === 'AbortError') {
        if (attempt < MAX_RETRIES) {
          await new Promise(r => setTimeout(r, 3000)); // 等 3s 后重试
          continue;
        }
        throw new Error('API 请求超时（60s），已重试 1 次');
      }
      throw e;
    }
  }

  if (!response.ok) {
    const rawText = await response.text().catch(() => '');
    let msg = response.statusText || '';
    try {
      const err = JSON.parse(rawText);
      msg = err.error?.message || err.message || msg;
    } catch (_) {
      if (rawText) msg = rawText.slice(0, 300);
    }
    throw new Error(`API 错误 ${response.status}: ${msg || '(空)'} [模型:${model} 地址:${requestUrl}]`);
  }

  const data = await response.json();
  if (isClaudeModel(model)) {
    if (!data.content?.[0]?.text) throw new Error(`API 返回格式异常: ${JSON.stringify(data).slice(0, 200)}`);
    return data.content[0].text;
  } else {
    const text = data.choices?.[0]?.message?.content;
    if (text === undefined || text === null) throw new Error(`API 返回格式异常: ${JSON.stringify(data).slice(0, 200)}`);
    return text;
  }
}

// ─── 将结构化筛选条件转为 prompt 文本 ────────────────────────────────────────
function buildCriteriaText(config) {
  const fc = config.filterCriteria || {};
  const hard = [];
  const soft = [];

  const tierMap = { bigtech: 'BAT/字节/美团等互联网大厂', listed: '上市公司', unicorn: '独角兽或知名创业公司', top: '行业头部公司' };
  const eduMap  = { bachelor: '本科及以上', master: '硕士及以上', phd: '博士' };
  const schoolMap = { '985': '985高校', '211': '211及以上高校', top: '双一流高校' };

  if (fc.minExpYears > 0 || fc.maxExpYears > 0) {
    const min = fc.minExpYears > 0 ? `${fc.minExpYears}年以上` : '';
    const max = fc.maxExpYears > 0 ? `${fc.maxExpYears}年以下` : '';
    hard.push(`工作年限：正式工作年限 ${[min, max].filter(Boolean).join('且')}（计算方法：以最高学历毕业年份→2026年；实习不计入；超出范围直接淘汰）`);
  }
  if (fc.minEducation && fc.minEducation !== 'any') {
    hard.push(`最低学历：${eduMap[fc.minEducation]}（低于此学历直接淘汰）`);
  }
  if (fc.school && fc.school !== 'any') {
    hard.push(`院校要求：必须毕业于${schoolMap[fc.school]}（不符合直接淘汰）`);
  }
  if (fc.keywords?.length && fc.keywordsLogic === 'all') {
    hard.push(`技术关键词（必须全部具备）：${fc.keywords.join('、')}（任意一项缺失直接淘汰）`);
  }
  if (fc.gender && fc.gender !== 'any') {
    hard.push(`性别：${fc.gender === 'male' ? '男性' : '女性'}（不符合直接淘汰）`);
  }
  if (fc.minAvgTenure > 0) {
    const t = fc.minAvgTenure >= 1 ? fc.minAvgTenure + '年' : (fc.minAvgTenure * 12) + '个月';
    hard.push(`稳定性：平均每家公司任职时长 ≥ ${t}（低于此值直接淘汰）`);
  }
  if (fc.minLastTenure > 0) {
    const t = fc.minLastTenure >= 1 ? fc.minLastTenure + '年' : (fc.minLastTenure * 12) + '个月';
    hard.push(`近期稳定性：最近一份工作任职时长 ≥ ${t}（低于此值直接淘汰）`);
  }

  if (fc.companyTier && fc.companyTier !== 'any') {
    soft.push(`优先来自${tierMap[fc.companyTier]}的候选人（大幅加分）`);
  }
  if (fc.targetCompanies) {
    soft.push(`来自以下公司大幅加分：${fc.targetCompanies}`);
  }
  if (fc.keywords?.length && fc.keywordsLogic !== 'all') {
    soft.push(`技术关键词（至少满足一项）：${fc.keywords.join('、')}（加分项）`);
  }
  if (fc.notes) soft.push(`补充说明：${fc.notes}`);

  const parts = [];
  if (hard.length) {
    parts.push('【硬性要求 — 不满足则 suitable=false，score≤40，在reason中说明哪项不达标】\n' +
      hard.map((l, i) => `${i + 1}. ${l}`).join('\n'));
  }
  if (soft.length) {
    parts.push('【软性偏好 — 满足则加分，不满足不扣分】\n' +
      soft.map((l, i) => `${i + 1}. ${l}`).join('\n'));
  }
  return parts.length ? parts.join('\n\n') : '无特殊筛选条件，根据岗位要求综合评估。';
}

// ─── 候选人评估 ───────────────────────────────────────────────────────────────
async function evaluateCandidate(candidateInfo, config) {
  const prompt = `你是一位资深猎头顾问，正在为客户寻找适合邀请面试的候选人。请根据岗位要求和筛选条件，综合评估该候选人是否值得主动联系。

## 招聘岗位
岗位名称：${config.jobTitle}
岗位要求：
${config.jobDescription}

筛选条件：
${buildCriteriaText(config)}

## 候选人资料
姓名：${candidateInfo.name || '未知'}
现任职位：${candidateInfo.title || '未知'}
所在公司：${candidateInfo.company || '未知'}
工作经历：${candidateInfo.experience || '（见下方完整资料）'}
教育背景：${candidateInfo.education || '（见下方完整资料）'}
技能标签：${candidateInfo.skills || ''}

候选人资料页完整文本：
---
${(candidateInfo.extra || '').slice(0, 3500)}
---

## 评估流程（必须按顺序执行）

**第一步：硬性要求逐项核查（一票否决）**
筛选条件中标注"硬性要求"的每一项都必须逐一核查：
- 若候选人不满足任意一项硬性要求 → suitable=false，score≤40，reason中说明哪项不达标
- 若简历信息不足以判断某项硬性要求 → 按不满足处理（宁可漏过，不可错放）
- 工作年限计算规则：优先找最高学历的毕业年份，以"毕业年份 → 2026"计算正式工作年限

**第二步：软性偏好评估（加分项）**
- 只有通过第一步的候选人才进行本步骤
- 根据软性偏好和岗位匹配度综合打分（60-100分）

**第三步：综合判断**
- 通过硬性要求 + 综合评分 ≥ 配置阈值 → suitable=true
- 任意硬性要求不满足 → suitable=false

## 请以 JSON 格式输出（不要有其他内容）：
{
  "suitable": true或false,
  "score": 0到100的整数,
  "reason": "按优先级说明匹配或不匹配的核心原因，50字内",
  "highlights": "候选人最突出的1-2个亮点（公司/学历/经验/稳定性），30字内",
  "stability": "稳定/较稳定/一般/频繁跳槽",
  "interviewReason": "邀请面试的个性化理由，结合公司背景或工作经历具体写，40字内，suitable为false时留空"
}`;

  const raw = await callLLM(prompt, config);

  const jsonMatch = raw.match(/```(?:json)?\s*([\s\S]*?)\s*```/) || raw.match(/(\{[\s\S]*\})/);
  if (!jsonMatch) throw new Error('AI 返回格式无法解析');

  const jsonStr = jsonMatch[1];
  try { return JSON.parse(jsonStr); } catch (_) {}

  const getBool = key => {
    const m = jsonStr.match(new RegExp(`"${key}"\\s*:\\s*(true|false)`));
    return m ? m[1] === 'true' : false;
  };
  const getNum = key => {
    const m = jsonStr.match(new RegExp(`"${key}"\\s*:\\s*(\\d+)`));
    return m ? parseInt(m[1]) : 0;
  };
  const getStrBetween = (startKey, endKey) => {
    const re = endKey
      ? new RegExp(`"${startKey}"\\s*:\\s*"([\\s\\S]*?)",\\s*"${endKey}"`)
      : new RegExp(`"${startKey}"\\s*:\\s*"([\\s\\S]*?)"\\s*[,}]`);
    const m = jsonStr.match(re);
    return m ? m[1] : '';
  };

  const suitable = getBool('suitable');
  const score    = getNum('score');
  if (score === 0 && !jsonStr.includes('"score": 0') && !jsonStr.includes('"score":0')) {
    throw new Error(`AI 返回 JSON 解析失败 | 原文: ${jsonStr.slice(0, 150)}`);
  }
  return {
    suitable,
    score,
    reason:          getStrBetween('reason', 'highlights'),
    highlights:      getStrBetween('highlights', 'stability'),
    stability:       getStrBetween('stability', 'interviewReason'),
    interviewReason: getStrBetween('interviewReason', null),
  };
}

// ─── 生成招聘消息 ─────────────────────────────────────────────────────────────
async function generateMessage(candidateInfo, messageTemplate, config, isFriend = true) {
  function fillVars(tpl) {
    const re = (key) => new RegExp('[\\[{｛【]' + key + '[\\]}｝】]', 'g');
    const company = candidateInfo.company || '';
    let result = tpl
      .replace(re('name'), candidateInfo.name || '')
      .replace(re('title'), candidateInfo.title || '')
      .replace(re('company'), company)
      .replace(re('jobTitle'), config.jobTitle || '')
      .replace(re('reason'), candidateInfo.interviewReason || '');
    if (!company) {
      result = result
        .replace(/在\s*的/g, '的')
        .replace(/，您在[的，。！？\s]/g, '，您');
    }
    return result;
  }

  if (!messageTemplate.includes('{ai}')) {
    return fillVars(messageTemplate);
  }

  const templateWithVars = fillVars(messageTemplate);

  const prompt = `你是招聘专员，请根据模板和候选人信息，生成一条自然、真诚的面试邀请消息。
在模板中，{ai} 是你需要创作的个性化内容，请将 {ai} 替换为针对该候选人的个性化邀面理由（${isFriend ? '30-60字' : '15-25字'}），其他部分保持不变。

模板：${templateWithVars}
岗位：${config.jobTitle || ''}
候选人职位：${candidateInfo.title || '未知'}
候选人公司：${candidateInfo.company || '未知'}
${candidateInfo.interviewReason ? `邀面核心理由（请围绕此展开）：${candidateInfo.interviewReason}` : ''}

要求：直接输出最终消息文本，不要说明，不要引号，不要{ai}占位符。`;

  return await callLLM(prompt, config);
}

// ─── AI 聊天回复生成 ──────────────────────────────────────────────────────────
async function generateChatReply(history, candidateName, config) {
  const conv = history.map(m =>
    `${m.isMe ? '我（招聘方）' : candidateName}: ${m.text}`
  ).join('\n');
  const prompt = `你是一位专业热情的招聘专员，正在通过 Boss直聘 和候选人沟通。
目标：真诚回答问题、消除顾虑、强调岗位亮点，引导候选人同意参加面试。
语气：自然、专业，50-120字，不要过于正式，不要AI感。

岗位：${config.jobTitle || '（未设置）'}
岗位要求：${(config.jobDescription || '').slice(0, 500)}

最近对话：
${conv}

直接输出回复文本，不要任何解释：`;
  return await callLLM(prompt, config);
}

// ─── 消息处理 ─────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handleMessage(msg, sender).then(sendResponse).catch(err => {
    addLog('error', err.message);
    sendResponse({ success: false, error: err.message });
  });
  return true;
});

async function handleMessage(msg, sender) {
  switch (msg.type) {

    case 'EVALUATE_CANDIDATE': {
      const mode = getModeForTab(sender?.tab?.id);
      const state = getStateForMode(mode);
      const config = await getConfig(mode);
      const result = await evaluateCandidate(msg.candidateInfo, config);
      const modeTag = mode === 'recruit' ? '[招聘] ' : '';
      addLog('info', `${modeTag}评估 ${msg.candidateInfo.name}：${result.score}分 ${result.suitable ? '✓ 匹配' : '✗ 不匹配'}`, result, mode);
      state.processed++;
      const threshold = config.scoreThreshold || 70;
      if (result.score >= threshold) state.matched++;
      broadcastStatus();
      return { success: true, result };
    }

    case 'GENERATE_MESSAGE': {
      const mode = getModeForTab(sender?.tab?.id);
      const config = await getConfig(mode);
      const template = msg.isFriend ? config.friendMessage : config.addFriendMessage;
      const effectiveTemplate = config.useAIMessage ? template : template.replace(/\{ai\}/g, '').replace(/[ \t]{2,}/g, ' ').trim();
      const text = await generateMessage(msg.candidateInfo, effectiveTemplate, config, msg.isFriend);
      return { success: true, text };
    }

    case 'GENERATE_CHAT_REPLY': {
      const config = await getConfig(getModeForTab(sender?.tab?.id));
      const reply = await generateChatReply(msg.history, msg.candidateName, config);
      return { success: true, reply };
    }

    case 'SET_AUTOMATION_TAB': {
      if (msg.mode === 'recruit') {
        recruitTaskState.automationTabId = msg.tabId;
        recruitTaskState.automationWindowId = msg.windowId || null;
      } else if (msg.mode === 'inbox') {
        inboxTaskState.automationTabId = msg.tabId;
      } else {
        taskState.automationTabId = msg.tabId;
        taskState.automationWindowId = msg.windowId || null;
      }
      return { success: true };
    }

    case 'WATCH_NEW_TAB': {
      // 监听接下来新打开的 Tab，激活它让用户能看到，并在加载完成后提取文本返回
      const originTabId = sender?.tab?.id;
      let resolved = false;

      const sendResumeText = (text, newTabId) => {
        if (originTabId) {
          chrome.tabs.sendMessage(originTabId, { type: 'RESUME_TAB_TEXT', text, newTabId }).catch(() => {});
        }
      };

      const onCreated = (tab) => {
        if (resolved) return;
        resolved = true;
        chrome.tabs.onCreated.removeListener(onCreated);
        // 激活新 Tab，让用户看到简历页面
        chrome.tabs.update(tab.id, { active: true }).catch(() => {});
        // 等页面加载完成后提取文本
        const onUpdated = (tabId, info) => {
          if (tabId !== tab.id || info.status !== 'complete') return;
          chrome.tabs.onUpdated.removeListener(onUpdated);
          chrome.tabs.get(tab.id).then(async (tabInfo) => {
            const tabUrl = tabInfo.url || '';
            // PDF 类型：用 PDF.js 提取文字
            if (/\.pdf(\?|#|$)/i.test(tabUrl) || tabUrl.startsWith('blob:')) {
              try {
                const text = await extractPdfText(tabUrl);
                console.log(`[WATCH_NEW_TAB] PDF提取 ${text.length}字符`);
                sendResumeText(text, tab.id);
              } catch (e) {
                console.warn('[WATCH_NEW_TAB] PDF提取异常:', e.message);
                sendResumeText('', tab.id);
              }
            } else {
              // 普通 HTML 页面：用 executeScript 读 body.innerText
              chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: () => (document.body?.innerText || '').slice(0, 5000),
              }).then(results => {
                const text = results?.[0]?.result || '';
                console.log(`[WATCH_NEW_TAB] HTML提取 ${text.length}字符`);
                sendResumeText(text, tab.id);
              }).catch(() => sendResumeText('', tab.id));
            }
          }).catch(() => sendResumeText('', tab.id));
        };
        chrome.tabs.onUpdated.addListener(onUpdated);
        // 15s 超时关闭监听
        setTimeout(() => chrome.tabs.onUpdated.removeListener(onUpdated), 15000);
      };
      chrome.tabs.onCreated.addListener(onCreated);
      // 10s 内没新 Tab 则取消
      setTimeout(() => {
        if (!resolved) {
          resolved = true;
          chrome.tabs.onCreated.removeListener(onCreated);
        }
      }, 10000);
      return { success: true };
    }

    case 'CLOSE_TAB': {
      if (msg.tabId) {
        chrome.tabs.remove(msg.tabId).catch(() => {});
      }
      return { success: true };
    }

    case 'OPEN_RESUME_TAB': {
      // 用新标签页打开简历 URL，激活后提取文字通知原 tab
      const originTabId = sender?.tab?.id;
      const { url } = msg;
      if (!url || !originTabId) return { success: false };

      (async () => {
        try {
          const tab = await chrome.tabs.create({ url, active: true });
          const onUpdated = (tabId, info) => {
            if (tabId !== tab.id || info.status !== 'complete') return;
            chrome.tabs.onUpdated.removeListener(onUpdated);

            // 用 async executeScript：
            //   1. 优先检测 div.textLayer（Boss PDF.js 阅读器渲染的文字层）
            //      textLayer 是异步填充的，需轮询等待 span 出现
            //   2. 兜底：body.innerText
            chrome.scripting.executeScript({
              target: { tabId: tab.id },
              func: async () => {
                // ── 等待 textLayer span 填充（最多 12 秒）
                const waitForTextLayer = async () => {
                  const deadline = Date.now() + 12000;
                  while (Date.now() < deadline) {
                    const spans = document.querySelectorAll(
                      '.textLayer span[role="presentation"]'
                    );
                    if (spans.length > 5) return Array.from(spans);
                    await new Promise(r => setTimeout(r, 300));
                  }
                  return null;
                };

                // ── 从 spans 按坐标重建可读文字
                const extractFromSpans = (spans) => {
                  const entries = spans.map(span => {
                    const style = span.getAttribute('style') || '';
                    const top  = parseFloat((style.match(/top:\s*([\d.]+)%/)  || [0, 0])[1]);
                    const left = parseFloat((style.match(/left:\s*([\d.]+)%/) || [0, 0])[1]);
                    return { top, left, text: span.textContent || '' };
                  }).filter(e => e.text.trim());

                  // 按 top 排序，再按 left 排序
                  entries.sort((a, b) => Math.abs(a.top - b.top) < 0.8
                    ? a.left - b.left
                    : a.top - b.top);

                  // 按行分组（top 差 < 0.8% 视为同一行）
                  const rows = [];
                  let curRow = [], lastTop = -999;
                  for (const e of entries) {
                    if (Math.abs(e.top - lastTop) > 0.8) {
                      if (curRow.length) rows.push(curRow);
                      curRow = [e]; lastTop = e.top;
                    } else {
                      curRow.push(e);
                    }
                  }
                  if (curRow.length) rows.push(curRow);
                  return rows.map(r => r.map(e => e.text).join(' ')).join('\n');
                };

                // 先尝试 textLayer
                const spans = await waitForTextLayer();
                if (spans) {
                  const text = extractFromSpans(spans).trim().slice(0, 6000);
                  if (text.length > 20) return text;
                }
                // 兜底：body.innerText
                return (document.body?.innerText || '').trim().slice(0, 5000);
              },
            }).then(results => {
              const text = results?.[0]?.result || '';
              console.log(`[OPEN_RESUME_TAB] 提取完成：${text.length} 字符`);
              chrome.tabs.sendMessage(originTabId, {
                type: 'RESUME_TAB_TEXT', text, newTabId: tab.id,
              }).catch(() => {});
            }).catch(() => {
              chrome.tabs.sendMessage(originTabId, {
                type: 'RESUME_TAB_TEXT', text: '', newTabId: tab.id,
              }).catch(() => {});
            });
          };
          chrome.tabs.onUpdated.addListener(onUpdated);
          setTimeout(() => chrome.tabs.onUpdated.removeListener(onUpdated), 20000);
        } catch (e) {
          chrome.tabs.sendMessage(originTabId, {
            type: 'RESUME_TAB_TEXT', text: '', newTabId: null,
          }).catch(() => {});
        }
      })();

      return { success: true };
    }

    case 'NAVIGATE_BACKGROUND': {
      const navTabId = sender?.tab?.id;
      if (navTabId && msg.url) {
        chrome.tabs.update(navTabId, { url: msg.url, active: false }).catch(() => {});
      }
      return { success: true };
    }

    case 'START_TASK': {
      const mode = getModeForTab(sender?.tab?.id);
      const profiles = msg.profiles || [];

      if (mode === 'recruit') {
        const prevActiveId = recruitTaskState.activeProfileId;
        const newProfiles = profiles.length ? profiles : recruitTaskState.jobProfiles;
        const newActiveId = prevActiveId && newProfiles.find(p => p.id === prevActiveId)
          ? prevActiveId : newProfiles[0]?.id || null;
        recruitTaskState = {
          running: true, paused: false,
          processed: 0, matched: 0, messaged: 0, failed: 0,
          currentKeyword: '',
          startTime: Date.now(),
          automationTabId: sender?.tab?.id || recruitTaskState.automationTabId,
          automationWindowId: recruitTaskState.automationWindowId,
          jobProfiles: newProfiles,
          activeProfileId: newActiveId,
        };
        if (profiles.length) {
          const jobNames = profiles.map(p => p.name || p.jobTitle || '未命名').join('、');
          addLog('info', `[招聘] 任务启动，共 ${profiles.length} 个岗位：${jobNames}`, null, 'recruit');
        }
      } else if (mode === 'inbox') {
        const newProfiles = profiles.length ? profiles : inboxTaskState.jobProfiles;
        inboxTaskState = {
          running: true, paused: false,
          processed: 0, matched: 0, messaged: 0, failed: 0,
          startTime: Date.now(),
          automationTabId: sender?.tab?.id || inboxTaskState.automationTabId,
          jobProfiles: newProfiles,
          activeProfileId: newProfiles[0]?.id || null,
        };
        if (profiles.length) {
          const jobNames = profiles.map(p => p.name || p.jobTitle || '未命名').join('、');
          addLog('info', `[收件箱] 任务启动：${jobNames}`, null, 'inbox');
        }
      } else {
        chrome.storage.local.remove('__boss_explicitly_stopped').catch(() => {});
        const startCfg = await getConfig('social');
        const prevActiveId = taskState.activeProfileId;
        const newProfiles = profiles.length ? profiles : taskState.jobProfiles;
        const newActiveId = prevActiveId && newProfiles.find(p => p.id === prevActiveId)
          ? prevActiveId : newProfiles[0]?.id || null;
        taskState = {
          running: true, paused: false,
          processed: 0, matched: 0, messaged: 0, added: 0, failed: 0,
          currentKeyword: '',
          startTime: Date.now(),
          logs: taskState.logs,
          maxCandidates: startCfg.maxCandidates || 30,
          automationTabId: sender?.tab?.id || taskState.automationTabId,
          automationWindowId: taskState.automationWindowId,
          panelWindowId: taskState.panelWindowId,
          jobProfiles: newProfiles,
          activeProfileId: newActiveId,
        };
        if (profiles.length) {
          const jobNames = profiles.map(p => p.name || p.jobTitle || '未命名').join('、');
          addLog('info', `任务启动，共 ${profiles.length} 个岗位：${jobNames}`, null, 'social');
        }
      }
      return { success: true };
    }

    case 'SET_ACTIVE_JOB': {
      const mode = getModeForTab(sender?.tab?.id);
      const state = getStateForMode(mode);
      state.activeProfileId = msg.profileId;
      const profile = state.jobProfiles.find(p => p.id === msg.profileId);
      if (profile) {
        state.currentKeyword = '';
        addLog('info', `🏢 切换到岗位：${profile.name || profile.jobTitle || '未命名'}`, null, mode);
      }
      broadcastStatus();
      return { success: true };
    }

    case 'STOP_TASK': {
      const stopMode = msg.mode || 'social';
      if (stopMode === 'recruit') {
        recruitTaskState.running = false;
        const rs = `共处理 ${recruitTaskState.processed} 人，匹配 ${recruitTaskState.matched} 人，沟通 ${recruitTaskState.messaged}${recruitTaskState.failed ? `，失败 ${recruitTaskState.failed}` : ''}`;
        addLog('info', `[招聘] 任务结束。${rs}`, null, 'recruit');
        if (recruitTaskState.automationTabId) {
          chrome.tabs.sendMessage(recruitTaskState.automationTabId, { type: 'STOP_TASK_CONTENT' }).catch(() => {});
          recruitTaskState.automationTabId = null;
        }
      } else if (stopMode === 'inbox') {
        inboxTaskState.running = false;
        const is = `共处理 ${inboxTaskState.processed} 人，匹配 ${inboxTaskState.matched} 人${inboxTaskState.failed ? `，失败 ${inboxTaskState.failed}` : ''}`;
        addLog('info', `[收件箱] 任务结束。${is}`, null, 'inbox');
        if (inboxTaskState.automationTabId) {
          chrome.tabs.sendMessage(inboxTaskState.automationTabId, { type: 'STOP_TASK_CONTENT' }).catch(() => {});
          inboxTaskState.automationTabId = null;
        }
      } else {
        taskState.running = false;
        chrome.storage.local.set({ __boss_explicitly_stopped: true }).catch(() => {});
        const socialAnyRunning = recruitTaskState.running;
        if (!socialAnyRunning) chrome.storage.local.remove('__boss_live_stats').catch(() => {});
        const stopSummary = `共处理 ${taskState.processed} 人，匹配 ${taskState.matched} 人，发消息 ${taskState.messaged}${taskState.failed ? `，失败 ${taskState.failed}` : ''}`;
        addLog('info', `任务结束。${stopSummary}`, null, 'social');
        if (taskState.processed > 0) {
          chrome.notifications.create('boss-task-done', {
            type: 'basic',
            iconUrl: 'icons/icon48.png',
            title: 'Boss AI 招聘助手',
            message: stopSummary,
          }).catch(() => {});
        }
        if (taskState.automationTabId) {
          const tabToStop = taskState.automationTabId;
          taskState.automationTabId = null;
          chrome.tabs.sendMessage(tabToStop, { type: 'STOP_TASK_CONTENT' }).catch(() => {});
          chrome.tabs.remove(tabToStop).catch(() => {});
        }
        taskState.automationWindowId = null;
      }
      return { success: true };
    }

    case 'PAUSE_TASK': {
      const pauseMode = msg.mode || 'social';
      const pauseState = getStateForMode(pauseMode);
      pauseState.paused = !pauseState.paused;
      const modeTag = pauseMode === 'recruit' ? '[招聘] ' : '';
      addLog('info', `${modeTag}${pauseState.paused ? '任务已暂停' : '任务已恢复'}`, null, pauseMode);
      broadcastStatus();
      if (pauseState.automationTabId) {
        chrome.tabs.sendMessage(pauseState.automationTabId, { type: 'SET_PAUSED', paused: pauseState.paused }).catch(() => {});
      }
      return { success: true, paused: pauseState.paused };
    }

    case 'LOG': {
      const logMode = getModeForTab(sender?.tab?.id);
      addLog(msg.level || 'info', msg.message, msg.data, logMode);
      return { success: true };
    }

    case 'SHOW_NOTIFICATION': {
      chrome.notifications.create({
        type: 'basic',
        iconUrl: chrome.runtime.getURL('icons/icon128.png'),
        title: msg.title || 'Boss AI 招聘助手',
        message: msg.message || '',
        priority: 1,
      });
      return { success: true };
    }

    case 'ACTION_DONE': {
      const actionMode = getModeForTab(sender?.tab?.id);
      const actionState = getStateForMode(actionMode);
      if (msg.action === 'messaged') actionState.messaged++;
      if (msg.action === 'added') actionState.added = (actionState.added || 0) + 1;
      if (msg.action === 'failed') actionState.failed++;
      broadcastStatus();
      return { success: true };
    }

    case 'RESTORE_STATS': {
      const restoreMode = getModeForTab(sender?.tab?.id);
      const restoreState = getStateForMode(restoreMode);

      if (!restoreState.running) {
        if (restoreMode === 'social') {
          const stored = await chrome.storage.local.get(['__boss_explicitly_stopped', 'config']);
          if (stored.__boss_explicitly_stopped) {
            return { success: true, stopped: true };
          }
          const cfg = stored.config || {};
          taskState.running = true;
          taskState.paused = false;
          taskState.startTime = taskState.startTime || Date.now();
          taskState.jobProfiles = cfg.jobProfiles || taskState.jobProfiles;
          taskState.activeProfileId = taskState.activeProfileId || cfg.activeProfileId || null;
          taskState.maxCandidates = taskState.maxCandidates || cfg.maxCandidates || 30;
        } else {
          recruitTaskState.running = true;
          recruitTaskState.paused = false;
          recruitTaskState.startTime = recruitTaskState.startTime || Date.now();
        }
      }
      if (sender?.tab?.id) restoreState.automationTabId = sender.tab.id;
      restoreState.currentKeyword = msg.keyword || restoreState.currentKeyword;
      if (msg.stats) {
        restoreState.processed = msg.stats.processed ?? restoreState.processed;
        restoreState.matched   = msg.stats.matched   ?? restoreState.matched;
        restoreState.messaged  = msg.stats.messaged  ?? restoreState.messaged;
        if (restoreMode === 'social') taskState.added = msg.stats.added ?? taskState.added;
        restoreState.failed    = msg.stats.failed    ?? restoreState.failed;
      }
      if (msg.profileId && restoreState.jobProfiles.length) {
        restoreState.activeProfileId = msg.profileId;
      }
      if (!restoreState.startTime) restoreState.startTime = Date.now();
      broadcastStatus();
      return { success: true, paused: restoreState.paused, activeProfileId: restoreState.activeProfileId };
    }

    case 'GET_STATUS': {
      const social = {
        running: taskState.running,
        paused: taskState.paused,
        processed: taskState.processed,
        matched: taskState.matched,
        messaged: taskState.messaged,
        added: taskState.added,
        failed: taskState.failed,
        currentKeyword: taskState.currentKeyword,
        activeProfileId: taskState.activeProfileId,
      };
      const recruit = {
        running: recruitTaskState.running,
        paused: recruitTaskState.paused,
        processed: recruitTaskState.processed,
        matched: recruitTaskState.matched,
        messaged: recruitTaskState.messaged,
        failed: recruitTaskState.failed,
        currentKeyword: recruitTaskState.currentKeyword,
        activeProfileId: recruitTaskState.activeProfileId,
      };
      const inbox = {
        running: inboxTaskState.running,
        paused: inboxTaskState.paused,
        processed: inboxTaskState.processed,
        matched: inboxTaskState.matched,
        messaged: inboxTaskState.messaged,
        failed: inboxTaskState.failed,
        activeProfileId: inboxTaskState.activeProfileId,
      };
      let statusResult = { social, recruit, inbox, recentLogs: taskState.logs.slice(0, 50) };
      if (!taskState.running && !recruitTaskState.running) {
        const stored = await chrome.storage.local.get(['__boss_live_stats', '__boss_explicitly_stopped']);
        const live = stored.__boss_live_stats;
        if (!stored.__boss_explicitly_stopped && (live?.social?.running || live?.recruit?.running)
            && Date.now() - (live?.savedAt || 0) < 5 * 60 * 1000) {
          statusResult = { ...statusResult, social: live.social || social, recruit: live.recruit || recruit };
        }
      }
      return { success: true, status: statusResult };
    }

    case 'TEST_API': {
      const config = await getConfig();
      const model = config.claudeModel || 'claude-sonnet-4-6';
      try {
        await callLLM('hi', { ...config, claudeMaxTokens: 5 });
        return { success: true, model, message: `✅ Key 有效，模型：${model}` };
      } catch (e) {
        const base = (config.claudeApiBase || 'https://api.anthropic.com').replace(/\/$/, '');
        const key  = config.claudeApiKey;
        if (isClaudeModel(model)) {
          try {
            const resp = await fetch(`${base}/v1/messages`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` },
              body: JSON.stringify({ model, max_tokens: 5, messages: [{ role: 'user', content: 'hi' }] }),
            });
            if (resp.ok) return { success: true, model, message: `✅ Key 有效，模型：${model}` };
            const body = await resp.text();
            return { success: false, error: `${resp.status}: ${body.slice(0, 200)}` };
          } catch (e2) {
            return { success: false, error: e2.message };
          }
        }
        return { success: false, error: e.message };
      }
    }

    case 'SAVE_MATCHED_CANDIDATE': {
      const { candidate } = msg;
      if (!candidate) return { success: false };
      const savedMode = getModeForTab(sender?.tab?.id);
      const candidateWithMode = { ...candidate, sourceMode: savedMode };
      const stored = await chrome.storage.local.get('matchedCandidates');
      const list = stored.matchedCandidates || [];
      if (candidateWithMode.profileUrl) {
        const cutoff = Date.now() - 5 * 60 * 1000;
        const dup = list.some(c => c.profileUrl === candidateWithMode.profileUrl && c.timestamp >= cutoff);
        if (dup) return { success: true, duplicate: true };
      }
      list.push(candidateWithMode);
      await chrome.storage.local.set({ matchedCandidates: list });
      return { success: true };
    }

    case 'GET_MATCHED_CANDIDATES': {
      const stored = await chrome.storage.local.get('matchedCandidates');
      return { candidates: stored.matchedCandidates || [] };
    }

    case 'CLEAR_MATCHED_CANDIDATES': {
      await chrome.storage.local.set({ matchedCandidates: [] });
      return { success: true };
    }

    case 'DOWNLOAD_RESUME': {
      const { url, filename } = msg;
      if (!url) return { success: false, error: 'no url' };
      try {
        const dlId = await chrome.downloads.download({
          url,
          filename: filename || 'resume.pdf',
          saveAs: false,
          conflictAction: 'uniquify',
        });
        return { success: true, dlId };
      } catch (e) {
        return { success: false, error: e.message };
      }
    }

    case 'OPEN_POPUP': {
      const popupUrl = chrome.runtime.getURL('popup.html');
      const wins = await chrome.windows.getAll({ populate: true });
      for (const w of wins) {
        const tab = w.tabs?.find(t => t.url?.startsWith(popupUrl));
        if (tab) {
          await chrome.windows.update(w.id, { focused: true });
          taskState.panelWindowId = w.id;
          return { success: true };
        }
      }
      const panelW = 400, panelH = 560;
      let left, top;
      try {
        const cur = await chrome.windows.getLastFocused();
        left = cur.left + cur.width  - panelW - 16;
        top  = cur.top  + cur.height - panelH - 80;
      } catch (_) {
        left = 900; top = 300;
      }
      const newWin = await chrome.windows.create({
        url: popupUrl + '?panel=1',
        type: 'popup',
        left: Math.max(0, left),
        top:  Math.max(0, top),
        width: panelW,
        height: panelH,
        focused: true,
      });
      taskState.panelWindowId = newWin?.id ?? null;
      return { success: true };
    }

    case 'GET_CONFIG': {
      const config = await getConfig();
      return { success: true, config };
    }

    case 'SAVE_CONFIG': {
      await chrome.storage.local.set({ config: msg.config });
      addLog('info', '配置已保存');
      return { success: true };
    }

    case 'IS_RUNNING': {
      return {
        success: true,
        social: { running: taskState.running, paused: taskState.paused },
        recruit: { running: recruitTaskState.running, paused: recruitTaskState.paused },
        running: taskState.running || recruitTaskState.running,
        paused: taskState.paused,
      };
    }

    // ── 简历筛选 ──────────────────────────────────────────────────────────────
    case 'EVALUATE_RESUME': {
      const cfg = await getConfig();
      const result = await evaluateResume(msg.resumeText, cfg);
      return { success: true, result };
    }

    case 'GET_RESUME_RESULTS': {
      const { resumeResults = [] } = await chrome.storage.local.get('resumeResults');
      return { success: true, results: resumeResults };
    }

    case 'SAVE_RESUME_RESULTS': {
      await chrome.storage.local.set({ resumeResults: msg.results });
      return { success: true };
    }

    default:
      return { success: false, error: `未知消息类型: ${msg.type}` };
  }
}

// ─── 简历评估（AI筛选Tab专用）────────────────────────────────────────────────
async function evaluateResume(resumeText, config) {
  const fc = config.filterCriteria || {};

  // ── 构建筛选条件描述 ──────────────────────────────────────────────────────
  const hard = [];  // 硬性条件（不符合则 suitable: false）
  const soft = [];  // 软性偏好（影响评分）

  const eduMap = { bachelor: '本科及以上', master: '硕士及以上', phd: '博士' };
  if (fc.minEducation && fc.minEducation !== 'any')
    hard.push(`学历：${eduMap[fc.minEducation]}`);

  if (fc.minExpYears > 0 || fc.maxExpYears > 0) {
    const min = fc.minExpYears > 0 ? `${fc.minExpYears}年以上` : '';
    const max = fc.maxExpYears > 0 ? `${fc.maxExpYears}年以下` : '';
    hard.push(`工作年限：${(min && max) ? `${fc.minExpYears}～${fc.maxExpYears}年` : (min || max)}`);
  }

  if (fc.keywords && fc.keywords.length > 0) {
    const logic = fc.keywordsLogic === 'all' ? '以下技术关键词必须全部出现' : '以下技术关键词至少满足一个';
    hard.push(`${logic}：${fc.keywords.join('、')}`);
  }

  if (fc.gender && fc.gender !== 'any')
    hard.push(`性别：${fc.gender === 'male' ? '男' : '女'}`);

  const schoolMap = { '985': '985院校', '211': '211及以上', top: '双一流' };
  if (fc.school && fc.school !== 'any')
    soft.push(`院校：${schoolMap[fc.school]}（不满足扣10分）`);

  const tierMap = { bigtech: '大厂（BAT/字节等）', listed: '上市公司', unicorn: '独角兽/知名创业', top: '行业头部' };
  if (fc.companyTier && fc.companyTier !== 'any')
    soft.push(`公司类型偏好：${tierMap[fc.companyTier]}（不满足扣5~10分）`);

  if (fc.targetCompanies)
    soft.push(`目标公司加分项：${fc.targetCompanies}（有经历额外加5分）`);

  if (fc.minAvgTenure > 0)
    soft.push(`平均任职时长：${fc.minAvgTenure}年以上（不满足扣5分）`);

  if (fc.minLastTenure > 0)
    soft.push(`最近工作时长：${fc.minLastTenure}年以上（不满足扣5分）`);

  if (fc.notes)
    soft.push(`补充说明：${fc.notes}`);

  let filterSection = '';
  if (hard.length || soft.length) {
    filterSection = '\n【候选人筛选条件】\n';
    if (hard.length) filterSection +=
      `硬性要求（任意一条不满足则 suitable: false，分数上限55）：\n${hard.map(l => '• ' + l).join('\n')}\n`;
    if (soft.length) filterSection +=
      `软性偏好（影响评分）：\n${soft.map(l => '• ' + l).join('\n')}\n`;
  }

  const prompt = `你是一位专业HR助理，请根据岗位要求和筛选条件，全面评估候选人简历是否适合邀请面试。

【岗位名称】
${config.jobTitle || '（未填写）'}

【岗位职责与任职要求】
${config.jobDescription || '（未填写，请根据岗位名称做合理评估）'}
${filterSection}
【候选人简历】
${resumeText.slice(0, 4000)}

评分说明：
1. 先依据「岗位职责与任职要求」对技能、经验、背景进行匹配评分（0-100）
2. 逐一核查所有「硬性要求」，任意一条不满足：suitable 置为 false，分数上限 55
3. 再按「软性偏好」逐项调整分数
4. 综合得出最终 score 和 suitable

请严格以 JSON 格式回复，不要有任何其他文字：
{
  "name": "候选人姓名（从简历提取，无法提取填'未知'）",
  "score": 0到100的整数,
  "suitable": true或false,
  "reason": "评估核心理由（含筛选条件核查结论），80字以内",
  "highlights": "主要亮点1-2条，30字以内",
  "weaknesses": "主要不足1-2条，30字以内，无明显不足填'暂无'",
  "interviewReason": "建议面试的个性化理由，40字以内；不推荐时留空"
}`;

  const raw = await callLLM(prompt, config);
  const jsonMatch = raw.match(/```(?:json)?\s*([\s\S]*?)\s*```/) || raw.match(/(\{[\s\S]*\})/);
  if (!jsonMatch) throw new Error('AI 返回格式无法解析');
  try {
    return JSON.parse(jsonMatch[1]);
  } catch (_) {
    const s = jsonMatch[1];
    const get = k => { const m = s.match(new RegExp(`"${k}"\\s*:\\s*"([^"]*?)"`)); return m ? m[1] : ''; };
    const getNum = k => { const m = s.match(new RegExp(`"${k}"\\s*:\\s*(\\d+)`)); return m ? parseInt(m[1], 10) : 50; };
    const getBool = k => { const m = s.match(new RegExp(`"${k}"\\s*:\\s*(true|false)`)); return m ? m[1] === 'true' : false; };
    return { name: get('name') || '未知', score: getNum('score'), suitable: getBool('suitable'),
      reason: get('reason'), highlights: get('highlights'), weaknesses: get('weaknesses'), interviewReason: get('interviewReason') };
  }
}

// ─── 获取配置 ─────────────────────────────────────────────────────────────────
async function getConfig(mode = null) {
  let { config = {} } = await chrome.storage.local.get('config');

  if (!config.claudeApiKey && !config.jobProfiles && !config.jobDescription) {
    try {
      const { config: syncCfg = {} } = await chrome.storage.sync.get('config');
      if (syncCfg.claudeApiKey || syncCfg.jobDescription) {
        config = syncCfg;
        await chrome.storage.local.set({ config });
      }
    } catch (_) {}
  }

  const base = {
    ...DEFAULT_CONFIG,
    ...config,
    selectors: { ...DEFAULT_CONFIG.selectors, ...(config.selectors || {}) },
    humanBehavior: { ...DEFAULT_CONFIG.humanBehavior, ...(config.humanBehavior || {}) },
    filterCriteria: { ...DEFAULT_CONFIG.filterCriteria, ...(config.filterCriteria || {}) },
  };

  const state = mode === 'recruit' ? recruitTaskState
              : mode === 'inbox'   ? inboxTaskState
              :                      taskState;
  if (state.activeProfileId && state.jobProfiles.length) {
    const profile = state.jobProfiles.find(p => p.id === state.activeProfileId);
    if (profile) {
      return {
        ...base,
        jobTitle:        profile.jobTitle        || base.jobTitle,
        jobDescription:  profile.jobDescription  || base.jobDescription,
        scoreThreshold:  profile.scoreThreshold  ?? base.scoreThreshold,
        friendMessage:   profile.friendMessage   || base.friendMessage,
        addFriendMessage: profile.addFriendMessage || base.addFriendMessage,
        useAIMessage:    profile.useAiMsg        ?? base.useAIMessage,
        filterCriteria: {
          ...base.filterCriteria,
          ...(profile.filterCriteria || {}),
        },
      };
    }
  }

  return base;
}

// ─── 窗口管理 ─────────────────────────────────────────────────────────────────
chrome.windows.onRemoved.addListener((windowId) => {
  if (taskState.panelWindowId && windowId === taskState.panelWindowId) {
    taskState.panelWindowId = null;
    if (taskState.running && taskState.automationTabId) {
      chrome.tabs.sendMessage(taskState.automationTabId, { type: 'SHOW_OVERLAY' }).catch(() => {});
    }
  }
});

// ─── 兜底：任务运行时自动关闭 Boss 产生的新标签 ─────────────────────────────
chrome.tabs.onCreated.addListener(async (newTab) => {
  if (!taskState.running && !recruitTaskState.running) return;
  await new Promise(r => setTimeout(r, 200));
  const tab = await chrome.tabs.get(newTab.id).catch(() => null);
  if (!tab) return;

  const url = tab.pendingUrl || tab.url || '';
  if (!url || !url.includes('zhipin.com')) return;

  if (tab.openerTabId) {
    chrome.tabs.sendMessage(tab.openerTabId, { type: 'NAVIGATE_TO', url }).catch(() => {});
    await chrome.tabs.remove(newTab.id).catch(() => {});
    return;
  }

  const autoTabId = taskState.automationTabId || recruitTaskState.automationTabId;
  if (autoTabId && newTab.id !== autoTabId) {
    const autoTab = await chrome.tabs.get(autoTabId).catch(() => null);
    if (autoTab && tab.windowId === autoTab.windowId) {
      chrome.tabs.sendMessage(autoTabId, { type: 'NAVIGATE_TO', url }).catch(() => {});
      await chrome.tabs.remove(newTab.id).catch(() => {});
    }
  }
});

// ─── 点击扩展图标：打开/聚焦操作台标签页 ────────────────────────────────────
chrome.action.onClicked.addListener(async () => {
  const panelUrl = chrome.runtime.getURL('popup.html') + '?standalone=1';
  const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL('popup.html') + '*' });
  if (tabs.length > 0) {
    const t = tabs[0];
    await chrome.windows.update(t.windowId, { focused: true }).catch(() => {});
    await chrome.tabs.update(t.id, { active: true });
  } else {
    chrome.tabs.create({ url: panelUrl });
  }
});

// ─── 扩展安装时写入默认配置 ───────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  if (reason === 'install') {
    const { config } = await chrome.storage.local.get('config');
    if (!config) {
      await chrome.storage.local.set({ config: DEFAULT_CONFIG });
    }
  }
});
