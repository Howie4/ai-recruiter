/**
 * window-override.js — 在页面 MAIN world 执行（扩展脚本，不受 CSP 限制）
 * 拦截 window.open：将 Boss 站内链接改为当前标签导航，彻底消灭新标签堆积
 */
(function () {
  if (window.__bossIntercepted) return;
  window.__bossIntercepted = true;

  const _open = window.open.bind(window);
  window.open = function (url, target, features) {
    // 只在招聘助主动运行时才拦截站内链接；否则恢复 Boss 原生行为（正常开新标签）
    if (sessionStorage.getItem('__boss_recruiter_active')) {
      const urlStr = String(url || '');
      // 拦截：绝对 URL 含 zhipin.com，或以 /chat / /im/ 开头的相对 URL
      if (urlStr.match(/zhipin\.com/) || /^\/(chat|im\/)/.test(urlStr) || /\.(pdf|doc|docx)/i.test(urlStr)) {
        try {
          // 用 localStorage（跨 iframe 共享），content script 在主文档读取
          localStorage.setItem('__boss_intercepted_url', urlStr);
        } catch (e) {}
        return null;
      }
    }
    return _open(url, target, features);
  };

  // 屏蔽 window/document.focus()：Boss 页面脚本会在加载时主动调 window.focus() 把窗口拉到前台。
  // 必须始终屏蔽，不做 sessionStorage 检查——因为 content.js 要到 document_idle 才能设置
  // __boss_recruiter_active，而 Boss JS 早在 document_start 之后就开始运行了，存在时序漏洞。
  window.focus   = function () { /* no-op：防止 Boss JS 抢焦点 */ };
  window.blur    = function () { /* no-op */ };
  document.focus = function () { /* no-op：防止 document 级别的焦点调用 */ };

  // 屏蔽元素级别的 focus()
  const _origElementFocus = HTMLElement.prototype.focus;
  HTMLElement.prototype.focus = function (opts) {
    if (sessionStorage.getItem('__boss_recruiter_active')) {
      return; // 自动化期间：禁止任何页面元素请求焦点
    }
    return _origElementFocus.call(this, opts);
  };

  // 屏蔽 visibilitychange / focus / blur 事件驱动的焦点抢占
  const _addEL = EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener = function (type, fn, opts) {
    if (type === 'focus' && this === window) return; // 禁止 Boss 给 window 注册 focus 监听
    return _addEL.call(this, type, fn, opts);
  };

  // 自动确认 window.alert() / confirm() / prompt()：弹出任何对话框都会阻塞流程并抢焦点。
  const _alert   = window.alert.bind(window);
  const _confirm = window.confirm.bind(window);
  const _prompt  = window.prompt.bind(window);
  window.alert = function (msg) {
    if (sessionStorage.getItem('__boss_recruiter_active')) {
      console.log('[Boss助手] 自动确认 alert:', String(msg).slice(0, 100));
      return;
    }
    return _alert(msg);
  };
  window.confirm = function (msg) {
    if (sessionStorage.getItem('__boss_recruiter_active')) {
      console.log('[Boss助手] 自动确认 confirm:', String(msg || '').slice(0, 100));
      return true; // 相当于点「确定」
    }
    return _confirm(msg);
  };
  window.prompt = function (msg, def) {
    if (sessionStorage.getItem('__boss_recruiter_active')) {
      console.log('[Boss助手] 自动关闭 prompt:', String(msg || '').slice(0, 100));
      return null; // 相当于点「取消」
    }
    return _prompt(msg, def);
  };

  // 拦截 visibilitychange：自动化窗口导航时页面短暂变为 hidden 再 visible
  document.addEventListener('visibilitychange', function (e) {
    if (sessionStorage.getItem('__boss_recruiter_active')) {
      e.stopImmediatePropagation();
    }
  }, true /* capture */);

  // 屏蔽 window.resizeTo / resizeBy / moveTo / moveBy
  ['resizeTo', 'resizeBy', 'moveTo', 'moveBy'].forEach(fn => {
    const _orig = window[fn]?.bind(window);
    if (!_orig) return;
    window[fn] = function (...args) {
      if (sessionStorage.getItem('__boss_recruiter_active')) return;
      return _orig(...args);
    };
  });

  // rAF 不再降级：降级会导致 Vue.js 组件（如下拉框）渲染异常
})();
