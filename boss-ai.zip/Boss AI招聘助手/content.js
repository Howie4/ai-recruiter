/**
 * content.js — Boss AI 招聘助手页面自动化核心
 *
 * 推荐牛人模式流程：
 *   Step 1: 点击「推荐牛人」进入推荐页
 *   Step 2: 在岗位下拉框中搜索并选中目标岗位
 *   Step 3: 遍历推荐候选人列表，逐一读取资料
 *   Step 4: AI 评估匹配度（EVALUATE_CANDIDATE → background.js）
 *   Step 5: 匹配 → 点击「打招呼」按钮（点击即发送，无弹窗）
 */

const _isInIframe = window.self !== window.top;

if (window.__bossRecruiterLoaded) {
  chrome.runtime.sendMessage({ type: 'LOG', level: 'info', message: `[Boss助手] content.js 已加载（${_isInIframe ? 'iframe' : '主文档'}），跳过重复注入` }).catch(() => {});
} else {
  window.__bossRecruiterLoaded = true;
  chrome.runtime.sendMessage({
    type: 'LOG', level: 'info',
    message: `[Boss助手] 初始化 | URL: ${location.href.slice(0, 80)} | 框架: ${_isInIframe ? 'iframe' : '主文档'}`
  }).catch(() => {});
  initBossRecruiter();
}

function initBossRecruiter() {

  // ─── 右下角胶囊按钮（仅主文档注入，iframe 内跳过） ───────────────────────────
  if (!_isInIframe) (function injectCapsule() {
    if (document.getElementById('__boss_capsule__')) return;

    // 外层容器（胶囊 + ✖ 组合）
    const wrap = document.createElement('div');
    wrap.id = '__boss_capsule__';
    wrap.style.cssText = [
      'position:fixed', 'bottom:24px', 'right:24px', 'z-index:2147483646',
      'display:flex', 'align-items:center', 'gap:6px',
      'font-family:sans-serif', 'user-select:none',
    ].join(';');

    // 主胶囊按钮
    const btn = document.createElement('div');
    btn.textContent = '🤖 招聘助';
    btn.style.cssText = [
      'background:linear-gradient(135deg,#00D9C5,#00A898)',
      'color:#fff', 'font-size:13px', 'font-weight:600',
      'padding:9px 18px', 'border-radius:999px',
      'box-shadow:0 4px 16px rgba(0,217,197,0.4)',
      'cursor:pointer',
      'transition:transform 0.15s,box-shadow 0.15s',
      'letter-spacing:0.3px',
    ].join(';');
    btn.addEventListener('mouseenter', () => {
      btn.style.transform = 'scale(1.06)';
      btn.style.boxShadow = '0 6px 22px rgba(0,217,197,0.5)';
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.transform = '';
      btn.style.boxShadow = '0 4px 16px rgba(0,217,197,0.4)';
    });
    btn.addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'OPEN_POPUP' }).catch(() => {});
    });

    // ✖ 关闭按钮
    const closeBtn = document.createElement('div');
    closeBtn.textContent = '✕';
    closeBtn.title = '关闭';
    closeBtn.style.cssText = [
      'width:20px', 'height:20px', 'border-radius:50%',
      'background:rgba(0,0,0,0.35)', 'color:#fff',
      'font-size:11px', 'line-height:20px', 'text-align:center',
      'cursor:pointer', 'flex-shrink:0',
      'transition:background 0.15s',
    ].join(';');
    closeBtn.addEventListener('mouseenter', () => { closeBtn.style.background = 'rgba(0,0,0,0.6)'; });
    closeBtn.addEventListener('mouseleave', () => { closeBtn.style.background = 'rgba(0,0,0,0.35)'; });
    let dismissed = false;
    let wasHiddenByStatus = false;

    closeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      dismissed = true;
      wrap.style.display = 'none';
    });

    wrap.appendChild(btn);
    wrap.appendChild(closeBtn);
    document.body.appendChild(wrap);

    // 有状态提示框时隐藏胶囊；状态框消失时自动恢复（除非用户主动关闭过）
    function isStatusVisible(el) { return el && el.style.display !== 'none'; }
    setInterval(() => {
      const iDoc = getIframeDoc();
      const hasStatus = !!(
        isStatusVisible(iDoc && iDoc.querySelector('#__boss_status__'))
        || isStatusVisible(document.getElementById('__boss_search_status__'))
        || isStatusVisible(document.getElementById('__boss_inbox_status__'))
      );
      if (hasStatus) {
        wrap.style.display = 'none';
        wasHiddenByStatus = true;
      } else if (wasHiddenByStatus && !dismissed) {
        // 状态框刚消失（任务结束），自动恢复胶囊
        wrap.style.display = '';
        wasHiddenByStatus = false;
      }
    }, 500);
  })();

  // ─── 全局状态 ─────────────────────────────────────────────────────────────
  let _taskRunning = false;
  let _taskPaused  = false;
  let _taskStopped = false;
  let _curProfiles = [];
  let _stats = { processed: 0, matched: 0, messaged: 0, failed: 0 };

  // ─── 15天去重：持久化已处理候选人 ─────────────────────────────────────────
  const SEEN_TTL_MS = 15 * 24 * 60 * 60 * 1000;  // 15天
  const SEEN_KEY    = '__boss_seen_uid';
  const SEEN_TS_KEY = '__boss_seen_uid_ts';

  async function loadSeenMap() {
    const data = await chrome.storage.local.get([SEEN_KEY, SEEN_TS_KEY]).catch(() => ({}));
    const arr = data[SEEN_KEY] || [];
    const ts  = data[SEEN_TS_KEY] || {};
    const cutoff = Date.now() - SEEN_TTL_MS;
    // 过期清理
    const validArr = arr.filter(id => ts[id] && ts[id] > cutoff);
    if (validArr.length !== arr.length) {
      const validTs = {};
      validArr.forEach(id => { validTs[id] = ts[id]; });
      chrome.storage.local.set({ [SEEN_KEY]: validArr, [SEEN_TS_KEY]: validTs }).catch(() => {});
    }
    return { arr: validArr, ts };
  }

  async function isSeenRecently(uid) {
    if (!uid) return false;
    const { arr, ts } = await loadSeenMap();
    const cutoff = Date.now() - SEEN_TTL_MS;
    return arr.includes(uid) && ts[uid] && ts[uid] > cutoff;
  }

  async function markSeen(uid) {
    if (!uid) return;
    const { arr, ts } = await loadSeenMap();
    if (!arr.includes(uid)) arr.push(uid);
    ts[uid] = Date.now();
    chrome.storage.local.set({ [SEEN_KEY]: arr, [SEEN_TS_KEY]: ts }).catch(() => {});
  }

  // 用户主动关闭状态框的标记（任务结束时自动重置）
  let _statusHiddenByUser = false;
  let _searchStatusHiddenByUser = false;
  let _inboxStatusHiddenByUser = false;

  // ─── 基础工具 ─────────────────────────────────────────────────────────────
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const rand  = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

  function log(msg, level = 'info') {
    console.log(`[Boss助手] ${msg}`);
    chrome.runtime.sendMessage({ type: 'LOG', level, message: msg }).catch(() => {});
  }
  function logErr(msg) { log(msg, 'error'); }
  function logWarn(msg) { log(msg, 'warn'); }

  /** 模拟完整鼠标点击（mouseenter→mouseover→mousedown→mouseup→click），兼容 Vue 事件 */
  function realClick(el) {
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top  + rect.height / 2;
    const opts = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy };
    ['mouseenter', 'mouseover', 'mousedown', 'mouseup', 'click'].forEach(type =>
      el.dispatchEvent(new MouseEvent(type, opts))
    );
    // 补充原生 click()：对 <a> 标签和 Vue @click 绑定的元素更可靠
    try { el.click(); } catch (_) {}
  }

  /**
   * 升级版点击：与脉脉助手同款 hoverThenClick
   * 关键改进：
   *   1. elementFromPoint —— 找坐标处真正的顶层元素（穿透 Vue 覆盖层/透明蒙层）
   *   2. PointerEvent (pointerdown/up) —— Vue3 / 现代框架依赖 Pointer 事件触发合成事件
   *   3. mousedown → 40ms延迟 → mouseup —— 模拟真实按压时长，触发依赖时序的监听器
   *   4. topEl ≠ el 时对原始 el 补发 click —— 兼容 onclick 直接绑定在叶子节点的场景
   */
  async function hoverThenClick(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    const cx = Math.round(rect.left + rect.width / 2);
    const cy = Math.round(rect.top  + rect.height / 2);
    const evInit = (extra = {}) => ({
      bubbles: true, cancelable: true, view: window,
      clientX: cx, clientY: cy, screenX: cx, screenY: cy,
      ...extra,
    });
    el.dispatchEvent(new MouseEvent('mouseover',  evInit()));
    el.dispatchEvent(new MouseEvent('mouseenter', evInit()));
    // 找坐标处真正最顶层元素（穿透透明覆盖层，确保 React/Vue 事件委托能捕获到）
    const topEl = (cx >= 0 && cy >= 0 && cx < window.innerWidth && cy < window.innerHeight)
      ? (document.elementFromPoint(cx, cy) || el)
      : el;
    topEl.dispatchEvent(new PointerEvent('pointerdown', { ...evInit(), isPrimary: true }));
    topEl.dispatchEvent(new MouseEvent('mousedown',      evInit({ buttons: 1 })));
    await sleep(40 + Math.random() * 40);
    topEl.dispatchEvent(new PointerEvent('pointerup',   { ...evInit(), isPrimary: true }));
    topEl.dispatchEvent(new MouseEvent('mouseup',        evInit({ buttons: 0 })));
    topEl.dispatchEvent(new MouseEvent('click',          evInit()));
    // 如果顶层元素不是原始元素，再对原始元素补发一次 click
    if (topEl !== el) {
      el.dispatchEvent(new MouseEvent('click', evInit()));
    }
    try { el.click(); } catch (_) {}
    return true;
  }

  /**
   * 高亮闪光后点击 —— 让用户能看到自动化正在操作哪个元素
   * @param {Element} el        要点击的元素
   * @param {number}  pauseMs   高亮停留时长（ms），默认 600
   * @param {boolean} useHover  true=用 hoverThenClick（穿透覆盖层），false=用 realClick
   */
  async function flashClick(el, pauseMs = 600, useHover = false) {
    if (!el) return;
    // 滚动到视野内，模拟真人目光移动
    el.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
    await sleep(200);
    // 保存原始样式
    const prev = {
      outline:    el.style.outline,
      background: el.style.background,
      boxShadow:  el.style.boxShadow,
      transition: el.style.transition,
    };
    // 高亮：青色边框 + 浅色背景 + 发光，让用户看清即将点击的位置
    el.style.transition  = 'all 0.15s';
    el.style.outline     = '2px solid #00D9C5';
    el.style.background  = 'rgba(0,217,197,0.18)';
    el.style.boxShadow   = '0 0 8px rgba(0,217,197,0.6)';
    await sleep(pauseMs);
    // 点击：附件简历等关键按钮用升级版，普通按钮用 realClick
    if (useHover) {
      await hoverThenClick(el);
    } else {
      realClick(el);
    }
    // 还原样式
    await sleep(150);
    el.style.outline    = prev.outline;
    el.style.background = prev.background;
    el.style.boxShadow  = prev.boxShadow;
    el.style.transition = prev.transition;
  }

  /** 按文字精确匹配元素 */
  function findByText(text, selector = '*', root = document) {
    for (const el of root.querySelectorAll(selector)) {
      if (el.textContent.trim() === text) return el;
    }
    return null;
  }

  /** 等待元素出现 */
  async function waitForEl(selector, timeoutMs = 8000, root = document) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      const el = root.querySelector(selector);
      if (el) return el;
      await sleep(200);
    }
    return null;
  }

  /** 等待文字元素出现 */
  async function waitForText(text, selector = '*', timeoutMs = 8000, root = document) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      const el = findByText(text, selector, root);
      if (el) return el;
      await sleep(200);
    }
    return null;
  }

  /** 模拟人工输入（逐字） */
  async function humanType(el, text) {
    el.focus();
    el.value = '';
    el.dispatchEvent(new Event('input', { bubbles: true }));
    for (const ch of text) {
      el.value += ch;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(rand(60, 160));
    }
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  /** 模拟人工输入（contenteditable div） */
  async function humanTypeContentEditable(el, text) {
    el.focus();
    el.textContent = '';
    el.dispatchEvent(new Event('input', { bubbles: true }));
    for (const ch of text) {
      document.execCommand('insertText', false, ch);
      await sleep(rand(60, 160));
    }
  }

  /** 检查暂停/停止，返回 true = 已停止 */
  async function checkPauseStop() {
    while (_taskPaused && !_taskStopped) await sleep(400);
    return _taskStopped;
  }

  // ─── 消息监听 ─────────────────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    switch (msg.type) {
      case 'PING':
        sendResponse({ loaded: true });
        return true;

      case 'RUN_TASK':
        if (_isInIframe) { sendResponse({ skipped: true }); return true; }
        _curProfiles = msg.profiles || [];
        runSocialTask().catch(e => logErr(`任务异常: ${e.message}`));
        sendResponse({ success: true });
        return true;

      case 'RUN_RECRUIT_TASK':
        _curProfiles = msg.profiles || [];
        if (_isInIframe) {
          // iframe 中：等待本框架的搜索 UI 出现后再运行（若本 iframe 无搜索 UI 则静默跳过）
          (async () => {
            const t0 = Date.now();
            while (Date.now() - t0 < 5000) {
              if (document.querySelector(SEARCH_INDICATOR)) {
                log(`[iframe] 检测到搜索 UI，在 iframe 中运行搜索任务（URL: ${location.href.slice(0, 60)}）`);
                runRecruitTask().catch(e => logErr(`招聘任务异常(iframe): ${e.message}`));
                return;
              }
              await sleep(300);
            }
            // 本 iframe 无搜索 UI，静默跳过
          })();
        } else {
          runRecruitTask().catch(e => logErr(`招聘任务异常: ${e.message}`));
        }
        sendResponse({ success: true });
        return true;

      case 'RUN_INBOX_TASK':
        if (_isInIframe) { sendResponse({ skipped: true }); return true; }
        _curProfiles = msg.profiles || [];
        runInboxTask().catch(e => logErr(`收件箱任务异常: ${e.message}`));
        sendResponse({ success: true });
        return true;

      case 'STOP_TASK_CONTENT':
        _taskStopped = true;
        _taskRunning = false;
        sessionStorage.removeItem('__boss_recruiter_active');
        log('任务已停止');
        sendResponse({ success: true });
        return true;

      case 'SET_PAUSED':
        _taskPaused = !!msg.paused;
        sendResponse({ success: true });
        return true;
    }
  });

  // ═══════════════════════════════════════════════════════════════════════════
  //  推荐牛人模式（👥 Boss搜索）
  // ═══════════════════════════════════════════════════════════════════════════

  async function runSocialTask() {
    if (_taskRunning) return;
    _taskRunning = true;
    _taskStopped = false;
    _taskPaused  = false;
    sessionStorage.setItem('__boss_recruiter_active', '1');

    await chrome.runtime.sendMessage({ type: 'START_TASK', profiles: _curProfiles }).catch(() => {});

    const JOB_DURATION_MS  = 40 * 60 * 1000;   // 每个岗位最多运行 40 分钟
    const WORK_DURATION_MS = 120 * 60 * 1000;  // 连续工作 120 分钟后休息
    const REST_DURATION_MS = 10 * 60 * 1000;   // 休息 10 分钟

    let jobIndex    = 0;
    let workStart   = Date.now();

    while (!_taskStopped && _curProfiles.length > 0) {
      const profile = _curProfiles[jobIndex % _curProfiles.length];
      await chrome.runtime.sendMessage({ type: 'SET_ACTIVE_JOB', profileId: profile.id }).catch(() => {});
      log(`开始处理岗位：${profile.jobTitle || profile.name}（第 ${Math.floor(jobIndex / _curProfiles.length) + 1} 轮）`);

      const jobDeadline = Date.now() + JOB_DURATION_MS;
      await runRecommendLoop(profile, jobDeadline);
      if (_taskStopped) break;

      jobIndex++;

      // 连续工作超过 120 分钟，自动休息 10 分钟
      if (Date.now() - workStart >= WORK_DURATION_MS) {
        log('已连续工作 2 小时，自动休息 10 分钟...');
        const iDoc = getIframeDoc();
        const restEnd = Date.now() + REST_DURATION_MS;
        const restInterval = setInterval(() => {
          const left = Math.ceil((restEnd - Date.now()) / 60000);
          try { showStatus(iDoc || document, '☕ 自动休息', `已连续工作 2 小时，休息中…还剩 ${left} 分钟`); } catch (_) {}
        }, 30000);
        showStatus(iDoc || document, '☕ 自动休息', `已连续工作 2 小时，休息 10 分钟后自动继续`);
        await sleep(REST_DURATION_MS);
        clearInterval(restInterval);
        workStart = Date.now();
      }
    }

    sessionStorage.removeItem('__boss_recruiter_active');
    _taskRunning = false;
    log('任务已停止');
  }

  /** 推荐牛人模式主循环 */
  async function runRecommendLoop(profile, deadline = Infinity) {

    // ── Step 1: 点击「推荐牛人」──────────────────────────────────────────────
    log('Step 1: 点击「推荐牛人」');
    const recommendBtn = await clickRecommendTab();
    if (!recommendBtn) {
      logErr('找不到「推荐牛人」按钮，中止本岗位');
      return;
    }
    await sleep(rand(1500, 2500));
    if (await checkPauseStop()) return;

    // ── Step 2: 选择目标岗位 ─────────────────────────────────────────────────
    log(`Step 2: 选择岗位「${profile.jobTitle || profile.name}」`);
    const jobSelected = await selectJobInDropdown(profile.jobTitle || profile.name);
    if (!jobSelected) {
      logErr(`未能选中岗位，中止本岗位`);
      return;
    }
    await sleep(rand(1200, 2000));
    if (await checkPauseStop()) return;

    // ── Step 3~5: 遍历候选人，AI评估，打招呼 ─────────────────────────────────
    log('Step 3: 开始遍历推荐候选人');
    await processRecommendCandidates(profile, deadline);
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Step 1: 点击「推荐牛人」
  // ─────────────────────────────────────────────────────────────────────────
  async function clickRecommendTab() {
    let btn = findByText('推荐牛人', 'span');
    if (!btn) btn = await waitForText('推荐牛人', 'span', 5000);
    if (!btn) { logErr('找不到「推荐牛人」span'); return null; }
    log('点击「推荐牛人」');
    realClick(btn);
    return btn;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Step 2: 岗位选择下拉
  // ─────────────────────────────────────────────────────────────────────────
  /** 查找岗位下拉的搜索框 */
  function findJobSearchInput() {
    return document.querySelector('input.ipt.chat-job-search')
      || document.querySelector('input[placeholder="请输入职位名称"]')
      || document.querySelector('[class*="chat-job-search"]')
      || document.querySelector('.top-chat-search input')
      || document.querySelector('[class*="dropmenu"] input[placeholder]')
      || document.querySelector('[class*="drop"] input[placeholder]');
  }

  /** 获取岗位下拉触发器（在 iframe 内） */
  function findDropLabel(iDoc) {
    const doc = iDoc || getIframeDoc() || document;
    const wrap = doc.querySelector('.job-selecter-wrap');
    if (wrap) return wrap.querySelector('.ui-dropmenu-label') || wrap;
    return null;
  }

  /** 查找岗位下拉的搜索框（在 iframe 内 .top-chat-search） */
  function findJobSearchInput(iDoc) {
    const doc = iDoc || getIframeDoc() || document;
    return doc.querySelector('.top-chat-search input') || null;
  }

  async function selectJobInDropdown(jobTitle) {
    if (!jobTitle) { logErr('岗位名为空'); return false; }

    // 等 iframe 加载好再操作
    let iDoc = getIframeDoc();
    if (!iDoc) {
      const t0 = Date.now();
      while (Date.now() - t0 < 8000) {
        iDoc = getIframeDoc();
        if (iDoc && iDoc.querySelector('.job-selecter-wrap')) break;
        await sleep(300);
      }
    }
    if (!iDoc) { logErr('iframe 未加载'); return false; }

    // ── 前置检查：当前是否已显示目标岗位 ─────────────────────────────────────
    let dropLabel = findDropLabel(iDoc);
    if (!dropLabel) {
      // 再等 5s
      const t0 = Date.now();
      while (Date.now() - t0 < 5000) {
        dropLabel = findDropLabel(iDoc);
        if (dropLabel) break;
        await sleep(300);
      }
    }
    if (!dropLabel) { logErr('找不到岗位选择器（.job-selecter-wrap）'); return false; }

    const currentText = dropLabel.textContent.trim();
    const key = jobKey(jobTitle);
    if (currentText.replace(/\s/g, '').includes(key)) {
      log(`当前岗位已是「${currentText.slice(0, 30)}」，无需切换`);
      return true;
    }

    // ── 点击展开下拉 ──────────────────────────────────────────────────────────
    log(`展开岗位选择框（当前：${currentText.slice(0, 20)}）`);
    realClick(dropLabel);
    await sleep(rand(1000, 1500));

    // ── 等待 job-list 出现 ────────────────────────────────────────────────────
    let jobList = null;
    const t1 = Date.now();
    while (Date.now() - t1 < 5000) {
      jobList = iDoc.querySelector('ul.job-list');
      if (jobList) break;
      await sleep(300);
    }
    if (!jobList) { logErr('岗位列表（ul.job-list）未出现'); return false; }

    // ── 若有搜索框，先搜索缩小范围 ────────────────────────────────────────────
    const searchInput = findJobSearchInput(iDoc);
    if (searchInput) {
      log(`输入搜索关键词：「${jobTitle.slice(0, 8)}」`);
      await humanType(searchInput, jobTitle.slice(0, 8));
      await sleep(rand(600, 1000));
    }

    // ── 从 ul.job-list li 中选目标岗位 ───────────────────────────────────────
    return await pickJobOption(iDoc, jobTitle);
  }

  async function pickJobOption(iDoc, jobTitle) {
    await sleep(400);
    const key = jobKey(jobTitle);
    const jobList = iDoc.querySelector('ul.job-list');

    if (jobList) {
      const items = [...jobList.querySelectorAll('li')].filter(
        li => li.offsetParent !== null && !li.textContent.includes('调整顺序')
      );
      log(`ul.job-list 共 ${items.length} 个可见选项`);

      const exact = items.find(li => li.textContent.replace(/\s/g, '').includes(key));
      if (exact) {
        log(`选中岗位：「${exact.textContent.trim().slice(0, 40)}」`);
        realClick(exact);
        return true;
      }
      if (items.length) {
        log(`未精确匹配「${key}」，选第一个：「${items[0].textContent.trim().slice(0, 40)}」`);
        realClick(items[0]);
        return true;
      }
    }

    logErr('未找到 ul.job-list 或列表为空');
    return false;
  }

  /** 岗位名匹配：去空格后全串，回退时取前8字 */
  function jobKey(jobTitle) {
    return jobTitle.replace(/\s/g, '');
  }

  /** 计算岗位名匹配得分（越高越好）— 用于选最近似选项 */
  function jobMatchScore(candidate, target) {
    const c = candidate.replace(/\s/g, '');
    const t = target.replace(/\s/g, '');
    if (c === t) return 100;
    if (c.includes(t) || t.includes(c)) return 80;
    // 按字符逐段匹配：计算最长公共子串
    let score = 0;
    for (let len = t.length; len >= 2; len--) {
      for (let i = 0; i <= t.length - len; i++) {
        if (c.includes(t.slice(i, i + len))) { score = Math.max(score, len); break; }
      }
    }
    return score;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Step 3~5: 遍历候选人、AI评估、打招呼
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * 获取推荐牛人 iframe 的 document（候选人列表在 iframe 里）
   */
  function getIframeDoc() {
    const iframe = document.querySelector('iframe[name="recommendFrame"]');
    return iframe?.contentDocument || iframe?.contentWindow?.document || null;
  }

  /**
   * 获取当前 iframe 内所有推荐候选人的「打招呼」按钮，
   * 并从每个按钮向上找到对应的候选人卡片容器。
   */
  function getRecommendCards() {
    const iDoc = getIframeDoc();
    if (!iDoc) return [];
    const greetBtns = [...iDoc.querySelectorAll('button.btn.btn-greet')];
    if (!greetBtns.length) return [];

    return greetBtns.map(btn => {
      let card = btn;
      for (let i = 0; i < 8; i++) {
        card = card.parentElement;
        if (!card) break;
        if (card.querySelector('.name-wrap') || card.querySelector('span.name')) break;
      }
      return { card: card || btn.parentElement, greetBtn: btn };
    }).filter(x => x.card);
  }

  /**
   * 从候选人卡片中提取资料信息
   * 只读取有效 section（geek-base-info / geek-expect / geek-work / geek-education），
   * 「牛人分析器」及以下内容忽略。
   */
  function extractCandidateInfo(card) {
    // 姓名
    const name = card.querySelector('span.name')?.textContent.trim() || '未知';
    // 活跃状态
    const activeText = card.querySelector('span.active-text')?.textContent.trim() || '';

    // ── 从 resume-detail-wrap 内的有效 section 拼装文本 ──────────────────────
    const USEFUL_SECTIONS = [
      '.geek-base-info-wrap',
      '.geek-expect-wrap',
      '.geek-work-experience-wrap',
      '.geek-education-experience-wrap',
    ];

    const detailWrap = card.querySelector('.resume-detail-wrap') || card;
    const sectionTexts = [];

    for (const sel of USEFUL_SECTIONS) {
      const sec = detailWrap.querySelector(sel);
      if (sec) sectionTexts.push(sec.innerText || sec.textContent || '');
    }

    // 如果没找到 detail-wrap 结构，退回整个卡片文本（截断到牛人分析器之前）
    let extra = sectionTexts.length
      ? sectionTexts.join('\n')
      : (card.innerText || card.textContent || '');

    // 去掉「牛人分析器」之后的内容
    const cutIdx = extra.indexOf('牛人分析器');
    if (cutIdx > -1) extra = extra.slice(0, cutIdx);

    // ── 结构化字段（从 extra 中补充，供日志使用）─────────────────────────────
    const lines = extra.split('\n').map(s => s.trim()).filter(Boolean);
    const title   = card.querySelector('.geek-expect-wrap [class*="expect-job"]')
                 ?.textContent.trim() || lines[1] || '';
    const company = card.querySelector('.geek-work-experience-wrap [class*="company"]')
                 ?.textContent.trim() || '';
    const experience = card.querySelector('.geek-expect-wrap [class*="exp"], [class*="year"]')
                    ?.textContent.trim() || '';
    const education  = card.querySelector('.geek-education-experience-wrap [class*="school"]')
                    ?.textContent.trim() || '';
    const skills = [...card.querySelectorAll('.geek-base-info-wrap [class*="tag"], .geek-base-info-wrap [class*="skill"]')]
                   .map(e => e.textContent.trim()).filter(Boolean).join('、');

    return { name, activeText, title, company, experience, education, skills, extra };
  }

  /**
   * 获取候选人列表项（iframe 内）
   * 返回包含 span.name 的卡片元素数组
   */
  function getCandidateListItems(iDoc) {
    // 优先用已知 class
    const byCard = [...iDoc.querySelectorAll('[class*="candidate-card-wrap"], [class*="geek-item"]')];
    if (byCard.length) return byCard;
    // 兜底：找 span.name 的祖先（包含 btn-greet 的最近容器）
    const seen = new Set();
    const items = [];
    iDoc.querySelectorAll('span.name').forEach(nameEl => {
      let el = nameEl;
      for (let i = 0; i < 8; i++) {
        el = el.parentElement;
        if (!el) break;
        if (el.querySelector('button.btn.btn-greet')) { if (!seen.has(el)) { seen.add(el); items.push(el); } break; }
      }
    });
    return items;
  }

  /**
   * 等待详情面板出现（iframe 内）
   * 判断依据：有 button.btn-v2.btn-sure-v2.btn-greet 或 .resume-detail-wrap
   */
  async function waitForDetailPanel(iDoc, timeoutMs = 8000) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      const el = iDoc.querySelector(
        'button.btn-v2.btn-sure-v2.btn-greet, .resume-detail-wrap, .resume-item-detail, .resume-layout-wrap'
      );
      if (el) return true;
      await sleep(300);
    }
    return false;
  }

  /**
   * 等待详情面板关闭（回到列表页）
   * 判断依据：button.btn-v2.btn-sure-v2.btn-greet 消失 且 列表按钮重新可见
   */
  async function waitForListReturn(iDoc, timeoutMs = 6000) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      const inDetail = iDoc.querySelector('button.btn-v2.btn-sure-v2.btn-greet');
      const inList   = iDoc.querySelector('button.btn.btn-greet');
      if (!inDetail && inList) return;
      await sleep(300);
    }
  }

  // ─── 视觉指示器 ───────────────────────────────────────────────────────────

  /** 获取（或创建）固定在页面右下角的状态浮窗 */
  function getStatusOverlay(iDoc) {
    let el = iDoc.querySelector('#__boss_status__');
    if (!el) {
      el = iDoc.createElement('div');
      el.id = '__boss_status__';
      el.style.cssText = [
        'position:fixed', 'bottom:20px', 'right:20px', 'z-index:2147483647',
        'background:rgba(18,24,35,0.92)', 'color:#fff',
        'padding:12px 16px', 'border-radius:10px',
        'font-size:13px', 'line-height:1.7', 'min-width:220px',
        'box-shadow:0 4px 16px rgba(0,0,0,0.4)',
        'cursor:pointer', 'font-family:sans-serif',
        'transition:box-shadow 0.15s',
      ].join(';');
      el.title = '点击打开操作台';
      el.addEventListener('mouseenter', () => {
        el.style.boxShadow = '0 6px 24px rgba(0,0,0,0.55)';
      });
      el.addEventListener('mouseleave', () => {
        el.style.boxShadow = '0 4px 16px rgba(0,0,0,0.4)';
      });
      el.addEventListener('click', () => {
        chrome.runtime.sendMessage({ type: 'OPEN_POPUP' }).catch(() => {});
      });
      // ✖ 关闭按钮
      const closeBtn = iDoc.createElement('div');
      closeBtn.title = '关闭';
      closeBtn.textContent = '✕';
      closeBtn.style.cssText = [
        'position:absolute', 'top:6px', 'right:8px',
        'width:18px', 'height:18px', 'line-height:18px', 'text-align:center',
        'border-radius:50%', 'background:rgba(255,255,255,0.18)', 'color:#ccc',
        'font-size:11px', 'cursor:pointer', 'z-index:1', 'flex-shrink:0',
        'transition:background 0.15s',
      ].join(';');
      closeBtn.addEventListener('mouseenter', () => { closeBtn.style.background = 'rgba(255,255,255,0.35)'; });
      closeBtn.addEventListener('mouseleave', () => { closeBtn.style.background = 'rgba(255,255,255,0.18)'; });
      closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        el.style.display = 'none';
        _statusHiddenByUser = true;
      });
      el.appendChild(closeBtn);
      // 内容容器（避免 innerHTML 覆盖 ✖ 按钮）
      const content = iDoc.createElement('div');
      content.id = '__boss_status__content';
      el.appendChild(content);
      iDoc.body.appendChild(el);
    }
    return el;
  }

  function showStatus(iDoc, name, step, extra = '') {
    try {
      if (_statusHiddenByUser) return;
      const el = getStatusOverlay(iDoc);
      el.style.display = '';
      const content = el.querySelector('#__boss_status__content') || el;
      content.innerHTML =
        `<div style="font-weight:700;margin-bottom:4px;color:#00D9C5">🤖 Boss AI招聘助手</div>` +
        `<div>👤 <b>${name}</b></div>` +
        `<div>📋 ${step}</div>` +
        (extra ? `<div style="color:#bbb;font-size:12px;margin-top:2px">${extra}</div>` : '');
    } catch (_) {}
  }

  function hideStatus(iDoc) {
    try { iDoc.querySelector('#__boss_status__')?.remove(); } catch (_) {}
    _statusHiddenByUser = false;
  }

  /** 高亮当前处理的候选人卡片，并滚动到视野中央 */
  function highlightCard(card, iDoc) {
    try {
      iDoc.querySelectorAll('[data-boss-highlight]').forEach(el => {
        el.style.outline = '';
        el.style.boxShadow = '';
        delete el.dataset.bossHighlight;
      });
      if (card) {
        card.dataset.bossHighlight = '1';
        card.style.outline = '2px solid #4fc3f7';
        card.style.boxShadow = '0 0 0 4px rgba(79,195,247,0.18)';
        card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    } catch (_) {}
  }

  /**
   * 主循环：遍历所有推荐候选人
   * 流程：高亮候选人 → 点名字打开详情 → 读资料 → AI评估 → 匹配打招呼 / 不匹配点✖ → 回列表 → 继续
   */
  async function processRecommendCandidates(profile, deadline = Infinity) {
    let processedOnPage = 0;

    // 等待 iframe 加载
    log('等待推荐牛人 iframe 加载...');
    let iDoc = null;
    const t0 = Date.now();
    while (Date.now() - t0 < 12000) {
      iDoc = getIframeDoc();
      if (iDoc && iDoc.querySelector('button.btn.btn-greet, span.name')) break;
      await sleep(400);
    }
    if (!iDoc) { logErr('iframe 未加载'); return; }
    log('iframe 已加载，开始处理候选人');

    const processedNames = new Set();

    while (!_taskStopped) {
      if (await checkPauseStop()) return;

      // 当前岗位已到 40 分钟，切换下一岗位
      if (Date.now() >= deadline) {
        log(`岗位「${profile.jobTitle || profile.name}」已运行 40 分钟，切换下一岗位`);
        const left = Math.max(0, Math.round((deadline - Date.now()) / 60000));
        showStatus(iDoc, profile.jobTitle || profile.name, `⏱ 本岗位时间到，切换下一岗位`);
        await sleep(1500);
        break;
      }

      // 找下一个未处理的候选人
      const items = getCandidateListItems(iDoc);
      const item = items.find(el =>
        !el.dataset.bossProcessed &&
        el.querySelector('span.name')?.textContent.trim()
      );

      if (!item) {
        const loaded = await scrollLoadMore();
        if (!loaded) break;
        continue;
      }

      // 标记 + 记录姓名
      item.dataset.bossProcessed = '1';
      const nameEl = item.querySelector('span.name');
      const candidateName = nameEl?.textContent.trim() || '未知';

      if (processedNames.has(candidateName)) continue;
      processedNames.add(candidateName);

      // 从列表卡片中预取资料页链接（点开详情后再二次确认）
      let profileUrl = extractProfileUrl(item, iDoc);

      // ── 15天去重：已处理过的候选人直接跳过 ─────────────────────────────
      const seenUid = profileUrl || candidateName;
      if (await isSeenRecently(seenUid)) {
        log(`${candidateName} 15天内已处理，跳过`);
        showStatus(iDoc, candidateName, '⏭ 15天内已处理，跳过');
        await sleep(400);
        continue;
      }

      // ── 高亮卡片，滚动到视野 ────────────────────────────────────────────
      highlightCard(item, iDoc);
      showStatus(iDoc, candidateName, '正在查看资料...');
      await sleep(rand(600, 1000));  // 模拟人工停顿后再点击

      // ── Step 3: 点开详情面板 ──────────────────────────────────────────
      log(`查看详情：${candidateName}`);
      realClick(nameEl || item);
      showStatus(iDoc, candidateName, '⏳ 加载详情中...');
      const opened = await waitForDetailPanel(iDoc, 8000);
      if (!opened) {
        logWarn(`${candidateName} 详情面板未打开，跳过`);
        showStatus(iDoc, candidateName, '⚠️ 详情未加载，已跳过');
        await sleep(1000);
        continue;
      }
      await sleep(rand(1000, 1800));  // 模拟人工阅读停顿

      if (await checkPauseStop()) { await closeDetailPanel(iDoc); hideStatus(iDoc); return; }

      // ── Step 3b: 提取详情资料 ─────────────────────────────────────────
      showStatus(iDoc, candidateName, '📖 读取简历...');
      const detailEl = iDoc.querySelector('.resume-detail-wrap, .resume-item-detail, .resume-layout-wrap') || item;
      // 详情面板打开后二次确认资料链接（链接可能在详情面板里更完整）
      if (!profileUrl && detailEl) profileUrl = extractProfileUrl(detailEl, iDoc);
      const info = extractCandidateInfo(detailEl);
      info.name = candidateName;  // 列表里的名字最准确，直接覆盖
      log(`读取资料：${info.name}（${info.title || ''}${info.company ? ' @ ' + info.company : ''}）`);
      _stats.processed++;
      await sleep(rand(800, 1400));  // 模拟阅读时间

      if (await checkPauseStop()) { await closeDetailPanel(iDoc); hideStatus(iDoc); return; }

      // ── Step 4: AI 评估 ────────────────────────────────────────────────
      log(`AI评估：${info.name}`);
      showStatus(iDoc, candidateName, '🤖 AI评估中...', '正在分析匹配度');
      let evalResult = null;
      try {
        const resp = await chrome.runtime.sendMessage({
          type: 'EVALUATE_CANDIDATE',
          candidateInfo: {
            name:       info.name,
            title:      info.title,
            company:    info.company,
            experience: info.experience,
            education:  info.education,
            skills:     info.skills,
            extra:      info.extra.slice(0, 3000),
          },
        });
        evalResult = resp?.result;
      } catch (e) {
        logErr(`AI评估失败：${e.message}`);
      }

      if (!evalResult) {
        logWarn(`${info.name} 评估失败，关闭详情`);
        showStatus(iDoc, candidateName, '❌ 评估失败，跳过');
        _stats.failed++;
        await chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'failed' }).catch(() => {});
        await sleep(600);
        await closeDetailPanel(iDoc);
        await sleep(rand(400, 700));
        continue;
      }

      const { score, suitable, reason } = evalResult;
      log(`评估结果：${info.name} ${score}分 ${suitable ? '✓ 匹配' : '✗ 不匹配'} — ${reason}`);
      const isMatch = suitable && Number(score) >= (profile.scoreThreshold ?? 70);

      if (!isMatch) {
        // ── 不匹配：停留片刻 → 点✖关闭资料页 ────────────────────────────
        showStatus(iDoc, candidateName, `✗ 不匹配（${score}分）`, reason?.slice(0, 40));
        await sleep(rand(600, 1000));
        log(`不匹配，关闭详情：${info.name}`);
        await markSeen(seenUid);
        await closeDetailPanel(iDoc);
        // 确认已回到列表（有候选人名字卡片）再继续
        await waitForListCards(iDoc);
        await sleep(rand(300, 600));
        continue;
      }

      // ── 匹配！ ────────────────────────────────────────────────────────
      showStatus(iDoc, candidateName, `✅ 匹配（${score}分）`, '即将打招呼');
      _stats.matched++;

      await sleep(rand(600, 1200));
      if (await checkPauseStop()) { await closeDetailPanel(iDoc); hideStatus(iDoc); return; }

      // ── Step 5: 点详情页「打招呼」────────────────────────────────────
      showStatus(iDoc, candidateName, '👋 正在打招呼...');
      log(`打招呼：${info.name}`);
      const greetBtn = iDoc.querySelector('button.btn-v2.btn-sure-v2.btn-greet')
                    || iDoc.querySelector('.resumeGreet button');
      if (greetBtn) {
        realClick(greetBtn);
        log(`✓ 已向 ${info.name} 打招呼`);
        showStatus(iDoc, candidateName, `✅ 已打招呼（${score}分）`);
        // 打招呼成功后再存记录，action 设为 'added'（显示为「💬已打招呼」）
        // 最后一次尝试取资料 URL（此时详情面板还在，DOM 最完整）
        if (!profileUrl) profileUrl = extractProfileUrl(iDoc.querySelector('.resume-detail-wrap, .resume-item-detail, .resume-layout-wrap'), iDoc);
        if (!profileUrl) profileUrl = extractProfileUrl(iDoc.body, iDoc);
        log(`资料链接：${profileUrl || '未找到'}`);
        _stats.messaged++;
        await chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'messaged' }).catch(() => {});
        await chrome.runtime.sendMessage({
          type: 'SAVE_MATCHED_CANDIDATE',
          candidate: {
            name:            candidateName,
            title:           info.title || '',
            company:         info.company || '',
            experience:      info.experience || '',
            education:       info.education || '',
            skills:          info.skills || '',
            score,
            reason,
            highlights:      evalResult.highlights || '',
            stability:       evalResult.stability || '',
            interviewReason: evalResult.interviewReason || '',
            action:          'added',
            timestamp:       Date.now(),
            jobName:         profile.name || profile.jobTitle,
          },
        }).catch(() => {});
        await markSeen(seenUid);
        await closeChatPopup();
        await closeDetailPanel(iDoc);
        await waitForListCards(iDoc);
        await sleep(rand(400, 800));
      } else {
        logWarn(`未找到打招呼按钮，关闭详情`);
        showStatus(iDoc, candidateName, '⚠️ 未找到打招呼按钮');
        _stats.failed++;
        await chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'failed' }).catch(() => {});
        await closeDetailPanel(iDoc);
        await sleep(rand(400, 700));
      }

      processedOnPage++;
      const delay = rand(2500, 4500);
      log(`等待 ${(delay / 1000).toFixed(1)}s 后继续...`);
      showStatus(iDoc, candidateName, `⏸ 冷却 ${(delay / 1000).toFixed(1)}s...`);
      await sleep(delay);
    }

    hideStatus(iDoc);
    highlightCard(null, iDoc);
    log(`本岗位处理完成：共处理 ${processedOnPage} 人`);
  }

  /**
   * 关闭打招呼后弹出的聊天窗口
   * 弹窗可能在主页面或 iframe，两处都检查
   */
  async function closeChatPopup() {
    const iDoc = getIframeDoc();
    const SELECTOR = 'div.iboss.iboss-close, .chat-global-outer-wrap .iboss-close, [class*="iboss-close"]';
    const t0 = Date.now();
    while (Date.now() - t0 < 5000) {
      const btn = document.querySelector(SELECTOR)
               || (iDoc && iDoc.querySelector(SELECTOR));
      if (btn) {
        realClick(btn);
        log('已关闭聊天弹窗');
        await sleep(rand(400, 700));
        return;
      }
      await sleep(200);
    }
    // 弹窗可能已自动关闭，不影响流程
  }

  /**
   * 从候选人详情面板中提取 Boss直聘 资料页链接
   * 优先级：<a href> → encrypt-geek-id 属性 → iframe URL geekId 参数
   */
  function extractProfileUrl(el, iDoc) {
    const BASE = 'https://www.zhipin.com';

    // 1. 元素内找 <a href> 含候选人资料路径
    for (const a of (el?.querySelectorAll('a[href]') || [])) {
      const href = a.href || a.getAttribute('href') || '';
      if (/\/(geek|resume|candidate)\//i.test(href)
          || /[?&](geekId|encryptGeekId|uid)=/.test(href)) {
        return href.startsWith('http') ? href : BASE + href;
      }
    }

    // 2. 找 encrypt-geek-id 属性（详情面板 DOM 里存在）
    //    先在当前元素找，再扫整个 iDoc
    const findEncId = (root) => {
      if (!root) return null;
      // 直接有属性的
      const direct = root.querySelector('[encrypt-geek-id]');
      if (direct) return direct.getAttribute('encrypt-geek-id');
      // 元素本身有
      if (root.getAttribute?.('encrypt-geek-id')) return root.getAttribute('encrypt-geek-id');
      return null;
    };

    const encId = findEncId(el) || findEncId(iDoc);
    if (encId) {
      // Boss直聘 HR 查看候选人资料的 URL 格式
      return `${BASE}/web/geek/resume.html?encryptGeekId=${encodeURIComponent(encId)}`;
    }

    // 3. iframe 的 src 属性或当前 URL 里有 geekId
    const iframe = document.querySelector('iframe[name="recommendFrame"]');
    for (const src of [iframe?.src, iDoc?.defaultView?.location?.href].filter(Boolean)) {
      const m = src.match(/[?&#](geekId|encryptGeekId|uid)=([^&]+)/);
      if (m) return `${BASE}/web/geek/resume.html?encryptGeekId=${encodeURIComponent(m[2])}`;
    }

    return '';
  }

  /**
   * 等候选人列表卡片重新可见（确认已回到列表页）
   */
  async function waitForListCards(iDoc, timeoutMs = 4000) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      const hasCards = iDoc.querySelector('span.name') &&
                       !iDoc.querySelector('button.btn-v2.btn-sure-v2.btn-greet');
      if (hasCards) return;
      await sleep(200);
    }
  }

  /**
   * 关闭候选人详情面板（点 i.icon-close）
   * 带重试，最多等 6 秒
   */
  async function closeDetailPanel(iDoc) {
    const t0 = Date.now();
    while (Date.now() - t0 < 6000) {
      // 检查详情面板是否还在（有打招呼按钮 = 还在详情页）
      const stillOpen = iDoc.querySelector(
        'button.btn-v2.btn-sure-v2.btn-greet, i.icon-close, .resume-layout-wrap, .resume-item-detail'
      );
      if (!stillOpen) return;  // 已自动关闭

      const closeBtn = iDoc.querySelector('i.icon-close');
      if (closeBtn) {
        realClick(closeBtn.parentElement || closeBtn);
        await sleep(600);
        // 验证是否已关
        const gone = !iDoc.querySelector('button.btn-v2.btn-sure-v2.btn-greet');
        if (gone) return;
      }
      await sleep(300);
    }
    logWarn('详情面板关闭超时');
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  滚动加载更多候选人
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * 滚动到底部触发懒加载，等待新候选人出现。
   * @returns {boolean} true = 有新候选人出现，false = 已到底
   */
  async function scrollLoadMore() {
    const iDoc = getIframeDoc();
    if (!iDoc) { log('找不到 iframe，停止滚动'); return false; }

    const beforeCount = iDoc.querySelectorAll('button.btn.btn-greet').length;
    log(`滚动加载更多（当前已有 ${beforeCount} 个候选人）...`);

    // 优先滚动 iframe 内的列表容器，兜底滚动 iframe body
    const listContainer = iDoc.querySelector(
      '[class*="recommend-list"], [class*="candidate-list"], [class*="geek-list"], .recommend-wrap, #container'
    );
    if (listContainer) {
      listContainer.scrollTop = listContainer.scrollHeight;
    } else {
      iDoc.documentElement.scrollTop = iDoc.documentElement.scrollHeight;
    }

    // 等待新内容加载（最多 6 秒）
    const t0 = Date.now();
    while (Date.now() - t0 < 6000) {
      await sleep(500);
      const nowCount = iDoc.querySelectorAll('button.btn.btn-greet').length;
      if (nowCount > beforeCount) {
        log(`✓ 加载到 ${nowCount - beforeCount} 个新候选人`);
        await sleep(rand(800, 1200));
        return true;
      }
    }

    log('滚动后无新候选人，已到底');
    return false;
  }


  // ═══════════════════════════════════════════════════════════════════════════
  //  招聘搜索模式（🏢 Boss招聘搜索，待实现）
  // ═══════════════════════════════════════════════════════════════════════════

  // ═══════════════════════════════════════════════════════════════════════════
  //  搜索模式（🔍 搜索）
  // ═══════════════════════════════════════════════════════════════════════════

  async function runRecruitTask() {
    if (_taskRunning) return;
    _taskRunning = true;
    _taskStopped = false;
    _taskPaused  = false;
    sessionStorage.setItem('__boss_recruiter_active', '1');
    await chrome.runtime.sendMessage({ type: 'START_TASK', profiles: _curProfiles }).catch(() => {});

    for (let pi = 0; pi < _curProfiles.length; pi++) {
      if (_taskStopped) break;
      const profile = _curProfiles[pi];
      await chrome.runtime.sendMessage({ type: 'SET_ACTIVE_JOB', profileId: profile.id }).catch(() => {});
      log(`搜索模式 - 开始处理岗位：${profile.name || profile.jobTitle}`);
      await runSearchLoop(profile);
      if (_taskStopped) break;
    }

    sessionStorage.removeItem('__boss_recruiter_active');
    _taskRunning = false;
    log('所有岗位处理完毕');
  }

  async function runSearchLoop(profile) {
    const jobTitle = profile.jobTitle || profile.name;

    // ── Step 1: 确认在搜索页（popup 已导航，这里做二次确认） ────────────────
    showSearchStatus('🔍 搜索模式', '⏳ 等待搜索页加载...');
    log('Step 1: 等待搜索页加载...');
    const pageReady = await waitForSearchPage();
    if (!pageReady) {
      showSearchStatus('❌ 出错', '搜索页未加载，请确认页面已打开');
      await sleep(3000); hideSearchStatus();
      logErr('搜索页未正常加载，中止'); return;
    }
    log('搜索页已就绪');
    if (await checkPauseStop()) { hideSearchStatus(); return; }

    // ── Step 3: 选择在招岗位 ─────────────────────────────────────────────────
    if (jobTitle) {
      showSearchStatus('🔍 搜索模式', `📋 选择岗位「${jobTitle}」`);
      log(`Step 3: 选择在招岗位「${jobTitle}」`);
      await selectSearchModeJob(jobTitle);
      await sleep(rand(1000, 1800));
      if (await checkPauseStop()) { hideSearchStatus(); return; }
    }

    // ── Step 4: 逐关键词组搜索并处理候选人 ──────────────────────────────────
    const kwGroups = parseKeywordGroups(profile.keywords);
    if (kwGroups.length === 0) {
      log('未配置搜索关键词，处理当前搜索结果');
      showSearchStatus('🔍 搜索模式', '开始遍历当前候选人...');
      await processSearchCandidates(profile);
    } else {
      for (let ki = 0; ki < kwGroups.length; ki++) {
        if (_taskStopped) break;
        if (await checkPauseStop()) { hideSearchStatus(); return; }

        const kwGroup = kwGroups[ki];
        log(`Step 4: 搜索关键词组「${kwGroup}」（${ki + 1}/${kwGroups.length}）`);
        showSearchStatus('🔍 搜索模式', `🔎 搜索「${kwGroup}」`, `第 ${ki + 1}/${kwGroups.length} 组`);

        const searched = await searchWithKeyword(kwGroup);
        if (!searched) continue;
        await sleep(rand(1500, 2500));
        if (await checkPauseStop()) { hideSearchStatus(); return; }

        // 等待搜索结果出现（卡片出现才算就绪）
        showSearchStatus('🔍 搜索模式', `⏳ 等待「${kwGroup}」搜索结果...`);
        const resultsReady = await waitForSearchResults(10000);
        if (!resultsReady) {
          logWarn(`关键词「${kwGroup}」无搜索结果，跳过`);
          showSearchStatus('🔍 搜索模式', `⚠️「${kwGroup}」无结果，跳过`);
          await sleep(1500);
          continue;
        }

        await processSearchCandidates(profile);
        if (_taskStopped) break;
      }
    }

    hideSearchStatus();
    log('搜索模式全部完成');
  }

  /** 专门等候选人卡片出现（搜索结果就绪） */
  async function waitForSearchResults(timeoutMs = 10000) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      const sDoc = getSearchDoc();
      if (sDoc.querySelector(SEARCH_CARD_SELS.join(','))) return true;
      await sleep(400);
    }
    // 超时：输出诊断帮助定位真实选择器
    try {
      const sDoc = getSearchDoc();
      // 输出含 "geek"/"result"/"list"/"card" 等关键词的 class 列表
      const interesting = new Set();
      for (const el of sDoc.querySelectorAll('*')) {
        const cls = el.className;
        if (typeof cls !== 'string') continue;
        if (/geek|result|card|item|entry|talent|candidate/.test(cls)) {
          interesting.add(`${el.tagName.toLowerCase()}.${cls.trim().replace(/\s+/g, '.')}`);
          if (interesting.size >= 30) break;
        }
      }
      log(`[诊断] 候选人卡片未找到，搜索页匹配 class 元素：\n${[...interesting].join('\n')}`, 'warn');
    } catch (_) {}
    return false;
  }

  /** 解析关键词组（每行一组，行内空格分隔为一个搜索串） */
  function parseKeywordGroups(keywords) {
    if (!keywords) return [];
    return keywords.split('\n').map(s => s.trim()).filter(Boolean);
  }

  /** 在搜索页选择在招岗位（.search-job-list-C 下拉） */
  async function selectSearchModeJob(jobTitle) {
    // 等待触发器出现（最多 15s，getSearchDoc 会一直重新扫描 iframe）
    const TRIGGER_SEL = '.search-job-list-C, [class*="search-job-list"], [class*="job-list-wrap"]';
    let sDoc = null;
    let trigger = null;
    const tw0 = Date.now();
    while (Date.now() - tw0 < 15000) {
      sDoc = getSearchDoc();
      trigger = sDoc.querySelector(TRIGGER_SEL);
      if (trigger) break;
      await sleep(500);
    }
    if (!trigger) {
      log('未找到搜索页岗位选择器，跳过岗位选择');
      showSearchStatus('🔍 搜索模式', '⚠️ 未找到岗位筛选框，跳过');
      dumpFrameInfo();
      return false;
    }

    const key = jobKey(jobTitle);

    // 先不点击，直接试试列表里是否已有岗位条目（部分场景下列表始终可见）
    const JOB_ITEM_SEL = 'li[ka="search_select_job"], .search-job-list-C li, .ui-dropmenu-list li';
    let preItems = [...sDoc.querySelectorAll(JOB_ITEM_SEL)];
    if (!preItems.length) {
      // 列表未显示 → 点击触发器展开
      showSearchStatus('🔍 搜索模式', `📋 展开岗位列表...`);
      realClick(trigger);
      log(`展开在招岗位下拉`);
      await sleep(rand(600, 1000));
    } else {
      log(`岗位列表已可见（${preItems.length} 项），直接选择`);
    }

    const t0 = Date.now();
    while (Date.now() - t0 < 8000) {
      const items = [...sDoc.querySelectorAll(JOB_ITEM_SEL)];

      if (items.length) {
        // 按得分选最佳匹配（全名匹配 > 包含 > 最长公共子串）
        const scored = items
          .filter(li => !(li.querySelector('span.job-name')?.textContent || li.textContent).replace(/\s/g,'').includes('不限职位'))
          .map(li => {
            const nameEl = li.querySelector('span.job-name');
            const txt = (nameEl?.textContent || li.textContent).trim();
            return { li, txt, score: jobMatchScore(txt, jobTitle) };
          })
          .filter(x => x.score > 0)
          .sort((a, b) => b.score - a.score);

        if (scored.length) {
          const best = scored[0];
          log(`选中岗位（得分${best.score}）：${best.txt.slice(0, 40)}`);
          showSearchStatus('🔍 搜索模式', `✅ 已选岗位：${best.txt.slice(0, 30)}`);
          realClick(best.li);
          await sleep(rand(800, 1200));
          return true;
        }

        // 无匹配得分 → 向下滚动岗位列表继续找
        const list = sDoc.querySelector('.ui-dropmenu-list, .search-job-list-C [class*="list"]');
        if (list && list.scrollHeight > list.clientHeight) {
          list.scrollTop += 200;
          log('岗位列表向下滚动...');
          await sleep(400);
          continue;
        }

        // 滚到底仍无分 → 选第一个
        const first = items.find(li => !li.textContent.replace(/\s/g,'').includes('不限职位')) || items[0];
        const firstName = (first.querySelector('span.job-name')?.textContent || first.textContent).trim().slice(0, 40);
        log(`无精确匹配，选第一个：${firstName}`);
        showSearchStatus('🔍 搜索模式', `✅ 已选岗位：${firstName}`);
        realClick(first);
        await sleep(rand(800, 1200));
        return true;
      }
      await sleep(200);
    }

    log('岗位选项未出现，跳过');
    return false;
  }

  /** 在 input.search-input 中输入关键词并点击搜索 */
  async function searchWithKeyword(keyword) {
    // 等待输入框出现（最多 10s）
    const INPUT_SEL = 'input.search-input, .search-input-wrap input, [class*="search-input-wrap"] input[type="text"]';
    let sDoc = null;
    let input = null;
    const iw0 = Date.now();
    while (Date.now() - iw0 < 10000) {
      sDoc = getSearchDoc();
      input = sDoc.querySelector(INPUT_SEL);
      if (input) break;
      await sleep(500);
    }
    if (!input) {
      logWarn(`未找到关键词搜索框，跳过「${keyword}」`);
      showSearchStatus('🔍 搜索模式', `⚠️ 未找到搜索框，跳过「${keyword}」`);
      return false;
    }

    showSearchStatus('🔍 搜索模式', `⌨️ 输入关键词「${keyword}」`);
    log(`输入搜索关键词：「${keyword}」`);
    input.focus();
    input.value = '';
    input.dispatchEvent(new Event('input', { bubbles: true }));
    await sleep(200);
    await humanType(input, keyword);
    await sleep(rand(500, 800));

    // 优先点搜索图标，其次回车
    const searchBtn = sDoc.querySelector(
      'i.icon-search, [class*="icon-search"], .search-input-wrap .btn-search'
    );
    if (searchBtn && searchBtn.offsetParent !== null) {
      realClick(searchBtn);
      log('点击搜索按钮');
    } else {
      input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
      input.dispatchEvent(new KeyboardEvent('keyup',   { key: 'Enter', keyCode: 13, bubbles: true }));
      log('回车搜索');
    }

    await sleep(rand(800, 1200));
    return true;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Step 1: 点击搜索导航
  // ─────────────────────────────────────────────────────────────────────────
  async function clickSearchNav() {
    // 如果已经在搜索页，直接跳过导航
    // 检查主文档和 iframe 中是否已有搜索页元素
    const iDoc = getIframeDoc();
    const searchSel = 'input.search-input, .search-job-list-C, .search-input-wrap';
    if (document.querySelector(searchSel) || (iDoc && iDoc.querySelector(searchSel))) {
      log('已在搜索页，跳过导航');
      return true;
    }

    // 选择器：a[ka="menu-geek-search"]
    let btn = document.querySelector('a[ka="menu-geek-search"]');
    if (!btn) {
      const t0 = Date.now();
      while (Date.now() - t0 < 5000) {
        btn = document.querySelector('a[ka="menu-geek-search"]');
        if (btn) break;
        await sleep(300);
      }
    }
    if (!btn) {
      logErr(`找不到搜索导航按钮，当前页：${location.href.slice(0, 80)}`);
      return false;
    }
    log(`点击搜索导航（href=${btn.href || btn.getAttribute('href') || '无'}）`);
    realClick(btn);
    return true;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Step 2: 等待搜索页候选人列表加载
  // ─────────────────────────────────────────────────────────────────────────
  /**
   * 搜索模式用的文档：扫描所有 iframe，找到含搜索 UI 的那个；
   * 都没有则返回主文档。
   */
  const SEARCH_INDICATOR = '.search-job-list-C, input.search-input, li[ka="search_select_job"], .search-input-wrap';

  let _searchDocCache = null;     // 缓存：避免每次都扫 iframe 并刷日志
  let _searchDocCacheTs = 0;      // 缓存时间戳（5s 过期）

  function getSearchDoc() {
    const now = Date.now();
    if (_searchDocCache && now - _searchDocCacheTs < 5000) return _searchDocCache;

    // 1. 先试主文档
    if (document.querySelector(SEARCH_INDICATOR)) {
      _searchDocCache = document;
      _searchDocCacheTs = now;
      return document;
    }
    // 2. 扫所有 iframe
    for (const iframe of document.querySelectorAll('iframe')) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (!doc) continue;
        if (doc.querySelector(SEARCH_INDICATOR)) {
          log(`搜索 UI 在 iframe（name="${iframe.name || '无'}" src="${(iframe.src||'').slice(0,60)}"）`);
          _searchDocCache = doc;
          _searchDocCacheTs = now;
          return doc;
        }
      } catch (_) {}
    }
    return document;
  }

  /** 主动清除 getSearchDoc 缓存（页面切换/搜索后调用） */
  function clearSearchDocCache() {
    _searchDocCache = null;
    _searchDocCacheTs = 0;
  }

  /** 诊断：输出当前页的框架结构（帮助定位搜索 UI） */
  function dumpFrameInfo() {
    try {
      // 主文档概况
      const bodySnippet = document.body?.innerHTML?.slice(0, 300) || '(空)';
      log(`[诊断] 主文档 body 片段：${bodySnippet}`, 'warn');

      // 列出所有 iframe
      const iframes = [...document.querySelectorAll('iframe')];
      log(`[诊断] iframe 总数：${iframes.length}`, 'warn');
      iframes.forEach((f, i) => {
        let accessible = false;
        let childElCount = 0;
        let hasSearchEl = false;
        try {
          const d = f.contentDocument || f.contentWindow?.document;
          if (d) {
            accessible = true;
            childElCount = d.querySelectorAll('*').length;
            hasSearchEl = !!d.querySelector(SEARCH_INDICATOR);
          }
        } catch (_) {}
        log(`[诊断] iframe[${i}] name="${f.name||'无'}" src="${(f.src||'').slice(0,80)}" 可访问=${accessible} 元素数=${childElCount} 含搜索UI=${hasSearchEl}`, 'warn');
      });
    } catch (e) {
      log(`[诊断] 异常：${e.message}`, 'warn');
    }
  }

  async function waitForSearchPage(timeoutMs = 15000) {
    // iframe 模式：已在含搜索 UI 的框架中，不检查 URL
    if (_isInIframe) {
      if (document.querySelector(SEARCH_INDICATOR)) {
        log('[iframe] 搜索 UI 已就绪');
        return true;
      }
      // 理论上不应到这里（RUN_RECRUIT_TASK 已做等待），直接返回
      return true;
    }

    // 1. URL 已经在搜索页 → 等 Vue 挂载后直接就绪
    if (location.href.includes('/chat/search') || location.href.includes('/boss/geek/search')) {
      log(`搜索页URL确认：${location.href.slice(0, 80)}，等待页面渲染...`);
      // 等 DOM 元素出现（最多 timeoutMs），出现即返回；到时仍以 URL 为准通过
        const SEARCH_SELS = [
        '.search-job-list-C', 'input.search-input', '.search-input-wrap',
        'li[ka="search_select_job"]', '[class*="search-wrap"]', ...SEARCH_CARD_SELS,
      ];
      const t0 = Date.now();
      while (Date.now() - t0 < timeoutMs) {
        // 扫主文档 + 所有 iframe
        const allDocs = [document, ...([...document.querySelectorAll('iframe')].map(f => {
          try { return f.contentDocument || f.contentWindow?.document; } catch (_) { return null; }
        }).filter(Boolean))];

        for (const doc of allDocs) {
          for (const sel of SEARCH_SELS) {
            if (doc.querySelector(sel)) {
              const ctx = doc === document ? '主文档' : `iframe(name=${document.querySelector(`iframe`)?.name || '无'})`;
              log(`搜索页元素就绪（${ctx}）：${sel}`);
              return true;
            }
          }
        }
        await sleep(400);
      }
      log('搜索页 URL 正确，但未检测到预期元素 —— 启动框架诊断...');
      dumpFrameInfo();
      return true;
    }

    // 2. URL 不对 → 等待导航完成
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      if (location.href.includes('/chat/search') || location.href.includes('/boss/geek/search')) {
        log(`检测到搜索页URL：${location.href.slice(0, 80)}`);
        await sleep(1500); // 给 Vue 初次渲染时间
        return true;
      }
      await sleep(400);
    }
    log(`waitForSearchPage 超时，当前页：${location.href.slice(0, 80)}`);
    return false;
  }

  // 搜索结果候选人卡片选择器（多个备选，按优先级排列）
  // Boss直聘 搜索页 iframe（/web/frame/search/）的候选人列表常见结构
  const SEARCH_CARD_SELS = [
    // Boss直聘已确认：has-geek 在容器上，结果列表常见 class
    '.geek-list li',
    'ul.geek-list > li',
    '.boss-entry-list li',
    'li[ka="search_result"]',
    'li[ka="geek_card"]',
    'li[ka="boss_card"]',
    // 通配：含 geek 字样的列表项
    '[class*="geek-list"] li',
    '[class*="geek-item"]',
    '[class*="geek-card"]',
    '[class*="boss-card"]',
    // 通配备选
    '.boss-geek-item',
    '[class*="candidate-item"]',
    '[class*="talent-item"]',
    '[class*="search-result"] li',
    '.search-result-list li',
    'ul[class*="result"] li',
  ];

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：视觉状态指示（注入主文档，非 iframe）
  // ─────────────────────────────────────────────────────────────────────────
  function getSearchStatusOverlay() {
    let el = document.getElementById('__boss_search_status__');
    if (!el) {
      el = document.createElement('div');
      el.id = '__boss_search_status__';
      el.style.cssText = [
        'position:fixed', 'bottom:20px', 'right:20px', 'z-index:2147483647',
        'background:rgba(18,24,35,0.92)', 'color:#fff',
        'padding:12px 16px', 'border-radius:10px',
        'font-size:13px', 'line-height:1.7', 'min-width:220px',
        'box-shadow:0 4px 16px rgba(0,0,0,0.4)',
        'cursor:pointer', 'font-family:sans-serif',
        'transition:box-shadow 0.15s',
      ].join(';');
      el.title = '点击打开操作台';
      el.addEventListener('mouseenter', () => { el.style.boxShadow = '0 6px 24px rgba(0,0,0,0.55)'; });
      el.addEventListener('mouseleave', () => { el.style.boxShadow = '0 4px 16px rgba(0,0,0,0.4)'; });
      el.addEventListener('click', () => {
        chrome.runtime.sendMessage({ type: 'OPEN_POPUP' }).catch(() => {});
      });
      // ✖ 关闭按钮
      const closeBtn = document.createElement('div');
      closeBtn.title = '关闭';
      closeBtn.textContent = '✕';
      closeBtn.style.cssText = [
        'position:absolute', 'top:6px', 'right:8px',
        'width:18px', 'height:18px', 'line-height:18px', 'text-align:center',
        'border-radius:50%', 'background:rgba(255,255,255,0.18)', 'color:#ccc',
        'font-size:11px', 'cursor:pointer', 'z-index:1',
        'transition:background 0.15s',
      ].join(';');
      closeBtn.addEventListener('mouseenter', () => { closeBtn.style.background = 'rgba(255,255,255,0.35)'; });
      closeBtn.addEventListener('mouseleave', () => { closeBtn.style.background = 'rgba(255,255,255,0.18)'; });
      closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        el.style.display = 'none';
        _searchStatusHiddenByUser = true;
      });
      el.appendChild(closeBtn);
      // 内容容器
      const content = document.createElement('div');
      content.id = '__boss_search_status__content';
      el.appendChild(content);
      document.body.appendChild(el);
    }
    return el;
  }

  function showSearchStatus(name, step, extra = '') {
    try {
      if (_searchStatusHiddenByUser) return;
      const el = getSearchStatusOverlay();
      el.style.display = '';
      const content = el.querySelector('#__boss_search_status__content') || el;
      content.innerHTML =
        `<div style="font-weight:700;margin-bottom:4px;color:#00D9C5">🤖 Boss AI招聘助手（搜索模式）</div>` +
        `<div>👤 <b>${name}</b></div>` +
        `<div>📋 ${step}</div>` +
        (extra ? `<div style="color:#bbb;font-size:12px;margin-top:2px">${extra}</div>` : '');
    } catch (_) {}
  }

  function hideSearchStatus() {
    try { document.getElementById('__boss_search_status__')?.remove(); } catch (_) {}
    _searchStatusHiddenByUser = false;
  }

  function highlightSearchCard(card) {
    try {
      getSearchDoc().querySelectorAll('[data-boss-search-highlight]').forEach(el => {
        el.style.outline = '';
        el.style.boxShadow = '';
        delete el.dataset.bossSearchHighlight;
      });
      if (card) {
        card.dataset.bossSearchHighlight = '1';
        card.style.outline = '2px solid #4fc3f7';
        card.style.boxShadow = '0 0 0 4px rgba(79,195,247,0.18)';
        card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    } catch (_) {}
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：候选人卡片 & 信息提取
  // ─────────────────────────────────────────────────────────────────────────
  function getSearchResultCards() {
    const sDoc = getSearchDoc();
    for (const sel of SEARCH_CARD_SELS) {
      const cards = [...sDoc.querySelectorAll(sel)].filter(c => c.offsetParent !== null);
      if (cards.length) return cards;
    }
    return [];
  }

  function extractSearchCardName(card) {
    // 清理状态文字（"热搜"、"刚刚活跃"、"急聘" 等紧跟在姓名后面的标签）
    const CLEAN = t => (t || '')
      .split('\n')[0].trim()
      .replace(/[\s　]*(热搜|急聘|急招|在线|热门|刚刚|近期|[\d]+[天时分]前)[^，,。]*$/g, '')
      .trim();
    const isName = t => t.length >= 2 && t.length <= 15;
    const sels = [
      'span.name',
      '.geek-name',
      '[class*="geek-name"]',
      'a[href*="/geek/"]',
      '[class*="geek-card"] [class*="name"]',
      '[class*="geek-info"] [class*="name"]',
      '[class*="card-info"] [class*="name"]',
      '[class*="primary"] [class*="name"]',
      '[class*="name"]:not([class*="company"]):not([class*="job"]):not([class*="school"]):not([class*="tag"])',
    ];
    for (const sel of sels) {
      const el = card.querySelector(sel);
      if (!el) continue;
      const t = CLEAN(el.textContent);
      if (isName(t)) return t;
    }
    // 兜底：遍历叶节点，取第一个看起来像姓名的文本
    for (const el of card.querySelectorAll('span, a, b, strong, em')) {
      if (el.children.length > 0) continue; // 叶节点
      const t = CLEAN(el.textContent);
      const LABEL_BLOCK = /期望|城市|薪资|工作|经验|学历|职位|地点|地区|意向|岗位|学校|院校|活跃|在线|热搜|急聘|招聘|求职|简历|面试|行业|级别|评级|月薪|年薪|以上|以下|不限|年|岁|季|项目/;
      if (isName(t) && !LABEL_BLOCK.test(t)) return t;
    }
    return '未知';
  }

  function extractSearchCardId(card) {
    return card.getAttribute('data-geek-id')
        || card.getAttribute('data-id')
        || card.getAttribute('encrypt-geek-id')
        || card.querySelector('[encrypt-geek-id]')?.getAttribute('encrypt-geek-id')
        || '';
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：等待资料详情面板
  // ─────────────────────────────────────────────────────────────────────────
  const SEARCH_DETAIL_SEL =
    '.resume-detail-wrap, [class*="resume-detail"], [class*="geek-detail"], ' +
    '[class*="detail-panel"], .detail-container, [class*="resume-panel"], ' +
    '.candidate-detail, [class*="profile-panel"], ' +
    // Boss直聘搜索侧边详情常见 class
    '.boss-geek-detail, .geek-info-panel, [class*="geek-info"], ' +
    '.boss-detail-main, [class*="search-detail"], [class*="geek-resume"]';

  /** 同时扫 iframe 和主文档，返回找到详情面板的文档 */
  function findDetailDoc() {
    const sDoc = getSearchDoc();
    if (sDoc.querySelector(SEARCH_DETAIL_SEL)) return sDoc;
    if (document !== sDoc && document.querySelector(SEARCH_DETAIL_SEL)) return document;
    return null;
  }

  async function waitForSearchDetailPanel(timeoutMs = 10000) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      if (findDetailDoc()) return true;
      await sleep(300);
    }

    // 诊断：列出 iframe 和主文档里出现的可疑元素
    try {
      const sDoc = getSearchDoc();
      const dumpDoc = (doc, label) => {
        const els = new Set();
        for (const el of doc.querySelectorAll('*')) {
          const c = el.className;
          if (typeof c !== 'string') continue;
          if (/detail|resume|geek|panel|info|profile|side/.test(c)) {
            els.add(`${el.tagName.toLowerCase()}.${c.trim().replace(/\s+/g,'.')}`);
            if (els.size >= 20) break;
          }
        }
        if (els.size) log(`[诊断-${label}] 详情相关元素：\n${[...els].join('\n')}`, 'warn');
      };
      dumpDoc(sDoc, 'iframe');
      if (document !== sDoc) dumpDoc(document, '主文档');
    } catch (_) {}
    return false;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：从详情面板提取候选人信息
  // ─────────────────────────────────────────────────────────────────────────
  function extractSearchCandidateInfo(defaultName) {
    const sDoc = findDetailDoc() || getSearchDoc();
    const panel = sDoc.querySelector(SEARCH_DETAIL_SEL) || sDoc.body;

    const USEFUL_SECTIONS = [
      '.geek-base-info-wrap',
      '.geek-expect-wrap',
      '.geek-work-experience-wrap',
      '.geek-education-experience-wrap',
      '[class*="base-info"]',
      '[class*="expect-info"]',
      '[class*="work-experience"]',
      '[class*="education"]',
    ];

    const sectionTexts = [];
    const seen = new Set();
    for (const sel of USEFUL_SECTIONS) {
      const sec = panel.querySelector(sel);
      if (sec && !seen.has(sec)) {
        seen.add(sec);
        sectionTexts.push(sec.innerText || sec.textContent || '');
      }
    }

    let extra = sectionTexts.length
      ? sectionTexts.join('\n')
      : (panel.innerText || panel.textContent || '');

    const cutIdx = extra.indexOf('牛人分析器');
    if (cutIdx > -1) extra = extra.slice(0, cutIdx);

    const name     = panel.querySelector('span.name, .geek-name, [class*="user-name"]')?.textContent.trim() || defaultName;
    const title    = panel.querySelector('[class*="expect-job"], [class*="job-title"]')?.textContent.trim() || '';
    const company  = panel.querySelector('[class*="company-name"], [class*="work"] [class*="company"]')?.textContent.trim() || '';
    const experience = panel.querySelector('[class*="exp-years"], [class*="experience"]')?.textContent.trim() || '';
    const education  = panel.querySelector('[class*="school-name"], [class*="education"] [class*="school"]')?.textContent.trim() || '';
    const skills   = [...panel.querySelectorAll('[class*="tag"], [class*="skill"]')]
                      .map(e => e.textContent.trim()).filter(Boolean).join('、');

    return { name, title, company, experience, education, skills, extra };
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：找「搜索畅聊卡」按钮
  // ─────────────────────────────────────────────────────────────────────────
  function findChatCardBtn() {
    // 候选文档列表：详情面板所在doc + iframe doc + 主文档（三处都查，防止面板开在主doc但被误归为iframe）
    const docs = [];
    const detailDoc = findDetailDoc();
    if (detailDoc) docs.push(detailDoc);
    const sDoc = getSearchDoc();
    if (sDoc && !docs.includes(sDoc)) docs.push(sDoc);
    if (!docs.includes(document)) docs.push(document);

    // 文字匹配（最可靠，无需可见性检查 —— 文字本身已足够具体）
    for (const doc of docs) {
      for (const el of doc.querySelectorAll('button, a.btn, [class*="btn"]')) {
        if (el.textContent.trim().includes('畅聊卡')) return el;
      }
    }
    // class 兜底
    const classSel =
      'button[class*="prop-card-chat"], .prop-card-chat, ' +
      'button[class*="chat-card"], .btn-chat-card, [class*="sure-btn"][class*="chat"]';
    for (const doc of docs) {
      const el = doc.querySelector(classSel);
      if (el) return el;
    }
    return null;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：关闭畅聊卡弹窗
  // ─────────────────────────────────────────────────────────────────────────
  async function closeSearchChatPopup() {
    // 搜索畅聊卡后会弹出"选择该牛人开聊职位"对话框，需点击确认按钮（非关闭按钮）
    const getDocs = () => [...new Set(
      [findDetailDoc(), getSearchDoc(), document].filter(Boolean)
    )];

    const findConfirmBtn = () => {
      for (const doc of getDocs()) {
        // 按class精确匹配
        for (const btn of doc.querySelectorAll('button.boss-btn-primary, button[class*="boss-btn-primary"], [class*="sure-btn"], [class*="confirm-btn"]')) {
          const txt = btn.textContent.trim();
          if (txt.includes('畅聊卡') || txt.includes('确认') || txt.includes('确定')) return btn;
        }
        // 按文本匹配兜底
        for (const btn of doc.querySelectorAll('button')) {
          if (btn.textContent.trim().includes('畅聊卡')) return btn;
        }
      }
      return null;
    };

    const t0 = Date.now();
    while (Date.now() - t0 < 5000) {
      const confirmBtn = findConfirmBtn();
      if (confirmBtn) {
        realClick(confirmBtn);
        log('✓ 已点击搜索畅聊卡确认按钮');
        await sleep(rand(600, 1000));
        return;
      }
      await sleep(200);
    }
    log('畅聊卡选职位弹窗未出现，继续执行');
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：关闭候选人资料页（点✖）
  // ─────────────────────────────────────────────────────────────────────────
  async function closeSearchDetailPanel() {
    const getDocs = () => [...new Set(
      [findDetailDoc(), getSearchDoc(), document].filter(Boolean)
    )];

    // 使用元素自身文档的 window 检查可见性（避免跨 iframe 的 offsetParent 误判）
    const isElVisible = el => {
      if (!el) return false;
      try {
        const win = el.ownerDocument.defaultView;
        const s = win.getComputedStyle(el);
        return s.display !== 'none' && s.visibility !== 'hidden';
      } catch (_) { return el.offsetParent !== null; }
    };

    // 候选人资料页的 icon-close，排除 dialog/modal 弹窗内的（那是其他弹窗的关闭按钮）
    const isInDialog = el =>
      !!el.closest('.major-dialog, .dialog-wrap, .dialog-container, [class*="dialog-wrap"], [class*="dialog-container"]');

    const findVisibleCloseIcon = () => {
      for (const doc of getDocs()) {
        for (const ic of doc.querySelectorAll('i.icon-close')) {
          if (isElVisible(ic) && !isInDialog(ic)) return ic;
        }
      }
      return null;
    };

    // 面板"仍开着"：存在可见的、非 dialog 的 icon-close
    const isDetailOpen = () => findVisibleCloseIcon() !== null;

    // 点击：优先 native .click()，再用元素自身 window 发事件
    const nativeClick = el => {
      if (!el) return;
      try { el.click(); } catch (_) {}
      try {
        const win = el.ownerDocument?.defaultView || window;
        el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: win }));
      } catch (_) {}
    };

    const t0 = Date.now();
    let attempt = 0;
    while (Date.now() - t0 < 6000) {
      if (!isDetailOpen()) return;

      const closeIcon = findVisibleCloseIcon();
      if (closeIcon) {
        attempt++;
        // 诊断：打印 icon-close 的祖先 class 链（帮助定位是否点的是正确元素）
        if (attempt === 1) {
          const chain = [];
          let el = closeIcon;
          for (let i = 0; i < 5 && el; i++, el = el.parentElement)
            chain.push(`<${el.tagName.toLowerCase()} class="${el.className}">`);
          log(`[诊断] 资料页 icon-close 祖先链：${chain.join(' → ')}`);
        }
        // 先点 <i> 自身，再点 parentElement
        nativeClick(closeIcon);
        await sleep(300);
        if (!isDetailOpen()) { log('资料页已关闭（点 icon-close）'); return; }
        nativeClick(closeIcon.parentElement || closeIcon);
        await sleep(700);
        if (!isDetailOpen()) { log('资料页已关闭（点 parentElement）'); return; }
      } else {
        // 找不到：Escape 兜底
        for (const doc of getDocs()) {
          try { doc.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true })); } catch (_) {}
        }
        await sleep(500);
      }
    }
    logWarn('搜索资料页关闭超时');
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：提取当前候选人资料页 URL
  // ─────────────────────────────────────────────────────────────────────────
  function extractSearchProfileUrl() {
    const BASE = 'https://www.zhipin.com';
    const sDoc = findDetailDoc() || getSearchDoc();

    // 1. 当前页 URL 就是资料页
    const href = location.href;
    if (/\/(geek|resume|candidate|profile)\//i.test(href)) return href;

    // 2. 详情面板内的 <a href>
    const panel = sDoc.querySelector(SEARCH_DETAIL_SEL);
    for (const a of (panel?.querySelectorAll('a[href]') || [])) {
      const h = a.href || a.getAttribute('href') || '';
      if (/\/(geek|resume|candidate)\//i.test(h) || /[?&](geekId|uid)=/.test(h)) {
        return h.startsWith('http') ? h : BASE + h;
      }
    }

    // 3. encrypt-geek-id 属性
    const encEl = (panel || sDoc).querySelector('[encrypt-geek-id]');
    if (encEl) {
      return `${BASE}/web/geek/resume.html?encryptGeekId=${encodeURIComponent(encEl.getAttribute('encrypt-geek-id'))}`;
    }

    return '';
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：滚动加载更多
  // ─────────────────────────────────────────────────────────────────────────
  async function scrollLoadMoreSearch() {
    const sDoc = getSearchDoc();
    const beforeCount = sDoc.querySelectorAll(SEARCH_CARD_SELS.join(',')).length;
    log(`搜索模式：滚动加载更多（当前 ${beforeCount} 个）...`);

    const listEl = sDoc.querySelector(
      '[class*="result-list"], [class*="candidate-list"], [class*="geek-list"], [class*="search-list"]'
    );
    if (listEl) listEl.scrollTop = listEl.scrollHeight;
    else sDoc.documentElement.scrollTop = sDoc.documentElement.scrollHeight;

    const t0 = Date.now();
    while (Date.now() - t0 < 6000) {
      await sleep(500);
      const nowCount = sDoc.querySelectorAll(SEARCH_CARD_SELS.join(',')).length;
      if (nowCount > beforeCount) {
        log(`✓ 搜索：加载 ${nowCount - beforeCount} 个新候选人`);
        await sleep(rand(600, 1000));
        return true;
      }
    }
    log('搜索：无更多候选人');
    return false;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Step 3~5: 遍历搜索候选人、AI评估、发送畅聊卡
  // ─────────────────────────────────────────────────────────────────────────
  async function processSearchCandidates(profile) {
    log('开始遍历搜索候选人');

    // ── 确认卡片选择器并等待列表出现 ──────────────────────────────────────────
    log('等待搜索结果列表...');
    const sDoc = getSearchDoc();
    let cardSel = null;
    const t0 = Date.now();
    while (Date.now() - t0 < 10000) {
      for (const sel of SEARCH_CARD_SELS) {
        if (sDoc.querySelector(sel)) { cardSel = sel; break; }
      }
      if (cardSel) break;
      await sleep(400);
    }
    if (!cardSel) { logErr('搜索结果列表未出现，中止'); return; }
    log(`候选人卡片选择器：${cardSel}`);

    const processedNames = new Set();

    while (!_taskStopped) {
      if (await checkPauseStop()) return;

      // 找下一个未处理的卡片
      const unprocessed = [...sDoc.querySelectorAll(cardSel)]
        .filter(c => c.offsetParent !== null && !c.dataset.bossProcessed);
      const card = unprocessed[0];

      if (!card) {
        const loaded = await scrollLoadMoreSearch();
        if (!loaded) { log('搜索结果已全部处理'); break; }
        continue;
      }

      card.dataset.bossProcessed = '1';
      const candidateName = extractSearchCardName(card);
      if (processedNames.has(candidateName) && candidateName !== '未知') continue;
      processedNames.add(candidateName);
      // 提前从卡片链接提取 profileUrl（点击后页面可能已变化）
      const cardProfileUrl = (() => {
        // 注意：此变量在下方 seen 检查前定义，后续 seenUid 会用到
        const BASE = 'https://www.zhipin.com';
        for (const a of card.querySelectorAll('a[href]')) {
          const h = a.getAttribute('href') || '';
          if (/\/(geek|resume|candidate)\//i.test(h) || /[?&](geekId|encryptGeekId|uid)=/.test(h))
            return h.startsWith('http') ? h : BASE + h;
        }
        const id = extractSearchCardId(card);
        return id ? `${BASE}/web/geek/resume.html?encryptGeekId=${encodeURIComponent(id)}` : '';
      })();

      // ── 15天去重 ──────────────────────────────────────────────────────────
      const searchSeenUid = cardProfileUrl || candidateName;
      if (await isSeenRecently(searchSeenUid)) {
        log(`${candidateName} 15天内已处理，跳过`);
        showSearchStatus(candidateName, '⏭ 15天内已处理，跳过');
        await sleep(400);
        continue;
      }

      // ── 视觉指示 ──────────────────────────────────────────────────────────
      highlightSearchCard(card);
      showSearchStatus(candidateName, '正在查看资料...');
      await sleep(rand(600, 1000));

      // ── Step 3b: 点开候选人资料 ────────────────────────────────────────────
      log(`查看候选人：${candidateName}`);
      // 优先点卡片内的主点击区（a 链接 或 primary 容器）
      const cardClickTarget =
        card.querySelector('a[href], .primary-box, [class*="card-info"], [class*="geek-info"]')
        || card;
      realClick(cardClickTarget);
      showSearchStatus(candidateName, '⏳ 加载资料中...');

      const opened = await waitForSearchDetailPanel(8000);
      if (!opened) {
        logWarn(`${candidateName} 资料页未打开，跳过`);
        continue;
      }
      await sleep(rand(1000, 1800));
      if (await checkPauseStop()) { await closeSearchDetailPanel(); return; }

      // ── Step 3c: 提取资料 ──────────────────────────────────────────────────
      showSearchStatus(candidateName, '📖 读取简历...');
      const info = extractSearchCandidateInfo(candidateName);
      info.name = candidateName;
      _stats.processed++;
      log(`读取资料：${info.name}（${info.title}${info.company ? ' @ ' + info.company : ''}）`);
      await sleep(rand(800, 1400));
      if (await checkPauseStop()) { await closeSearchDetailPanel(); return; }

      // ── Step 4: AI 评估 ────────────────────────────────────────────────────
      showSearchStatus(candidateName, '🤖 AI评估中...', '正在分析匹配度');
      log(`AI评估：${info.name}`);
      let evalResult = null;
      try {
        const resp = await chrome.runtime.sendMessage({
          type: 'EVALUATE_CANDIDATE',
          candidateInfo: {
            name:       info.name,
            title:      info.title,
            company:    info.company,
            experience: info.experience,
            education:  info.education,
            skills:     info.skills,
            extra:      info.extra.slice(0, 3000),
          },
        });
        evalResult = resp?.result;
      } catch (e) {
        logErr(`AI评估失败：${e.message}`);
      }

      if (!evalResult) {
        logWarn(`${info.name} 评估失败，跳过`);
        showSearchStatus(candidateName, '❌ 评估失败，跳过');
        _stats.failed++;
        await chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'failed' }).catch(() => {});
        await sleep(600);
        await closeSearchDetailPanel();
        await sleep(rand(400, 700));
        continue;
      }

      const { score, suitable, reason } = evalResult;
      log(`评估结果：${info.name} ${score}分 ${suitable ? '✓ 匹配' : '✗ 不匹配'} — ${reason}`);
      const isMatch = suitable && Number(score) >= (profile.scoreThreshold ?? 70);

      if (!isMatch) {
        showSearchStatus(candidateName, `✗ 不匹配（${score}分）`, reason?.slice(0, 40));
        await sleep(rand(600, 1000));
        log(`不匹配，关闭资料页：${info.name}`);
        await markSeen(searchSeenUid);
        await closeSearchDetailPanel();
        await sleep(rand(300, 600));
        continue;
      }

      // ── 匹配！──────────────────────────────────────────────────────────────
      showSearchStatus(candidateName, `✅ 匹配（${score}分）`, '即将发送畅聊卡');
      _stats.matched++;
      await sleep(rand(600, 1200));
      if (await checkPauseStop()) { await closeSearchDetailPanel(); return; }

      // ── Step 5: 点「搜索畅聊卡」────────────────────────────────────────────
      showSearchStatus(candidateName, '💬 正在发送畅聊卡...');
      log(`发送畅聊卡：${info.name}`);
      const chatCardBtn = findChatCardBtn();

      if (chatCardBtn) {
        realClick(chatCardBtn);
        log(`✓ 已点击畅聊卡：${info.name}`);
        await sleep(rand(1000, 1500));

        // 关闭弹出的功能框
        await closeSearchChatPopup();
        await sleep(rand(400, 700));

        // 保存人选记录（优先从详情面板提取，兜底用卡片预提取的链接）
        const profileUrl = extractSearchProfileUrl() || cardProfileUrl;
        log(`资料链接：${profileUrl || '未找到'}`);
        _stats.messaged++;
        await chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'messaged' }).catch(() => {});
        await chrome.runtime.sendMessage({
          type: 'SAVE_MATCHED_CANDIDATE',
          candidate: {
            name:            candidateName,
            title:           info.title || '',
            company:         info.company || '',
            experience:      info.experience || '',
            education:       info.education || '',
            skills:          info.skills || '',
            score,
            reason,
            highlights:      evalResult.highlights || '',
            stability:       evalResult.stability || '',
            interviewReason: evalResult.interviewReason || '',
            action:          'messaged',
            timestamp:       Date.now(),
            jobName:         profile.name || profile.jobTitle,
            mode:            'recruit',
          },
        }).catch(() => {});

        await markSeen(searchSeenUid);
        showSearchStatus(candidateName, `✅ 已发送畅聊卡（${score}分）`);
      } else {
        logWarn(`未找到畅聊卡按钮`);
        showSearchStatus(candidateName, '⚠️ 未找到畅聊卡按钮');
        _stats.failed++;
        await chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'failed' }).catch(() => {});
      }

      // ── Step 6: 关闭资料页 ─────────────────────────────────────────────────
      await closeSearchDetailPanel();
      await sleep(rand(300, 600));

      const delay = rand(2500, 4500);
      log(`等待 ${(delay / 1000).toFixed(1)}s 后继续...`);
      showSearchStatus(candidateName, `⏸ 冷却 ${(delay / 1000).toFixed(1)}s...`);
      await sleep(delay);
    }

    hideSearchStatus();
    highlightSearchCard(null);
    log('搜索模式处理完毕');
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  已获取简历模式（📥 Boss收件箱 /web/chat/index）
  // ═══════════════════════════════════════════════════════════════════════════

  async function runInboxTask() {
    if (_taskRunning) return;
    _taskRunning = true;
    _taskStopped = false;
    _taskPaused  = false;
    sessionStorage.setItem('__boss_recruiter_active', '1');
    await chrome.runtime.sendMessage({ type: 'START_TASK', mode: 'inbox', profiles: _curProfiles }).catch(() => {});

    for (let pi = 0; pi < _curProfiles.length; pi++) {
      if (_taskStopped) break;
      const profile = _curProfiles[pi];
      await chrome.runtime.sendMessage({ type: 'SET_ACTIVE_JOB', profileId: profile.id }).catch(() => {});
      log(`[收件箱] 开始处理岗位：${profile.name || profile.jobTitle}`);
      await runInboxLoop(profile);
      if (_taskStopped) break;
    }

    sessionStorage.removeItem('__boss_recruiter_active');
    _taskRunning = false;
    hideInboxStatus();
    log('[收件箱] 所有岗位处理完毕');

    // 全部完成通知
    if (!_taskStopped) {
      const totalMatched = _inboxPanelState.matched;
      const jobCount = _curProfiles.length;
      chrome.runtime.sendMessage({
        type: 'SHOW_NOTIFICATION',
        title: '✅ 简历筛选完毕',
        message: `共筛选 ${jobCount} 个岗位，找到 ${totalMatched} 位合适人选。\n现在可以去人选记录查看简历，安排面试或进一步沟通。`,
      }).catch(() => {});
      showInboxDoneToast(totalMatched, jobCount);
    }
  }

  async function runInboxLoop(profile) {
    showInboxStatus('📥 已获取简历', '⏳ 等待页面加载...');

    // 等收件箱页面就绪
    const onPage = await waitForInboxPage();
    if (!onPage) {
      showInboxStatus('❌', '未检测到 Boss 聊天页，请先打开 zhipin.com/web/chat/index');
      await sleep(3000); hideInboxStatus(); return;
    }

    // 点击「已获取简历」标签
    showInboxStatus('📥 已获取简历', '🔖 切换到「已获取简历」标签...');
    await clickInboxTab('已获取简历');
    await sleep(rand(1200, 2000));
    if (await checkPauseStop()) { hideInboxStatus(); return; }

    // 在职位下拉框里选择当前岗位
    showInboxStatus('📥 已获取简历', '🎯 筛选职位...');
    await selectInboxJob(profile);
    await sleep(rand(1000, 1600));
    if (await checkPauseStop()) { hideInboxStatus(); return; }

    // 遍历候选人
    await processInboxCandidates(profile);
    hideInboxStatus();
    log('[收件箱] 本岗位处理完毕');
  }

  /** 等待收件箱页面特有元素出现 */
  async function waitForInboxPage() {
    const t0 = Date.now();
    while (Date.now() - t0 < 12000) {
      const found = document.querySelector(
        '.chat-label-item, [class*="chat-label-item"], [class*="chat-label"], ' +
        '[class*="chat-list"], [class*="conversation"], [class*="geek-list-item"]'
      );
      if (found) return true;
      await sleep(400);
    }
    // 超时诊断
    const clsList = new Set();
    for (const el of document.querySelectorAll('*')) {
      const c = el.className;
      if (typeof c === 'string' && /chat|label|list|conv|geek|inbox/.test(c)) {
        clsList.add(`${el.tagName.toLowerCase()}.${c.trim().replace(/\s+/g, '.')}`);
        if (clsList.size >= 20) break;
      }
    }
    log(`[诊断] 收件箱页面元素：\n${[...clsList].join('\n')}`, 'warn');
    return false;
  }

  /** 点击指定标签（已获取简历 / 已交换电话 等） */
  async function clickInboxTab(tabText) {
    // 策略1: span.content 精确文字
    let tab = findByText(tabText, 'span.content');
    // 策略2: 含 content class 的 span
    if (!tab) tab = [...document.querySelectorAll('span[class*="content"]')]
      .find(el => el.textContent.trim().includes(tabText));
    // 策略3: chat-label-item 内文字
    if (!tab) {
      const item = [...document.querySelectorAll('[class*="chat-label-item"], [class*="label-item"]')]
        .find(el => el.textContent.trim().includes(tabText));
      if (item) { realClick(item); return true; }
    }
    // 策略4: 任意小元素精确匹配
    if (!tab) tab = [...document.querySelectorAll('div,span,button,a')]
      .find(el => el.children.length <= 2 && el.textContent.trim() === tabText);

    if (!tab) { logWarn(`未找到标签「${tabText}」，继续使用当前列表`); return false; }

    const clickTarget = tab.closest('[class*="chat-label-item"], [class*="label-item"]') || tab;
    log(`点击标签「${tabText}」`);
    realClick(clickTarget);
    await sleep(rand(600, 1000));
    return true;
  }

  /** 在「已获取简历」页面的职位下拉框中搜索并选中当前岗位 */
  async function selectInboxJob(profile) {
    const jobName = (profile.name || profile.jobTitle || '').trim();
    if (!jobName) { log('[收件箱] 未设置岗位名，跳过职位筛选'); return; }

    // 诊断确认结构：容器 class 含 "chat-top-job"，选项在容器内 .ui-dropmenu-list li
    // 不能全局搜索，否则会命中 top-profile-logout 的退出/账号设置等选项
    const container = document.querySelector('[class*="chat-top-job"]');
    if (!container) { logWarn('[收件箱] 未找到职位下拉容器(.chat-top-job)，跳过筛选'); return; }

    // 点击容器内的触发器展开列表
    const trigger = container.querySelector('span.dropmenu-label, [class*="dropmenu-label"]') || container;
    log(`[收件箱] 点击职位下拉，目标：${jobName}`);
    realClick(trigger);
    await sleep(rand(800, 1200));

    // 在容器内等待列表出现
    await waitForEl('.ui-dropmenu-list', 2000, container);

    // 容器内搜索框（如果有）
    const searchInput = container.querySelector('input');
    if (searchInput && searchInput.offsetParent !== null) {
      log(`[收件箱] 搜索框输入：${jobName}`);
      searchInput.focus();
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      if (nativeSetter) nativeSetter.call(searchInput, jobName);
      else searchInput.value = jobName;
      searchInput.dispatchEvent(new Event('input', { bubbles: true }));
      searchInput.dispatchEvent(new Event('change', { bubbles: true }));
      await sleep(rand(800, 1200));
    }

    // 严格在容器内取职位选项，完全避免全局搜索误中其他菜单
    const options = [...container.querySelectorAll('.ui-dropmenu-list li')]
      .filter(el => el.textContent.trim().length > 0);

    log(`[收件箱] 职位列表（${options.length}项）：${options.map(el => el.textContent.trim()).join(' / ')}`);

    // 精确匹配 → 模糊匹配 → 第一个非"全部"项
    const target = options.find(el => el.textContent.trim() === jobName)
      || options.find(el => el.textContent.trim().includes(jobName))
      || options.find(el => !/(全部|所有)/.test(el.textContent.trim()));

    if (target) {
      log(`[收件箱] 选中职位：${target.textContent.trim()}`);
      realClick(target);
      await sleep(rand(800, 1200));
    } else {
      logWarn(`[收件箱] 未找到匹配职位（共${options.length}项），关闭下拉`);
      document.body.click();
      await sleep(400);
    }
  }

  /** 获取收件箱左侧候选人列表项（已确认真实 class: geek-item-wrap / geek-item） */
  function getInboxListItems() {
    const SELS = [
      'div.geek-item-wrap',      // ✅ 真实结构，最优先
      'div.geek-item',
      '[class*="geek-item"]',
      '[class*="chat-list-item"]',
      '[class*="conversation-item"]',
      '[class*="contact-item"]',
    ];
    for (const sel of SELS) {
      const items = [...document.querySelectorAll(sel)].filter(el => el.offsetParent !== null);
      if (items.length) return items;
    }
    // 兜底：左侧面板内的可见列表项
    const leftPanel = document.querySelector('[class*="chat-left"], [class*="left-panel"], .chat-navbar');
    if (leftPanel) {
      return [...leftPanel.querySelectorAll('[class*="item"]')]
        .filter(el => el.offsetParent !== null && el.querySelector('.geek-name, [class*="name"]'));
    }
    return [];
  }

  /** 从右侧面板提取候选人信息（含附件简历内容） */
  async function extractInboxCandidateInfo(listItem) {
    // ── 从列表项直接读名字（已知 class: span.geek-name）
    const nameFromList = (
      listItem.querySelector('span.geek-name, [class*="geek-name"]')?.textContent.trim() ||
      listItem.querySelector('[class*="name"]')?.textContent.trim() || ''
    ).split('\n')[0].trim();

    // ── 等右侧面板渲染
    await sleep(rand(1000, 1600));

    // ── 读右侧顶部候选人基本信息
    // 结构示意：顶部区域有姓名、年龄、学历、期望职位等
    const rightTop = document.querySelector(
      '[class*="chat-header"], [class*="chat-top"], [class*="geek-info"], ' +
      '[class*="candidate-info"], [class*="chat-title"], [class*="header-wrap"]'
    );

    // 姓名：优先右侧顶部，兜底用列表项里读到的
    const name = (
      rightTop?.querySelector('span.geek-name, [class*="geek-name"], h1, [class*="name"]:first-child')
        ?.textContent.trim().split('\n')[0] || nameFromList || '未知'
    ).replace(/\s+/g, ' ').trim() || nameFromList || '未知';

    // 期望职位（source-job 或顶部职位字段）
    const title = (
      listItem.querySelector('span.source-job, [class*="source-job"]')?.textContent.trim() ||
      rightTop?.querySelector('[class*="expect"], [class*="position"], [class*="job-name"]')?.textContent.trim() || ''
    ).trim();

    const company = rightTop?.querySelector('[class*="company"]')?.textContent.trim() || '';

    // ── 右侧顶部整体信息（学历/工作年限等摘要行）
    const topText = (rightTop?.innerText || '').replace(/\s+/g, ' ').slice(0, 800);

    // ── 找聊天区中的附件简历按钮（两种形态）
    // 形态 A：「附件简历」（页面内展开预览）
    // 形态 B：「点击预览附件简历」（打开新 PDF 标签页）
    let extra = topText;
    let _resumeText = '';   // 最终提取到的简历全文（用于存入人选记录）
    let _pdfUrl = '';       // 附件简历的 PDF 直链（用于下载）

    setInboxStep(1, '查找附件简历按钮...');
    const attachBtn = [...document.querySelectorAll('a, button, span, div, p')]
      .find(el => {
        const t = (el.textContent || '').trim();
        return /^附件简历$|点击预览附件简历|预览附件简历|点击查看附件简历|查看附件简历/.test(t) && t.length < 30;
      });

    if (attachBtn) {
      const btnText = attachBtn.textContent.trim();
      log(`[收件箱] ✅ 找到按钮：「${btnText}」`);
      setInboxStep(1, `「${btnText}」— 点击中...`);

      const INLINE_SELS = [
        '[class*="resume-file-content"]',
        '[class*="lime-file-content"]',
        '[class*="resume-file-wrap"]',
        '[class*="resume-info-content"]',
        '[class*="resume-preview"]',
        '[class*="resume-detail"]',
        '[class*="resume-wrap"]',
        '[class*="resume-main"]',
        '[class*="geek-resume"]',
        '[class*="cv-wrap"]',
      ];

      // ── 从各种来源提取简历 PDF URL
      const findPdfUrl = () => {
        // 优先：Boss 内嵌 PDF 阅读器 iframe（bzl-office/pdf-viewer-b?url=...）
        for (const fr of document.querySelectorAll('iframe[src*="pdf-viewer"], iframe[src*="bzl-office"]')) {
          try {
            const u = new URL(fr.src);
            const raw = u.searchParams.get('url') || '';
            if (raw) {
              const full = raw.startsWith('http') ? raw : 'https://www.zhipin.com' + decodeURIComponent(raw);
              return full;
            }
          } catch (_) {}
        }
        // 其次：<a href> 直链
        for (const a of document.querySelectorAll('a[href]')) {
          const h = a.href || '';
          if (/\.(pdf|doc|docx)/i.test(h) || /resume|cv|attachment/i.test(h)) return h;
        }
        // 再次：data 属性
        for (const el of document.querySelectorAll('[data-url],[data-href],[data-src]')) {
          const h = el.dataset.url || el.dataset.href || el.dataset.src || '';
          if (/\.(pdf|doc|docx)/i.test(h)) return h;
        }
        return '';
      };

      // 记录点击前 inline 容器的文字快照（用于检测内容变化）
      const snapBefore = {};
      for (const sel of INLINE_SELS) {
        const el = document.querySelector(sel);
        if (el) snapBefore[sel] = (el.innerText || '').trim();
      }

      // ── 点击「附件简历」按钮（用 hoverThenClick 穿透 Vue 覆盖层）
      setInboxStep(1, '点击按钮，等待简历展开...');
      await flashClick(attachBtn, 700, true);
      await sleep(500);

      // ── 直接从页面内嵌 iframe 的 textLayer 读取简历文字
      // Boss 点击「附件简历」后，PDF 在当前聊天页内用 iframe 展开，
      // 同源（www.zhipin.com），可以直接访问 contentDocument。
      // 不需要开新标签页。
      setInboxStep(1, '等待简历 PDF 渲染...');
      const resumeText = await (async () => {
        const deadline = Date.now() + 15000;
        while (Date.now() < deadline) {
          for (const fr of document.querySelectorAll(
            'iframe[src*="bzl-office"], iframe[src*="pdf-viewer"]'
          )) {
            try {
              const iframeDoc = fr.contentDocument || fr.contentWindow?.document;
              if (!iframeDoc) continue;
              const spans = iframeDoc.querySelectorAll('.textLayer span[role="presentation"]');
              if (spans.length < 5) continue;

              // 按坐标（top/left %）重建阅读顺序
              const entries = Array.from(spans).map(span => {
                const style = span.getAttribute('style') || '';
                const top  = parseFloat((style.match(/top:\s*([\d.]+)%/)  || [0, 0])[1]);
                const left = parseFloat((style.match(/left:\s*([\d.]+)%/) || [0, 0])[1]);
                return { top, left, text: span.textContent || '' };
              }).filter(e => e.text.trim());

              entries.sort((a, b) =>
                Math.abs(a.top - b.top) < 0.8 ? a.left - b.left : a.top - b.top
              );

              // 按行分组（top 差 < 0.8% 视为同行）
              const rows = [];
              let curRow = [], lastTop = -999;
              for (const e of entries) {
                if (Math.abs(e.top - lastTop) > 0.8) {
                  if (curRow.length) rows.push(curRow);
                  curRow = [e]; lastTop = e.top;
                } else {
                  curRow.push(e);
                }
              }
              if (curRow.length) rows.push(curRow);

              const text = rows.map(r => r.map(e => e.text).join(' ')).join('\n').trim();
              if (text.length > 20) {
                log(`[收件箱] 📄 iframe textLayer 提取：${text.length} 字符`);
                if (!_pdfUrl) _pdfUrl = findPdfUrl(); // iframe 仍在时抓 PDF 直链
                return text.slice(0, 6000);
              }
            } catch (_) { /* iframe 未就绪，继续等 */ }
          }
          await sleep(400);
        }
        log('[收件箱] ⚠️ textLayer 等待超时');
        return '';
      })();

      if (resumeText) {
        log(`[收件箱] 📄 简历提取完成：${resumeText.length} 字符`);
        // 模拟真人阅读速度：按字数估算停留时间（约 1.5~2.5 秒）
        const readMs = Math.min(800 + Math.round(resumeText.length * 0.8), 2500);
        setInboxStep(1, `阅读中… (${resumeText.length} 字)`);
        await sleep(readMs);
        setInboxStep(1, `读取完成 ${resumeText.length} 字`);
        _resumeText = resumeText;
        extra = topText + '\n\n【附件简历内容】\n' + resumeText;
      } else {
        log(`[收件箱] ⚠️ 简历内容提取失败，使用顶部摘要`);
        setInboxStep(1, '⚠️ 提取失败，使用顶部摘要');
      }

      // 关闭内嵌简历：找关闭按钮，兜底按 Escape
      await sleep(600);
      {
        const CLOSE_SELS = [
          '[class*="lime-file"] [class*="close"]',
          '[class*="resume-file"] [class*="close"]',
          '[class*="resume"] [class*="close-btn"]',
          '[class*="resume"] [class*="back"]',
          '[class*="preview"] [class*="close"]',
          '[class*="dialog"] [class*="close"]',
          '[class*="modal"] [class*="close"]',
        ];
        let closed = false;
        for (const sel of CLOSE_SELS) {
          const btn = document.querySelector(sel);
          if (btn && btn.offsetParent !== null) {
            log(`[收件箱] 🗙 关闭简历弹窗（${sel}）`);
            await flashClick(btn, 300);
            await sleep(400);
            closed = true;
            break;
          }
        }
        if (!closed) {
          log(`[收件箱] 🗙 按 Escape 关闭简历弹窗`);
          document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, keyCode: 27 }));
          await sleep(400);
        }
      }

    } else {
      // 没有附件按钮 —— 直接用聊天区文字
      log(`[收件箱] ⚠️ 未找到附件简历按钮，读取聊天记录文字`);
      setInboxStep(1, '未找到按钮，读聊天记录');
      const msgArea = document.querySelector(
        '[class*="chat-conversation"], [class*="message-list"], [class*="msg-list"], ' +
        '[class*="chat-content"], [class*="im-chat"]'
      );
      if (msgArea) {
        const msgText = (msgArea.innerText || '').slice(0, 3000);
        if (msgText.length > 30) extra = topText + '\n\n' + msgText;
      }
    }

    return { name, title, company, experience: '', education: '', skills: '', extra, resumeText: _resumeText, pdfUrl: _pdfUrl };
  }

  /** 主循环：遍历已获取简历的候选人列表 */
  async function processInboxCandidates(profile) {
    let processedCount = 0;
    const processedNames = new Set();
    log(`[收件箱] 开始处理岗位：${profile.name || profile.jobTitle}（15天内已处理的自动跳过）`);

    while (!_taskStopped) {
      if (await checkPauseStop()) return;

      const items = getInboxListItems();
      const item  = items.find(el => !el.dataset.inboxDone && el.offsetParent !== null);

      if (!item) {
        // 尝试滚动加载更多
        const leftPanel = document.querySelector(
          '[class*="chat-left"], [class*="left-panel"], [class*="sidebar"], .chat-navbar, ' +
          '[class*="chat-list-wrap"], [class*="geek-list-wrap"]'
        ) || items[0]?.parentElement;
        if (leftPanel) {
          const before = items.length;
          leftPanel.scrollTop = leftPanel.scrollHeight;
          log('[收件箱] 滚动加载更多...');
          await sleep(2000);
          const after = getInboxListItems().length;
          if (after > before) continue;
        }
        log('[收件箱] 列表已到底，处理完毕');
        break;
      }

      item.dataset.inboxDone = '1';

      // 取列表中候选人名字（geek-name 是确认的真实 class）
      const listName = (
        item.querySelector('span.geek-name, [class*="geek-name"]')?.textContent.trim() ||
        item.querySelector('[class*="name"]')?.textContent.trim().split('\n')[0] ||
        `候选人${processedCount + 1}`
      ).trim();
      if (processedNames.has(listName)) continue;

      // 15天内已处理 → 跳过，灰化显示
      if (await isSeenRecently(listName)) {
        log(`[收件箱] ⏭ 15天内已筛选，跳过：${listName}`);
        item.style.opacity = '0.35';
        item.title = '15天内已筛选';
        continue;
      }

      // 步骤 0：点击候选人
      setInboxStep(0, '', listName);
      log(`[收件箱] 点击：${listName}`);
      highlightInboxItem(item);
      await flashClick(item, 500);
      await sleep(rand(800, 1400));
      if (await checkPauseStop()) { highlightInboxItem(null); return; }

      // 步骤 1：读取附件简历
      setInboxStep(1, '查找简历按钮...');
      const info = await extractInboxCandidateInfo(item);
      const candidateName = (info.name !== '未知' && info.name) ? info.name : listName;
      info.name = candidateName;
      processedNames.add(listName);
      // 持久化：标记为已筛选（15天内再次运行自动跳过）
      markSeen(listName);
      markSeen(candidateName);
      processedCount++;
      updateInboxStats(processedCount, _inboxPanelState.matched);
      log(`[收件箱] 读取：${candidateName}（${info.title || ''}${info.company ? ' @ ' + info.company : ''}）`);

      if (await checkPauseStop()) return;

      // 步骤 2：AI 评估
      setInboxStep(2, '分析匹配度...');
      log(`[收件箱] AI评估：${candidateName}`);
      let evalResult = null;
      try {
        const resp = await chrome.runtime.sendMessage({
          type: 'EVALUATE_CANDIDATE',
          candidateInfo: {
            name: info.name, title: info.title, company: info.company,
            experience: info.experience, education: info.education,
            skills: info.skills, extra: info.extra,
          },
        });
        evalResult = resp?.result;
      } catch (e) { logErr(`[收件箱] AI评估失败：${e.message}`); }

      if (!evalResult) {
        setInboxStep(2, '❌ 评估失败，跳过');
        await chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'failed' }).catch(() => {});
        highlightInboxItem(null);
        await sleep(800); continue;
      }

      const { score, suitable, reason } = evalResult;
      const isMatch = suitable && Number(score) >= (profile.scoreThreshold ?? 70);
      log(`[收件箱] ${candidateName} ${score}分 ${suitable ? '✓ 匹配' : '✗ 不匹配'} — ${reason}`);

      if (!isMatch) {
        // 不匹配：步骤停在第 2 步，显示原因
        setInboxStep(2, `✗ ${score}分 — ${(reason || '').slice(0, 30)}`);
        highlightInboxItem(null);
        await sleep(rand(600, 1000));
        continue;
      }

      // 步骤 3：记录结果（匹配）
      setInboxStep(3, `✅ ${score}分 匹配`);
      log(`[收件箱] ✅ 匹配：${candidateName}（${score}分）`);
      // 高亮变绿
      const activeEl = document.querySelector('[data-inbox-active]');
      if (activeEl) { activeEl.style.background = 'rgba(0,217,197,0.14)'; activeEl.style.borderLeft = '3px solid #00D9C5'; }

      await chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'messaged' }).catch(() => {});
      await chrome.runtime.sendMessage({
        type: 'SAVE_MATCHED_CANDIDATE',
        candidate: {
          name: candidateName, title: info.title || '', company: info.company || '',
          experience: info.experience || '', education: info.education || '',
          skills: info.skills || '', score, reason,
          highlights: evalResult.highlights || '',
          stability: evalResult.stability || '',
          interviewReason: evalResult.interviewReason || '',
          action: 'inbox_matched', timestamp: Date.now(),
          jobName: profile.name || profile.jobTitle,
          sourceMode: 'inbox',
          resumeText: info.resumeText || '',
          pdfUrl: info.pdfUrl || '',
        },
      }).catch(() => {});

      // 自动下载附件简历 PDF
      if (info.pdfUrl) {
        const dateStr = new Date().toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' }).replace(/\//g, '');
        const safeName = candidateName.replace(/[\\/:*?"<>|]/g, '_');
        const jobShort = (profile.name || profile.jobTitle || '').slice(0, 10).replace(/[\\/:*?"<>|]/g, '_');
        const filename = `简历_${safeName}_${jobShort}_${dateStr}.pdf`;
        chrome.runtime.sendMessage({ type: 'DOWNLOAD_RESUME', url: info.pdfUrl, filename }).catch(() => {});
        log(`[收件箱] ⬇ 触发下载：${filename}`);
      }

      const matched = _inboxPanelState.matched + 1;
      updateInboxStats(processedCount, matched);
      _inboxPanelState.matched = matched;

      const delay = rand(1800, 3000);
      setInboxStep(3, `⏸ 冷却 ${(delay / 1000).toFixed(1)}s...`);
      highlightInboxItem(null);
      await sleep(delay);
    }

    hideInboxStatus();
    log(`[收件箱] 共处理 ${processedCount} 位候选人`);
  }

  // ─── 收件箱状态浮窗（步骤进度版）────────────────────────────────────────────

  // 步骤定义（固定顺序）
  const INBOX_STEPS = ['点击候选人', '读取附件简历', 'AI 评估', '记录结果'];

  // 当前浮窗状态
  let _inboxPanelState = { name: '', step: -1, stepDetail: '', processed: 0, matched: 0 };

  function getInboxStatusEl() {
    let el = document.getElementById('__boss_inbox_status__');
    if (!el) {
      el = document.createElement('div');
      el.id = '__boss_inbox_status__';
      el.style.cssText = [
        'position:fixed', 'bottom:24px', 'right:24px', 'z-index:2147483647',
        'background:rgba(14,20,30,0.96)', 'color:#fff',
        'padding:14px 18px', 'border-radius:12px',
        'font-size:13px', 'line-height:1.6', 'min-width:240px',
        'box-shadow:0 6px 24px rgba(0,0,0,0.5)',
        'cursor:pointer', 'font-family:sans-serif',
        'border:1px solid rgba(0,217,197,0.25)',
      ].join(';');
      el.title = '点击打开操作台';
      el.addEventListener('click', () => {
        chrome.runtime.sendMessage({ type: 'OPEN_POPUP' }).catch(() => {});
      });
      // ✖ 关闭按钮
      const closeBtn = document.createElement('div');
      closeBtn.title = '关闭';
      closeBtn.textContent = '✕';
      closeBtn.style.cssText = [
        'position:absolute', 'top:8px', 'right:10px',
        'width:18px', 'height:18px', 'line-height:18px', 'text-align:center',
        'border-radius:50%', 'background:rgba(255,255,255,0.18)', 'color:#ccc',
        'font-size:11px', 'cursor:pointer', 'z-index:1',
        'transition:background 0.15s',
      ].join(';');
      closeBtn.addEventListener('mouseenter', () => { closeBtn.style.background = 'rgba(255,255,255,0.35)'; });
      closeBtn.addEventListener('mouseleave', () => { closeBtn.style.background = 'rgba(255,255,255,0.18)'; });
      closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        el.style.display = 'none';
        _inboxStatusHiddenByUser = true;
      });
      el.appendChild(closeBtn);
      // 内容容器
      const content = document.createElement('div');
      content.id = '__boss_inbox_status__content';
      el.appendChild(content);
      document.body.appendChild(el);
    }
    return el;
  }

  function renderInboxStatus() {
    try {
      if (_inboxStatusHiddenByUser) return;
      const el = getInboxStatusEl();
      const { name, step, stepDetail, processed, matched } = _inboxPanelState;

      const stepsHtml = INBOX_STEPS.map((label, i) => {
        let icon, color;
        if (i < step)       { icon = '✅'; color = '#6ee6de'; }   // 已完成
        else if (i === step) { icon = '⏳'; color = '#fff'; }      // 进行中
        else                 { icon = '○'; color = '#555'; }       // 待执行
        const detail = (i === step && stepDetail)
          ? `<span style="color:#aaa;font-size:11px;margin-left:4px">${stepDetail}</span>` : '';
        return `<div style="color:${color}">${icon} ${label}${detail}</div>`;
      }).join('');

      el.style.display = '';
      const content = el.querySelector('#__boss_inbox_status__content') || el;
      content.innerHTML =
        `<div style="font-weight:700;margin-bottom:8px;color:#00D9C5;font-size:14px">🤖 AI 智能筛选</div>` +
        (name ? `<div style="margin-bottom:8px;font-weight:600;border-bottom:1px solid rgba(255,255,255,0.1);padding-bottom:6px">👤 ${name}</div>` : '') +
        `<div style="margin-bottom:8px">${stepsHtml}</div>` +
        `<div style="color:#888;font-size:11px;border-top:1px solid rgba(255,255,255,0.08);padding-top:6px">` +
        `已处理 <b style="color:#fff">${processed}</b> 人 · 匹配 <b style="color:#00D9C5">${matched}</b> 人</div>`;
    } catch (_) {}
  }

  /**
   * 更新收件箱浮窗状态
   * @param {string} name       候选人姓名（传 null 保持不变）
   * @param {number} step       当前步骤索引 0-3（传 -1 保持不变）
   * @param {string} stepDetail 步骤补充说明（传 null 保持不变）
   */
  function showInboxStatus(title, line1, line2 = '') {
    // 兼容旧调用格式：showInboxStatus(title, line1, line2)
    // 解析：title 通常是 '📥 已获取简历' 或 '❌'，line1 是候选人，line2 是步骤
    if (line1 !== undefined) {
      // 从 line1 提取姓名（去掉 emoji 前缀）
      const nameMatch = line1.replace(/^[👤✅✗❌⏸⏳📥\s]+/, '').split('（')[0].trim();
      if (nameMatch && nameMatch.length > 0 && nameMatch.length < 20) {
        _inboxPanelState.name = nameMatch;
      }
    }
    renderInboxStatus();
  }

  /** 精确控制步骤进度（新 API） */
  function setInboxStep(step, stepDetail = '', name = null) {
    if (name !== null) _inboxPanelState.name = name;
    _inboxPanelState.step = step;
    _inboxPanelState.stepDetail = stepDetail;
    renderInboxStatus();
  }

  /** 更新统计数字 */
  function updateInboxStats(processed, matched) {
    _inboxPanelState.processed = processed;
    _inboxPanelState.matched = matched;
    renderInboxStatus();
  }

  function hideInboxStatus() {
    try { document.getElementById('__boss_inbox_status__')?.remove(); } catch (_) {}
    _inboxPanelState = { name: '', step: -1, stepDetail: '', processed: 0, matched: 0 };
    _inboxStatusHiddenByUser = false;
  }

  /**
   * 全部完成后弹出页面内提示横幅（5 秒后自动消失）
   * 告知用户去人选记录查看，并可开展其他操作。
   */
  function showInboxDoneToast(matched, jobCount) {
    const id = '__boss_done_toast__';
    document.getElementById(id)?.remove();
    const el = document.createElement('div');
    el.id = id;
    el.style.cssText = [
      'position:fixed', 'bottom:32px', 'left:50%', 'transform:translateX(-50%)',
      'z-index:2147483647', 'background:linear-gradient(135deg,#0D3B2E,#0A4A3A)',
      'border:1.5px solid #00D9C5', 'border-radius:14px',
      'padding:16px 26px', 'min-width:320px', 'max-width:460px',
      'box-shadow:0 8px 32px rgba(0,217,197,0.25)',
      'font-family:sans-serif', 'color:#E8FFF8', 'text-align:center',
      'animation:__bossSlideUp 0.35s ease',
    ].join(';');
    el.innerHTML = `
      <style>@keyframes __bossSlideUp{from{opacity:0;transform:translateX(-50%) translateY(20px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}</style>
      <div style="font-size:20px;margin-bottom:6px">✅</div>
      <div style="font-size:14px;font-weight:700;margin-bottom:4px">简历筛选完毕</div>
      <div style="font-size:12.5px;color:#9EEEE6;line-height:1.6">
        共筛选 <b style="color:#fff">${jobCount}</b> 个岗位，找到
        <b style="color:#00D9C5">${matched}</b> 位合适人选<br>
        可前往「人选记录」查看简历 · 安排面试 · 直接沟通
      </div>
    `;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 6000);
  }

  /** 高亮候选人列表项 */
  function highlightInboxItem(el) {
    // 清除之前高亮
    document.querySelectorAll('[data-inbox-active]').forEach(prev => {
      prev.style.background = '';
      prev.style.borderLeft = '';
      prev.style.transition = '';
      delete prev.dataset.inboxActive;
    });
    if (!el) return;
    el.dataset.inboxActive = '1';
    el.style.transition = 'background 0.2s';
    el.style.background = 'rgba(0,217,197,0.08)';
    el.style.borderLeft = '3px solid #00D9C5';
    el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

} // end initBossRecruiter
