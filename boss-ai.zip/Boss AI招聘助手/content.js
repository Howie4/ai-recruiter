/**
 * content.js — Boss AI 招聘助手页面自动化核心
 *
 * 推荐牛人模式流程：
 *   Step 1: 点击「推荐牛人」进入推荐页
 *   Step 2: 在岗位下拉框中搜索并选中目标岗位
 *   Step 3: 遍历推荐候选人列表，逐一读取资料
 *   Step 4: AI 评估匹配度（EVALUATE_CANDIDATE → background.js）
 *   Step 5: 匹配 → 点击「打招呼」按钮（点击即发送，无弹窗）
 */

const _isInIframe = window.self !== window.top;

if (window.__bossRecruiterLoaded) {
  chrome.runtime.sendMessage({ type: 'LOG', level: 'info', message: `[Boss助手] content.js 已加载（${_isInIframe ? 'iframe' : '主文档'}），跳过重复注入` }).catch(() => {});
} else {
  window.__bossRecruiterLoaded = true;
  chrome.runtime.sendMessage({
    type: 'LOG', level: 'info',
    message: `[Boss助手] 初始化 | URL: ${location.href.slice(0, 80)} | 框架: ${_isInIframe ? 'iframe' : '主文档'}`
  }).catch(() => {});
  initBossRecruiter();
}

function initBossRecruiter() {

  // ─── 右下角胶囊按钮（仅主文档注入，iframe 内跳过） ───────────────────────────
  if (!_isInIframe) (function injectCapsule() {
    if (document.getElementById('__boss_capsule__')) return;

    // 外层容器（胶囊 + ✖ 组合）
    const wrap = document.createElement('div');
    wrap.id = '__boss_capsule__';
    wrap.style.cssText = [
      'position:fixed', 'bottom:24px', 'right:24px', 'z-index:2147483646',
      'display:flex', 'align-items:center', 'gap:6px',
      'font-family:sans-serif', 'user-select:none',
    ].join(';');

    // 主胶囊按钮
    const btn = document.createElement('div');
    btn.textContent = '🤖 招聘助';
    btn.style.cssText = [
      'background:linear-gradient(135deg,#00D9C5,#00A898)',
      'color:#fff', 'font-size:13px', 'font-weight:600',
      'padding:9px 18px', 'border-radius:999px',
      'box-shadow:0 4px 16px rgba(0,217,197,0.4)',
      'cursor:pointer',
      'transition:transform 0.15s,box-shadow 0.15s',
      'letter-spacing:0.3px',
    ].join(';');
    btn.addEventListener('mouseenter', () => {
      btn.style.transform = 'scale(1.06)';
      btn.style.boxShadow = '0 6px 22px rgba(0,217,197,0.5)';
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.transform = '';
      btn.style.boxShadow = '0 4px 16px rgba(0,217,197,0.4)';
    });
    btn.addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'OPEN_POPUP' }).catch(() => {});
    });

    // ✖ 关闭按钮
    const closeBtn = document.createElement('div');
    closeBtn.textContent = '✕';
    closeBtn.title = '关闭';
    closeBtn.style.cssText = [
      'width:20px', 'height:20px', 'border-radius:50%',
      'background:rgba(0,0,0,0.35)', 'color:#fff',
      'font-size:11px', 'line-height:20px', 'text-align:center',
      'cursor:pointer', 'flex-shrink:0',
      'transition:background 0.15s',
    ].join(';');
    closeBtn.addEventListener('mouseenter', () => { closeBtn.style.background = 'rgba(0,0,0,0.6)'; });
    closeBtn.addEventListener('mouseleave', () => { closeBtn.style.background = 'rgba(0,0,0,0.35)'; });
    let dismissed = false;
    let wasHiddenByStatus = false;

    closeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      dismissed = true;
      wrap.style.display = 'none';
    });

    wrap.appendChild(btn);
    wrap.appendChild(closeBtn);
    document.body.appendChild(wrap);

    // 有状态提示框时隐藏胶囊；状态框消失时自动恢复（除非用户主动关闭过）
    setInterval(() => {
      const iDoc = getIframeDoc();
      const hasStatus = !!(
        (iDoc && iDoc.querySelector('#__boss_status__'))
        || document.getElementById('__boss_search_status__')
      );
      if (hasStatus) {
        wrap.style.display = 'none';
        wasHiddenByStatus = true;
      } else if (wasHiddenByStatus && !dismissed) {
        // 状态框刚消失（任务结束），自动恢复胶囊
        wrap.style.display = '';
        wasHiddenByStatus = false;
      }
    }, 500);
  })();

  // ─── 全局状态 ─────────────────────────────────────────────────────────────
  let _taskRunning = false;
  let _taskPaused  = false;
  let _taskStopped = false;
  let _curProfiles = [];
  let _stats = { processed: 0, matched: 0, messaged: 0, failed: 0 };

  // ─── 基础工具 ─────────────────────────────────────────────────────────────
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const rand  = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

  function log(msg, level = 'info') {
    console.log(`[Boss助手] ${msg}`);
    chrome.runtime.sendMessage({ type: 'LOG', level, message: msg }).catch(() => {});
  }
  function logErr(msg) { log(msg, 'error'); }
  function logWarn(msg) { log(msg, 'warn'); }

  /** 模拟完整鼠标点击（mouseenter→mouseover→mousedown→mouseup→click），兼容 Vue 事件 */
  function realClick(el) {
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top  + rect.height / 2;
    const opts = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy };
    ['mouseenter', 'mouseover', 'mousedown', 'mouseup', 'click'].forEach(type =>
      el.dispatchEvent(new MouseEvent(type, opts))
    );
  }

  /** 按文字精确匹配元素 */
  function findByText(text, selector = '*', root = document) {
    for (const el of root.querySelectorAll(selector)) {
      if (el.textContent.trim() === text) return el;
    }
    return null;
  }

  /** 等待元素出现 */
  async function waitForEl(selector, timeoutMs = 8000, root = document) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      const el = root.querySelector(selector);
      if (el) return el;
      await sleep(200);
    }
    return null;
  }

  /** 等待文字元素出现 */
  async function waitForText(text, selector = '*', timeoutMs = 8000, root = document) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      const el = findByText(text, selector, root);
      if (el) return el;
      await sleep(200);
    }
    return null;
  }

  /** 模拟人工输入（逐字） */
  async function humanType(el, text) {
    el.focus();
    el.value = '';
    el.dispatchEvent(new Event('input', { bubbles: true }));
    for (const ch of text) {
      el.value += ch;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(rand(60, 160));
    }
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  /** 模拟人工输入（contenteditable div） */
  async function humanTypeContentEditable(el, text) {
    el.focus();
    el.textContent = '';
    el.dispatchEvent(new Event('input', { bubbles: true }));
    for (const ch of text) {
      document.execCommand('insertText', false, ch);
      await sleep(rand(60, 160));
    }
  }

  /** 检查暂停/停止，返回 true = 已停止 */
  async function checkPauseStop() {
    while (_taskPaused && !_taskStopped) await sleep(400);
    return _taskStopped;
  }

  // ─── 消息监听 ─────────────────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    switch (msg.type) {
      case 'PING':
        sendResponse({ loaded: true });
        return true;

      case 'RUN_TASK':
        if (_isInIframe) { sendResponse({ skipped: true }); return true; }
        _curProfiles = msg.profiles || [];
        runSocialTask().catch(e => logErr(`任务异常: ${e.message}`));
        sendResponse({ success: true });
        return true;

      case 'RUN_RECRUIT_TASK':
        _curProfiles = msg.profiles || [];
        if (_isInIframe) {
          // iframe 中：等待本框架的搜索 UI 出现后再运行（若本 iframe 无搜索 UI 则静默跳过）
          (async () => {
            const t0 = Date.now();
            while (Date.now() - t0 < 5000) {
              if (document.querySelector(SEARCH_INDICATOR)) {
                log(`[iframe] 检测到搜索 UI，在 iframe 中运行搜索任务（URL: ${location.href.slice(0, 60)}）`);
                runRecruitTask().catch(e => logErr(`招聘任务异常(iframe): ${e.message}`));
                return;
              }
              await sleep(300);
            }
            // 本 iframe 无搜索 UI，静默跳过
          })();
        } else {
          runRecruitTask().catch(e => logErr(`招聘任务异常: ${e.message}`));
        }
        sendResponse({ success: true });
        return true;

      case 'STOP_TASK_CONTENT':
        _taskStopped = true;
        _taskRunning = false;
        sessionStorage.removeItem('__boss_recruiter_active');
        log('任务已停止');
        sendResponse({ success: true });
        return true;

      case 'SET_PAUSED':
        _taskPaused = !!msg.paused;
        sendResponse({ success: true });
        return true;
    }
  });

  // ═══════════════════════════════════════════════════════════════════════════
  //  推荐牛人模式（👥 Boss搜索）
  // ═══════════════════════════════════════════════════════════════════════════

  async function runSocialTask() {
    if (_taskRunning) return;
    _taskRunning = true;
    _taskStopped = false;
    _taskPaused  = false;
    sessionStorage.setItem('__boss_recruiter_active', '1');

    await chrome.runtime.sendMessage({ type: 'START_TASK', profiles: _curProfiles }).catch(() => {});

    for (let pi = 0; pi < _curProfiles.length; pi++) {
      if (_taskStopped) break;
      const profile = _curProfiles[pi];
      await chrome.runtime.sendMessage({ type: 'SET_ACTIVE_JOB', profileId: profile.id }).catch(() => {});
      log(`开始处理岗位：${profile.name || profile.jobTitle}`);
      await runRecommendLoop(profile);
      if (_taskStopped) break;
    }

    sessionStorage.removeItem('__boss_recruiter_active');
    _taskRunning = false;
    log('所有岗位处理完毕');
  }

  /** 推荐牛人模式主循环 */
  async function runRecommendLoop(profile) {

    // ── Step 1: 点击「推荐牛人」──────────────────────────────────────────────
    log('Step 1: 点击「推荐牛人」');
    const recommendBtn = await clickRecommendTab();
    if (!recommendBtn) {
      logErr('找不到「推荐牛人」按钮，中止本岗位');
      return;
    }
    await sleep(rand(1500, 2500));
    if (await checkPauseStop()) return;

    // ── Step 2: 选择目标岗位 ─────────────────────────────────────────────────
    log(`Step 2: 选择岗位「${profile.jobTitle || profile.name}」`);
    const jobSelected = await selectJobInDropdown(profile.jobTitle || profile.name);
    if (!jobSelected) {
      logErr(`未能选中岗位，中止本岗位`);
      return;
    }
    await sleep(rand(1200, 2000));
    if (await checkPauseStop()) return;

    // ── Step 3~5: 遍历候选人，AI评估，打招呼 ─────────────────────────────────
    log('Step 3: 开始遍历推荐候选人');
    await processRecommendCandidates(profile);
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Step 1: 点击「推荐牛人」
  // ─────────────────────────────────────────────────────────────────────────
  async function clickRecommendTab() {
    let btn = findByText('推荐牛人', 'span');
    if (!btn) btn = await waitForText('推荐牛人', 'span', 5000);
    if (!btn) { logErr('找不到「推荐牛人」span'); return null; }
    log('点击「推荐牛人」');
    realClick(btn);
    return btn;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Step 2: 岗位选择下拉
  // ─────────────────────────────────────────────────────────────────────────
  /** 查找岗位下拉的搜索框 */
  function findJobSearchInput() {
    return document.querySelector('input.ipt.chat-job-search')
      || document.querySelector('input[placeholder="请输入职位名称"]')
      || document.querySelector('[class*="chat-job-search"]')
      || document.querySelector('.top-chat-search input')
      || document.querySelector('[class*="dropmenu"] input[placeholder]')
      || document.querySelector('[class*="drop"] input[placeholder]');
  }

  /** 获取岗位下拉触发器（在 iframe 内） */
  function findDropLabel(iDoc) {
    const doc = iDoc || getIframeDoc() || document;
    const wrap = doc.querySelector('.job-selecter-wrap');
    if (wrap) return wrap.querySelector('.ui-dropmenu-label') || wrap;
    return null;
  }

  /** 查找岗位下拉的搜索框（在 iframe 内 .top-chat-search） */
  function findJobSearchInput(iDoc) {
    const doc = iDoc || getIframeDoc() || document;
    return doc.querySelector('.top-chat-search input') || null;
  }

  async function selectJobInDropdown(jobTitle) {
    if (!jobTitle) { logErr('岗位名为空'); return false; }

    // 等 iframe 加载好再操作
    let iDoc = getIframeDoc();
    if (!iDoc) {
      const t0 = Date.now();
      while (Date.now() - t0 < 8000) {
        iDoc = getIframeDoc();
        if (iDoc && iDoc.querySelector('.job-selecter-wrap')) break;
        await sleep(300);
      }
    }
    if (!iDoc) { logErr('iframe 未加载'); return false; }

    // ── 前置检查：当前是否已显示目标岗位 ─────────────────────────────────────
    let dropLabel = findDropLabel(iDoc);
    if (!dropLabel) {
      // 再等 5s
      const t0 = Date.now();
      while (Date.now() - t0 < 5000) {
        dropLabel = findDropLabel(iDoc);
        if (dropLabel) break;
        await sleep(300);
      }
    }
    if (!dropLabel) { logErr('找不到岗位选择器（.job-selecter-wrap）'); return false; }

    const currentText = dropLabel.textContent.trim();
    const key = jobKey(jobTitle);
    if (currentText.replace(/\s/g, '').includes(key)) {
      log(`当前岗位已是「${currentText.slice(0, 30)}」，无需切换`);
      return true;
    }

    // ── 点击展开下拉 ──────────────────────────────────────────────────────────
    log(`展开岗位选择框（当前：${currentText.slice(0, 20)}）`);
    realClick(dropLabel);
    await sleep(rand(1000, 1500));

    // ── 等待 job-list 出现 ────────────────────────────────────────────────────
    let jobList = null;
    const t1 = Date.now();
    while (Date.now() - t1 < 5000) {
      jobList = iDoc.querySelector('ul.job-list');
      if (jobList) break;
      await sleep(300);
    }
    if (!jobList) { logErr('岗位列表（ul.job-list）未出现'); return false; }

    // ── 若有搜索框，先搜索缩小范围 ────────────────────────────────────────────
    const searchInput = findJobSearchInput(iDoc);
    if (searchInput) {
      log(`输入搜索关键词：「${jobTitle.slice(0, 8)}」`);
      await humanType(searchInput, jobTitle.slice(0, 8));
      await sleep(rand(600, 1000));
    }

    // ── 从 ul.job-list li 中选目标岗位 ───────────────────────────────────────
    return await pickJobOption(iDoc, jobTitle);
  }

  async function pickJobOption(iDoc, jobTitle) {
    await sleep(400);
    const key = jobKey(jobTitle);
    const jobList = iDoc.querySelector('ul.job-list');

    if (jobList) {
      const items = [...jobList.querySelectorAll('li')].filter(
        li => li.offsetParent !== null && !li.textContent.includes('调整顺序')
      );
      log(`ul.job-list 共 ${items.length} 个可见选项`);

      const exact = items.find(li => li.textContent.replace(/\s/g, '').includes(key));
      if (exact) {
        log(`选中岗位：「${exact.textContent.trim().slice(0, 40)}」`);
        realClick(exact);
        return true;
      }
      if (items.length) {
        log(`未精确匹配「${key}」，选第一个：「${items[0].textContent.trim().slice(0, 40)}」`);
        realClick(items[0]);
        return true;
      }
    }

    logErr('未找到 ul.job-list 或列表为空');
    return false;
  }

  /** 岗位名匹配：去空格后全串，回退时取前8字 */
  function jobKey(jobTitle) {
    return jobTitle.replace(/\s/g, '');
  }

  /** 计算岗位名匹配得分（越高越好）— 用于选最近似选项 */
  function jobMatchScore(candidate, target) {
    const c = candidate.replace(/\s/g, '');
    const t = target.replace(/\s/g, '');
    if (c === t) return 100;
    if (c.includes(t) || t.includes(c)) return 80;
    // 按字符逐段匹配：计算最长公共子串
    let score = 0;
    for (let len = t.length; len >= 2; len--) {
      for (let i = 0; i <= t.length - len; i++) {
        if (c.includes(t.slice(i, i + len))) { score = Math.max(score, len); break; }
      }
    }
    return score;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Step 3~5: 遍历候选人、AI评估、打招呼
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * 获取推荐牛人 iframe 的 document（候选人列表在 iframe 里）
   */
  function getIframeDoc() {
    const iframe = document.querySelector('iframe[name="recommendFrame"]');
    return iframe?.contentDocument || iframe?.contentWindow?.document || null;
  }

  /**
   * 获取当前 iframe 内所有推荐候选人的「打招呼」按钮，
   * 并从每个按钮向上找到对应的候选人卡片容器。
   */
  function getRecommendCards() {
    const iDoc = getIframeDoc();
    if (!iDoc) return [];
    const greetBtns = [...iDoc.querySelectorAll('button.btn.btn-greet')];
    if (!greetBtns.length) return [];

    return greetBtns.map(btn => {
      let card = btn;
      for (let i = 0; i < 8; i++) {
        card = card.parentElement;
        if (!card) break;
        if (card.querySelector('.name-wrap') || card.querySelector('span.name')) break;
      }
      return { card: card || btn.parentElement, greetBtn: btn };
    }).filter(x => x.card);
  }

  /**
   * 从候选人卡片中提取资料信息
   * 只读取有效 section（geek-base-info / geek-expect / geek-work / geek-education），
   * 「牛人分析器」及以下内容忽略。
   */
  function extractCandidateInfo(card) {
    // 姓名
    const name = card.querySelector('span.name')?.textContent.trim() || '未知';
    // 活跃状态
    const activeText = card.querySelector('span.active-text')?.textContent.trim() || '';

    // ── 从 resume-detail-wrap 内的有效 section 拼装文本 ──────────────────────
    const USEFUL_SECTIONS = [
      '.geek-base-info-wrap',
      '.geek-expect-wrap',
      '.geek-work-experience-wrap',
      '.geek-education-experience-wrap',
    ];

    const detailWrap = card.querySelector('.resume-detail-wrap') || card;
    const sectionTexts = [];

    for (const sel of USEFUL_SECTIONS) {
      const sec = detailWrap.querySelector(sel);
      if (sec) sectionTexts.push(sec.innerText || sec.textContent || '');
    }

    // 如果没找到 detail-wrap 结构，退回整个卡片文本（截断到牛人分析器之前）
    let extra = sectionTexts.length
      ? sectionTexts.join('\n')
      : (card.innerText || card.textContent || '');

    // 去掉「牛人分析器」之后的内容
    const cutIdx = extra.indexOf('牛人分析器');
    if (cutIdx > -1) extra = extra.slice(0, cutIdx);

    // ── 结构化字段（从 extra 中补充，供日志使用）─────────────────────────────
    const lines = extra.split('\n').map(s => s.trim()).filter(Boolean);
    const title   = card.querySelector('.geek-expect-wrap [class*="expect-job"]')
                 ?.textContent.trim() || lines[1] || '';
    const company = card.querySelector('.geek-work-experience-wrap [class*="company"]')
                 ?.textContent.trim() || '';
    const experience = card.querySelector('.geek-expect-wrap [class*="exp"], [class*="year"]')
                    ?.textContent.trim() || '';
    const education  = card.querySelector('.geek-education-experience-wrap [class*="school"]')
                    ?.textContent.trim() || '';
    const skills = [...card.querySelectorAll('.geek-base-info-wrap [class*="tag"], .geek-base-info-wrap [class*="skill"]')]
                   .map(e => e.textContent.trim()).filter(Boolean).join('、');

    return { name, activeText, title, company, experience, education, skills, extra };
  }

  /**
   * 获取候选人列表项（iframe 内）
   * 返回包含 span.name 的卡片元素数组
   */
  function getCandidateListItems(iDoc) {
    // 优先用已知 class
    const byCard = [...iDoc.querySelectorAll('[class*="candidate-card-wrap"], [class*="geek-item"]')];
    if (byCard.length) return byCard;
    // 兜底：找 span.name 的祖先（包含 btn-greet 的最近容器）
    const seen = new Set();
    const items = [];
    iDoc.querySelectorAll('span.name').forEach(nameEl => {
      let el = nameEl;
      for (let i = 0; i < 8; i++) {
        el = el.parentElement;
        if (!el) break;
        if (el.querySelector('button.btn.btn-greet')) { if (!seen.has(el)) { seen.add(el); items.push(el); } break; }
      }
    });
    return items;
  }

  /**
   * 等待详情面板出现（iframe 内）
   * 判断依据：有 button.btn-v2.btn-sure-v2.btn-greet 或 .resume-detail-wrap
   */
  async function waitForDetailPanel(iDoc, timeoutMs = 8000) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      const el = iDoc.querySelector(
        'button.btn-v2.btn-sure-v2.btn-greet, .resume-detail-wrap, .resume-item-detail, .resume-layout-wrap'
      );
      if (el) return true;
      await sleep(300);
    }
    return false;
  }

  /**
   * 等待详情面板关闭（回到列表页）
   * 判断依据：button.btn-v2.btn-sure-v2.btn-greet 消失 且 列表按钮重新可见
   */
  async function waitForListReturn(iDoc, timeoutMs = 6000) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      const inDetail = iDoc.querySelector('button.btn-v2.btn-sure-v2.btn-greet');
      const inList   = iDoc.querySelector('button.btn.btn-greet');
      if (!inDetail && inList) return;
      await sleep(300);
    }
  }

  // ─── 视觉指示器 ───────────────────────────────────────────────────────────

  /** 获取（或创建）固定在页面右下角的状态浮窗 */
  function getStatusOverlay(iDoc) {
    let el = iDoc.querySelector('#__boss_status__');
    if (!el) {
      el = iDoc.createElement('div');
      el.id = '__boss_status__';
      el.style.cssText = [
        'position:fixed', 'bottom:20px', 'right:20px', 'z-index:2147483647',
        'background:rgba(18,24,35,0.92)', 'color:#fff',
        'padding:12px 16px', 'border-radius:10px',
        'font-size:13px', 'line-height:1.7', 'min-width:220px',
        'box-shadow:0 4px 16px rgba(0,0,0,0.4)',
        'cursor:pointer', 'font-family:sans-serif',
        'transition:box-shadow 0.15s',
      ].join(';');
      el.title = '点击打开操作台';
      el.addEventListener('mouseenter', () => {
        el.style.boxShadow = '0 6px 24px rgba(0,0,0,0.55)';
      });
      el.addEventListener('mouseleave', () => {
        el.style.boxShadow = '0 4px 16px rgba(0,0,0,0.4)';
      });
      el.addEventListener('click', () => {
        chrome.runtime.sendMessage({ type: 'OPEN_POPUP' }).catch(() => {});
      });
      iDoc.body.appendChild(el);
    }
    return el;
  }

  function showStatus(iDoc, name, step, extra = '') {
    try {
      const el = getStatusOverlay(iDoc);
      el.innerHTML =
        `<div style="font-weight:700;margin-bottom:4px;color:#00D9C5">🤖 Boss AI招聘助手</div>` +
        `<div>👤 <b>${name}</b></div>` +
        `<div>📋 ${step}</div>` +
        (extra ? `<div style="color:#bbb;font-size:12px;margin-top:2px">${extra}</div>` : '');
    } catch (_) {}
  }

  function hideStatus(iDoc) {
    try { iDoc.querySelector('#__boss_status__')?.remove(); } catch (_) {}
  }

  /** 高亮当前处理的候选人卡片，并滚动到视野中央 */
  function highlightCard(card, iDoc) {
    try {
      iDoc.querySelectorAll('[data-boss-highlight]').forEach(el => {
        el.style.outline = '';
        el.style.boxShadow = '';
        delete el.dataset.bossHighlight;
      });
      if (card) {
        card.dataset.bossHighlight = '1';
        card.style.outline = '2px solid #4fc3f7';
        card.style.boxShadow = '0 0 0 4px rgba(79,195,247,0.18)';
        card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    } catch (_) {}
  }

  /**
   * 主循环：遍历所有推荐候选人
   * 流程：高亮候选人 → 点名字打开详情 → 读资料 → AI评估 → 匹配打招呼 / 不匹配点✖ → 回列表 → 继续
   */
  async function processRecommendCandidates(profile) {
    let processedOnPage = 0;

    // 等待 iframe 加载
    log('等待推荐牛人 iframe 加载...');
    let iDoc = null;
    const t0 = Date.now();
    while (Date.now() - t0 < 12000) {
      iDoc = getIframeDoc();
      if (iDoc && iDoc.querySelector('button.btn.btn-greet, span.name')) break;
      await sleep(400);
    }
    if (!iDoc) { logErr('iframe 未加载'); return; }
    log('iframe 已加载，开始处理候选人');

    const processedNames = new Set();

    while (!_taskStopped) {
      if (await checkPauseStop()) return;

      // 找下一个未处理的候选人
      const items = getCandidateListItems(iDoc);
      const item = items.find(el =>
        !el.dataset.bossProcessed &&
        el.querySelector('span.name')?.textContent.trim()
      );

      if (!item) {
        const loaded = await scrollLoadMore();
        if (!loaded) break;
        continue;
      }

      // 标记 + 记录姓名
      item.dataset.bossProcessed = '1';
      const nameEl = item.querySelector('span.name');
      const candidateName = nameEl?.textContent.trim() || '未知';

      if (processedNames.has(candidateName)) continue;
      processedNames.add(candidateName);

      // 从列表卡片中预取资料页链接（点开详情后再二次确认）
      let profileUrl = extractProfileUrl(item, iDoc);

      // ── 高亮卡片，滚动到视野 ────────────────────────────────────────────
      highlightCard(item, iDoc);
      showStatus(iDoc, candidateName, '正在查看资料...');
      await sleep(rand(600, 1000));  // 模拟人工停顿后再点击

      // ── Step 3: 点开详情面板 ──────────────────────────────────────────
      log(`查看详情：${candidateName}`);
      realClick(nameEl || item);
      showStatus(iDoc, candidateName, '⏳ 加载详情中...');
      const opened = await waitForDetailPanel(iDoc, 8000);
      if (!opened) {
        logWarn(`${candidateName} 详情面板未打开，跳过`);
        showStatus(iDoc, candidateName, '⚠️ 详情未加载，已跳过');
        await sleep(1000);
        continue;
      }
      await sleep(rand(1000, 1800));  // 模拟人工阅读停顿

      if (await checkPauseStop()) { await closeDetailPanel(iDoc); hideStatus(iDoc); return; }

      // ── Step 3b: 提取详情资料 ─────────────────────────────────────────
      showStatus(iDoc, candidateName, '📖 读取简历...');
      const detailEl = iDoc.querySelector('.resume-detail-wrap, .resume-item-detail, .resume-layout-wrap') || item;
      // 详情面板打开后二次确认资料链接（链接可能在详情面板里更完整）
      if (!profileUrl && detailEl) profileUrl = extractProfileUrl(detailEl, iDoc);
      const info = extractCandidateInfo(detailEl);
      info.name = candidateName;  // 列表里的名字最准确，直接覆盖
      log(`读取资料：${info.name}（${info.title || ''}${info.company ? ' @ ' + info.company : ''}）`);
      _stats.processed++;
      await sleep(rand(800, 1400));  // 模拟阅读时间

      if (await checkPauseStop()) { await closeDetailPanel(iDoc); hideStatus(iDoc); return; }

      // ── Step 4: AI 评估 ────────────────────────────────────────────────
      log(`AI评估：${info.name}`);
      showStatus(iDoc, candidateName, '🤖 AI评估中...', '正在分析匹配度');
      let evalResult = null;
      try {
        const resp = await chrome.runtime.sendMessage({
          type: 'EVALUATE_CANDIDATE',
          candidateInfo: {
            name:       info.name,
            title:      info.title,
            company:    info.company,
            experience: info.experience,
            education:  info.education,
            skills:     info.skills,
            extra:      info.extra.slice(0, 3000),
          },
        });
        evalResult = resp?.result;
      } catch (e) {
        logErr(`AI评估失败：${e.message}`);
      }

      if (!evalResult) {
        logWarn(`${info.name} 评估失败，关闭详情`);
        showStatus(iDoc, candidateName, '❌ 评估失败，跳过');
        _stats.failed++;
        await chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'failed' }).catch(() => {});
        await sleep(600);
        await closeDetailPanel(iDoc);
        await sleep(rand(400, 700));
        continue;
      }

      const { score, suitable, reason } = evalResult;
      log(`评估结果：${info.name} ${score}分 ${suitable ? '✓ 匹配' : '✗ 不匹配'} — ${reason}`);
      const isMatch = suitable && Number(score) >= (profile.scoreThreshold ?? 70);

      if (!isMatch) {
        // ── 不匹配：停留片刻 → 点✖关闭资料页 ────────────────────────────
        showStatus(iDoc, candidateName, `✗ 不匹配（${score}分）`, reason?.slice(0, 40));
        await sleep(rand(600, 1000));
        log(`不匹配，关闭详情：${info.name}`);
        await closeDetailPanel(iDoc);
        // 确认已回到列表（有候选人名字卡片）再继续
        await waitForListCards(iDoc);
        await sleep(rand(300, 600));
        continue;
      }

      // ── 匹配！ ────────────────────────────────────────────────────────
      showStatus(iDoc, candidateName, `✅ 匹配（${score}分）`, '即将打招呼');
      _stats.matched++;

      await sleep(rand(600, 1200));
      if (await checkPauseStop()) { await closeDetailPanel(iDoc); hideStatus(iDoc); return; }

      // ── Step 5: 点详情页「打招呼」────────────────────────────────────
      showStatus(iDoc, candidateName, '👋 正在打招呼...');
      log(`打招呼：${info.name}`);
      const greetBtn = iDoc.querySelector('button.btn-v2.btn-sure-v2.btn-greet')
                    || iDoc.querySelector('.resumeGreet button');
      if (greetBtn) {
        realClick(greetBtn);
        log(`✓ 已向 ${info.name} 打招呼`);
        showStatus(iDoc, candidateName, `✅ 已打招呼（${score}分）`);
        // 打招呼成功后再存记录，action 设为 'added'（显示为「💬已打招呼」）
        // 最后一次尝试取资料 URL（此时详情面板还在，DOM 最完整）
        if (!profileUrl) profileUrl = extractProfileUrl(iDoc.querySelector('.resume-detail-wrap, .resume-item-detail, .resume-layout-wrap'), iDoc);
        if (!profileUrl) profileUrl = extractProfileUrl(iDoc.body, iDoc);
        log(`资料链接：${profileUrl || '未找到'}`);
        _stats.messaged++;
        await chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'messaged' }).catch(() => {});
        await chrome.runtime.sendMessage({
          type: 'SAVE_MATCHED_CANDIDATE',
          candidate: {
            name:       candidateName,
            title:      info.title || '',
            company:    info.company || '',
            score,
            reason,
            highlights: evalResult.highlights || '',
            action:     'added',
            timestamp:  Date.now(),
            jobName:    profile.name || profile.jobTitle,
            profileUrl: profileUrl || '',
          },
        }).catch(() => {});
        await closeChatPopup();
        await closeDetailPanel(iDoc);
        await waitForListCards(iDoc);
        await sleep(rand(400, 800));
      } else {
        logWarn(`未找到打招呼按钮，关闭详情`);
        showStatus(iDoc, candidateName, '⚠️ 未找到打招呼按钮');
        _stats.failed++;
        await chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'failed' }).catch(() => {});
        await closeDetailPanel(iDoc);
        await sleep(rand(400, 700));
      }

      processedOnPage++;
      const delay = rand(2500, 4500);
      log(`等待 ${(delay / 1000).toFixed(1)}s 后继续...`);
      showStatus(iDoc, candidateName, `⏸ 冷却 ${(delay / 1000).toFixed(1)}s...`);
      await sleep(delay);
    }

    hideStatus(iDoc);
    highlightCard(null, iDoc);
    log(`本岗位处理完成：共处理 ${processedOnPage} 人`);
  }

  /**
   * 关闭打招呼后弹出的聊天窗口
   * 弹窗可能在主页面或 iframe，两处都检查
   */
  async function closeChatPopup() {
    const iDoc = getIframeDoc();
    const SELECTOR = 'div.iboss.iboss-close, .chat-global-outer-wrap .iboss-close, [class*="iboss-close"]';
    const t0 = Date.now();
    while (Date.now() - t0 < 5000) {
      const btn = document.querySelector(SELECTOR)
               || (iDoc && iDoc.querySelector(SELECTOR));
      if (btn) {
        realClick(btn);
        log('已关闭聊天弹窗');
        await sleep(rand(400, 700));
        return;
      }
      await sleep(200);
    }
    // 弹窗可能已自动关闭，不影响流程
  }

  /**
   * 从候选人详情面板中提取 Boss直聘 资料页链接
   * 优先级：<a href> → encrypt-geek-id 属性 → iframe URL geekId 参数
   */
  function extractProfileUrl(el, iDoc) {
    const BASE = 'https://www.zhipin.com';

    // 1. 元素内找 <a href> 含候选人资料路径
    for (const a of (el?.querySelectorAll('a[href]') || [])) {
      const href = a.href || a.getAttribute('href') || '';
      if (/\/(geek|resume|candidate)\//i.test(href)
          || /[?&](geekId|encryptGeekId|uid)=/.test(href)) {
        return href.startsWith('http') ? href : BASE + href;
      }
    }

    // 2. 找 encrypt-geek-id 属性（详情面板 DOM 里存在）
    //    先在当前元素找，再扫整个 iDoc
    const findEncId = (root) => {
      if (!root) return null;
      // 直接有属性的
      const direct = root.querySelector('[encrypt-geek-id]');
      if (direct) return direct.getAttribute('encrypt-geek-id');
      // 元素本身有
      if (root.getAttribute?.('encrypt-geek-id')) return root.getAttribute('encrypt-geek-id');
      return null;
    };

    const encId = findEncId(el) || findEncId(iDoc);
    if (encId) {
      // Boss直聘 HR 查看候选人资料的 URL 格式
      return `${BASE}/web/resume/${encodeURIComponent(encId)}.html`;
    }

    // 3. iframe 的 src 属性或当前 URL 里有 geekId
    const iframe = document.querySelector('iframe[name="recommendFrame"]');
    for (const src of [iframe?.src, iDoc?.defaultView?.location?.href].filter(Boolean)) {
      const m = src.match(/[?&#](geekId|encryptGeekId|uid)=([^&]+)/);
      if (m) return `${BASE}/web/resume/${encodeURIComponent(m[2])}.html`;
    }

    return '';
  }

  /**
   * 等候选人列表卡片重新可见（确认已回到列表页）
   */
  async function waitForListCards(iDoc, timeoutMs = 4000) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      const hasCards = iDoc.querySelector('span.name') &&
                       !iDoc.querySelector('button.btn-v2.btn-sure-v2.btn-greet');
      if (hasCards) return;
      await sleep(200);
    }
  }

  /**
   * 关闭候选人详情面板（点 i.icon-close）
   * 带重试，最多等 6 秒
   */
  async function closeDetailPanel(iDoc) {
    const t0 = Date.now();
    while (Date.now() - t0 < 6000) {
      // 检查详情面板是否还在（有打招呼按钮 = 还在详情页）
      const stillOpen = iDoc.querySelector(
        'button.btn-v2.btn-sure-v2.btn-greet, i.icon-close, .resume-layout-wrap, .resume-item-detail'
      );
      if (!stillOpen) return;  // 已自动关闭

      const closeBtn = iDoc.querySelector('i.icon-close');
      if (closeBtn) {
        realClick(closeBtn.parentElement || closeBtn);
        await sleep(600);
        // 验证是否已关
        const gone = !iDoc.querySelector('button.btn-v2.btn-sure-v2.btn-greet');
        if (gone) return;
      }
      await sleep(300);
    }
    logWarn('详情面板关闭超时');
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  滚动加载更多候选人
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * 滚动到底部触发懒加载，等待新候选人出现。
   * @returns {boolean} true = 有新候选人出现，false = 已到底
   */
  async function scrollLoadMore() {
    const iDoc = getIframeDoc();
    if (!iDoc) { log('找不到 iframe，停止滚动'); return false; }

    const beforeCount = iDoc.querySelectorAll('button.btn.btn-greet').length;
    log(`滚动加载更多（当前已有 ${beforeCount} 个候选人）...`);

    // 优先滚动 iframe 内的列表容器，兜底滚动 iframe body
    const listContainer = iDoc.querySelector(
      '[class*="recommend-list"], [class*="candidate-list"], [class*="geek-list"], .recommend-wrap, #container'
    );
    if (listContainer) {
      listContainer.scrollTop = listContainer.scrollHeight;
    } else {
      iDoc.documentElement.scrollTop = iDoc.documentElement.scrollHeight;
    }

    // 等待新内容加载（最多 6 秒）
    const t0 = Date.now();
    while (Date.now() - t0 < 6000) {
      await sleep(500);
      const nowCount = iDoc.querySelectorAll('button.btn.btn-greet').length;
      if (nowCount > beforeCount) {
        log(`✓ 加载到 ${nowCount - beforeCount} 个新候选人`);
        await sleep(rand(800, 1200));
        return true;
      }
    }

    log('滚动后无新候选人，已到底');
    return false;
  }


  // ═══════════════════════════════════════════════════════════════════════════
  //  招聘搜索模式（🏢 Boss招聘搜索，待实现）
  // ═══════════════════════════════════════════════════════════════════════════

  // ═══════════════════════════════════════════════════════════════════════════
  //  搜索模式（🔍 搜索）
  // ═══════════════════════════════════════════════════════════════════════════

  async function runRecruitTask() {
    if (_taskRunning) return;
    _taskRunning = true;
    _taskStopped = false;
    _taskPaused  = false;
    sessionStorage.setItem('__boss_recruiter_active', '1');
    await chrome.runtime.sendMessage({ type: 'START_TASK', profiles: _curProfiles }).catch(() => {});

    for (let pi = 0; pi < _curProfiles.length; pi++) {
      if (_taskStopped) break;
      const profile = _curProfiles[pi];
      await chrome.runtime.sendMessage({ type: 'SET_ACTIVE_JOB', profileId: profile.id }).catch(() => {});
      log(`搜索模式 - 开始处理岗位：${profile.name || profile.jobTitle}`);
      await runSearchLoop(profile);
      if (_taskStopped) break;
    }

    sessionStorage.removeItem('__boss_recruiter_active');
    _taskRunning = false;
    log('所有岗位处理完毕');
  }

  async function runSearchLoop(profile) {
    const jobTitle = profile.jobTitle || profile.name;

    // ── Step 1: 确认在搜索页（popup 已导航，这里做二次确认） ────────────────
    showSearchStatus('🔍 搜索模式', '⏳ 等待搜索页加载...');
    log('Step 1: 等待搜索页加载...');
    const pageReady = await waitForSearchPage();
    if (!pageReady) {
      showSearchStatus('❌ 出错', '搜索页未加载，请确认页面已打开');
      await sleep(3000); hideSearchStatus();
      logErr('搜索页未正常加载，中止'); return;
    }
    log('搜索页已就绪');
    if (await checkPauseStop()) { hideSearchStatus(); return; }

    // ── Step 3: 选择在招岗位 ─────────────────────────────────────────────────
    if (jobTitle) {
      showSearchStatus('🔍 搜索模式', `📋 选择岗位「${jobTitle}」`);
      log(`Step 3: 选择在招岗位「${jobTitle}」`);
      await selectSearchModeJob(jobTitle);
      await sleep(rand(1000, 1800));
      if (await checkPauseStop()) { hideSearchStatus(); return; }
    }

    // ── Step 4: 逐关键词组搜索并处理候选人 ──────────────────────────────────
    const kwGroups = parseKeywordGroups(profile.keywords);
    if (kwGroups.length === 0) {
      log('未配置搜索关键词，处理当前搜索结果');
      showSearchStatus('🔍 搜索模式', '开始遍历当前候选人...');
      await processSearchCandidates(profile);
    } else {
      for (let ki = 0; ki < kwGroups.length; ki++) {
        if (_taskStopped) break;
        if (await checkPauseStop()) { hideSearchStatus(); return; }

        const kwGroup = kwGroups[ki];
        log(`Step 4: 搜索关键词组「${kwGroup}」（${ki + 1}/${kwGroups.length}）`);
        showSearchStatus('🔍 搜索模式', `🔎 搜索「${kwGroup}」`, `第 ${ki + 1}/${kwGroups.length} 组`);

        const searched = await searchWithKeyword(kwGroup);
        if (!searched) continue;
        await sleep(rand(1500, 2500));
        if (await checkPauseStop()) { hideSearchStatus(); return; }

        // 等待搜索结果出现（卡片出现才算就绪）
        showSearchStatus('🔍 搜索模式', `⏳ 等待「${kwGroup}」搜索结果...`);
        const resultsReady = await waitForSearchResults(10000);
        if (!resultsReady) {
          logWarn(`关键词「${kwGroup}」无搜索结果，跳过`);
          showSearchStatus('🔍 搜索模式', `⚠️「${kwGroup}」无结果，跳过`);
          await sleep(1500);
          continue;
        }

        await processSearchCandidates(profile);
        if (_taskStopped) break;
      }
    }

    hideSearchStatus();
    log('搜索模式全部完成');
  }

  /** 专门等候选人卡片出现（搜索结果就绪） */
  async function waitForSearchResults(timeoutMs = 10000) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      const sDoc = getSearchDoc();
      if (sDoc.querySelector(SEARCH_CARD_SELS.join(','))) return true;
      await sleep(400);
    }
    // 超时：输出诊断帮助定位真实选择器
    try {
      const sDoc = getSearchDoc();
      // 输出含 "geek"/"result"/"list"/"card" 等关键词的 class 列表
      const interesting = new Set();
      for (const el of sDoc.querySelectorAll('*')) {
        const cls = el.className;
        if (typeof cls !== 'string') continue;
        if (/geek|result|card|item|entry|talent|candidate/.test(cls)) {
          interesting.add(`${el.tagName.toLowerCase()}.${cls.trim().replace(/\s+/g, '.')}`);
          if (interesting.size >= 30) break;
        }
      }
      log(`[诊断] 候选人卡片未找到，搜索页匹配 class 元素：\n${[...interesting].join('\n')}`, 'warn');
    } catch (_) {}
    return false;
  }

  /** 解析关键词组（每行一组，行内空格分隔为一个搜索串） */
  function parseKeywordGroups(keywords) {
    if (!keywords) return [];
    return keywords.split('\n').map(s => s.trim()).filter(Boolean);
  }

  /** 在搜索页选择在招岗位（.search-job-list-C 下拉） */
  async function selectSearchModeJob(jobTitle) {
    // 等待触发器出现（最多 15s，getSearchDoc 会一直重新扫描 iframe）
    const TRIGGER_SEL = '.search-job-list-C, [class*="search-job-list"], [class*="job-list-wrap"]';
    let sDoc = null;
    let trigger = null;
    const tw0 = Date.now();
    while (Date.now() - tw0 < 15000) {
      sDoc = getSearchDoc();
      trigger = sDoc.querySelector(TRIGGER_SEL);
      if (trigger) break;
      await sleep(500);
    }
    if (!trigger) {
      log('未找到搜索页岗位选择器，跳过岗位选择');
      showSearchStatus('🔍 搜索模式', '⚠️ 未找到岗位筛选框，跳过');
      dumpFrameInfo();
      return false;
    }

    const key = jobKey(jobTitle);

    // 先不点击，直接试试列表里是否已有岗位条目（部分场景下列表始终可见）
    const JOB_ITEM_SEL = 'li[ka="search_select_job"], .search-job-list-C li, .ui-dropmenu-list li';
    let preItems = [...sDoc.querySelectorAll(JOB_ITEM_SEL)];
    if (!preItems.length) {
      // 列表未显示 → 点击触发器展开
      showSearchStatus('🔍 搜索模式', `📋 展开岗位列表...`);
      realClick(trigger);
      log(`展开在招岗位下拉`);
      await sleep(rand(600, 1000));
    } else {
      log(`岗位列表已可见（${preItems.length} 项），直接选择`);
    }

    const t0 = Date.now();
    while (Date.now() - t0 < 8000) {
      const items = [...sDoc.querySelectorAll(JOB_ITEM_SEL)];

      if (items.length) {
        // 按得分选最佳匹配（全名匹配 > 包含 > 最长公共子串）
        const scored = items
          .filter(li => !(li.querySelector('span.job-name')?.textContent || li.textContent).replace(/\s/g,'').includes('不限职位'))
          .map(li => {
            const nameEl = li.querySelector('span.job-name');
            const txt = (nameEl?.textContent || li.textContent).trim();
            return { li, txt, score: jobMatchScore(txt, jobTitle) };
          })
          .filter(x => x.score > 0)
          .sort((a, b) => b.score - a.score);

        if (scored.length) {
          const best = scored[0];
          log(`选中岗位（得分${best.score}）：${best.txt.slice(0, 40)}`);
          showSearchStatus('🔍 搜索模式', `✅ 已选岗位：${best.txt.slice(0, 30)}`);
          realClick(best.li);
          await sleep(rand(800, 1200));
          return true;
        }

        // 无匹配得分 → 向下滚动岗位列表继续找
        const list = sDoc.querySelector('.ui-dropmenu-list, .search-job-list-C [class*="list"]');
        if (list && list.scrollHeight > list.clientHeight) {
          list.scrollTop += 200;
          log('岗位列表向下滚动...');
          await sleep(400);
          continue;
        }

        // 滚到底仍无分 → 选第一个
        const first = items.find(li => !li.textContent.replace(/\s/g,'').includes('不限职位')) || items[0];
        const firstName = (first.querySelector('span.job-name')?.textContent || first.textContent).trim().slice(0, 40);
        log(`无精确匹配，选第一个：${firstName}`);
        showSearchStatus('🔍 搜索模式', `✅ 已选岗位：${firstName}`);
        realClick(first);
        await sleep(rand(800, 1200));
        return true;
      }
      await sleep(200);
    }

    log('岗位选项未出现，跳过');
    return false;
  }

  /** 在 input.search-input 中输入关键词并点击搜索 */
  async function searchWithKeyword(keyword) {
    // 等待输入框出现（最多 10s）
    const INPUT_SEL = 'input.search-input, .search-input-wrap input, [class*="search-input-wrap"] input[type="text"]';
    let sDoc = null;
    let input = null;
    const iw0 = Date.now();
    while (Date.now() - iw0 < 10000) {
      sDoc = getSearchDoc();
      input = sDoc.querySelector(INPUT_SEL);
      if (input) break;
      await sleep(500);
    }
    if (!input) {
      logWarn(`未找到关键词搜索框，跳过「${keyword}」`);
      showSearchStatus('🔍 搜索模式', `⚠️ 未找到搜索框，跳过「${keyword}」`);
      return false;
    }

    showSearchStatus('🔍 搜索模式', `⌨️ 输入关键词「${keyword}」`);
    log(`输入搜索关键词：「${keyword}」`);
    input.focus();
    input.value = '';
    input.dispatchEvent(new Event('input', { bubbles: true }));
    await sleep(200);
    await humanType(input, keyword);
    await sleep(rand(500, 800));

    // 优先点搜索图标，其次回车
    const searchBtn = sDoc.querySelector(
      'i.icon-search, [class*="icon-search"], .search-input-wrap .btn-search'
    );
    if (searchBtn && searchBtn.offsetParent !== null) {
      realClick(searchBtn);
      log('点击搜索按钮');
    } else {
      input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
      input.dispatchEvent(new KeyboardEvent('keyup',   { key: 'Enter', keyCode: 13, bubbles: true }));
      log('回车搜索');
    }

    await sleep(rand(800, 1200));
    return true;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Step 1: 点击搜索导航
  // ─────────────────────────────────────────────────────────────────────────
  async function clickSearchNav() {
    // 如果已经在搜索页，直接跳过导航
    // 检查主文档和 iframe 中是否已有搜索页元素
    const iDoc = getIframeDoc();
    const searchSel = 'input.search-input, .search-job-list-C, .search-input-wrap';
    if (document.querySelector(searchSel) || (iDoc && iDoc.querySelector(searchSel))) {
      log('已在搜索页，跳过导航');
      return true;
    }

    // 选择器：a[ka="menu-geek-search"]
    let btn = document.querySelector('a[ka="menu-geek-search"]');
    if (!btn) {
      const t0 = Date.now();
      while (Date.now() - t0 < 5000) {
        btn = document.querySelector('a[ka="menu-geek-search"]');
        if (btn) break;
        await sleep(300);
      }
    }
    if (!btn) {
      logErr(`找不到搜索导航按钮，当前页：${location.href.slice(0, 80)}`);
      return false;
    }
    log(`点击搜索导航（href=${btn.href || btn.getAttribute('href') || '无'}）`);
    realClick(btn);
    return true;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Step 2: 等待搜索页候选人列表加载
  // ─────────────────────────────────────────────────────────────────────────
  /**
   * 搜索模式用的文档：扫描所有 iframe，找到含搜索 UI 的那个；
   * 都没有则返回主文档。
   */
  const SEARCH_INDICATOR = '.search-job-list-C, input.search-input, li[ka="search_select_job"], .search-input-wrap';

  let _searchDocCache = null;     // 缓存：避免每次都扫 iframe 并刷日志
  let _searchDocCacheTs = 0;      // 缓存时间戳（5s 过期）

  function getSearchDoc() {
    const now = Date.now();
    if (_searchDocCache && now - _searchDocCacheTs < 5000) return _searchDocCache;

    // 1. 先试主文档
    if (document.querySelector(SEARCH_INDICATOR)) {
      _searchDocCache = document;
      _searchDocCacheTs = now;
      return document;
    }
    // 2. 扫所有 iframe
    for (const iframe of document.querySelectorAll('iframe')) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (!doc) continue;
        if (doc.querySelector(SEARCH_INDICATOR)) {
          log(`搜索 UI 在 iframe（name="${iframe.name || '无'}" src="${(iframe.src||'').slice(0,60)}"）`);
          _searchDocCache = doc;
          _searchDocCacheTs = now;
          return doc;
        }
      } catch (_) {}
    }
    return document;
  }

  /** 主动清除 getSearchDoc 缓存（页面切换/搜索后调用） */
  function clearSearchDocCache() {
    _searchDocCache = null;
    _searchDocCacheTs = 0;
  }

  /** 诊断：输出当前页的框架结构（帮助定位搜索 UI） */
  function dumpFrameInfo() {
    try {
      // 主文档概况
      const bodySnippet = document.body?.innerHTML?.slice(0, 300) || '(空)';
      log(`[诊断] 主文档 body 片段：${bodySnippet}`, 'warn');

      // 列出所有 iframe
      const iframes = [...document.querySelectorAll('iframe')];
      log(`[诊断] iframe 总数：${iframes.length}`, 'warn');
      iframes.forEach((f, i) => {
        let accessible = false;
        let childElCount = 0;
        let hasSearchEl = false;
        try {
          const d = f.contentDocument || f.contentWindow?.document;
          if (d) {
            accessible = true;
            childElCount = d.querySelectorAll('*').length;
            hasSearchEl = !!d.querySelector(SEARCH_INDICATOR);
          }
        } catch (_) {}
        log(`[诊断] iframe[${i}] name="${f.name||'无'}" src="${(f.src||'').slice(0,80)}" 可访问=${accessible} 元素数=${childElCount} 含搜索UI=${hasSearchEl}`, 'warn');
      });
    } catch (e) {
      log(`[诊断] 异常：${e.message}`, 'warn');
    }
  }

  async function waitForSearchPage(timeoutMs = 15000) {
    // iframe 模式：已在含搜索 UI 的框架中，不检查 URL
    if (_isInIframe) {
      if (document.querySelector(SEARCH_INDICATOR)) {
        log('[iframe] 搜索 UI 已就绪');
        return true;
      }
      // 理论上不应到这里（RUN_RECRUIT_TASK 已做等待），直接返回
      return true;
    }

    // 1. URL 已经在搜索页 → 等 Vue 挂载后直接就绪
    if (location.href.includes('/chat/search') || location.href.includes('/boss/geek/search')) {
      log(`搜索页URL确认：${location.href.slice(0, 80)}，等待页面渲染...`);
      // 等 DOM 元素出现（最多 timeoutMs），出现即返回；到时仍以 URL 为准通过
        const SEARCH_SELS = [
        '.search-job-list-C', 'input.search-input', '.search-input-wrap',
        'li[ka="search_select_job"]', '[class*="search-wrap"]', ...SEARCH_CARD_SELS,
      ];
      const t0 = Date.now();
      while (Date.now() - t0 < timeoutMs) {
        // 扫主文档 + 所有 iframe
        const allDocs = [document, ...([...document.querySelectorAll('iframe')].map(f => {
          try { return f.contentDocument || f.contentWindow?.document; } catch (_) { return null; }
        }).filter(Boolean))];

        for (const doc of allDocs) {
          for (const sel of SEARCH_SELS) {
            if (doc.querySelector(sel)) {
              const ctx = doc === document ? '主文档' : `iframe(name=${document.querySelector(`iframe`)?.name || '无'})`;
              log(`搜索页元素就绪（${ctx}）：${sel}`);
              return true;
            }
          }
        }
        await sleep(400);
      }
      log('搜索页 URL 正确，但未检测到预期元素 —— 启动框架诊断...');
      dumpFrameInfo();
      return true;
    }

    // 2. URL 不对 → 等待导航完成
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      if (location.href.includes('/chat/search') || location.href.includes('/boss/geek/search')) {
        log(`检测到搜索页URL：${location.href.slice(0, 80)}`);
        await sleep(1500); // 给 Vue 初次渲染时间
        return true;
      }
      await sleep(400);
    }
    log(`waitForSearchPage 超时，当前页：${location.href.slice(0, 80)}`);
    return false;
  }

  // 搜索结果候选人卡片选择器（多个备选，按优先级排列）
  // Boss直聘 搜索页 iframe（/web/frame/search/）的候选人列表常见结构
  const SEARCH_CARD_SELS = [
    // Boss直聘已确认：has-geek 在容器上，结果列表常见 class
    '.geek-list li',
    'ul.geek-list > li',
    '.boss-entry-list li',
    'li[ka="search_result"]',
    'li[ka="geek_card"]',
    'li[ka="boss_card"]',
    // 通配：含 geek 字样的列表项
    '[class*="geek-list"] li',
    '[class*="geek-item"]',
    '[class*="geek-card"]',
    '[class*="boss-card"]',
    // 通配备选
    '.boss-geek-item',
    '[class*="candidate-item"]',
    '[class*="talent-item"]',
    '[class*="search-result"] li',
    '.search-result-list li',
    'ul[class*="result"] li',
  ];

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：视觉状态指示（注入主文档，非 iframe）
  // ─────────────────────────────────────────────────────────────────────────
  function getSearchStatusOverlay() {
    let el = document.getElementById('__boss_search_status__');
    if (!el) {
      el = document.createElement('div');
      el.id = '__boss_search_status__';
      el.style.cssText = [
        'position:fixed', 'bottom:20px', 'right:20px', 'z-index:2147483647',
        'background:rgba(18,24,35,0.92)', 'color:#fff',
        'padding:12px 16px', 'border-radius:10px',
        'font-size:13px', 'line-height:1.7', 'min-width:220px',
        'box-shadow:0 4px 16px rgba(0,0,0,0.4)',
        'cursor:pointer', 'font-family:sans-serif',
        'transition:box-shadow 0.15s',
      ].join(';');
      el.title = '点击打开操作台';
      el.addEventListener('mouseenter', () => { el.style.boxShadow = '0 6px 24px rgba(0,0,0,0.55)'; });
      el.addEventListener('mouseleave', () => { el.style.boxShadow = '0 4px 16px rgba(0,0,0,0.4)'; });
      el.addEventListener('click', () => {
        chrome.runtime.sendMessage({ type: 'OPEN_POPUP' }).catch(() => {});
      });
      document.body.appendChild(el);
    }
    return el;
  }

  function showSearchStatus(name, step, extra = '') {
    try {
      const el = getSearchStatusOverlay();
      el.innerHTML =
        `<div style="font-weight:700;margin-bottom:4px;color:#00D9C5">🤖 Boss AI招聘助手（搜索模式）</div>` +
        `<div>👤 <b>${name}</b></div>` +
        `<div>📋 ${step}</div>` +
        (extra ? `<div style="color:#bbb;font-size:12px;margin-top:2px">${extra}</div>` : '');
    } catch (_) {}
  }

  function hideSearchStatus() {
    try { document.getElementById('__boss_search_status__')?.remove(); } catch (_) {}
  }

  function highlightSearchCard(card) {
    try {
      getSearchDoc().querySelectorAll('[data-boss-search-highlight]').forEach(el => {
        el.style.outline = '';
        el.style.boxShadow = '';
        delete el.dataset.bossSearchHighlight;
      });
      if (card) {
        card.dataset.bossSearchHighlight = '1';
        card.style.outline = '2px solid #4fc3f7';
        card.style.boxShadow = '0 0 0 4px rgba(79,195,247,0.18)';
        card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    } catch (_) {}
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：候选人卡片 & 信息提取
  // ─────────────────────────────────────────────────────────────────────────
  function getSearchResultCards() {
    const sDoc = getSearchDoc();
    for (const sel of SEARCH_CARD_SELS) {
      const cards = [...sDoc.querySelectorAll(sel)].filter(c => c.offsetParent !== null);
      if (cards.length) return cards;
    }
    return [];
  }

  function extractSearchCardName(card) {
    const el = card.querySelector(
      'span.name, .geek-name, [class*="name"]:not([class*="company"]):not([class*="job"]):not([class*="school"])'
    );
    return el?.textContent.trim() || '未知';
  }

  function extractSearchCardId(card) {
    return card.getAttribute('data-geek-id')
        || card.getAttribute('data-id')
        || card.getAttribute('encrypt-geek-id')
        || card.querySelector('[encrypt-geek-id]')?.getAttribute('encrypt-geek-id')
        || '';
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：等待资料详情面板
  // ─────────────────────────────────────────────────────────────────────────
  const SEARCH_DETAIL_SEL =
    '.resume-detail-wrap, [class*="resume-detail"], [class*="geek-detail"], ' +
    '[class*="detail-panel"], .detail-container, [class*="resume-panel"], ' +
    '.candidate-detail, [class*="profile-panel"], ' +
    // Boss直聘搜索侧边详情常见 class
    '.boss-geek-detail, .geek-info-panel, [class*="geek-info"], ' +
    '.boss-detail-main, [class*="search-detail"], [class*="geek-resume"]';

  /** 同时扫 iframe 和主文档，返回找到详情面板的文档 */
  function findDetailDoc() {
    const sDoc = getSearchDoc();
    if (sDoc.querySelector(SEARCH_DETAIL_SEL)) return sDoc;
    if (document !== sDoc && document.querySelector(SEARCH_DETAIL_SEL)) return document;
    return null;
  }

  async function waitForSearchDetailPanel(timeoutMs = 10000) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      if (findDetailDoc()) return true;
      await sleep(300);
    }

    // 诊断：列出 iframe 和主文档里出现的可疑元素
    try {
      const sDoc = getSearchDoc();
      const dumpDoc = (doc, label) => {
        const els = new Set();
        for (const el of doc.querySelectorAll('*')) {
          const c = el.className;
          if (typeof c !== 'string') continue;
          if (/detail|resume|geek|panel|info|profile|side/.test(c)) {
            els.add(`${el.tagName.toLowerCase()}.${c.trim().replace(/\s+/g,'.')}`);
            if (els.size >= 20) break;
          }
        }
        if (els.size) log(`[诊断-${label}] 详情相关元素：\n${[...els].join('\n')}`, 'warn');
      };
      dumpDoc(sDoc, 'iframe');
      if (document !== sDoc) dumpDoc(document, '主文档');
    } catch (_) {}
    return false;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：从详情面板提取候选人信息
  // ─────────────────────────────────────────────────────────────────────────
  function extractSearchCandidateInfo(defaultName) {
    const sDoc = findDetailDoc() || getSearchDoc();
    const panel = sDoc.querySelector(SEARCH_DETAIL_SEL) || sDoc.body;

    const USEFUL_SECTIONS = [
      '.geek-base-info-wrap',
      '.geek-expect-wrap',
      '.geek-work-experience-wrap',
      '.geek-education-experience-wrap',
      '[class*="base-info"]',
      '[class*="expect-info"]',
      '[class*="work-experience"]',
      '[class*="education"]',
    ];

    const sectionTexts = [];
    const seen = new Set();
    for (const sel of USEFUL_SECTIONS) {
      const sec = panel.querySelector(sel);
      if (sec && !seen.has(sec)) {
        seen.add(sec);
        sectionTexts.push(sec.innerText || sec.textContent || '');
      }
    }

    let extra = sectionTexts.length
      ? sectionTexts.join('\n')
      : (panel.innerText || panel.textContent || '');

    const cutIdx = extra.indexOf('牛人分析器');
    if (cutIdx > -1) extra = extra.slice(0, cutIdx);

    const name     = panel.querySelector('span.name, .geek-name, [class*="user-name"]')?.textContent.trim() || defaultName;
    const title    = panel.querySelector('[class*="expect-job"], [class*="job-title"]')?.textContent.trim() || '';
    const company  = panel.querySelector('[class*="company-name"], [class*="work"] [class*="company"]')?.textContent.trim() || '';
    const experience = panel.querySelector('[class*="exp-years"], [class*="experience"]')?.textContent.trim() || '';
    const education  = panel.querySelector('[class*="school-name"], [class*="education"] [class*="school"]')?.textContent.trim() || '';
    const skills   = [...panel.querySelectorAll('[class*="tag"], [class*="skill"]')]
                      .map(e => e.textContent.trim()).filter(Boolean).join('、');

    return { name, title, company, experience, education, skills, extra };
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：找「搜索畅聊卡」按钮
  // ─────────────────────────────────────────────────────────────────────────
  function findChatCardBtn() {
    const sDoc = findDetailDoc() || getSearchDoc();
    // 优先按文字找（最可靠）
    for (const el of sDoc.querySelectorAll('button, a.btn, [class*="btn"]')) {
      if (!el.offsetParent) continue;
      const text = el.textContent.trim();
      if (text.includes('畅聊卡') || text === '搜索畅聊卡' || text === '使用畅聊卡') {
        return el;
      }
    }
    // 按 class 兜底
    return sDoc.querySelector(
      'button[class*="chat-card"], .btn-chat-card, [class*="sure-btn"][class*="chat"]'
    ) || null;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：关闭畅聊卡弹窗
  // ─────────────────────────────────────────────────────────────────────────
  async function closeSearchChatPopup() {
    const sDoc = findDetailDoc() || getSearchDoc();
    const t0 = Date.now();
    while (Date.now() - t0 < 5000) {
      const closeEl = sDoc.querySelector(
        '[class*="dialog"] [class*="close"], [class*="modal"] [class*="close"], ' +
        '[class*="popup"] [class*="close"], [class*="layer"] [class*="close"], ' +
        '[class*="overlay"] [class*="close"], ' +
        '.close-btn, button.btn-close, [class*="close-icon"]'
      );
      if (closeEl && closeEl.offsetParent !== null) {
        realClick(closeEl);
        log('已关闭畅聊卡弹窗');
        await sleep(rand(400, 700));
        return;
      }
      const iconClose = sDoc.querySelector('i.icon-close');
      if (iconClose && iconClose.offsetParent !== null) {
        realClick(iconClose.parentElement || iconClose);
        log('已关闭弹窗（icon-close）');
        await sleep(rand(400, 700));
        return;
      }
      await sleep(200);
    }
    log('畅聊卡弹窗已自动关闭或未出现');
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：关闭候选人资料页（点✖）
  // ─────────────────────────────────────────────────────────────────────────
  async function closeSearchDetailPanel() {
    const t0 = Date.now();
    while (Date.now() - t0 < 6000) {
      const sDoc = findDetailDoc();
      if (!sDoc) return; // 面板已消失

      const panel = sDoc.querySelector(SEARCH_DETAIL_SEL);
      if (!panel) return;

      const closeBtn =
        panel.querySelector('i.icon-close, [class*="close-btn"], [class*="btn-close"], [class*="icon-x"]')
        || sDoc.querySelector('i.icon-close');

      if (closeBtn && closeBtn.offsetParent !== null) {
        realClick(closeBtn.parentElement || closeBtn);
        await sleep(600);
        if (!findDetailDoc()) return;
      }
      await sleep(300);
    }
    logWarn('搜索资料页关闭超时');
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：提取当前候选人资料页 URL
  // ─────────────────────────────────────────────────────────────────────────
  function extractSearchProfileUrl() {
    const BASE = 'https://www.zhipin.com';
    const sDoc = findDetailDoc() || getSearchDoc();

    // 1. 当前页 URL 就是资料页
    const href = location.href;
    if (/\/(geek|resume|candidate|profile)\//i.test(href)) return href;

    // 2. 详情面板内的 <a href>
    const panel = sDoc.querySelector(SEARCH_DETAIL_SEL);
    for (const a of (panel?.querySelectorAll('a[href]') || [])) {
      const h = a.href || a.getAttribute('href') || '';
      if (/\/(geek|resume|candidate)\//i.test(h) || /[?&](geekId|uid)=/.test(h)) {
        return h.startsWith('http') ? h : BASE + h;
      }
    }

    // 3. encrypt-geek-id 属性
    const encEl = (panel || sDoc).querySelector('[encrypt-geek-id]');
    if (encEl) {
      return `${BASE}/web/resume/${encodeURIComponent(encEl.getAttribute('encrypt-geek-id'))}.html`;
    }

    return '';
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  搜索模式：滚动加载更多
  // ─────────────────────────────────────────────────────────────────────────
  async function scrollLoadMoreSearch() {
    const sDoc = getSearchDoc();
    const beforeCount = sDoc.querySelectorAll(SEARCH_CARD_SELS.join(',')).length;
    log(`搜索模式：滚动加载更多（当前 ${beforeCount} 个）...`);

    const listEl = sDoc.querySelector(
      '[class*="result-list"], [class*="candidate-list"], [class*="geek-list"], [class*="search-list"]'
    );
    if (listEl) listEl.scrollTop = listEl.scrollHeight;
    else sDoc.documentElement.scrollTop = sDoc.documentElement.scrollHeight;

    const t0 = Date.now();
    while (Date.now() - t0 < 6000) {
      await sleep(500);
      const nowCount = sDoc.querySelectorAll(SEARCH_CARD_SELS.join(',')).length;
      if (nowCount > beforeCount) {
        log(`✓ 搜索：加载 ${nowCount - beforeCount} 个新候选人`);
        await sleep(rand(600, 1000));
        return true;
      }
    }
    log('搜索：无更多候选人');
    return false;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  Step 3~5: 遍历搜索候选人、AI评估、发送畅聊卡
  // ─────────────────────────────────────────────────────────────────────────
  async function processSearchCandidates(profile) {
    log('开始遍历搜索候选人');

    // ── 确认卡片选择器并等待列表出现 ──────────────────────────────────────────
    log('等待搜索结果列表...');
    const sDoc = getSearchDoc();
    let cardSel = null;
    const t0 = Date.now();
    while (Date.now() - t0 < 10000) {
      for (const sel of SEARCH_CARD_SELS) {
        if (sDoc.querySelector(sel)) { cardSel = sel; break; }
      }
      if (cardSel) break;
      await sleep(400);
    }
    if (!cardSel) { logErr('搜索结果列表未出现，中止'); return; }
    log(`候选人卡片选择器：${cardSel}`);

    const processedNames = new Set();

    while (!_taskStopped) {
      if (await checkPauseStop()) return;

      // 找下一个未处理的卡片
      const unprocessed = [...sDoc.querySelectorAll(cardSel)]
        .filter(c => c.offsetParent !== null && !c.dataset.bossProcessed);
      const card = unprocessed[0];

      if (!card) {
        const loaded = await scrollLoadMoreSearch();
        if (!loaded) { log('搜索结果已全部处理'); break; }
        continue;
      }

      card.dataset.bossProcessed = '1';
      const candidateName = extractSearchCardName(card);
      if (processedNames.has(candidateName) && candidateName !== '未知') continue;
      processedNames.add(candidateName);

      // ── 视觉指示 ──────────────────────────────────────────────────────────
      highlightSearchCard(card);
      showSearchStatus(candidateName, '正在查看资料...');
      await sleep(rand(600, 1000));

      // ── Step 3b: 点开候选人资料 ────────────────────────────────────────────
      log(`查看候选人：${candidateName}`);
      // 优先点卡片内的主点击区（a 链接 或 primary 容器）
      const cardClickTarget =
        card.querySelector('a[href], .primary-box, [class*="card-info"], [class*="geek-info"]')
        || card;
      realClick(cardClickTarget);
      showSearchStatus(candidateName, '⏳ 加载资料中...');

      const opened = await waitForSearchDetailPanel(8000);
      if (!opened) {
        logWarn(`${candidateName} 资料页未打开，跳过`);
        continue;
      }
      await sleep(rand(1000, 1800));
      if (await checkPauseStop()) { await closeSearchDetailPanel(); return; }

      // ── Step 3c: 提取资料 ──────────────────────────────────────────────────
      showSearchStatus(candidateName, '📖 读取简历...');
      const info = extractSearchCandidateInfo(candidateName);
      info.name = candidateName;
      _stats.processed++;
      log(`读取资料：${info.name}（${info.title}${info.company ? ' @ ' + info.company : ''}）`);
      await sleep(rand(800, 1400));
      if (await checkPauseStop()) { await closeSearchDetailPanel(); return; }

      // ── Step 4: AI 评估 ────────────────────────────────────────────────────
      showSearchStatus(candidateName, '🤖 AI评估中...', '正在分析匹配度');
      log(`AI评估：${info.name}`);
      let evalResult = null;
      try {
        const resp = await chrome.runtime.sendMessage({
          type: 'EVALUATE_CANDIDATE',
          candidateInfo: {
            name:       info.name,
            title:      info.title,
            company:    info.company,
            experience: info.experience,
            education:  info.education,
            skills:     info.skills,
            extra:      info.extra.slice(0, 3000),
          },
        });
        evalResult = resp?.result;
      } catch (e) {
        logErr(`AI评估失败：${e.message}`);
      }

      if (!evalResult) {
        logWarn(`${info.name} 评估失败，跳过`);
        showSearchStatus(candidateName, '❌ 评估失败，跳过');
        _stats.failed++;
        await chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'failed' }).catch(() => {});
        await sleep(600);
        await closeSearchDetailPanel();
        await sleep(rand(400, 700));
        continue;
      }

      const { score, suitable, reason } = evalResult;
      log(`评估结果：${info.name} ${score}分 ${suitable ? '✓ 匹配' : '✗ 不匹配'} — ${reason}`);
      const isMatch = suitable && Number(score) >= (profile.scoreThreshold ?? 70);

      if (!isMatch) {
        showSearchStatus(candidateName, `✗ 不匹配（${score}分）`, reason?.slice(0, 40));
        await sleep(rand(600, 1000));
        log(`不匹配，关闭资料页：${info.name}`);
        await closeSearchDetailPanel();
        await sleep(rand(300, 600));
        continue;
      }

      // ── 匹配！──────────────────────────────────────────────────────────────
      showSearchStatus(candidateName, `✅ 匹配（${score}分）`, '即将发送畅聊卡');
      _stats.matched++;
      await sleep(rand(600, 1200));
      if (await checkPauseStop()) { await closeSearchDetailPanel(); return; }

      // ── Step 5: 点「搜索畅聊卡」────────────────────────────────────────────
      showSearchStatus(candidateName, '💬 正在发送畅聊卡...');
      log(`发送畅聊卡：${info.name}`);
      const chatCardBtn = findChatCardBtn();

      if (chatCardBtn) {
        realClick(chatCardBtn);
        log(`✓ 已点击畅聊卡：${info.name}`);
        await sleep(rand(1000, 1500));

        // 关闭弹出的功能框
        await closeSearchChatPopup();
        await sleep(rand(400, 700));

        // 保存人选记录
        const profileUrl = extractSearchProfileUrl();
        log(`资料链接：${profileUrl || '未找到'}`);
        _stats.messaged++;
        await chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'messaged' }).catch(() => {});
        await chrome.runtime.sendMessage({
          type: 'SAVE_MATCHED_CANDIDATE',
          candidate: {
            name:       candidateName,
            title:      info.title || '',
            company:    info.company || '',
            score,
            reason,
            highlights: evalResult.highlights || '',
            action:     'messaged',
            timestamp:  Date.now(),
            jobName:    profile.name || profile.jobTitle,
            mode:       'recruit',
            profileUrl: profileUrl || '',
          },
        }).catch(() => {});

        showSearchStatus(candidateName, `✅ 已发送畅聊卡（${score}分）`);
      } else {
        logWarn(`未找到畅聊卡按钮`);
        showSearchStatus(candidateName, '⚠️ 未找到畅聊卡按钮');
        _stats.failed++;
        await chrome.runtime.sendMessage({ type: 'ACTION_DONE', action: 'failed' }).catch(() => {});
      }

      // ── Step 6: 关闭资料页 ─────────────────────────────────────────────────
      await closeSearchDetailPanel();
      await sleep(rand(300, 600));

      const delay = rand(2500, 4500);
      log(`等待 ${(delay / 1000).toFixed(1)}s 后继续...`);
      showSearchStatus(candidateName, `⏸ 冷却 ${(delay / 1000).toFixed(1)}s...`);
      await sleep(delay);
    }

    hideSearchStatus();
    highlightSearchCard(null);
    log('搜索模式处理完毕');
  }

} // end initBossRecruiter
