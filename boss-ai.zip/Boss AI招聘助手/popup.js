/**
 * popup.js — 整合控制面板 + 配置管理
 * Boss AI 招聘助手
 */

const $ = id => document.getElementById(id);
let pollTimer = null;

// ─── 多岗位 Profile 状态 ──────────────────────────────────────────────────────
let jobProfiles = [];      // 完整岗位列表（同步自 storage）
let activeProfileId = null; // 配置 Tab 当前编辑的岗位 ID
let runningProfileId = null;       // 搜索模式正在处理的岗位 ID
let recruitRunningProfileId = null; // 招聘搜索页模式正在处理的岗位 ID
let candFilterJobName = null; // 人选 Tab 岗位过滤（null = 显示全部）
let candFilterMode = '';     // 人选 Tab 来源模式过滤（'' = 全部, 'social', 'recruit'）
let _allCandidates = [];      // 人选完整列表缓存

// 独立标签页模式（popup.html?standalone=1）：宽度自适应，高度占满视口
if (new URLSearchParams(location.search).get('standalone') === '1') {
  document.body.classList.add('standalone');
}

// 面板模式（popup.html?panel=1）：悬浮小窗，宽度铺满面板，内容可滚动
if (new URLSearchParams(location.search).get('panel') === '1') {
  document.documentElement.style.cssText = 'height:100%;';
  document.body.style.cssText = 'width:100%;height:100%;overflow-y:auto;';
  const s = document.createElement('style');
  s.textContent = 'body { width: 100% !important; } .app { min-height: 100%; }';
  document.head.appendChild(s);
}

// ─── 工具：与 background 通信 ────────────────────────────────────────────────
function sendMsg(msg) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(msg, resp => {
      if (chrome.runtime.lastError) return reject(chrome.runtime.lastError);
      resolve(resp);
    });
  });
}

// ─── Tab 导航 ────────────────────────────────────────────────────────────────
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const leavingConfig = !!document.querySelector('#tab-config.active');
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    $(btn.dataset.tab)?.classList.add('active');
    // 离开配置 Tab 时立即保存（取消待触发的延迟保存，直接落盘）
    if (leavingConfig && btn.dataset.tab !== 'tab-config') {
      clearTimeout(_autoSaveTimer);
      autoSaveAll().catch(() => {});
    }
  });
});

// ─── 行为Tab：实时显示滑块值 ──────────────────────────────────────────────────
function bindRange(inputId, displayId, fmt) {
  const el = $(inputId); if (!el) return;
  el.addEventListener('input', () => {
    const d = $(displayId); if (d) d.textContent = fmt ? fmt(el.value) : el.value;
  });
}

// 各模型对应的默认 API 地址
const MODEL_BASE_MAP = {
  'claude-sonnet-4-6':            'https://llm-proxy.tapsvc.com',
  'claude-opus-4-6':              'https://llm-proxy.tapsvc.com',
  'claude-haiku-4-5-20251001':    'https://llm-proxy.tapsvc.com',
  'claude-haiku-4-5':             'https://llm-proxy.tapsvc.com',
  'gpt-5.4':                      'https://api.openai.com/v1',
  'gpt-5.4-mini':                 'https://api.openai.com/v1',
  'gpt-4.1':                      'https://api.openai.com/v1',
  'gpt-4.1-mini':                 'https://api.openai.com/v1',
  'o3':                           'https://api.openai.com/v1',
  'o3-pro':                       'https://api.openai.com/v1',
  'o4-mini':                      'https://api.openai.com/v1',
  'gemini-3.1-pro-preview':       'https://generativelanguage.googleapis.com/v1beta/openai',
  'gemini-3-flash-preview':       'https://generativelanguage.googleapis.com/v1beta/openai',
  'gemini-2.5-pro':               'https://generativelanguage.googleapis.com/v1beta/openai',
  'gemini-2.5-flash':             'https://generativelanguage.googleapis.com/v1beta/openai',
  'qwen-max':                     'https://dashscope.aliyuncs.com/compatible-mode/v1',
  'qwq-plus':                     'https://dashscope.aliyuncs.com/compatible-mode/v1',
  'qwen-plus':                    'https://dashscope.aliyuncs.com/compatible-mode/v1',
  'doubao-seed-2-0-pro-260215':   'https://ark.cn-beijing.volces.com/api/v3',
  'doubao-seed-2-0-lite-260215':  'https://ark.cn-beijing.volces.com/api/v3',
  'doubao-seed-2-0-mini-260215':  'https://ark.cn-beijing.volces.com/api/v3',
  'deepseek-chat':                'https://api.deepseek.com/v1',
  'deepseek-reasoner':            'https://api.deepseek.com/v1',
};
function getDefaultBase(modelId) {
  return MODEL_BASE_MAP[modelId] || '';
}

// 模型选择：自动填 API 地址，选「自定义」时显示文本输入框
$('model').addEventListener('change', () => {
  const val = $('model').value;
  $('model-custom').style.display = val === 'custom' ? '' : 'none';
  if (val !== 'custom') {
    const base = getDefaultBase(val);
    if (base) $('api-base').value = base;
  }
});

bindRange('score-threshold', 'score-val', v => v);
bindRange('scroll-steps', 'scroll-steps-val', v => v);
bindRange('typing-min', 'typing-min-val', v => v);
bindRange('typing-max', 'typing-max-val', v => v);
bindRange('break-n', 'break-n-val', v => v);
bindRange('skip-prob', 'skip-val', v => v);

// ─── 消息字数计数器 ────────────────────────────────────────────────────────────
function updateCharCount(inputId, countId, limit) {
  const el = $(inputId), countEl = $(countId);
  if (!el || !countEl) return;
  const len = el.value.length;
  countEl.textContent = limit ? `${len}/${limit}字` : `${len}字`;
  countEl.className = 'char-count' + (
    limit && len > limit ? ' over' :
    limit && len > Math.round(limit * 0.85) ? ' warn' : ''
  );
}
// 岗位名称实时同步到 profile-bar 下拉 + 任务栏岗位列表
$('job-title')?.addEventListener('input', () => {
  const idx = jobProfiles.findIndex(p => p.id === activeProfileId);
  if (idx < 0) return;
  const jt = $('job-title').value.trim();
  jobProfiles[idx].name     = jt || '未命名岗位';
  jobProfiles[idx].jobTitle = jt;
  renderProfileSelector();
  renderJobList();
});

// 工作时间显示/隐藏
$('work-hours-enabled').addEventListener('change', () => {
  $('work-hours-row').classList.toggle('visible', $('work-hours-enabled').checked);
});

// ─── 行为预设 ────────────────────────────────────────────────────────────────
const PRESETS = {
  gentle: {
    typingSpeedMin: 120, typingSpeedMax: 350,
    breakAfterN: 5, skipProbability: 0.12,
    dailyContactLimit: 30, scrollSteps: 4, scrollProfileEnabled: true,
  },
  normal: {
    typingSpeedMin: 80, typingSpeedMax: 200,
    breakAfterN: 8, skipProbability: 0.08,
    dailyContactLimit: 50, scrollSteps: 3, scrollProfileEnabled: true,
  },
  fast: {
    typingSpeedMin: 40, typingSpeedMax: 100,
    breakAfterN: 15, skipProbability: 0.03,
    dailyContactLimit: 80, scrollSteps: 2, scrollProfileEnabled: false,
  },
};

function applyPreset(name) {
  const p = PRESETS[name];
  $('typing-min').value = p.typingSpeedMin; $('typing-min-val').textContent = p.typingSpeedMin;
  $('typing-max').value = p.typingSpeedMax; $('typing-max-val').textContent = p.typingSpeedMax;
  $('break-n').value = p.breakAfterN; $('break-n-val').textContent = p.breakAfterN;
  $('skip-prob').value = Math.round(p.skipProbability * 100); $('skip-val').textContent = Math.round(p.skipProbability * 100);
  $('daily-limit').value = p.dailyContactLimit;
  $('scroll-steps').value = p.scrollSteps; $('scroll-steps-val').textContent = p.scrollSteps;
  $('scroll-enabled').checked = p.scrollProfileEnabled;

  document.querySelectorAll('.btn-preset').forEach(b => b.classList.remove('active'));
  $(`preset-${name}`)?.classList.add('active');
}

$('preset-gentle').addEventListener('click', () => applyPreset('gentle'));
$('preset-normal').addEventListener('click', () => applyPreset('normal'));
$('preset-fast').addEventListener('click', () => applyPreset('fast'));

// ─── 旧配置迁移（单岗位 → 多岗位） ──────────────────────────────────────────
function migrateConfig(config) {
  if (config.jobProfiles) return config; // 已是新格式
  const profile = {
    id: 'j_' + Date.now(),
    name: config.jobTitle || '默认岗位',
    enabled: true,
    keywords: config.searchKeywords || '',
    jobTitle: config.jobTitle || '',
    jobDescription: config.jobDescription || '',
    scoreThreshold: config.scoreThreshold ?? 70,
    useAiMsg: !!config.useAIMessage,
    filterCriteria: config.filterCriteria || {},
  };
  return { ...config, jobProfiles: [profile], activeProfileId: profile.id };
}

// ─── 从表单读取当前 Profile 字段 ────────────────────────────────────────────
function readCurrentProfileFields() {
  const checkedKwLogic = document.querySelector('input[name="p-kwLogic"]:checked');
  const jt = $('job-title').value.trim();
  return {
    name: jt || '未命名岗位',
    jobTitle: jt,
    keywords: $('keywords').value.trim(),
    jobDescription: $('job-desc').value.trim(),
    scoreThreshold: parseInt($('score-threshold').value) || 70,
    useAiMsg: $('use-ai-msg').checked,
    filterCriteria: {
      companyTier:     $('f-companyTier').value,
      targetCompanies: $('f-targetCompanies').value.trim(),
      minEducation:    $('f-minEducation').value,
      school:          $('f-school').value,
      minExpYears:     parseInt($('f-minExpYears').value) || 0,
      maxExpYears:     parseInt($('f-maxExpYears').value) || 0,
      minAvgTenure:    parseFloat($('f-minAvgTenure').value) || 0,
      minLastTenure:   parseFloat($('f-minLastTenure').value) || 0,
      gender:          $('f-gender').value,
      notes:           $('f-notes').value.trim(),
      keywords:        [...popupKeywords],
      keywordsLogic:   checkedKwLogic ? checkedKwLogic.value : 'any',
    },
  };
}

// 将当前表单值写入内存中的 jobProfiles（不写 storage）
function saveCurrentProfileToMemory() {
  const idx = jobProfiles.findIndex(p => p.id === activeProfileId);
  if (idx >= 0) {
    jobProfiles[idx] = { ...jobProfiles[idx], ...readCurrentProfileFields() };
  }
}

// ─── 从 Profile 数据填充表单 ─────────────────────────────────────────────────
function fillFormFromProfile(profile) {
  $('keywords').value     = profile.keywords || '';
  $('job-title').value    = profile.jobTitle || profile.name || '';
  $('job-desc').value     = profile.jobDescription || '';
  const thr = profile.scoreThreshold ?? 70;
  $('score-threshold').value = thr;
  $('score-val').textContent = thr;
  $('use-ai-msg').checked = !!profile.useAiMsg;
  const fc = profile.filterCriteria || {};
  setSelectVal('f-companyTier',   fc.companyTier   || 'any');
  $('f-targetCompanies').value = fc.targetCompanies || '';
  setSelectVal('f-minEducation',  fc.minEducation  || 'any');
  setSelectVal('f-school',        fc.school        || 'any');
  setSelectVal('f-minExpYears',   String(fc.minExpYears  ?? 0));
  setSelectVal('f-maxExpYears',   String(fc.maxExpYears  ?? 0));
  setSelectVal('f-minAvgTenure',  String(fc.minAvgTenure  ?? 0));
  setSelectVal('f-minLastTenure', String(fc.minLastTenure ?? 0));
  setSelectVal('f-gender',        fc.gender || 'any');
  $('f-notes').value = fc.notes || '';
  popupKeywords = Array.isArray(fc.keywords) ? [...fc.keywords] : [];
  renderPopupKeywords();
  const kwLogic = fc.keywordsLogic || 'any';
  const kwRadio = document.querySelector(`input[name="p-kwLogic"][value="${kwLogic}"]`);
  if (kwRadio) kwRadio.checked = true;

}

// ─── 渲染岗位相关 UI ─────────────────────────────────────────────────────────
function renderProfileSelector() {
  const sel = $('profile-selector');
  if (!sel) return;
  sel.innerHTML = jobProfiles.map(p =>
    `<option value="${p.id}">${escHtml(p.name || p.jobTitle || '未命名岗位')}</option>`
  ).join('');
  if (activeProfileId) sel.value = activeProfileId;
}

// 任务栏岗位名称原位编辑
function startInlineEdit(nameEl, id) {
  const profile = jobProfiles.find(p => p.id === id);
  if (!profile) return;
  const originalName = profile.name || profile.jobTitle || '';

  const input = document.createElement('input');
  input.type = 'text';
  input.value = originalName;
  input.className = 'job-name-edit-input';
  nameEl.textContent = '';
  nameEl.appendChild(input);
  input.focus();
  input.select();

  let cancelled = false;
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter')  { e.preventDefault(); input.blur(); }
    if (e.key === 'Escape') { cancelled = true; input.blur(); }
    e.stopPropagation();
  });
  input.addEventListener('blur', () => {
    if (cancelled) { renderJobList(); return; }
    const newName = input.value.trim() || '未命名岗位';
    const idx = jobProfiles.findIndex(p => p.id === id);
    if (idx >= 0) {
      jobProfiles[idx].name     = newName;
      jobProfiles[idx].jobTitle = newName;
      if (id === activeProfileId) $('job-title').value = newName;
      renderProfileSelector();
      renderJobList();
      scheduleAutoSave();
    }
  });
}

function renderJobList() {
  const el = $('job-list');
  if (!el) return;
  if (!jobProfiles.length) {
    el.innerHTML = '<div class="job-empty">暂无岗位，请先在「配置」中新增</div>';
    return;
  }
  const anyRunning = runningProfileId || recruitRunningProfileId;
  const sorted = anyRunning
    ? [...jobProfiles].sort((a, b) => {
        const aRun = (a.id === runningProfileId || a.id === recruitRunningProfileId) ? 1 : 0;
        const bRun = (b.id === runningProfileId || b.id === recruitRunningProfileId) ? 1 : 0;
        return bRun - aRun;
      })
    : jobProfiles;

  const showOrder = jobProfiles.length > 1;

  el.innerHTML = sorted.map(p => {
    const kwLines = (p.keywords || '').split('\n').filter(Boolean);
    const kwSummary = kwLines.length > 0
      ? kwLines.slice(0, 3).join(' / ') + (kwLines.length > 3 ? '...' : '')
      : '（未设置关键词）';
    const on = p.enabled !== false;
    const isSocialRunning = runningProfileId && p.id === runningProfileId;
    const isRecruitRunning = recruitRunningProfileId && p.id === recruitRunningProfileId;
    const isRunning = isSocialRunning || isRecruitRunning;
    const isSelected = p.id === activeProfileId;
    const originalIdx = jobProfiles.indexOf(p);
    const orderBadge = showOrder
      ? `<span class="job-order-badge">${originalIdx + 1}</span>`
      : '';
    const moveBtns = showOrder ? `
        <div class="job-move-btns">
          <button class="btn-move-job up" data-id="${p.id}" title="上移" ${originalIdx === 0 ? 'disabled' : ''}>▲</button>
          <button class="btn-move-job down" data-id="${p.id}" title="下移" ${originalIdx === jobProfiles.length - 1 ? 'disabled' : ''}>▼</button>
        </div>` : '';
    return `
      <div class="job-item${on ? '' : ' disabled'}${isRunning ? ' job-running' : ''}${isSelected ? ' selected' : ''}" data-id="${p.id}">
        ${orderBadge}
        <input type="checkbox" class="job-item-check" ${on ? 'checked' : ''} tabindex="-1">
        <div class="job-item-info">
          <div class="job-item-name">${isSocialRunning ? '👥▶ ' : isRecruitRunning ? '🏢▶ ' : ''}${escHtml(p.name || p.jobTitle || '未命名岗位')}</div>
          <div class="job-item-kw">${escHtml(kwSummary)}</div>
        </div>
        ${moveBtns}
        <button class="btn-edit-job" data-id="${p.id}" title="查看/编辑配置">⚙️</button>
      </div>`;
  }).join('');

  el.querySelectorAll('.job-item').forEach(row => {
    row.querySelector('.job-item-check')?.addEventListener('click', e => {
      e.stopPropagation();
      const p = jobProfiles.find(x => x.id === row.dataset.id);
      if (!p) return;
      p.enabled = !e.target.checked ? false : true;
      row.classList.toggle('disabled', p.enabled === false);
      scheduleAutoSave();
      renderRotationHint();
    });

    row.addEventListener('click', async e => {
      if (e.target.closest('.btn-edit-job') || e.target.closest('.btn-move-job') || e.target.closest('.job-item-check')) return;
      await selectJob(row.dataset.id);
      renderJobList();
    });
  });

  el.querySelectorAll('.btn-edit-job').forEach(btn => {
    btn.addEventListener('click', async e => {
      e.stopPropagation();
      await selectJob(btn.dataset.id);
      document.querySelector('[data-tab="tab-config"]')?.click();
    });
  });

  el.querySelectorAll('.btn-move-job').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const id = btn.dataset.id;
      const idx = jobProfiles.findIndex(p => p.id === id);
      const dir = btn.classList.contains('up') ? -1 : 1;
      const newIdx = idx + dir;
      if (newIdx < 0 || newIdx >= jobProfiles.length) return;
      [jobProfiles[idx], jobProfiles[newIdx]] = [jobProfiles[newIdx], jobProfiles[idx]];
      scheduleAutoSave();
      renderJobList();
      renderRotationHint();
    });
  });

  renderRotationHint();
}

function renderRotationHint() {
  const hint = $('job-rotation-hint');
  if (!hint) return;
  const enabled = jobProfiles.filter(p => p.enabled !== false);
  if (enabled.length >= 2) {
    const circled = ['①','②','③','④','⑤','⑥','⑦','⑧','⑨','⑩'];
    const names = enabled.map((p, i) => `${circled[i] || (i+1+'.')}${escHtml(p.name || p.jobTitle || '未命名')}`).join(' → ');
    hint.innerHTML = `🔁 <b>多岗位轮转</b>：${names} → 循环<br>每个岗位找满 <b>1 小时</b>后自动切换，直到手动停止`;
    hint.style.display = '';
  } else {
    hint.style.display = 'none';
  }
}

// ─── Profile 切换 / 新增 / 删除 ──────────────────────────────────────────────
async function switchProfile(id) {
  if (id === activeProfileId) return;
  saveCurrentProfileToMemory();
  activeProfileId = id;
  const profile = jobProfiles.find(p => p.id === id);
  if (profile) {
    fillFormFromProfile(profile);
    renderProfileSelector();
    renderJobList();
  }
  clearTimeout(_autoSaveTimer);
  autoSaveAll().catch(() => {});
}

async function addProfile() {
  saveCurrentProfileToMemory();
  const tplSrc = jobProfiles[0] || {};
  const newProfile = {
    id: 'j_' + Date.now(),
    name: '新岗位',
    enabled: true,
    keywords: '',
    jobTitle: '新岗位',
    jobDescription: '',
    scoreThreshold: 70,
    useAiMsg: tplSrc.useAiMsg || false,
    filterCriteria: {},
  };
  jobProfiles.push(newProfile);
  activeProfileId = newProfile.id;
  fillFormFromProfile(newProfile);
  renderProfileSelector();
  renderJobList();
  await autoSaveAll();
  document.querySelector('[data-tab="tab-config"]')?.click();
  setTimeout(() => { const jt = $('job-title'); if (jt) { jt.select(); jt.focus(); } }, 150);
}

async function deleteProfile() {
  if (jobProfiles.length <= 1) { alert('至少保留一个岗位'); return; }
  const cur = jobProfiles.find(p => p.id === activeProfileId);
  if (!confirm(`确定删除岗位「${cur?.name || cur?.jobTitle || ''}」？`)) return;
  const idx = jobProfiles.findIndex(p => p.id === activeProfileId);
  jobProfiles.splice(idx, 1);
  const newIdx = Math.min(idx, jobProfiles.length - 1);
  activeProfileId = jobProfiles[newIdx].id;
  fillFormFromProfile(jobProfiles[newIdx]);
  renderProfileSelector();
  renderJobList();
  scheduleAutoSave();
}

// ─── 岗位选中：同步配置 Tab + 人选 Tab ──────────────────────────────────────
async function selectJob(id) {
  if (id !== activeProfileId) await switchProfile(id);
  const profile = jobProfiles.find(p => p.id === id);
  candFilterJobName = profile?.name || profile?.jobTitle || null;
  const candTab = $('tab-candidates');
  if (candTab?.classList.contains('active')) {
    renderCandidates(_allCandidates);
  }
}

// ─── 加载配置 ────────────────────────────────────────────────────────────────
async function loadConfig() {
  let { config = {} } = await chrome.storage.local.get('config');

  if (!config.claudeApiKey && !config.jobProfiles && !config.jobDescription) {
    try {
      const { config: syncCfg = {} } = await chrome.storage.sync.get('config');
      if (syncCfg.claudeApiKey || syncCfg.jobDescription) {
        config = syncCfg;
        await chrome.storage.local.set({ config });
      }
    } catch (_) {}
  }

  if (!config.jobProfiles) config = migrateConfig(config);

  jobProfiles = config.jobProfiles || [];
  activeProfileId = config.activeProfileId || jobProfiles[0]?.id || null;

  if (config.claudeApiKey) $('api-key').value = config.claudeApiKey;
  const savedModel = config.claudeModel || 'claude-sonnet-4-6';
  const opt = $('model').querySelector(`option[value="${savedModel}"]`);
  if (opt) {
    $('model').value = savedModel;
  } else {
    $('model').value = 'custom';
    $('model-custom').value = savedModel;
    $('model-custom').style.display = '';
  }
  const defaultBaseForModel = getDefaultBase(savedModel);
  const claudeProxyHosts = ['llm-proxy.tapsvc.com', 'api.anthropic.com'];
  const savedBase = config.claudeApiBase || '';
  const savedBaseIsClaudeProxy = claudeProxyHosts.some(h => savedBase.includes(h));
  const modelIsNonClaude = savedModel && !savedModel.startsWith('claude-');
  if (modelIsNonClaude && savedBaseIsClaudeProxy && defaultBaseForModel) {
    $('api-base').value = defaultBaseForModel;
  } else {
    $('api-base').value = savedBase || defaultBaseForModel || 'https://llm-proxy.tapsvc.com';
  }
  $('debug-mode').checked = !!config.debugMode;
  $('chat-assist-enabled').checked = config.chatAssistEnabled !== false;

  const bh = config.humanBehavior || {};
  $('daily-limit').value = bh.dailyContactLimit ?? 50;
  $('scroll-enabled').checked = bh.scrollProfileEnabled !== false;
  $('scroll-steps').value = bh.scrollSteps ?? 3;
  $('scroll-steps-val').textContent = bh.scrollSteps ?? 3;
  $('work-hours-enabled').checked = !!bh.workHoursEnabled;
  $('work-hours-row').classList.toggle('visible', !!bh.workHoursEnabled);
  $('work-start').value = bh.workHoursStart ?? 9;
  $('work-end').value = bh.workHoursEnd ?? 18;
  $('typing-min').value = bh.typingSpeedMin ?? 80;
  $('typing-min-val').textContent = bh.typingSpeedMin ?? 80;
  $('typing-max').value = bh.typingSpeedMax ?? 200;
  $('typing-max-val').textContent = bh.typingSpeedMax ?? 200;
  $('break-n').value = bh.breakAfterN ?? 8;
  $('break-n-val').textContent = bh.breakAfterN ?? 8;
  $('skip-prob').value = Math.round((bh.skipProbability ?? 0.08) * 100);
  $('skip-val').textContent = Math.round((bh.skipProbability ?? 0.08) * 100);

  const activeProfile = jobProfiles.find(p => p.id === activeProfileId) || jobProfiles[0];
  if (activeProfile) fillFormFromProfile(activeProfile);

  renderProfileSelector();
  renderJobList();

  const anyReady = jobProfiles.some(p => p.jobDescription);
  $('notice-no-config').style.display = (config.claudeApiKey && anyReady) ? 'none' : '';
}

function setSelectVal(id, value) {
  const el = $(id);
  if (!el) return;
  if ([...el.options].some(o => o.value === value)) el.value = value;
}

// ─── 保存配置 ────────────────────────────────────────────────────────────────
function showTip(elId, msg, isErr = false) {
  const el = $(elId);
  el.textContent = msg;
  el.className = 'save-tip' + (isErr ? ' err' : '');
  if (el._tipTimer) clearTimeout(el._tipTimer);
  if (isErr) {
    el.style.cursor = 'pointer';
    el.onclick = () => { el.textContent = ''; el.className = 'save-tip'; el.style.cursor = ''; el.onclick = null; };
  } else {
    el.style.cursor = '';
    el.onclick = null;
    el._tipTimer = setTimeout(() => { el.textContent = ''; el.className = 'save-tip'; }, 4000);
  }
}

$('btn-save-config').addEventListener('click', async () => {
  if (!$('api-key').value.trim()) {
    showTip('save-tip', '⚠️ 请填写 API Key', true); return;
  }
  if (!$('job-desc').value.trim()) {
    showTip('save-tip', '⚠️ 请填写岗位要求', true); return;
  }
  const _minY = parseInt($('f-minExpYears').value) || 0;
  const _maxY = parseInt($('f-maxExpYears').value) || 0;
  if (_minY > 0 && _maxY > 0 && _minY >= _maxY) {
    showTip('save-tip', '⚠️ 工作年限：最少不能 ≥ 最多', true); return;
  }

  saveCurrentProfileToMemory();
  const { config = {} } = await chrome.storage.local.get('config');
  const updated = {
    ...config,
    claudeApiKey:  $('api-key').value.trim(),
    claudeApiBase: $('api-base').value.trim(),
    claudeModel:   $('model').value === 'custom' ? $('model-custom').value.trim() : $('model').value,
    debugMode:     $('debug-mode').checked,
    jobProfiles,
    activeProfileId,
  };

  try {
    await chrome.storage.local.set({ config: updated });
    renderProfileSelector();
    renderJobList();
    showTip('save-tip', '✅ 已保存');
    $('notice-no-config').style.display = 'none';
  } catch (e) {
    showTip('save-tip', '❌ 保存失败，请重试', true);
  }
});

$('btn-test-key').addEventListener('click', async () => {
  const key = $('api-key').value.trim();
  if (!key) { showTip('save-tip', '⚠️ 请先填写 API Key', true); return; }
  const { config: cur = {} } = await chrome.storage.local.get('config');
  const currentModel = $('model').value === 'custom' ? $('model-custom').value.trim() : $('model').value;
  await chrome.storage.local.set({ config: { ...cur, claudeApiKey: key, claudeApiBase: $('api-base').value.trim(), claudeModel: currentModel } });
  showTip('save-tip', '🔄 验证中...');
  const resp = await sendMsg({ type: 'TEST_API' }).catch(e => ({ success: false, error: e.message }));
  if (resp.success) {
    showTip('save-tip', resp.message);
    const sel = $('model');
    if (resp.model && sel.querySelector(`option[value="${resp.model}"]`)) {
      sel.value = resp.model;
    } else if (resp.model) {
      sel.value = 'custom';
      $('model-custom').value = resp.model;
      $('model-custom').style.display = '';
    }
  } else {
    showTip('save-tip', `❌ ${resp.error}`, true);
  }
});

// ─── 岗位 Profile 管理按钮事件 ───────────────────────────────────────────────
$('profile-selector')?.addEventListener('change', () => {
  switchProfile($('profile-selector').value);
});

$('btn-add-profile')?.addEventListener('click', addProfile);
$('btn-del-profile')?.addEventListener('click', deleteProfile);
$('btn-add-job-quick')?.addEventListener('click', addProfile);

// ─── 关键词标签管理（筛选条件）──────────────────────────────────────────────
let popupKeywords = [];

function renderPopupKeywords() {
  const el = $('p-keyword-tags');
  if (!el) return;
  el.innerHTML = popupKeywords.map((kw, i) => `
    <span class="tag-item-p">${kw}<span class="tag-del-p" data-i="${i}">×</span></span>`).join('');
  el.querySelectorAll('.tag-del-p').forEach(btn => {
    btn.addEventListener('click', () => {
      popupKeywords.splice(parseInt(btn.dataset.i), 1);
      renderPopupKeywords();
      scheduleAutoSave();
    });
  });
}

function addPopupKeyword() {
  const input = $('p-keyword-input');
  const val = input.value.trim();
  if (val && !popupKeywords.includes(val)) {
    popupKeywords.push(val);
    renderPopupKeywords();
  }
  input.value = '';
  input.focus();
}

$('p-keyword-input')?.addEventListener('keydown', e => {
  if (e.key === 'Enter') { e.preventDefault(); addPopupKeyword(); }
});

$('btn-save-behavior').addEventListener('click', async () => {
  const { config = {} } = await chrome.storage.local.get('config');
  const bh = config.humanBehavior || {};

  const updated = {
    ...config,
    chatAssistEnabled: $('chat-assist-enabled').checked,
    humanBehavior: {
      ...bh,
      typingSpeedMin: parseInt($('typing-min').value) || 80,
      typingSpeedMax: parseInt($('typing-max').value) || 200,
      breakAfterN: parseInt($('break-n').value) || 8,
      skipProbability: (parseInt($('skip-prob').value) || 8) / 100,
      dailyContactLimit: parseInt($('daily-limit').value) || 50,
      scrollProfileEnabled: $('scroll-enabled').checked,
      scrollSteps: parseInt($('scroll-steps').value) || 3,
      workHoursEnabled: $('work-hours-enabled').checked,
      workHoursStart: parseInt($('work-start').value) ?? 9,
      workHoursEnd: parseInt($('work-end').value) ?? 18,
    },
  };

  await chrome.storage.local.set({ config: updated });
  showTip('save-tip-b', '✅ 已保存');
});

// ─── 自动保存（配置/行为 Tab 任意字段变动后 800ms 自动保存）────────────────────
let _autoSaveTimer = null;

async function autoSaveAll() {
  const { config = {} } = await chrome.storage.local.get('config');
  const bh = config.humanBehavior || {};
  saveCurrentProfileToMemory();
  const updated = {
    ...config,
    claudeApiKey:      $('api-key').value.trim(),
    claudeApiBase:     $('api-base').value.trim(),
    claudeModel:       $('model').value === 'custom' ? $('model-custom').value.trim() : $('model').value,
    debugMode:         $('debug-mode').checked,
    chatAssistEnabled: $('chat-assist-enabled').checked,
    jobProfiles,
    activeProfileId,
    humanBehavior: {
      ...bh,
      typingSpeedMin:       parseInt($('typing-min').value) || 80,
      typingSpeedMax:       parseInt($('typing-max').value) || 200,
      breakAfterN:          parseInt($('break-n').value) || 8,
      skipProbability:      (parseInt($('skip-prob').value) || 8) / 100,
      dailyContactLimit:    parseInt($('daily-limit').value) || 50,
      scrollProfileEnabled: $('scroll-enabled').checked,
      scrollSteps:          parseInt($('scroll-steps').value) || 3,
      workHoursEnabled:     $('work-hours-enabled').checked,
      workHoursStart:       parseInt($('work-start').value) ?? 9,
      workHoursEnd:         parseInt($('work-end').value) ?? 18,
    },
  };
  try {
    await chrome.storage.local.set({ config: updated });
    renderJobList();
    renderProfileSelector();
    showTip('save-tip', '✅ 已自动保存');
    $('notice-no-config').style.display = 'none';
  } catch (e) {
    showTip('save-tip', '⚠️ 自动保存失败，请手动点击保存重试', true);
    console.error('[Boss助手] storage.local.set 失败:', e);
  }
}

function scheduleAutoSave() {
  clearTimeout(_autoSaveTimer);
  _autoSaveTimer = setTimeout(autoSaveAll, 800);
}

document.getElementById('tab-config')?.addEventListener('input', scheduleAutoSave);
document.getElementById('tab-config')?.addEventListener('change', scheduleAutoSave);
document.getElementById('tab-behavior')?.addEventListener('input', scheduleAutoSave);
document.getElementById('tab-behavior')?.addEventListener('change', scheduleAutoSave);

// ─── 任务状态渲染 ─────────────────────────────────────────────────────────────
function renderStatus(status) {
  const social  = status.social  || status;
  const recruit = status.recruit || { running: false, paused: false, processed: 0, matched: 0, messaged: 0, failed: 0 };

  const newRunningId = social.running ? (social.activeProfileId || null) : null;
  const newRecruitRunningId = recruit.running ? (recruit.activeProfileId || null) : null;
  if (newRunningId !== runningProfileId || newRecruitRunningId !== recruitRunningProfileId) {
    runningProfileId = newRunningId;
    recruitRunningProfileId = newRecruitRunningId;
    renderJobList();
  }

  // ── 推荐牛人模式 ──
  const sDot = $('social-dot'), sTxt = $('social-status-text');
  if (sDot && sTxt) {
    if (social.running && !social.paused) {
      sDot.className = 'dot running';
      const prog = social.processed > 0 ? ` · ${social.processed}人` : '';
      sTxt.textContent = `运行中 · ${social.currentKeyword || ''}${prog}`;
      $('btn-start').disabled = true;
      $('btn-pause').disabled = false;
      $('btn-stop').disabled = false;
      $('btn-pause').textContent = '⏸ 暂停';
    } else if (social.running && social.paused) {
      sDot.className = 'dot paused';
      sTxt.textContent = '已暂停';
      $('btn-pause').textContent = '▶ 继续';
      $('btn-pause').disabled = false;
      $('btn-stop').disabled = false;
      $('btn-start').disabled = true;
    } else {
      sDot.className = 'dot idle';
      sTxt.textContent = '就绪';
      $('btn-start').disabled = false;
      $('btn-pause').disabled = true;
      $('btn-stop').disabled = true;
      $('btn-pause').textContent = '⏸ 暂停';
    }
  }

  if (social.processed > 0 || social.running) {
    $('social-stats').style.display = '';
    $('s-processed').textContent = social.processed || 0;
    $('s-matched').textContent = social.matched || 0;
    $('s-messaged').textContent = social.messaged || 0;
    const sf = social.failed || 0;
    $('s-failed').textContent = sf;
    $('s-failed-wrap').style.display = sf > 0 ? '' : 'none';
  }

  // ── 搜索模式 ──
  const rDot = $('recruit-dot'), rTxt = $('recruit-status-text');
  if (rDot && rTxt) {
    if (recruit.running && !recruit.paused) {
      rDot.className = 'dot running';
      const prog = recruit.processed > 0 ? ` · ${recruit.processed}人` : '';
      rTxt.textContent = `运行中${prog}`;
      $('btn-start-recruit').disabled = true;
      $('btn-pause-recruit').disabled = false;
      $('btn-stop-recruit').disabled = false;
      $('btn-pause-recruit').textContent = '⏸ 暂停';
    } else if (recruit.running && recruit.paused) {
      rDot.className = 'dot paused';
      rTxt.textContent = '已暂停';
      $('btn-pause-recruit').textContent = '▶ 继续';
      $('btn-pause-recruit').disabled = false;
      $('btn-stop-recruit').disabled = false;
      $('btn-start-recruit').disabled = true;
    } else {
      rDot.className = 'dot idle';
      rTxt.textContent = '就绪';
      $('btn-start-recruit').disabled = false;
      $('btn-pause-recruit').disabled = true;
      $('btn-stop-recruit').disabled = true;
      $('btn-pause-recruit').textContent = '⏸ 暂停';
    }
  }

  if (recruit.processed > 0 || recruit.running) {
    $('recruit-stats').style.display = '';
    $('r-processed').textContent = recruit.processed || 0;
    $('r-matched').textContent = recruit.matched || 0;
    $('r-messaged').textContent = recruit.messaged || 0;
    const rf = recruit.failed || 0;
    $('r-failed').textContent = rf;
    $('r-failed-wrap').style.display = rf > 0 ? '' : 'none';
  }

  if (status.recentLogs?.length) renderLogs(status.recentLogs);
}

let _lastLogs = [];
let _prevLogCount = 0;

function renderLogs(logs) {
  const list = $('log-list');
  if (!logs.length) return;
  if (logs.length === _prevLogCount && logs[0]?.message === _lastLogs[0]?.message) return;
  _prevLogCount = logs.length;
  _lastLogs = logs;
  const errCount = logs.filter(l => l.level === 'error').length;
  const title = $('log-title-text');
  if (title) title.textContent = errCount > 0 ? `最近日志 ⚠️ ${errCount}个错误` : '最近日志';
  list.innerHTML = logs.slice(0, 50).map(l =>
    `<div class="log-entry ${l.level || 'info'}"><span class="t">${l.time}</span>${escHtml(l.message)}</div>`
  ).join('');
}

$('btn-copy-log').addEventListener('click', () => {
  if (!_lastLogs.length) return;
  const text = _lastLogs.slice(0, 100).map(l => `[${l.time}][${l.level}] ${l.message}`).join('\n');
  navigator.clipboard.writeText(text).then(() => {
    const btn = $('btn-copy-log');
    const orig = btn.textContent;
    btn.textContent = '✅ 已复制';
    setTimeout(() => { btn.textContent = orig; }, 1500);
  }).catch(() => {});
});

function escHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// ─── 任务控制按钮 ─────────────────────────────────────────────────────────────
$('btn-start').onclick = async () => {
  saveCurrentProfileToMemory();

  const enabledProfiles = jobProfiles.filter(p => p.enabled !== false);
  if (!enabledProfiles.length) {
    alert('请在岗位列表中至少勾选一个岗位');
    return;
  }

  const { config = {} } = await chrome.storage.local.get('config');
  if (!config.claudeApiKey) {
    alert('⚠️ 请先在「配置」Tab 填写 API Key');
    document.querySelector('[data-tab="tab-config"]').click();
    return;
  }
  for (const p of enabledProfiles) {
    if (!p.jobDescription) {
      alert(`⚠️ 岗位「${p.name || p.jobTitle || '未命名'}」未填写岗位职责，请先在「配置」Tab 完善`);
      await switchProfile(p.id);
      document.querySelector('[data-tab="tab-config"]').click();
      return;
    }
  }

  const runCheck = await sendMsg({ type: 'IS_RUNNING' }).catch(() => ({ social: { running: false } }));
  const socialRunning = runCheck.social?.running ?? runCheck.running ?? false;
  if (socialRunning) {
    if (!confirm('推荐牛人任务正在运行中。\n\n是否停止当前任务并重新开始？')) return;
    await sendMsg({ type: 'STOP_TASK', mode: 'social' });
    await new Promise(r => setTimeout(r, 1000));
  }

  $('social-dot').className = 'dot starting';
  $('social-status-text').textContent = '启动中...';
  $('btn-start').disabled = true;

  await autoSaveAll();

  // 优先使用已打开的 Boss 直聘标签页（避免后台标签 UI 事件失效）
  let targetTab = null;
  const bossTabs = await chrome.tabs.query({ url: '*://www.zhipin.com/*' }).catch(() => []);
  targetTab = bossTabs.find(t => !t.url?.includes('chrome-extension://')) || bossTabs[0] || null;

  if (targetTab) {
    // 已有 Boss 标签：激活它（确保 UI 可交互）
    await chrome.tabs.update(targetTab.id, { active: true }).catch(() => {});
    await chrome.windows.update(targetTab.windowId, { focused: true }).catch(() => {});
  } else {
    // 没有已打开的 Boss 标签：新开（前台，确保 UI 事件正常）
    const userWin = await chrome.windows.getLastFocused({ windowTypes: ['normal'], populate: false })
      .catch(() => null);
    targetTab = await chrome.tabs.create({
      url: 'https://www.zhipin.com/web/chat/index',
      active: true,
      windowId: userWin?.id,
    }).catch(e => { alert(`创建自动化标签失败: ${e.message}`); return null; });
    if (!targetTab) return;
    await waitTabLoad(targetTab.id);
  }

  await sendMsg({ type: 'SET_AUTOMATION_TAB', tabId: targetTab.id, windowId: null });
  await injectAndRun(targetTab.id, enabledProfiles);

  const sw = window.screen.availWidth || 1440;
  const sl = window.screen.availLeft  || 0;
  const st = window.screen.availTop   || 0;
  const panelW = 400, panelH = 560;
  await chrome.windows.create({
    url: chrome.runtime.getURL('popup.html') + '?panel=1',
    type: 'popup',
    left: Math.max(sl, sl + sw - panelW - 24),
    top: st + 40,
    width: panelW, height: panelH,
    focused: false,
  }).catch(() => {});

  window.close();
};

$('btn-pause').onclick = async () => { await sendMsg({ type: 'PAUSE_TASK', mode: 'social' }); };
$('btn-stop').onclick  = async () => { await sendMsg({ type: 'STOP_TASK',  mode: 'social' }); };

$('btn-pause-recruit').onclick = async () => { await sendMsg({ type: 'PAUSE_TASK', mode: 'recruit' }); };
$('btn-stop-recruit').onclick  = async () => { await sendMsg({ type: 'STOP_TASK',  mode: 'recruit' }); };

// ─── 搜索模式：在已打开的 Boss 搜索页注入运行 ────────────────────────────────
$('btn-start-recruit').onclick = async () => {
  saveCurrentProfileToMemory();

  const enabledProfiles = jobProfiles
    .filter(p => p.enabled !== false)
    .sort((a, b) => {
      if (a.id === activeProfileId) return -1;
      if (b.id === activeProfileId) return 1;
      return 0;
    });
  if (!enabledProfiles.length) {
    alert('请在岗位列表中至少勾选一个岗位');
    return;
  }

  const { config = {} } = await chrome.storage.local.get('config');
  if (!config.claudeApiKey) {
    alert('⚠️ 请先在「配置」Tab 填写 API Key');
    document.querySelector('[data-tab="tab-config"]').click();
    return;
  }
  for (const p of enabledProfiles) {
    if (!p.jobDescription) {
      alert(`⚠️ 岗位「${p.name || p.jobTitle || '未命名'}」未填写岗位职责，请先在「配置」Tab 完善`);
      await switchProfile(p.id);
      document.querySelector('[data-tab="tab-config"]').click();
      return;
    }
  }

  const runCheck2 = await sendMsg({ type: 'IS_RUNNING' }).catch(() => ({ recruit: { running: false } }));
  const recruitRunning = runCheck2.recruit?.running ?? false;
  if (recruitRunning) {
    if (!confirm('搜索任务正在运行中。\n\n是否停止当前任务并重新开始？')) return;
    await sendMsg({ type: 'STOP_TASK', mode: 'recruit' });
    await new Promise(r => setTimeout(r, 1000));
  }

  // 查找已打开的 Boss 招聘端标签页（或新建）
  const SEARCH_URL = 'https://www.zhipin.com/web/chat/search';
  const recruitTabs = await chrome.tabs.query({ url: '*://www.zhipin.com/*' }).catch(() => []);
  let targetTab = recruitTabs.find(t => !t.url?.includes('chrome-extension://')) || recruitTabs[0];

  if (!targetTab) {
    const userWin = await chrome.windows.getLastFocused({ windowTypes: ['normal'], populate: false }).catch(() => null);
    targetTab = await chrome.tabs.create({ url: SEARCH_URL, active: true, windowId: userWin?.id }).catch(() => null);
    if (!targetTab) { alert('无法打开 Boss直聘 页面，请手动打开后重试'); return; }
  }

  $('recruit-dot').className = 'dot starting';
  $('recruit-status-text').textContent = '启动中...';
  $('btn-start-recruit').disabled = true;

  await autoSaveAll();

  // 若当前不在搜索页，先导航过去（避免 content script 在非搜索页做 SPA 跳转后被销毁）
  const curUrl = targetTab.url || '';
  if (!curUrl.includes('/web/chat/search')) {
    await chrome.tabs.update(targetTab.id, { url: SEARCH_URL, active: true }).catch(() => {});
    await chrome.windows.update(targetTab.windowId, { focused: true }).catch(() => {});
    await waitTabLoad(targetTab.id);
    // 重新获取 tab 信息（url 已更新）
    targetTab = await chrome.tabs.get(targetTab.id).catch(() => targetTab);
  } else {
    await chrome.tabs.update(targetTab.id, { active: true }).catch(() => {});
    await chrome.windows.update(targetTab.windowId, { focused: true }).catch(() => {});
  }

  await sendMsg({ type: 'SET_AUTOMATION_TAB', tabId: targetTab.id, windowId: null, mode: 'recruit' });

  await chrome.scripting.executeScript({ target: { tabId: targetTab.id }, files: ['content.js'] }).catch(() => {});
  await chrome.scripting.insertCSS({ target: { tabId: targetTab.id }, files: ['content.css'] }).catch(() => {});

  let ready = false;
  for (let i = 0; i < 15; i++) {
    try {
      const resp = await chrome.tabs.sendMessage(targetTab.id, { type: 'PING' });
      if (resp?.loaded) { ready = true; break; }
    } catch (_) {}
    await new Promise(r => setTimeout(r, 200));
  }

  if (!ready) {
    alert('启动失败：content script 未就绪，请刷新页面后重试');
    $('btn-start-recruit').disabled = false;
    return;
  }

  await chrome.tabs.sendMessage(targetTab.id, { type: 'RUN_RECRUIT_TASK', profiles: enabledProfiles })
    .catch(err => alert(`启动失败: ${err.message}`));

  const sw = window.screen.availWidth || 1440;
  const sl = window.screen.availLeft || 0;
  const st = window.screen.availTop || 0;
  const panelW = 400, panelH = 560;
  await chrome.windows.create({
    url: chrome.runtime.getURL('popup.html') + '?panel=1',
    type: 'popup',
    left: Math.max(sl, sl + sw - panelW - 24),
    top: st + 40,
    width: panelW, height: panelH,
    focused: true,
  }).catch(() => {});

  window.close();
};

// ─── 注入并运行 ──────────────────────────────────────────────────────────────
async function injectAndRun(tabId, profiles) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }).catch(() => {});
  await chrome.scripting.insertCSS({ target: { tabId }, files: ['content.css'] }).catch(() => {});
  let ready = false;
  for (let i = 0; i < 15; i++) {
    try {
      const resp = await chrome.tabs.sendMessage(tabId, { type: 'PING' });
      if (resp?.loaded) { ready = true; break; }
    } catch (_) {}
    await new Promise(r => setTimeout(r, 200));
  }
  if (!ready) {
    alert('启动失败：content script 未就绪\n请确认当前页面是 Boss直聘，并刷新后重试');
    return;
  }
  await chrome.tabs.sendMessage(tabId, { type: 'RUN_TASK', profiles }).catch(err => {
    alert(`启动失败: ${err.message}\n请确认当前页面是 Boss直聘，并刷新后重试`);
  });
}

async function waitTabLoad(tabId) {
  return new Promise(resolve => {
    const listener = (id, info) => {
      if (id === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
    setTimeout(resolve, 8000);
  });
}

// ─── 状态轮询 + 推送监听 ──────────────────────────────────────────────────────
function startPolling() {
  pollTimer = setInterval(async () => {
    const resp = await sendMsg({ type: 'GET_STATUS' }).catch(() => null);
    if (resp?.status) renderStatus(resp.status);
  }, 800);
}

chrome.runtime.onMessage.addListener(msg => {
  if (msg.type === 'STATUS_UPDATE' && msg.status) renderStatus(msg.status);
});

window.addEventListener('unload', () => { if (pollTimer) clearInterval(pollTimer); });

// ─── 已查阅/联系记录（1个月内不重复） ──────────────────────────────────────
async function refreshSeenCount() {
  const data = await chrome.storage.local.get(['__boss_seen_uid', '__boss_seen_uid_ts']);
  const arr = data.__boss_seen_uid || [];
  const ts  = data.__boss_seen_uid_ts || {};
  const oneMonthAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
  const validArr = arr.filter(id => ts[id] && ts[id] > oneMonthAgo);
  if (validArr.length !== arr.length) {
    const validTs = {};
    validArr.forEach(id => { validTs[id] = ts[id]; });
    await chrome.storage.local.set({ __boss_seen_uid: validArr, __boss_seen_uid_ts: validTs });
  }
  const el = $('seen-count');
  if (el) el.textContent = validArr.length;
}

$('btn-clear-seen').addEventListener('click', async () => {
  await chrome.storage.local.remove(['__boss_seen_uid', '__boss_seen_uid_ts']);
  const el = $('seen-count');
  if (el) el.textContent = '0';
  const btn = $('btn-clear-seen');
  const orig = btn.textContent;
  btn.textContent = '✅ 已清空';
  setTimeout(() => { btn.textContent = orig; }, 1500);
});

// ─── 人选明细 Tab ─────────────────────────────────────────────────────────────
function fmtTime(ts) {
  const d = new Date(ts);
  const pad = n => String(n).padStart(2, '0');
  return `${d.getMonth()+1}/${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function renderCandidates(list) {
  const el = $('cand-list');
  const count = $('cand-count');

  let filtered = candFilterMode
    ? list.filter(c => (c.sourceMode || 'social') === candFilterMode)
    : list;

  filtered = candFilterJobName
    ? filtered.filter(c => c.jobName === candFilterJobName)
    : filtered;
  const filterBar  = $('cand-filter-bar');
  const filterText = $('cand-filter-text');
  if (filterBar)  filterBar.style.display = candFilterJobName ? '' : 'none';
  if (filterText && candFilterJobName) filterText.textContent = `岗位：${candFilterJobName}`;

  count.textContent = `共 ${filtered.length} 位人选`;
  if (!filtered.length) {
    el.innerHTML = candFilterJobName
      ? '<div class="cand-empty">该岗位暂无人选记录</div>'
      : '<div class="cand-empty">暂无通过筛选的人选</div>';
    return;
  }

  const groupMap = new Map();
  [...filtered].reverse().forEach(c => {
    const key = c.jobName || '';
    if (!groupMap.has(key)) groupMap.set(key, []);
    groupMap.get(key).push(c);
  });
  const groups = [...groupMap.entries()].sort((a, b) => {
    if (!a[0] && b[0]) return 1;
    if (a[0] && !b[0]) return -1;
    return 0;
  });
  const showHeaders = groups.length > 1 || (groups.length === 1 && groups[0][0]);

  function renderCard(c, i) {
    const scoreClass = c.score >= 85 ? 'badge-score high' : 'badge-score';
    const actionBadge = c.action === 'messaged'
      ? '<span class="badge badge-messaged">✉️ 已发消息</span>'
      : c.action === 'added'
        ? '<span class="badge badge-added">💬 已打招呼</span>'
        : '<span class="badge badge-failed">❌ 操作失败</span>';
    const highlight = c.highlights
      ? `<div class="cand-highlight">⭐ ${c.highlights}</div>` : '';
    return `
      <div class="cand-card" data-i="${i}">
        <div class="cand-card-header">
          <span class="cand-name">${escHtml(c.name || '未知')}</span>
          <span class="cand-meta">${escHtml([c.company, c.title].filter(Boolean).join(' · '))}</span>
          <div class="cand-badges">
            <span class="badge ${scoreClass}">${c.score}分</span>
            ${actionBadge}
          </div>
        </div>
        <div class="cand-time">🕐 ${fmtTime(c.timestamp)}${c.profileUrl ? ` · <a class="cand-link" href="${c.profileUrl}" target="_blank">查看主页 →</a>` : ''}</div>
        <div class="cand-detail">
          <div>${escHtml(c.reason || '')}</div>
          ${highlight}
        </div>
      </div>`;
  }

  let html = '';
  groups.forEach(([jobName, members]) => {
    if (showHeaders) {
      const messaged = members.filter(c => c.action === 'messaged').length;
      const added    = members.filter(c => c.action === 'added').length;
      const failed   = members.filter(c => c.action === 'failed').length;
      const statParts = [
        messaged ? `✉️ ${messaged}` : '',
        added    ? `💬 ${added}` : '',
        failed   ? `❌ ${failed}` : '',
      ].filter(Boolean).join('  ');
      const displayName = jobName || '历史记录';
      html += `<div class="cand-group">
        <div class="cand-group-header">
          <span class="cand-group-name">${escHtml(displayName)}</span>
          <span class="cand-group-stat">${members.length} 人  ${statParts}</span>
        </div>`;
    } else {
      html += '<div class="cand-group">';
    }
    members.forEach((c, i) => { html += renderCard(c, i); });
    html += '</div>';
  });

  el.innerHTML = html;
  el.querySelectorAll('.cand-card').forEach(card => {
    card.addEventListener('click', e => {
      if (e.target.classList.contains('cand-link')) return;
      card.classList.toggle('expanded');
    });
  });
}

async function loadCandidates() {
  const resp = await sendMsg({ type: 'GET_MATCHED_CANDIDATES' }).catch(() => ({ candidates: [] }));
  _allCandidates = resp.candidates || [];
  renderCandidates(_allCandidates);
}

$('btn-clear-cand').addEventListener('click', async () => {
  if (!confirm('确定清空所有人选记录？')) return;
  await sendMsg({ type: 'CLEAR_MATCHED_CANDIDATES' });
  _allCandidates = [];
  renderCandidates([]);
});

$('btn-clear-cand-filter').addEventListener('click', () => {
  candFilterJobName = null;
  renderCandidates(_allCandidates);
});

document.querySelectorAll('.btn-mode-filter').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.btn-mode-filter').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    candFilterMode = btn.dataset.mode || '';
    renderCandidates(_allCandidates);
  });
});

$('btn-export-cand').addEventListener('click', async () => {
  const resp = await sendMsg({ type: 'GET_MATCHED_CANDIDATES' }).catch(() => ({ candidates: [] }));
  const list = resp.candidates || [];
  if (!list.length) { alert('暂无人选记录'); return; }
  const header = '岗位,姓名,公司,职位,匹配分,操作结果,评估理由,时间';
  const rows = list.map(c => [
    '"' + (c.jobName || '').replace(/"/g, '""') + '"',
    c.name, c.company, c.title, c.score,
    c.action === 'messaged' ? '已发消息' : c.action === 'added' ? '已打招呼' : '操作失败',
    '"' + (c.reason || '').replace(/"/g, '""') + '"',
    fmtTime(c.timestamp),
  ].join(','));
  const csv = [header, ...rows].join('\n');
  navigator.clipboard.writeText(csv).then(() => {
    const btn = $('btn-export-cand');
    const orig = btn.textContent;
    btn.textContent = '✅ 已复制';
    setTimeout(() => { btn.textContent = orig; }, 1500);
  });
});

document.querySelectorAll('.tab-btn[data-tab="tab-candidates"]').forEach(btn => {
  btn.addEventListener('click', loadCandidates);
});

// ─── 初始化 ──────────────────────────────────────────────────────────────────
async function init() {
  await loadConfig();
  await refreshSeenCount();
  const resp = await sendMsg({ type: 'GET_STATUS' }).catch(() => null);
  if (resp?.status) renderStatus(resp.status);
  startPolling();
}

init().catch(console.error);
