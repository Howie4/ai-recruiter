/**
 * resume-tab.js — 简历筛选 Tab（ES Module）
 * 依赖：mammoth（全局 window.mammoth）、libs/pdf.min.mjs
 * 数据通过 chrome.runtime.sendMessage 与 background.js 通信
 */

import * as pdfjsLib from './libs/pdf.min.mjs';
pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('libs/pdf.worker.min.mjs');

// ─── 状态 ─────────────────────────────────────────────────────────────────────
let resumeQueue   = [];   // {name, type, getText: async()=>string}
let resumeResults = [];   // 评估结果
let isRunning     = false;

// ─── 初始化（模块加载即运行，此时 DOM 已就绪） ───────────────────────────────
initResumeTab();
loadResumeResults();

function initResumeTab() {
  const dropZone  = document.getElementById('resume-drop-zone');
  const fileInput = document.getElementById('resume-file-input');
  if (!dropZone) return; // 防御：若 Tab 不存在则跳过

  // 拖拽上传
  dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('dragover'); });
  dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
  dropZone.addEventListener('drop', e => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    addFiles([...e.dataTransfer.files]);
  });
  dropZone.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', () => {
    addFiles([...fileInput.files]);
    fileInput.value = '';
  });

  // 粘贴添加
  document.getElementById('resume-paste-add').addEventListener('click', () => {
    const text = document.getElementById('resume-paste-input').value.trim();
    if (!text) return;
    const idx = resumeQueue.filter(q => q.type === 'paste').length + 1;
    resumeQueue.push({ name: `粘贴文本 #${idx}`, type: 'paste', getText: async () => text });
    document.getElementById('resume-paste-input').value = '';
    updateQueueUI();
  });

  // 清空队列
  document.getElementById('resume-clear-queue').addEventListener('click', () => {
    resumeQueue = [];
    updateQueueUI();
    renderFileList();
  });

  // 开始筛选
  document.getElementById('resume-start-btn').addEventListener('click', startScreening);

  // 导出
  document.getElementById('resume-export-btn').addEventListener('click', exportCsv);

  // 清空结果
  document.getElementById('resume-clear-results').addEventListener('click', async () => {
    if (!confirm('确定清空全部简历筛选结果？')) return;
    resumeResults = [];
    await chrome.runtime.sendMessage({ type: 'SAVE_RESUME_RESULTS', results: [] });
    renderResults();
  });
}

// ─── 文件处理 ─────────────────────────────────────────────────────────────────
function addFiles(files) {
  const ok = files.filter(f => /\.(pdf|docx|txt)$/i.test(f.name));
  const skip = files.length - ok.length;
  ok.forEach(file => {
    if (resumeQueue.some(q => q.name === file.name && q.type !== 'paste')) return;
    resumeQueue.push({ name: file.name, type: file.name.split('.').pop().toLowerCase(), getText: makeParser(file) });
  });
  if (skip > 0) showError(`跳过 ${skip} 个不支持的格式（仅支持 PDF、DOCX、TXT）`);
  else hideError();
  updateQueueUI();
  renderFileList();
}

function makeParser(file) {
  const ext = file.name.split('.').pop().toLowerCase();
  return async () => {
    if (ext === 'pdf')  return parsePdf(file);
    if (ext === 'docx') return parseDocx(file);
    return parseTxt(file);
  };
}

async function parsePdf(file) {
  const buf = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: buf }).promise;
  let text = '';
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    text += content.items.map(it => it.str).join(' ') + '\n';
  }
  return text.trim();
}

async function parseDocx(file) {
  const buf = await file.arrayBuffer();
  const result = await window.mammoth.extractRawText({ arrayBuffer: buf });
  return result.value.trim();
}

function parseTxt(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = e => resolve(e.target.result.trim());
    reader.onerror = () => reject(new Error('文件读取失败'));
    reader.readAsText(file, 'utf-8');
  });
}

function renderFileList() {
  const list = document.getElementById('resume-file-list');
  const fileItems = resumeQueue.filter(q => q.type !== 'paste');
  list.innerHTML = fileItems.map((q, i) => `
    <div class="resume-file-item">
      <span class="resume-file-name" title="${esc(q.name)}">${esc(q.name)}</span>
      <span class="resume-file-type">${q.type.toUpperCase()}</span>
      <button class="resume-file-del" data-name="${esc(q.name)}" title="移除">×</button>
    </div>`).join('');
  list.querySelectorAll('.resume-file-del').forEach(btn => {
    btn.addEventListener('click', () => {
      resumeQueue = resumeQueue.filter(q => q.name !== btn.dataset.name || q.type === 'paste');
      updateQueueUI();
      renderFileList();
    });
  });
}

function updateQueueUI() {
  const count = resumeQueue.length;
  const qs = document.getElementById('resume-queue-status');
  qs.style.display = count > 0 ? 'flex' : 'none';
  document.getElementById('resume-queue-count').textContent = count;
  document.getElementById('resume-start-btn').disabled = count === 0 || isRunning;
}

// ─── 主流程 ───────────────────────────────────────────────────────────────────
async function startScreening() {
  if (isRunning || resumeQueue.length === 0) return;
  isRunning = true;
  hideError();

  const startBtn = document.getElementById('resume-start-btn');
  startBtn.disabled = true;
  document.getElementById('resume-progress-wrap').style.display = 'block';

  const total = resumeQueue.length;
  for (let i = 0; i < total; i++) {
    const item = resumeQueue[i];
    updateProgress(i, total, item.name);
    const placeholderId = `rph-${Date.now()}-${i}`;
    addPlaceholder(placeholderId, item.name);
    try {
      const text = await item.getText();
      if (!text || text.length < 20) throw new Error('文件内容为空或过短');
      const resp = await chrome.runtime.sendMessage({ type: 'EVALUATE_RESUME', resumeText: text });
      if (!resp.success) throw new Error(resp.error || 'AI 评估失败');
      const result = { ...resp.result, _file: item.name, _id: placeholderId };
      resumeResults.push(result);
      replacePlaceholder(placeholderId, result);
    } catch (e) {
      const err = { name: item.name, score: 0, suitable: false, reason: e.message,
        highlights: '', weaknesses: '', interviewReason: '', _file: item.name, _id: placeholderId, _error: true };
      resumeResults.push(err);
      replacePlaceholder(placeholderId, err);
    }
    if (i < total - 1) await sleep(600);
  }

  updateProgress(total, total, '全部完成');
  resumeQueue = [];
  renderFileList();
  updateQueueUI();
  await chrome.runtime.sendMessage({ type: 'SAVE_RESUME_RESULTS', results: resumeResults });
  updateStats();
  isRunning = false;
  startBtn.disabled = false;
  setTimeout(() => { document.getElementById('resume-progress-wrap').style.display = 'none'; }, 2000);
}

function updateProgress(done, total, name) {
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;
  document.getElementById('resume-progress-bar').style.width = pct + '%';
  document.getElementById('resume-progress-label').textContent = done < total
    ? `正在评估 ${done + 1}/${total}：${name}`
    : `完成，共处理 ${total} 份简历`;
}

// ─── 结果渲染 ─────────────────────────────────────────────────────────────────
async function loadResumeResults() {
  const resp = await chrome.runtime.sendMessage({ type: 'GET_RESUME_RESULTS' });
  if (resp.success) { resumeResults = resp.results || []; renderResults(); }
}

function renderResults() {
  const list = document.getElementById('resume-results-list');
  list.innerHTML = '';
  resumeResults.forEach(r => list.appendChild(buildCard(r)));
  updateStats();
}

function addPlaceholder(id, fileName) {
  const list = document.getElementById('resume-results-list');
  const div = document.createElement('div');
  div.id = id;
  div.className = 'resume-card';
  div.innerHTML = `<div class="resume-card-header">
    <div class="resume-score-circle gray">…</div>
    <div class="resume-card-info">
      <div class="resume-card-name" style="color:var(--c-text3)">评估中…</div>
      <div class="resume-card-file">${esc(fileName)}</div>
    </div>
    <span class="resume-card-tag err">处理中</span>
  </div>`;
  list.insertBefore(div, list.firstChild);
}

function replacePlaceholder(id, result) {
  const old = document.getElementById(id);
  if (old) old.replaceWith(buildCard(result));
}

function buildCard(r) {
  // 获取分数线（从 config 的 scoreThreshold，默认 70）
  const score = r.score || 0;
  const scoreClass = r._error ? 'gray' : score >= 70 ? 'green' : score >= 50 ? 'yellow' : 'red';
  const tagClass = r._error ? 'err' : r.suitable ? 'recommend' : 'no';
  const tagText  = r._error ? '解析失败' : r.suitable ? '推荐面试' : '不推荐';

  const div = document.createElement('div');
  div.className = 'resume-card';
  div.innerHTML = `
    <div class="resume-card-header">
      <div class="resume-score-circle ${scoreClass}">${r._error ? '—' : score}</div>
      <div class="resume-card-info">
        <div class="resume-card-name">${esc(r.name || '未知')}</div>
        <div class="resume-card-file">${esc(r._file || '')}</div>
        ${r.highlights ? `<div class="resume-card-hl">★ ${esc(r.highlights)}</div>` : ''}
      </div>
      <span class="resume-card-tag ${tagClass}">${tagText}</span>
      <span class="resume-card-chevron">▼</span>
    </div>
    <div class="resume-card-detail">
      ${r.reason          ? detailRow('评估', r.reason) : ''}
      ${r.highlights      ? detailRow('亮点', r.highlights) : ''}
      ${r.weaknesses      ? detailRow('不足', r.weaknesses) : ''}
      ${r.interviewReason ? detailRow('面试', r.interviewReason) : ''}
      ${r._error          ? detailRow('错误', r.reason) : ''}
    </div>`;
  div.querySelector('.resume-card-header').addEventListener('click', () => div.classList.toggle('open'));
  return div;
}

function detailRow(key, val) {
  return `<div class="resume-detail-row"><span class="resume-detail-key">${key}</span><span class="resume-detail-val">${esc(val)}</span></div>`;
}

function updateStats() {
  const valid = resumeResults.filter(r => !r._error);
  const recommend = valid.filter(r => r.suitable).length;
  const avg = valid.length ? Math.round(valid.reduce((s, r) => s + (r.score || 0), 0) / valid.length) : null;

  const bar = document.getElementById('resume-stats-bar');
  bar.style.display = resumeResults.length > 0 ? 'flex' : 'none';
  document.getElementById('rs-total').textContent     = resumeResults.length;
  document.getElementById('rs-recommend').textContent = recommend;
  document.getElementById('rs-avg').textContent       = avg !== null ? avg : '—';
}

// ─── 导出 CSV ─────────────────────────────────────────────────────────────────
function exportCsv() {
  if (!resumeResults.length) return;
  const header = ['姓名', '评分', '推荐面试', '亮点', '不足', '评估理由', '面试建议', '文件名'];
  const rows = resumeResults.map(r => [
    r.name || '未知', r.score ?? '', r._error ? '失败' : r.suitable ? '是' : '否',
    r.highlights || '', r.weaknesses || '', r.reason || '', r.interviewReason || '', r._file || ''
  ].map(v => `"${String(v).replace(/"/g, '""')}"`).join(','));
  const csv = '\uFEFF' + [header.join(','), ...rows].join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  a.download = `简历筛选_${new Date().toLocaleDateString('zh-CN').replace(/\//g, '-')}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
}

// ─── 工具 ─────────────────────────────────────────────────────────────────────
function esc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function showError(msg) {
  const el = document.getElementById('resume-error');
  el.textContent = msg; el.style.display = 'block';
}
function hideError() { document.getElementById('resume-error').style.display = 'none'; }
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
