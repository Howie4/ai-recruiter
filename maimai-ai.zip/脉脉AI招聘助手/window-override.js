/**
 * window-override.js — 在页面 MAIN world 执行（扩展脚本，不受 CSP 限制）
 * 拦截 window.open：将脉脉站内链接改为当前标签 SPA 导航，彻底消灭新标签堆积
 */
(function () {
  if (window.__maimaiIntercepted) return;
  window.__maimaiIntercepted = true;

  const _open = window.open.bind(window);
  window.open = function (url, target, features) {
    // 只在招聘助手主动运行时才拦截站内链接；否则恢复脉脉原生行为（正常开新标签）
    if (sessionStorage.getItem('__maimai_recruiter_active')) {
      const urlStr = String(url || '');
      // 拦截：绝对 URL 含 maimai.cn，或以 /chat / /im/ / /message/ 开头的相对 URL
      if (urlStr.match(/maimai\.cn/) || /^\/(chat|im\/|message\/)/.test(urlStr)) {
        try {
          // 只存 URL 给 content script 读取；导航由 content script 用 window.location.href 完成
          sessionStorage.setItem('__maimai_intercepted_url', urlStr);
        } catch (e) {}
        return null;
      }
    }
    return _open(url, target, features);
  };

  // 屏蔽 window/document.focus()：脉脉页面脚本会在加载时主动调 window.focus() 把窗口拉到前台。
  // 必须始终屏蔽，不做 sessionStorage 检查——因为 content.js 要到 document_idle 才能设置
  // __maimai_recruiter_active，而脉脉 JS 早在 document_start 之后就开始运行了，存在时序漏洞。
  // 正常浏览脉脉时用户窗口已在前台，window.focus() 本就多余，屏蔽不影响正常使用。
  window.focus   = function () { /* no-op：防止脉脉 JS 抢焦点 */ };
  window.blur    = function () { /* no-op */ };
  document.focus = function () { /* no-op：防止 document 级别的焦点调用 */ };

  // 屏蔽元素级别的 focus()：脉脉 SPA 在页面跳转、表单交互时频繁调用 element.focus()，
  // Chrome 在 Windows/macOS 上可能因此激活自动化窗口，抢走用户当前使用的其他软件的焦点。
  // 自动化运行时将 HTMLElement.prototype.focus 替换为 no-op，彻底断绝这条路径。
  const _origElementFocus = HTMLElement.prototype.focus;
  HTMLElement.prototype.focus = function (opts) {
    if (sessionStorage.getItem('__maimai_recruiter_active')) {
      return; // 自动化期间：禁止任何页面元素请求焦点
    }
    return _origElementFocus.call(this, opts);
  };

  // 屏蔽 visibilitychange / focus / blur 事件驱动的焦点抢占
  // 脉脉 SPA 有时监听 visibilitychange 后调 window.focus()，此处直接截断
  const _addEL = EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener = function (type, fn, opts) {
    if (type === 'focus' && this === window) return; // 禁止脉脉给 window 注册 focus 监听
    return _addEL.call(this, type, fn, opts);
  };

  // 自动确认 window.alert() / confirm() / prompt()：脉脉弹出任何对话框都会阻塞流程并抢焦点。
  const _alert   = window.alert.bind(window);
  const _confirm = window.confirm.bind(window);
  const _prompt  = window.prompt.bind(window);
  window.alert = function (msg) {
    if (sessionStorage.getItem('__maimai_recruiter_active')) {
      console.log('[脉脉助手] 自动确认 alert:', String(msg).slice(0, 100));
      return;
    }
    return _alert(msg);
  };
  window.confirm = function (msg) {
    if (sessionStorage.getItem('__maimai_recruiter_active')) {
      console.log('[脉脉助手] 自动确认 confirm:', String(msg || '').slice(0, 100));
      return true; // 相当于点「确定」
    }
    return _confirm(msg);
  };
  window.prompt = function (msg, def) {
    if (sessionStorage.getItem('__maimai_recruiter_active')) {
      console.log('[脉脉助手] 自动关闭 prompt:', String(msg || '').slice(0, 100));
      return null; // 相当于点「取消」
    }
    return _prompt(msg, def);
  };

  // 拦截 visibilitychange：自动化窗口导航时页面短暂变为 hidden 再 visible，
  // 脉脉某些版本在 visible 时调用 focus 逻辑导致窗口抢到前台。
  // 捕获阶段拦截该事件，在自动化运行时阻止后续 JS 处理（stopImmediatePropagation）。
  document.addEventListener('visibilitychange', function (e) {
    if (sessionStorage.getItem('__maimai_recruiter_active')) {
      e.stopImmediatePropagation();
    }
  }, true /* capture */);

  // 屏蔽 window.resizeTo / resizeBy / moveTo / moveBy：
  // 这些 API 会触发 macOS/Windows 窗口管理器重新聚焦窗口，与 state:'minimized' 冲突。
  // 自动化期间统一屏蔽；非自动化期间恢复原生行为（脉脉一般不调用这些 API，影响极小）。
  ['resizeTo', 'resizeBy', 'moveTo', 'moveBy'].forEach(fn => {
    const _orig = window[fn]?.bind(window);
    if (!_orig) return;
    window[fn] = function (...args) {
      if (sessionStorage.getItem('__maimai_recruiter_active')) return;
      return _orig(...args);
    };
  });

  // 屏蔽 requestAnimationFrame 在后台不必要的唤醒行为（降低 CPU 并减少潜在焦点触发）：
  // 不完全屏蔽，仅在运行时将 rAF 降级为 setTimeout，避免后台标签高频触发渲染。
  // 注：此操作不影响 DOM 操作和事件，仅影响动画帧率。
  const _origRAF = window.requestAnimationFrame.bind(window);
  window.requestAnimationFrame = function (cb) {
    if (sessionStorage.getItem('__maimai_recruiter_active')) {
      return setTimeout(cb, 100); // 降级为100ms静默定时器，不触发渲染管线
    }
    return _origRAF(cb);
  };
})();
