/**
 * content.js — 脉脉页面自动化核心
 * 负责：DOM 交互 | 搜索流程 | 资料抓取 | AI 评估 | 发送消息/加好友 | 状态浮层
 */

(function () {
  'use strict';

  // ─── 防止重复注入 ────────────────────────────────────────────────────────────
  if (window.__maimaiRecruiterLoaded) return;
  window.__maimaiRecruiterLoaded = true;

  // ─── 全局状态 ────────────────────────────────────────────────────────────────
  let config = null;
  let running = false;
  let paused = false;
  let stopFlag = false;
  let overlay = null;
  let dailyContacts = 0;  // 本次任务已主动联系的候选人数
  let currentKeyword = '';  // 当前处理的关键词（跨页跳转时传递给 pending profile）
  let _pauseCardIndex = 0;  // 暂停时记录的卡片位置，供断点恢复使用
  let _processedCount = 0; // 当前循环已处理数量，供暂停断点保存用
  let _seenCandidates = new Set();  // 已看过的候选人 dstu ID，跨任务持久化
  let _runProfiles = [];      // 本次运行的岗位列表（全部 enabled 岗位）
  let _currentProfileId = null; // 当前正在处理的岗位 ID

  // 获取当前岗位名称（供人选明细使用）
  function getCurrentJobName() {
    const id = _currentProfileId || sessionStorage.getItem('__maimai_current_profile_id');
    if (!id) return '';
    const profiles = _runProfiles.length ? _runProfiles
      : (() => { try { return JSON.parse(sessionStorage.getItem('__maimai_run_profiles') || '[]'); } catch (_) { return []; } })();
    const p = profiles.find(x => x.id === id);
    return p ? (p.name || p.jobTitle || '') : '';
  }

  // 从 URL 提取候选人唯一 ID（dstu 参数 或 /p/ 短链 ID）
  function extractCandidateId(url) {
    const m = url.match(/[?&]dstu=(\d+)/) || url.match(/\/p\/([a-zA-Z0-9_-]+)/);
    return m ? m[1] : null;
  }

  // 加载已查阅/联系过的候选人 ID 到内存，并清除超过1个月的过期条目
  async function loadSeenCandidates() {
    const data = await chrome.storage.local.get(['__maimai_seen_dstu', '__maimai_seen_dstu_ts']);
    const arr = data.__maimai_seen_dstu || [];
    const ts  = data.__maimai_seen_dstu_ts || {};
    const oneMonthAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
    // 只保留1个月内有时间戳的记录，过期或无时间戳的一律视为失效
    const validArr = arr.filter(id => ts[id] && ts[id] > oneMonthAgo);
    const validTs  = {};
    validArr.forEach(id => { validTs[id] = ts[id]; });
    _seenCandidates = new Set(validArr);
    // 若有清除，写回 storage（瘦身）
    if (validArr.length !== arr.length) {
      await chrome.storage.local.set({ __maimai_seen_dstu: validArr, __maimai_seen_dstu_ts: validTs });
    }
  }

  // 标记候选人已看过（持久化，附带时间戳供30天TTL使用）
  async function markCandidateSeen(id) {
    if (!id || _seenCandidates.has(id)) return;
    _seenCandidates.add(id);
    const data = await chrome.storage.local.get(['__maimai_seen_dstu', '__maimai_seen_dstu_ts']);
    const arr = data.__maimai_seen_dstu || [];
    const ts  = data.__maimai_seen_dstu_ts || {};
    if (!arr.includes(id)) arr.push(id);
    ts[id] = Date.now();
    await chrome.storage.local.set({ __maimai_seen_dstu: arr, __maimai_seen_dstu_ts: ts });
  }

  // window.open 拦截由 window-override.js（MAIN world 内容脚本）处理，此处无需注入

  // ─── 工具：等待 ──────────────────────────────────────────────────────────────
  // 可中断的 sleep：每 150ms 检查一次 stopFlag/paused，暂停/停止时立即唤醒
  const sleep = (ms) => {
    if (ms <= 150) return new Promise(r => setTimeout(r, ms));
    return new Promise(resolve => {
      let remaining = ms;
      const tick = () => {
        if (stopFlag || paused) { resolve(); return; }
        remaining -= 150;
        if (remaining <= 0) { resolve(); return; }
        setTimeout(tick, Math.min(150, remaining));
      };
      setTimeout(tick, 150);
    });
  };

  const waitFor = (selector, timeout = 8000, root = document) =>
    new Promise((resolve, reject) => {
      const el = root.querySelector(selector);
      if (el) return resolve(el);
      const ob = new MutationObserver(() => {
        const found = root.querySelector(selector);
        if (found) { ob.disconnect(); resolve(found); }
      });
      ob.observe(root.body || root, { childList: true, subtree: true });
      setTimeout(() => { ob.disconnect(); reject(new Error(`等待超时: ${selector}`)); }, timeout);
    });

  const waitForAll = (selector, minCount = 1, timeout = 8000) =>
    new Promise((resolve, reject) => {
      const check = () => {
        const els = document.querySelectorAll(selector);
        if (els.length >= minCount) return resolve(Array.from(els));
      };
      check();
      const ob = new MutationObserver(check);
      ob.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => { ob.disconnect(); reject(new Error(`等待元素超时: ${selector}`)); }, timeout);
    });

  // 用谓词函数等待元素（比 waitFor 更灵活，找不到时返回 null 不 reject）
  const waitForEl = (predicate, timeout = 10000) =>
    new Promise(resolve => {
      const found = predicate();
      if (found) return resolve(found);
      const ob = new MutationObserver(() => {
        const el = predicate();
        if (el) { ob.disconnect(); resolve(el); }
      });
      ob.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => { ob.disconnect(); resolve(null); }, timeout);
    });

  // ─── 工具：查找包含文字的元素 ────────────────────────────────────────────────
  function findByText(selector, text, root = document) {
    return Array.from(root.querySelectorAll(selector))
      .find(el => el.textContent.trim().includes(text));
  }

  // ─── 工具：安全点击（模拟真实用户行为）──────────────────────────────────────
  function simulateClick(el) {
    if (!el) return false;
    el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
    el.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
    el.click();
    return true;
  }

  // ─── 工具：向 input/textarea 输入内容（兼容 React 受控组件）────────────────
  function setInputValue(el, value) {
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
      el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype,
      'value'
    )?.set;
    if (nativeInputValueSetter) {
      nativeInputValueSetter.call(el, value);
    } else {
      el.value = value;
    }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // ─── 工具：跨页导航（彻底消除焦点干扰）──────────────────────────────────────
  // 当前方案：后台标签页 + chrome.tabs.update(active:false) by Service Worker
  // 后台标签页本身没有 OS 窗口焦点，macOS Window Server 对其导航完全无感知。
  // SW 路径仍为首选；SW 极罕见地不可用时，后台标签页内的 window.location.href
  // 同样不会触发 OS 焦点事件（标签非活跃，不涉及窗口级 OS 事件）。
  function navigateTo(url) {
    chrome.runtime.sendMessage({ type: 'NAVIGATE_BACKGROUND', url }, () => {
      if (chrome.runtime.lastError) window.location.href = url;
    });
  }

  // ─── 工具：与 background 通信 ────────────────────────────────────────────────
  function sendMsg(msg) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(msg, resp => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (resp?.success === false) return reject(new Error(resp.error || '未知错误'));
        resolve(resp);
      });
    });
  }

  function log(level, message, data) {
    sendMsg({ type: 'LOG', level, message, data }).catch(() => {});
    updateOverlay(message);
    if (config?.debugMode) console.log(`[脉脉助手][${level}]`, message, data || '');
  }

  // ─── 状态面板 UI（右侧固定卡片，实时显示日志+统计）────────────────────────────
  function createOverlay() {
    if (overlay) return;
    sessionStorage.setItem('__maimai_recruiter_active', '1');
    overlay = document.createElement('div');
    overlay.id = '__maimai_recruiter_overlay';
    overlay.innerHTML = `
      <div class="mmr-panel">
        <div class="mmr-panel-header" id="mmr-panel-header">
          <span class="mmr-panel-icon">🤖</span>
          <span class="mmr-panel-title">招聘助手</span>
          <span class="mmr-panel-dot"></span>
          <span class="mmr-panel-close" id="mmr-close-btn" title="停止任务">✕</span>
        </div>
        <div class="mmr-panel-status" id="mmr-status-text">启动中...</div>
        <div class="mmr-panel-stats">
          <div class="mmr-stat-item"><b id="mmr-st-processed">0</b><span>处理</span></div>
          <div class="mmr-stat-item"><b id="mmr-st-matched">0</b><span>匹配</span></div>
          <div class="mmr-stat-item"><b id="mmr-st-messaged">0</b><span>消息</span></div>
          <div class="mmr-stat-item"><b id="mmr-st-added">0</b><span>好友</span></div>
        </div>
        <div class="mmr-log-list" id="mmr-log-list"></div>
      </div>
    `;
    document.body.appendChild(overlay);

    // 点标题栏 → 隐藏胶囊并打开操作台（两者互斥显示）
    overlay.querySelector('#mmr-panel-header').addEventListener('click', (e) => {
      if (e.target.id === 'mmr-close-btn') return;
      const panel = overlay.querySelector('.mmr-panel');
      if (panel) panel.style.display = 'none'; // 先隐藏胶囊
      sendMsg({ type: 'OPEN_POPUP' }).catch(() => {
        // 打开失败则恢复显示
        if (panel) panel.style.display = '';
      });
    });

    // 点 ✕ → 停止任务
    overlay.querySelector('#mmr-close-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      stopFlag = true;
      running = false;
      sessionStorage.setItem('__maimai_task_stopped', '1');
      sessionStorage.removeItem('__maimai_pending_profile');
      sessionStorage.removeItem('__maimai_pending_task_resume');
      sessionStorage.removeItem('__maimai_pending_sendmsg');
      sessionStorage.removeItem('__maimai_pending_addfriend');
      sessionStorage.removeItem('__maimai_task_paused');
      sessionStorage.removeItem('__maimai_pause_checkpoint');
      sendMsg({ type: 'STOP_TASK' }).catch(() => {});
      removeOverlay();
    });
  }

  function removeOverlay() {
    if (overlay) { overlay.remove(); overlay = null; }
    sessionStorage.removeItem('__maimai_recruiter_active');
  }

  function updateOverlay(text) {
    if (!overlay) return;
    const el = document.getElementById('mmr-status-text');
    if (el) el.textContent = text || '';
  }

  function updateStats(stats) {
    if (!overlay) return;
    ['processed', 'matched', 'messaged', 'added'].forEach(k => {
      const el = document.getElementById(`mmr-st-${k}`);
      if (el && stats[k] !== undefined) el.textContent = stats[k];
    });
  }

  function addLogLine(text) {
    log('info', text);
    const list = document.getElementById('mmr-log-list');
    if (!list) return;
    const entry = document.createElement('div');
    entry.className = 'mmr-log-entry';
    entry.textContent = text;
    list.appendChild(entry);
    // 保留最近 10 条
    while (list.children.length > 10) list.removeChild(list.firstChild);
    list.scrollTop = list.scrollHeight;
  }

  // ─── 人类行为工具函数 ─────────────────────────────────────────────────────────

  /**
   * 返回带随机抖动的延迟时间（在 baseMs 基础上 ±jitterPercent%）
   */
  function humanDelay(baseMs, jitterPercent) {
    const bh = config?.humanBehavior;
    const pct = (jitterPercent !== undefined ? jitterPercent : (bh?.jitterPercent ?? 30)) / 100;
    const factor = 1 + (Math.random() * 2 - 1) * pct;
    return Math.max(100, baseMs * factor);
  }

  /**
   * React 原生 value setter（兼容受控组件）
   */
  function nativeSetter(el, value) {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) {
      setter.call(el, value);
    } else {
      el.value = value;
    }
  }

  /**
   * 逐字符人工打字，速度随机化，偶尔停顿，模拟真实操作节奏
   * 适用于 input/textarea 和 contenteditable 元素
   */
  async function humanType(el, text) {
    const bh = config?.humanBehavior;
    if (!text) return;

    el.focus();
    const isContentEditable = el.contentEditable === 'true';

    // humanBehavior 未配置时快速填入（仍保持事件完整性）
    if (!bh) {
      if (isContentEditable) {
        document.execCommand('selectAll', false, null);
        document.execCommand('delete', false, null);
        document.execCommand('insertText', false, text);
      } else {
        nativeSetter(el, text);
        el.dispatchEvent(new InputEvent('input', { bubbles: true, data: text, inputType: 'insertText' }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
      }
      return;
    }

    // 打字前稍作停顿（看一眼输入框的真实感）
    await sleep(200 + Math.random() * 300);

    const minMs = bh.typingSpeedMin || 80;
    const maxMs = bh.typingSpeedMax || 220;
    let typedSoFar = '';

    for (let i = 0; i < text.length; i++) {
      if (stopFlag || paused) break;
      const ch = text[i];

      if (isContentEditable) {
        // contenteditable：execCommand 是最可靠的插入方式
        document.execCommand('insertText', false, ch);
      } else {
        // input/textarea：完整键盘事件序列，让 React 等框架正确感知输入
        typedSoFar += ch;
        el.dispatchEvent(new KeyboardEvent('keydown',  { key: ch, bubbles: true, cancelable: true }));
        el.dispatchEvent(new KeyboardEvent('keypress', { key: ch, bubbles: true, cancelable: true }));
        nativeSetter(el, typedSoFar);
        el.dispatchEvent(new InputEvent('input', { bubbles: true, data: ch, inputType: 'insertText' }));
        el.dispatchEvent(new KeyboardEvent('keyup',    { key: ch, bubbles: true, cancelable: true }));
      }

      // 随机打字间隔（模拟手速变化）
      await sleep(minMs + Math.random() * (maxMs - minMs));

      // 偶尔停顿一下（像在回看内容或想下一句话），在标点后更自然
      const isPunct = /[，。！？、,!?]/.test(ch);
      if (isPunct ? Math.random() < 0.5 : Math.random() < 0.04) {
        await sleep(350 + Math.random() * 650);
      }
    }

    if (!isContentEditable) {
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }
    // 打完后短暂停顿（像在看一遍再提交）
    await sleep(300 + Math.random() * 400);
  }

  /**
   * 按资料字数估算阅读时间并等待
   */
  async function readingPause(textContent) {
    const bh = config?.humanBehavior;
    if (!bh) return;
    const chars = (textContent || '').length;
    const estimatedMs = (chars / bh.readingSpeedCharsPerSec) * 1000;
    const clamped = Math.min(Math.max(estimatedMs, bh.readingMinMs), bh.readingMaxMs);
    const finalMs = clamped * (0.8 + Math.random() * 0.4);  // ±20% 随机
    log('info', `📖 阅读停顿 ${(finalMs / 1000).toFixed(1)}s...`);
    await sleep(finalMs);
  }

  /**
   * 鼠标先 hover 停留一段时间再点击
   */
  async function hoverThenClick(el) {
    if (!el) return false;
    const bh = config?.humanBehavior;
    // 获取元素中心坐标，用于事件和 elementFromPoint
    const rect = el.getBoundingClientRect();
    const cx = Math.round(rect.left + rect.width / 2);
    const cy = Math.round(rect.top + rect.height / 2);
    // 包含坐标的事件参数（React 合成事件依赖 clientX/clientY 判断点击位置）
    const evInit = (extra = {}) => ({
      bubbles: true, cancelable: true, view: window,
      clientX: cx, clientY: cy, screenX: cx, screenY: cy,
      ...extra,
    });
    el.dispatchEvent(new MouseEvent('mouseover', evInit()));
    el.dispatchEvent(new MouseEvent('mouseenter', evInit()));
    if (bh) {
      const hoverMs = bh.hoverMinMs + Math.random() * (bh.hoverMaxMs - bh.hoverMinMs);
      await sleep(hoverMs);
    }
    // 用 elementFromPoint 找到坐标处真正的最顶层元素（可能有透明覆盖层）
    // 如果找不到（坐标越界等），退回原始元素
    const topEl = (cx >= 0 && cy >= 0 && cx < window.innerWidth && cy < window.innerHeight)
      ? (document.elementFromPoint(cx, cy) || el)
      : el;
    // 完整指针事件序列（发到 topEl，确保穿透覆盖层、触发 React 事件委托）
    topEl.dispatchEvent(new PointerEvent('pointerdown', { ...evInit(), isPrimary: true }));
    topEl.dispatchEvent(new MouseEvent('mousedown', evInit({ buttons: 1 })));
    await sleep(40 + Math.random() * 40);
    topEl.dispatchEvent(new PointerEvent('pointerup', { ...evInit(), isPrimary: true }));
    topEl.dispatchEvent(new MouseEvent('mouseup', evInit({ buttons: 0 })));
    topEl.dispatchEvent(new MouseEvent('click', evInit()));
    // 同时对原始元素发 click（兼容直接绑定 onclick 属性的场景）
    if (topEl !== el) {
      el.dispatchEvent(new MouseEvent('click', evInit()));
    }
    try { el.click(); } catch (_) {}
    return true;
  }

  /**
   * 分步平滑滚动详情页（模拟阅读行为）
   * 真人阅读特征：偶尔往回滚一点（重看某段），在工作经历区停得更久
   */
  async function scrollProfile() {
    const bh = config?.humanBehavior;
    // scrollProfileEnabled 未配置时默认开启，scrollSteps 默认 3
    if (bh?.scrollProfileEnabled === false) return;
    const scrollEl = document.scrollingElement || document.body;

    // 找到「看了TA的人还看了」所在行，滚到刚好看到这行即停，不再往下
    const STOP_KEYWORDS = ['看了TA的人还看了', '相似人脉', '你可能认识', '为你推荐'];
    let stopY = scrollEl.scrollHeight - scrollEl.clientHeight;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    outer: while ((node = walker.nextNode())) {
      const t = node.textContent.trim();
      if (STOP_KEYWORDS.some(kw => t.includes(kw))) {
        const rect = node.parentElement?.getBoundingClientRect();
        if (rect) {
          // 让该行刚好出现在视口内即可（顶部留 20px 空间）
          stopY = Math.max(0, rect.top + scrollEl.scrollTop - 20);
          break outer;
        }
      }
    }
    if (stopY <= 50) return;

    const scrollSteps = bh?.scrollSteps ?? 3;
    for (let step = 1; step <= scrollSteps; step++) {
      if (stopFlag || paused) return;  // 停止/暂停时立即退出滚动
      const targetY = (stopY / scrollSteps) * step;
      scrollEl.scrollTo({ top: targetY, behavior: 'smooth' });

      const isLaterSection = step > Math.floor(bh.scrollSteps / 2);
      await sleep(isLaterSection ? 1200 + Math.random() * 1500 : 700 + Math.random() * 800);
      if (stopFlag) return;

      if (step < scrollSteps && Math.random() < 0.3) {
        const backY = Math.max(0, targetY - (80 + Math.random() * 120));
        scrollEl.scrollTo({ top: backY, behavior: 'smooth' });
        await sleep(500 + Math.random() * 700);
        if (stopFlag) return;
        scrollEl.scrollTo({ top: targetY, behavior: 'smooth' });
        await sleep(400 + Math.random() * 400);
      }
    }
    if (!stopFlag && !paused) await sleep(600 + Math.random() * 800);
  }

  /**
   * Session 管理：跟踪处理数量，在达到阈值时触发休息
   */
  const sessionManager = {
    count: 0,
    async checkBreak() {
      this.count++;
      const bh = config?.humanBehavior;
      if (!bh) return;

      if (bh.longBreakAfterN > 0 && this.count % bh.longBreakAfterN === 0) {
        const ms = bh.longBreakMinMs + Math.random() * (bh.longBreakMaxMs - bh.longBreakMinMs);
        const mins = Math.round(ms / 60000);
        const secs = Math.round(ms / 1000);
        const label = mins >= 1 ? `${mins} 分钟` : `${secs} 秒`;
        updateOverlay(`☕ 长休息中 ${label}...`);
        addLogLine(`☕ 长休息 ${label}`);
        const end = Date.now() + ms;
        while (Date.now() < end && !stopFlag && !paused) await sleep(500);
      } else if (bh.breakAfterN > 0 && this.count % bh.breakAfterN === 0) {
        const ms = bh.breakMinMs + Math.random() * (bh.breakMaxMs - bh.breakMinMs);
        const secs = Math.round(ms / 1000);
        updateOverlay(`💤 短休息中 ${secs} 秒...`);
        addLogLine(`💤 短休息 ${secs} 秒`);
        const end = Date.now() + ms;
        while (Date.now() < end && !stopFlag && !paused) await sleep(500);
      }
    },
  };

  /**
   * 随机跳过：模拟人类犹豫行为，仅对低分边缘候选人生效
   * score >= 85 的强匹配候选人不跳过（太可惜），只有边缘候选人才随机放弃
   */
  function shouldSkip(score) {
    const bh = config?.humanBehavior;
    if (!bh) return false;
    if (score >= 85) return false; // 强匹配不随机跳过
    return Math.random() < bh.skipProbability;
  }

  /**
   * 检查是否在工作时间内，不在则等待到开始时间
   */
  async function checkWorkHours() {
    const bh = config?.humanBehavior;
    if (!bh || !bh.workHoursEnabled) return;

    const now = new Date();
    const hour = now.getHours();
    if (hour >= bh.workHoursStart && hour < bh.workHoursEnd) return;

    const nextStart = new Date();
    nextStart.setHours(bh.workHoursStart, 0, 0, 0);
    if (nextStart <= now) nextStart.setDate(nextStart.getDate() + 1);

    const waitMs = nextStart - now;
    const waitMins = Math.round(waitMs / 60000);
    updateOverlay(`🕐 等待工作时间 ${bh.workHoursStart}:00（${waitMins} 分钟）`);
    addLogLine(`🕐 非工作时间，等待约 ${waitMins} 分钟到 ${bh.workHoursStart}:00`);
    // 分段等待，每秒检查一次停止标志
    const endTime = Date.now() + waitMs;
    while (Date.now() < endTime && !stopFlag) await sleep(1000);
  }

  // ─── 脉脉 DOM 操作封装 ───────────────────────────────────────────────────────

  // 脉脉「人脉」搜索的正确 URL 格式（从实际操作中确认）
  function contactsUrl(keyword) {
    return `https://maimai.cn/web/search_center?type=contact&query=${encodeURIComponent(keyword)}&highlight=true`;
  }

  /**
   * 搜索流程：先在搜索框像真人一样输入，然后直接跳到「人脉」URL
   * 这样既有人类输入行为，又能精准落在人脉结果页
   */
  async function doSearch(keyword) {
    updateOverlay(`正在搜索：${keyword}`);
    addLogLine(`🔍 搜索：${keyword}`);

    // 先找搜索框，像真人一样输入（有交互记录，不直接跳URL）
    const searchBox = await waitForEl(() =>
      document.querySelector(
        'input.webimSearchInput, ' +    // WebIM 搜索框（搜索结果页）
        'input#search-input, ' +        // 主页搜索框（id=search-input）
        'input.search-input, ' +        // 主页搜索框（class=search-input）
        'input[placeholder="搜索"], input[placeholder*="搜索"], ' +
        '[class*="search"] input[type="text"], [class*="Search"] input[type="text"]'
      ),
      5000
    );

    if (searchBox) {
      await hoverThenClick(searchBox);
      await sleep(300 + Math.random() * 500);
      nativeSetter(searchBox, '');
      searchBox.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(150 + Math.random() * 200);
      await humanType(searchBox, keyword);
      // 停顿一下，像人确认了一眼
      await sleep(600 + Math.random() * 600);
    }

    // 清除停止标志，防止跳转后 IIFE 误判
    sessionStorage.removeItem('__maimai_task_stopped');
    // 保存任务状态（跳转后脚本可能销毁）
    await chrome.storage.local.set({
      __maimaiPendingTask: { keyword, step: 'contacts', savedAt: Date.now() }
    });

    // 直接导航到人脉搜索 URL（正确格式已确认）
    const target = contactsUrl(keyword);
    const originalUrl = location.href;
    navigateTo(target);

    // 等待导航（SPA 则脚本存活；全页刷新则脚本销毁，由恢复 IIFE 接管）
    for (let i = 0; i < 150; i++) {
      await sleep(100);
      if (location.href !== originalUrl && location.href.includes('type=contact')) {
        // SPA 导航成功，脚本存活
        await chrome.storage.local.remove('__maimaiPendingTask');
        await sleep(2500); // 等结果渲染
        return;
      }
    }
    await sleep(30000); // 全页刷新中，永远不会执行到这里
  }

  /**
   * 点击"人脉"标签
   * 关键：找 textContent 最短的匹配元素（叶子节点），让 click 事件能正确向上冒泡
   * 到有 React onClick 的祖先元素，避免点击父容器而 onClick 在子节点上的问题。
   */
  async function clickConnectionsTab() {
    addLogLine('正在查找「人脉」标签...');

    const tab = await waitForEl(() => {
      // 优先：已知 class（search-result-type）精确定位人脉 Tab
      const byClass = Array.from(document.querySelectorAll('li.search-result-type'))
        .find(el => el.offsetParent && el.textContent.trim().replace(/[\s\d()\[\]【】]+$/, '').trim() === '人脉');
      if (byClass) {
        // 优先返回内部的 <a> 元素（点击更精准）
        return byClass.querySelector('a') || byClass;
      }

      // 兜底：文字匹配
      const candidates = Array.from(document.querySelectorAll('span, div, a, li, button'))
        .filter(el => {
          if (!el.offsetParent) return false; // 不在视口/隐藏元素排除
          const text = el.textContent.trim().replace(/[\s\d()\[\]【】]+$/, '').trim();
          return text === '人脉';
        });
      if (!candidates.length) return null;
      // 按 textContent 长度升序，优先最短（最具体的叶子节点）
      candidates.sort((a, b) => a.textContent.trim().length - b.textContent.trim().length);
      return candidates[0];
    }, 15000);

    if (!tab) {
      // 兜底：按位置点第三个 tab（实名动态/职言交流/人脉）
      const posTabs = Array.from(document.querySelectorAll('[class*="tab"], [role="tab"]'))
        .filter(el => el.offsetParent !== null);
      console.log('[脉脉助手] 文字匹配失败，按位置找tab，共', posTabs.length, '个');
      addLogLine(`❌ 文字匹配「人脉」失败，按位置尝试第3个tab（共${posTabs.length}个）`);
      if (posTabs.length >= 3) {
        await hoverThenClick(posTabs[2]);
        await waitForEl(() => getProfileCards().length > 0 ? getProfileCards()[0] : null, 10000);
        return true;
      }
      log('warn', '无法定位「人脉」标签');
      return false;
    }

    console.log('[脉脉助手] 找到人脉tab:', tab.tagName, tab.className, `"${tab.textContent.trim()}"`);
    addLogLine(`找到「人脉」标签 <${tab.tagName.toLowerCase()}> ，即将点击`);

    // 优先用 anchor href 导航（最可靠）
    const anchor = tab.tagName === 'A' ? tab : tab.closest('a');
    if (anchor?.href && !anchor.href.startsWith('javascript')) {
      console.log('[脉脉助手] anchor 导航:', anchor.href);
      anchor.click();
    } else {
      // 点叶子节点，事件冒泡到有 onClick 的祖先
      await hoverThenClick(tab);
      // 补一次父元素点击，防止 onClick 在父容器上
      await sleep(400);
      if (tab.parentElement && tab.parentElement !== document.body) {
        tab.parentElement.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
      }
    }

    addLogLine('已点击「人脉」，等待候选人列表加载...');

    // 等卡片真正出现（最多 12 秒）
    const firstCard = await waitForEl(() => {
      const cards = getProfileCards();
      return cards.length > 0 ? cards[0] : null;
    }, 12000);

    if (firstCard) {
      addLogLine('✅ 人脉列表加载完成');
    } else {
      log('warn', '12 秒内未出现候选人卡片');
      addLogLine('⚠️ 人脉列表未加载，请打开 DevTools Console 查看诊断信息');
      console.log('[脉脉助手] 人脉卡片未出现，当前URL:', location.href);
      console.log('[脉脉助手] body HTML 前2000字符:', document.body.innerHTML.slice(0, 2000));
    }
    return true;
  }

  /**
   * 找头像元素（只在主内容区内找，排除导航栏、侧边栏等无关头像）
   */
  function findAvatarImgs(root) {
    return Array.from(root.querySelectorAll('img')).filter(img => {
      if (!img.offsetParent) return false;
      const src = (img.src || img.getAttribute('data-src') || '').toLowerCase();
      const cls = (img.className || '').toLowerCase();
      // 头像特征：class 含 avatar/head/photo，或 src 含这些关键词，或尺寸在头像常见范围内
      return cls.includes('avatar') || cls.includes('head') || cls.includes('photo') ||
             src.includes('avatar') || src.includes('head') || src.includes('/u/') ||
             (img.naturalWidth >= 30 && img.naturalWidth <= 120);
    });
  }

  /**
   * 获取当前人脉列表中的所有候选人卡片
   * 策略：先尝试 CSS 选择器，失败则以头像 img 为锚点向上找 li / item 容器
   */
  function getProfileCards() {
    // 主内容区（避免命中顶部导航里的头像）
    const main = document.querySelector('main, [class*="content-wrap"], [class*="main-content"], #app') || document.body;

    // 策略1：CSS 选择器（优先已知精确 class）
    const selectors = [
      config?.selectors?.profileCard,
      'li.Tappable-inactive.list-group-item',  // 已知精确 class（人脉搜索结果卡片）
      'li.list-group-item',                     // 降级兜底
      '[class*="contact-item"]',
      '[class*="search-result-item"]',
      '[class*="people-item"]',
      '[class*="user-item"]',
      '[class*="person-item"]',
      '[class*="list-item"]',
      '[class*="member-item"]',
      '[class*="result-item"]',
      '[class*="card-item"]',
    ].filter(Boolean);

    for (const sel of selectors) {
      try {
        const cards = Array.from(main.querySelectorAll(sel))
          .filter(el => el.offsetParent !== null && el.querySelector('img'));
        if (cards.length > 0) {
          console.log(`[脉脉助手] getProfileCards 命中: ${sel}，共 ${cards.length} 个`);
          return cards;
        }
      } catch (_) {}
    }

    // 策略2：以头像 img 为锚点，向上找 li 或含 item/card 的容器
    const avatars = findAvatarImgs(main);
    console.log(`[脉脉助手] 头像法：找到 ${avatars.length} 张头像图`);

    const containers = avatars.map(img =>
      img.closest('li') ||
      img.closest('[class*="item"]') ||
      img.closest('[class*="card"]') ||
      img.closest('[class*="row"]')
    ).filter(el => el && el.offsetParent !== null);

    const unique = [...new Set(containers)];

    if (unique.length === 0) {
      console.log('[脉脉助手] 未找到人选卡片，URL:', location.href);
      console.log('[脉脉助手] body前1500字符:', document.body.innerHTML.slice(0, 1500));
    } else {
      console.log(`[脉脉助手] 头像法找到 ${unique.length} 个人选容器`);
    }
    return unique;
  }

  /**
   * 从卡片提取基础信息（无需点击进详情）
   */
  function extractCardInfo(card) {
    const sel = (s) => card.querySelector(s)?.textContent?.trim() || '';

    // 优先：已知卡片结构（li.Tappable-inactive.list-group-item）
    // 姓名在 .media-body 内第一个子 div 的直接文本节点（排除「活跃时间」span）
    let name = '', title = '', company = '';
    const mediaBody = card.querySelector('.media-body');
    if (mediaBody) {
      const nameDiv = mediaBody.querySelector('div > div');
      if (nameDiv) {
        name = Array.from(nameDiv.childNodes)
          .filter(n => n.nodeType === Node.TEXT_NODE)
          .map(n => n.textContent.trim()).filter(Boolean)[0] || '';
      }
      // 第一个 .text-muted 含职位+公司（合并显示，如"字节跳动广告算法工程师"）
      const titleEl = mediaBody.querySelector('.text-muted');
      if (titleEl) title = titleEl.childNodes[0]?.textContent?.trim() || titleEl.textContent.trim();
    }

    // 兜底：config 选择器 + 常见 class 关键词
    if (!name)  name    = sel(config.selectors?.cardName)    || sel('[class*="name"], [class*="nick"]');
    if (!title) title   = sel(config.selectors?.cardTitle)   || sel('[class*="position"], [class*="job"], [class*="title"]');
    if (!company) company = sel(config.selectors?.cardCompany) || sel('[class*="company"], [class*="corp"], [class*="org"]');

    // 兜底：遍历卡片内所有叶子节点可见文本，按长度和特征猜测字段
    if (!name || !title || !company) {
      const leaves = Array.from(card.querySelectorAll('*'))
        .filter(el => el.children.length === 0 && el.offsetParent !== null)
        .map(el => el.textContent.trim())
        .filter(t => t.length >= 2 && t.length <= 30)
        .filter((v, i, a) => a.indexOf(v) === i); // 去重

      // 关系词 / 操作词：这些出现在卡片里，但不是姓名或公司
      const RELATION_RE = /查看|共同好友|好友|同事|同学|校友|初识|认识|LV\d|^\d+个|^50\+/;
      if (!name) {
        // 姓名特征：2-10个字符，含汉字，排除职位词、活跃时间、关系词、标点
        name = leaves.find(t => /[\u4e00-\u9fa5]/.test(t) && t.length >= 2 && t.length <= 10 &&
          !RELATION_RE.test(t) &&
          !/工程师|经理|总监|主管|专家|架构|研发|算法|产品|设计|运营|活跃|前活跃|天前|小时前|分钟前|刚刚|在线|@|·|【|】/.test(t)) || '';
      }
      if (!title) {
        title = leaves.find(t => /工程师|经理|总监|主管|专家|架构师|研发|算法|产品经理|设计师|运营/.test(t)) || '';
      }
      if (!company) {
        // 公司：排除已选的 name/title、活跃时间、关系词
        company = leaves.find(t => t !== name && t !== title &&
          !RELATION_RE.test(t) &&
          !/活跃|天前|小时前|分钟前|刚刚|在线|@|·/.test(t) && t.length <= 20) || '';
      }
    }

    return { name, title, company };
  }

  /**
   * 从详情页抓取完整资料
   * 策略：先尝试具体选择器，全部失败时回退到"抓取全页可见文本"，让 AI 自行解析
   */
  function extractProfileDetail() {
    const single = (sel) => {
      try { return document.querySelector(sel)?.textContent?.trim() || ''; } catch(_){ return ''; }
    };
    const multiText = (sel) => {
      try {
        return Array.from(document.querySelectorAll(sel))
          .map(e => e.textContent.trim()).filter(Boolean).join(' | ');
      } catch(_){ return ''; }
    };

    // ── 策略1：找页面中最大/最显眼的名字文本 ──────────────────────────────────
    // 脉脉详情页通常 h1 或醒目 div 包含姓名
    const nameFromH1 = single('h1');
    // 找字体最大或最粗的短文本（姓名通常 2-6 个汉字）
    const nameFromBold = (() => {
      const candidates = Array.from(document.querySelectorAll('strong, b, [class*="name"], [class*="nick"]'))
        .filter(el => el.offsetParent !== null)
        .map(el => el.textContent.trim())
        .filter(t => t.length >= 2 && t.length <= 15);
      return candidates[0] || '';
    })();

    // ── 策略2：获取页面主体区域的全部可见文本作为 extra ─────────────────────
    const pageText = (() => {
      const excludeTags = ['script', 'style', 'nav', 'header', 'footer',
        '[class*="nav"]', '[class*="sidebar"]', '[id="__maimai_recruiter_overlay"]'];
      const clone = document.body.cloneNode(true);
      excludeTags.forEach(sel => { try { clone.querySelectorAll(sel).forEach(el => el.remove()); } catch(_){} });
      let text = (clone.innerText || clone.textContent || '')
        .replace(/[ \t]+/g, ' ')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
      // 截断"看了TA的人还看了"及以后的无关推荐内容
      const cutIdx = text.indexOf('看了TA的人还看了');
      if (cutIdx > 0) text = text.slice(0, cutIdx);
      return text.slice(0, 4000);
    })();

    // ── 策略3：专门尝试提取工作经历和教育经历区块 ──────────────────────────
    // 脉脉工作经历通常在含 work/career/exp/job 的容器里
    const workText = (() => {
      const el = document.querySelector(
        '[class*="work-exp"], [class*="career"], [class*="experience"], ' +
        '[class*="work_exp"], [class*="job-exp"], [class*="workExp"]'
      );
      return el ? el.innerText?.replace(/\s+/g, ' ').trim().slice(0, 1500) : '';
    })();

    const eduText = (() => {
      const el = document.querySelector(
        '[class*="edu-exp"], [class*="education"], [class*="school"], ' +
        '[class*="edu_exp"], [class*="eduExp"]'
      );
      return el ? el.innerText?.replace(/\s+/g, ' ').trim().slice(0, 500) : '';
    })();

    // ── 从全文中简单提取常见字段 ────────────────────────────────────────────
    // h1 若超过 20 字，大概率是搜索词/页面标题而非人名，丢弃
    // 不强制要求包含汉字，兼容英文名（如 David Chen）
    const cleanH1 = nameFromH1.length >= 2 && nameFromH1.length <= 20 ? nameFromH1 : '';
    const name = cleanH1 || nameFromBold || '';
    const title = single('[class*="position"]') || single('[class*="job"]') || '';

    // 公司名：先试多种选择器，全部失败时从工作经历文本首行推断
    let company = single('[class*="company"]') || single('[class*="corp"]') ||
                  single('[class*="org"]')     || single('[class*="firm"]') ||
                  single('[class*="employer"]')|| single('[data-company]')  || '';
    const JOB_RE  = /工程师|经理|主管|总监|专家|架构师|算法|开发|产品|设计|运营|研究员|分析师|顾问|助理|实习|负责人|engineer|manager|director/i;
    const DATE_RE = /\d{4}[-–\/年]|\d+年|\d+个?月|至今|present|now/i;
    // 兜底：从工作经历区块文本首行推断（workText 选择器匹配时最准）
    if (!company && workText) {
      // 脉脉 UI 固定词汇（影响力分、积分等），排除误识别
      const UI_RE = /影响力|信用分|活跃度|积分|点赞|关注|粉丝|互动/;
      const lines = workText.split(/[\n·•｜|]/).map(l => l.trim()).filter(Boolean);
      for (const line of lines) {
        if (line.length >= 2 && line.length <= 25 &&
            !JOB_RE.test(line) && !DATE_RE.test(line) &&
            !UI_RE.test(line) && !/^\d+$/.test(line)) {
          company = line;
          break;
        }
      }
    }

    console.log('[脉脉助手] extractProfileDetail name:', name, '| title:', title, '| company:', company,
      '| pageText前200:', pageText.slice(0, 200));

    // 组合 extra：优先拼接专项区块，再附全文（去重避免太长）
    const extra = [
      workText ? `【工作经历】\n${workText}` : '',
      eduText  ? `【教育经历】\n${eduText}`  : '',
      pageText,
    ].filter(Boolean).join('\n\n').slice(0, 4000);

    return {
      name,
      title,
      company,
      experience: workText || multiText('[class*="work"], [class*="career"], [class*="exp"]'),
      education:  eduText  || multiText('[class*="edu"], [class*="school"]'),
      skills:     multiText('[class*="skill"], [class*="tag"]'),
      extra,
    };
  }

  /**
   * 检测详情页是否已是好友
   * 截图分析：
   *   - 好友：右侧边栏显示蓝色「发消息」按钮 + 「申请交换手机号」按钮
   *   - 非好友：右侧边栏显示蓝色「+加好友」按钮
   */
  /**
   * 找可见的操作元素（兼容 button/div/span/a 等各种实现）
   * 脉脉的操作按钮不一定是 <button>，可能是 <div> 或 <span>
   */
  function findVisibleBtn(...texts) {
    // 搜索所有可见元素（button/div/span/a 等），兼容脉脉用 div 实现按钮的情况
    // 排除我们自己的悬浮日志面板，避免日志内容被误识别为按钮
    // 注意：用 getBoundingClientRect() 检测可见性，而非 offsetParent（offsetParent 对
    // position:fixed 的元素返回 null，会漏掉脉脉固定侧边栏里的操作按钮）
    const overlayEl = document.getElementById('__maimai_recruiter_overlay');
    const isVisible = el => {
      if (overlayEl?.contains(el)) return false;
      const r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0 &&
        r.top < window.innerHeight && r.bottom > 0 &&
        r.left < window.innerWidth && r.right > 0;
    };
    const all = Array.from(document.querySelectorAll('button, [role="button"], div, span, a'))
      .filter(isVisible);
    for (const text of texts) {
      // 找所有包含目标文字的候选元素，选文字最短的（最具体的叶子节点）
      const candidates = all.filter(el => {
        const t = el.textContent.trim();
        return t.includes(text) && t.length <= 30; // 宽松上限，避免误命中长段落
      });
      if (candidates.length > 0) {
        // 按文字长度升序，取最短（最精确）的
        candidates.sort((a, b) => a.textContent.trim().length - b.textContent.trim().length);
        return candidates[0];
      }
    }
    return null;
  }

  function detectIsFriend() {
    const _visByClass = (text) => Array.from(document.querySelectorAll('.btn-secondary.btn-block'))
      .some(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && el.textContent.trim() === text; });
    const hasSendMsg   = _visByClass('发消息') || !!findVisibleBtn('发消息', '发私信');
    // 兼容「+ 加好友」「+加好友」「＋加好友」等各种格式
    const hasAddFriend = _visByClass('＋加好友') || !!findVisibleBtn('+ 加好友', '+加好友', '＋加好友', '加好友', '申请好友', '打招呼', '添加好友');

    // 诊断：打印所有含关键词的可见元素（用 BoundingClientRect 避免漏掉 fixed 元素）
    const allEls = Array.from(document.querySelectorAll('button, [role="button"], div, span, a'))
      .filter(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; });
    const actionEls = allEls.filter(el => {
      const t = el.textContent.trim();
      return ['发消息','加好友','打招呼','私信','联系','发私信','沟通','邀请','招呼'].some(k => t.includes(k) && t.length < 15);
    });
    console.log('[脉脉助手] detectIsFriend 操作元素:',
      actionEls.map(el => `${el.tagName}"${el.textContent.trim()}"`).join(' | ') || '（未找到）');
    console.log('[脉脉助手] 发消息:', hasSendMsg, '加好友:', hasAddFriend);

    if (hasSendMsg && !hasAddFriend) return true;
    if (hasAddFriend) return false;
    return document.body.textContent.includes('共同好友');
  }

  /**
   * 找聊天输入框：兼容 textarea / contenteditable / input[type=text] / div 输入框
   * 脉脉 /chat 页面聊天输入框可能是任意一种
   */
  function findChatInput() {
    // 可见性检测（兼容 position:fixed 的聊天面板）
    const isVis = el => { if (!el) return false; const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };

    // 最优先：已知 class（inputPanel）+ placeholder「请输入信息」，脉脉聊天页固定输入框
    const byClass = document.querySelector('.inputPanel[contenteditable="true"]') ||
                    document.querySelector('[placeholder="请输入信息"][contenteditable="true"]');
    if (byClass && isVis(byClass)) return byClass;

    // 0. 脉脉 WebIM 内联面板的消息编辑区（优先，避免误命中 webimSearchInput）
    const webimEditor = Array.from(document.querySelectorAll(
      '[class*="webim"] [contenteditable="true"], [id*="webim"] [contenteditable="true"], ' +
      '[class*="webim"] textarea:not([readonly]), [class*="im-panel"] [contenteditable="true"], ' +
      '[class*="im-panel"] textarea, [class*="chat-panel"] [contenteditable="true"], ' +
      '[class*="chat-panel"] textarea, [class*="message-panel"] textarea, ' +
      '[class*="conversation"] [contenteditable="true"], [class*="conversation"] textarea'
    )).find(el => isVis(el) && !el.readOnly);
    if (webimEditor) return webimEditor;

    // 1. textarea（排除 webimSearch）
    const textarea = Array.from(document.querySelectorAll('textarea'))
      .find(t => {
        if (!isVis(t) || t.readOnly) return false;
        const idcls = (t.id + t.className).toLowerCase();
        return !idcls.includes('search');
      });
    if (textarea) return textarea;

    // 2. contenteditable（排除搜索框区域）
    const ceList = Array.from(document.querySelectorAll('[contenteditable="true"]'))
      .filter(el => {
        if (!isVis(el)) return false;
        const idcls = (el.id + el.className).toLowerCase();
        return !idcls.includes('search');
      });
    for (const el of ceList) {
      const inChat = el.closest(
        '[class*="dialog"], [class*="modal"], [class*="chat"], [class*="message"], ' +
        '[class*="popup"], [role="dialog"], [class*="input"], [class*="webim"], [class*="im-"]'
      );
      if (inChat) return el;
    }
    if (ceList.length > 0) {
      ceList.sort((a, b) => a.textContent.length - b.textContent.length);
      return ceList[0];
    }

    // 3. input[type=text]（排除搜索框）
    const textInput = Array.from(document.querySelectorAll('input[type="text"], input:not([type])'))
      .find(el => {
        if (!isVis(el) || el.readOnly || el.disabled) return false;
        const cls = (el.className || '').toLowerCase();
        const name = (el.name || el.id || '').toLowerCase();
        const ph = (el.placeholder || '').toLowerCase();
        return !cls.includes('search') && !name.includes('search') &&
               !ph.includes('搜索') && !ph.includes('search') && !ph.includes('查找');
      });
    if (textInput) return textInput;

    // 4. div/span 类输入框
    const divInput = Array.from(document.querySelectorAll(
      '[class*="editor"], [class*="compose"], [class*="msg-input"], ' +
      '[class*="input-box"], [class*="chat-input"], [class*="message-input"], ' +
      '[class*="send-input"], [class*="reply-input"], [class*="inputArea"], ' +
      '[class*="text-input"], [class*="write-input"]'
    )).find(el => isVis(el) && !el.readOnly);
    if (divInput) return divInput;

    // 5. 位置兜底：页面右侧（x>40%）最靠下的可编辑元素（聊天输入框通常在底部，不限y高度）
    const _rightEditable = Array.from(document.querySelectorAll(
      'textarea, [contenteditable="true"], input[type="text"], input:not([type])'
    )).filter(el => {
      if (!isVis(el) || el.readOnly || el.disabled) return false;
      const r = el.getBoundingClientRect();
      const cls = (el.className || el.id || '').toLowerCase();
      return r.left > window.innerWidth * 0.4 && r.width > 50 && !cls.includes('search');
    });
    const bottomInput = _rightEditable.length ? _rightEditable.reduce((bot, el) =>
      el.getBoundingClientRect().top > bot.getBoundingClientRect().top ? el : bot
    ) : null;
    if (bottomInput) return bottomInput;

    return null;
  }

  // 判断一个元素是否是合法的消息输入框（排除搜索框等）—— 模块级可复用
  function isValidMsgInput(el) {
    if (!el || el === document.body) return false;
    const tag = el.tagName;
    const cls = (el.className || '').toLowerCase();
    const name = (el.name || el.id || '').toLowerCase();
    const ph = (el.placeholder || '').toLowerCase();
    if (cls.includes('search') || name.includes('search') ||
        ph.includes('搜索') || ph.includes('search') || ph.includes('查找')) return false;
    if (tag === 'TEXTAREA') return true;
    if (el.contentEditable === 'true') return true;
    if (tag === 'INPUT' && !['hidden','submit','button','checkbox','radio','file'].includes(el.type)) return true;
    if (el.getAttribute('role') === 'textbox') return true;
    return false;
  }

  /**
   * 向已是好友的候选人发送消息
   * 脉脉「发消息」行为：
   *   A) 弹出内联聊天对话框（URL 不变，输入框出现在当前页）
   *   B) 跳转到独立聊天页（URL 变化），发完后 history.back() 回详情页
   */
  // rescueInfo: { listUrl, keyword, nextCardIndex, stats } - 由 profile IIFE 传入，用于聊天页全页跳转后救援
  async function sendMessageToFriend(candidateInfo, rescueInfo) {
    addLogLine(`✉️ 准备发消息给 ${candidateInfo.name}...`);
    const bh = config.humanBehavior;
    const profileUrl = location.href;

    // 1. 生成消息内容
    let msgText;
    try {
      const resp = await sendMsg({ type: 'GENERATE_MESSAGE', candidateInfo, isFriend: true });
      msgText = resp.text;
      if (!msgText) throw new Error('消息内容为空，请检查配置页消息模板');
    } catch (err) {
      addLogLine(`❌ 生成消息失败：${err.message}`);
      log('error', `生成消息失败: ${err.message}`);
      return false;
    }
    console.log('[脉脉助手] 待发消息:', msgText.slice(0, 50));

    // 生成完消息后立即存救援快照：如果点击「发消息」触发全页跳转到聊天页，
    // 新页面 IIFE 会检测到这个 key，接着完成发送并返回列表
    if (rescueInfo) {
      sessionStorage.setItem('__maimai_pending_sendmsg', JSON.stringify({
        ...rescueInfo,
        msgText,
        candidateName: candidateInfo.name,
        candidateCompany: candidateInfo.company || '',
        candidateTitle: candidateInfo.title || '',
        jobName: getCurrentJobName(),
        savedAt: Date.now(),
      }));
    }

    // 2. 找并点击「发消息」按钮：优先已知 class（btn-secondary btn-block），兜底文字匹配
    const msgBtn = (() => {
      const byClass = Array.from(document.querySelectorAll('.btn-secondary.btn-block'))
        .find(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && el.textContent.trim() === '发消息'; });
      return byClass || findVisibleBtn('发消息', '发私信', '私信', '联系TA', '联系');
    })();
    if (!msgBtn) {
      sessionStorage.removeItem('__maimai_pending_sendmsg');
      const shortEls = Array.from(document.querySelectorAll('button, [role="button"], div, span, a'))
        .filter(el => el.offsetParent !== null)
        .map(el => el.textContent.trim()).filter(t => t.length > 0 && t.length <= 10)
        .filter((v, i, a) => a.indexOf(v) === i).slice(0, 15);
      addLogLine(`❌ 未找到发消息按钮。页面可见短文本：${shortEls.join(' | ')}`);
      return false;
    }
    addLogLine(`🖱️ 点击「发消息」按钮...`);

    // 点击前：移除 target="_blank"，否则合成点击无法触发新标签导航（浏览器拦截），等于没点
    const _msgAnchor = msgBtn.tagName === 'A' ? msgBtn : msgBtn.closest('a');
    if (_msgAnchor) {
      _msgAnchor.removeAttribute('target');
      _msgAnchor.removeAttribute('rel');
    }
    msgBtn.querySelectorAll('a[target]').forEach(a => { a.removeAttribute('target'); a.removeAttribute('rel'); });

    // 记录按钮自带的 href（button 本身或祖先 <a> 上）
    const _msgBtnHref = _msgAnchor?.getAttribute('href') || null;
    const _hrefIsChatUrl = h => !!(h && (h.includes('/chat') || h.includes('/im/') || h.includes('/message/')));

    // ★ 快速路径：href 已包含聊天页地址 → 直接导航，绕过 window.open / SPA 导航的不确定性
    // __maimai_pending_sendmsg 已保存，导航后由救援 IIFE 接管发送
    if (_hrefIsChatUrl(_msgBtnHref)) {
      addLogLine(`💬 直接跳转聊天页（href）: ${_msgBtnHref.slice(0, 60)}`);
      navigateTo(_msgBtnHref);
      return 'navigating';
    }
    if (_msgBtnHref) addLogLine(`📎 按钮 href: ${_msgBtnHref.slice(0, 50)}`);

    await hoverThenClick(msgBtn);

    // 3. 等待并激活消息输入框
    // 策略：先等 URL 变化/弹窗出现，再主动点击对话区激活输入框，最后检查 activeElement
    addLogLine(`⏳ 等待消息输入框...`);
    let inputBox = null;

    // 辅助：点击页面右侧区域并检查 activeElement 是否变成了输入框
    const tryClickActivate = async () => {
      // 点击页面右下角（聊天编辑区通常在右侧底部）
      const x = Math.round(window.innerWidth * 0.65);
      const y = Math.round(window.innerHeight * 0.88);
      const el = document.elementFromPoint(x, y);
      if (el && el !== document.body) {
        el.click();
        await sleep(600);
        if (isValidMsgInput(document.activeElement)) return document.activeElement;
      }
      // 再试更靠下的位置
      const el2 = document.elementFromPoint(x, window.innerHeight - 30);
      if (el2 && el2 !== document.body) {
        el2.click();
        await sleep(400);
        if (isValidMsgInput(document.activeElement)) return document.activeElement;
      }
      return null;
    };

    // 阶段1：等待 URL 跳转到聊天页 或内联弹窗出现（最多 8s）
    const _isChatUrl = url => url.includes('/chat') || url.includes('/im/') || url.includes('/message/');
    let onChatPage = false;
    let hasWebimPanel = false;
    for (let i = 0; i < 16; i++) {
      if (stopFlag) return false;
      const curUrl = location.href;
      // 如果跳到下载页或非 maimai 页，退回
      if (curUrl !== profileUrl && (curUrl.includes('download') || !curUrl.includes('maimai'))) {
        addLogLine(`⚠️ 发消息后跳到非聊天页，返回`);
        history.back();
        return false;
      }
      if (_isChatUrl(curUrl)) { onChatPage = true; addLogLine(`💬 已进入聊天页: ${curUrl.slice(0, 60)}`); break; }
      // window.open 被扩展拦截时：URL 存入 __maimai_intercepted_url，用全页跳转打开聊天页
      const _icUrl = sessionStorage.getItem('__maimai_intercepted_url');
      if (_icUrl && _isChatUrl(_icUrl)) {
        sessionStorage.removeItem('__maimai_intercepted_url');
        addLogLine(`💬 跳转聊天页（window.open 已拦截）: ${_icUrl.slice(0, 60)}`);
        navigateTo(_icUrl);
        return 'navigating'; // 页面即将跳转，后续由救援 IIFE 处理；调用方应立即 return，不再执行任何导航
      }
      // 内联弹窗：URL 未变但输入框已出现
      inputBox = findChatInput();
      if (inputBox && isValidMsgInput(inputBox)) break;
      // 检测脉脉内联 WebIM 面板（有 webimSearchInput 但还没有编辑区）
      if (document.querySelector('input[id*="webimSearch"], input[class*="webim"][class*="search"]')) {
        hasWebimPanel = true; break;
      }
      // 第 6 次（3s）还没反应，且有 href，直接导航过去
      if (i === 5 && _msgBtnHref && !inputBox && !onChatPage && !hasWebimPanel) {
        addLogLine(`💬 点击无响应，直接导航到: ${_msgBtnHref.slice(0, 50)}`);
        navigateTo(_msgBtnHref);
        await sleep(3000);
        if (_isChatUrl(location.href)) { onChatPage = true; break; }
        if (location.href !== profileUrl && !location.href.includes('maimai')) {
          history.back(); return false;
        }
      }
      await sleep(500);
    }

    // 阶段2a：内联 WebIM 面板 — 用位置法点击对话条目激活编辑区
    if (!inputBox && hasWebimPanel) {
      addLogLine(`💬 检测到内联聊天面板，激活对话...`);
      await sleep(800);

      const targetName = candidateInfo.name?.split('(')[0].trim() || '';
      let convClicked = false;

      const searchInput = document.querySelector('input[id*="webimSearch"], input[class*="webim"][class*="search"]');
      if (searchInput) {
        const sr = searchInput.getBoundingClientRect();
        const cx = Math.round(sr.left + sr.width / 2); // 搜索框中心 X（面板中线）

        // 先用文本内容全局扫描（如果命中则最准）
        // 用 getBoundingClientRect 而非 offsetParent，兼容 position:fixed 的 WebIM 面板
        if (targetName && !convClicked) {
          const allVisible = Array.from(document.querySelectorAll('*'))
            .filter(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; });
          const named = allVisible.find(el => {
            const r = el.getBoundingClientRect();
            return r.top > sr.bottom + 5 && r.left >= sr.left - 30 && r.right <= sr.right + 30
              && r.height > 15 && r.height < 100 && el.textContent.trim().includes(targetName);
          });
          if (named) {
            addLogLine(`🖱️ 按名字点击「${targetName}」对话条目`);
            named.click();
            await sleep(2500);
            convClicked = true;
          }
        }

        // 用 elementFromPoint 在搜索框正下方逐步扫描，点击首个有文字的元素
        if (!convClicked) {
          for (let dy = 50; dy <= 250; dy += 35) {
            const el = document.elementFromPoint(cx, sr.bottom + dy);
            if (!el || el === document.body || el === document.documentElement) continue;
            if (el === searchInput || searchInput.contains(el)) continue;
            const txt = el.textContent.trim();
            if (txt.length > 0) {
              const label = targetName && txt.includes(targetName)
                ? `「${targetName}」对话`
                : `坐标(${cx},${Math.round(sr.bottom + dy)})`;
              addLogLine(`🖱️ 点击${label} [${el.tagName}.${el.className.slice(0, 20)}]`);
              el.click();
              await sleep(2500);
              convClicked = true;
              break;
            }
          }
        }
      }

      // 兜底：tryClickActivate
      if (!convClicked) inputBox = await tryClickActivate();

      // 会话点击后，主动点击面板右侧区域激活聊天输入框（WebIM 面板左右分栏时输入框在右侧）
      if (convClicked && !inputBox && searchInput) {
        inputBox = findChatInput();
        if (inputBox && !isValidMsgInput(inputBox)) inputBox = null;
        if (!inputBox) {
          const _sr = searchInput.getBoundingClientRect();
          // 尝试点击面板右侧（searchInput 右半部 + 屏幕右侧）的不同高度
          const _rxCandidates = [
            Math.round(_sr.left + _sr.width * 0.7),
            Math.round(_sr.right + 80),
            Math.round(window.innerWidth * 0.7),
          ].filter(x => x > 0 && x < window.innerWidth);
          outer: for (const _rx of _rxCandidates) {
            for (const _yf of [0.55, 0.65, 0.75, 0.82]) {
              const _py = Math.round(window.innerHeight * _yf);
              const _pe = document.elementFromPoint(_rx, _py);
              if (!_pe || _pe === document.body || _pe === document.documentElement) continue;
              _pe.click();
              await sleep(400);
              if (isValidMsgInput(document.activeElement)) { inputBox = document.activeElement; break outer; }
              const _fc = findChatInput();
              if (_fc && isValidMsgInput(_fc)) { inputBox = _fc; break outer; }
            }
          }
        }
      }

      // 等待编辑框出现（最多 10s），并尝试 Tab 触发
      const deadline = Date.now() + 10000;
      let lastTabAt = 0;
      while (!inputBox && Date.now() < deadline && !stopFlag) {
        await sleep(400);
        // 点击对话条目后可能跳转到独立聊天页，检测 URL 变化
        if (location.href.includes('/chat') || location.href.includes('/im/')) {
          onChatPage = true; break;
        }
        const candidate = findChatInput();
        if (candidate && isValidMsgInput(candidate)) { inputBox = candidate; break; }
        // 每 3s 向 searchInput 发一次 Tab，尝试把焦点切换到编辑区
        if (searchInput && Date.now() - lastTabAt > 3000) {
          lastTabAt = Date.now();
          searchInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', keyCode: 9, bubbles: true }));
          await sleep(300);
          if (isValidMsgInput(document.activeElement)) { inputBox = document.activeElement; break; }
        }
        if (Date.now() - deadline > -5000) {
          const activated = await tryClickActivate();
          if (activated) { inputBox = activated; break; }
        }
      }
    }

    // 阶段2b：在独立聊天页激活输入框
    if (!inputBox && onChatPage) {
      await sleep(1500); // 等页面渲染

      // 先尝试 findChatInput（可能已经可见）
      inputBox = findChatInput();
      if (inputBox && !isValidMsgInput(inputBox)) inputBox = null;

      // 优先：按候选人姓名在对话列表中精确查找并点击
      if (!inputBox) {
        const targetName = (candidateInfo.name || '').split('(')[0].trim();
        if (targetName) {
          // 在左侧对话列表区域（x < 45% 宽，y > 80px 跳过顶栏）中找含姓名的条目
          const namedConv = Array.from(document.querySelectorAll('*')).find(el => {
            const r = el.getBoundingClientRect();
            return r.width > 0 && r.height > 10 && r.height < 100
              && r.left < window.innerWidth * 0.45
              && r.top > 80
              && el.textContent.trim().includes(targetName)
              && !el.querySelector('input, textarea, [contenteditable]'); // 排除输入框
          });
          if (namedConv) {
            addLogLine(`🖱️ 按名字找到「${targetName}」对话条目，点击`);
            namedConv.click();
            await sleep(1500);
            inputBox = findChatInput();
            if (inputBox && !isValidMsgInput(inputBox)) inputBox = null;
          }
        }
      }

      // 兜底：坐标法点击对话列表（y 从 180 开始跳过顶部导航区，且验证不是跳转链接）
      if (!inputBox) {
        const cx = Math.round(window.innerWidth * 0.2);
        const chatPageUrl = location.href;
        for (let dy = 180; dy <= 400; dy += 40) {
          const el = document.elementFromPoint(cx, dy);
          if (!el || el === document.body || el === document.documentElement) continue;
          const txt = el.textContent.trim();
          if (txt.length === 0 || txt.length > 40) continue;
          // 安全检查：只跳过明确指向 profile/detail 资料页的链接（不排除含 dstu 的聊天链接）
          const anchor = el.closest('a[href]');
          if (anchor && /\/profile|\/detail/.test(anchor.getAttribute('href') || '')) continue;
          addLogLine(`🖱️ 点击对话区坐标(${cx},${dy}) [${el.tagName}]`);
          el.click();
          await sleep(2500);
          // 检查 URL 是否意外跳离聊天页
          if (!location.href.includes('/chat')) {
            addLogLine(`⚠️ 点击后跳出聊天页，退回`);
            history.back();
            await sleep(1500);
          }
          inputBox = findChatInput();
          if (inputBox && !isValidMsgInput(inputBox)) inputBox = null;
          // 若还未找到，尝试点击右侧区域激活输入框
          if (!inputBox) {
            const _activated = await tryClickActivate();
            if (_activated && isValidMsgInput(_activated)) inputBox = _activated;
          }
          if (inputBox) break;
        }
      }

      // 主动点击右下区域激活编辑框
      if (!inputBox) inputBox = await tryClickActivate();

      // 轮询等待（最多再等 12s）
      const deadline = Date.now() + 12000;
      let lastActivateAt = 0;
      while (!inputBox && Date.now() < deadline && !stopFlag) {
        await sleep(500);
        const candidate = findChatInput();
        if (candidate && isValidMsgInput(candidate)) { inputBox = candidate; break; }
        // 每隔 2s 再点一次激活
        if (Date.now() - lastActivateAt >= 2000) {
          lastActivateAt = Date.now();
          const activated = await tryClickActivate();
          if (activated) { inputBox = activated; break; }
        }
      }
    }

    if (stopFlag) return false;
    if (!inputBox) {
      // 诊断：打印所有可见的可交互元素（含 class 名）
      const allEls = Array.from(document.querySelectorAll(
        'textarea, input, [contenteditable="true"], [role="textbox"], ' +
        '[class*="input"], [class*="editor"], [class*="compose"], [class*="write"], [class*="send"]'
      )).filter(el => el.offsetParent !== null)
        .map(el => `${el.tagName}[${el.className.slice(0, 25) || el.type || ''}]`);
      addLogLine(`❌ 未找到消息输入框（已等约 20s）`);
      addLogLine(`   URL: ${location.href.slice(0, 80)}`);
      addLogLine(`   可见候选元素: ${allEls.slice(0, 10).join(' | ') || '无'}`);
      // ★ 如果当前已在聊天页（SPA 导航进来的），强制全页跳转让救援 IIFE 重新接管
      // __maimai_pending_sendmsg 仍在 sessionStorage，救援 IIFE 会完成发送
      const _curUrl = location.href;
      if (_curUrl !== profileUrl && (_curUrl.includes('/chat') || _curUrl.includes('/im/'))) {
        addLogLine(`🔄 强制重载聊天页，让救援 IIFE 接管发送...`);
        navigateTo(_curUrl);
        return 'navigating';
      }
      if (_curUrl !== profileUrl) history.back();
      return false;
    }

    console.log('[脉脉助手] 找到输入框:', inputBox.tagName, inputBox.className.slice(0, 40));
    // 4. 输入消息
    // ⚠️ 找到输入框后立即清除救援快照，防止页面跳动时 IIFE 重复触发发送
    sessionStorage.removeItem('__maimai_pending_sendmsg');
    addLogLine(`⌨️ 找到输入框：${inputBox.tagName}${inputBox.className ? '[' + inputBox.className.slice(0, 30) + ']' : ''}`);
    inputBox.click();
    inputBox.focus();
    await sleep(300);
    if (inputBox.contentEditable === 'true') {
      // contenteditable：先清空再逐字输入
      document.execCommand('selectAll', false, null);
      document.execCommand('delete', false, null);
      await sleep(200);
      await humanType(inputBox, msgText);
    } else if (inputBox.tagName === 'TEXTAREA' || inputBox.tagName === 'INPUT') {
      // textarea/input：用 nativeSetter 清空后逐字输入
      nativeSetter(inputBox, '');
      inputBox.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(200);
      await humanType(inputBox, msgText);
    } else {
      // div 类输入框：用 insertText 命令逐字输入
      inputBox.click();
      inputBox.focus();
      await sleep(200);
      document.execCommand('selectAll', false, null);
      document.execCommand('delete', false, null);
      await sleep(150);
      await humanType(inputBox, msgText);
    }

    // 5. 审阅停顿
    const reviewMs = (bh?.reviewMinMs ?? 1500) + Math.random() * ((bh?.reviewMaxMs ?? 3000) - (bh?.reviewMinMs ?? 1500));
    addLogLine(`👀 审阅消息 ${(reviewMs / 1000).toFixed(1)}s...`);
    await sleep(reviewMs);

    // 6. 找发送按钮并点击
    // 优先：已知结构（a[data-radium] 蓝色发送按钮），兜底文字匹配
    const _findSendBtn = () => {
      const byAttr = Array.from(document.querySelectorAll('a[data-radium="true"], button[data-radium="true"]'))
        .find(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && el.textContent.trim() === '发送'; });
      return byAttr || findVisibleBtn('发送', '送出', 'Send');
    };
    const sendBtn = _findSendBtn();
    if (!sendBtn) {
      addLogLine(`⚠️ 未找到发送按钮，尝试 Enter 键发送`);
      // 兜底：按 Enter 发送
      inputBox.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
      inputBox.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, bubbles: true }));
    } else {
      await hoverThenClick(sendBtn);
    }
    // 发送后冷却（防止脉脉"发送消息太频繁"限制）：6-10 秒随机等待
    const coolMs = 6000 + Math.random() * 4000;
    addLogLine(`⏱️ 冷却中 ${(coolMs / 1000).toFixed(0)}s，防频率限制...`);
    const coolEnd = Date.now() + coolMs;
    while (Date.now() < coolEnd && !stopFlag && !paused) await sleep(1000);

    sessionStorage.removeItem('__maimai_pending_sendmsg'); // 发送成功，清除救援快照
    await sendMsg({ type: 'ACTION_DONE', action: 'messaged' });
    dailyContacts++;
    addLogLine(`✅ 已发消息给 ${candidateInfo.name}`);
    // 不在此处导航，由 profile IIFE 的 window.location.href = pp.listUrl 统一返回列表
    return true;
  }

  /**
   * 向非好友候选人发送好友申请
   * 脉脉「+加好友」流程：点按钮 → 弹出弹窗或跳转页面 → 填写附言 → 点确认
   *
   * 核心策略：完全不依赖弹窗 class 名；用"点击前快照对比 + getBoundingClientRect"
   * 检测任何新出现的可见输入框，兼容 position:fixed / 无 class / list-group 等各种弹窗实现。
   */
  async function addAsFriend(candidateInfo, rescueInfo = {}) {
    addLogLine(`➕ 准备向 ${candidateInfo.name} 发送好友申请...`);
    const bh = config.humanBehavior;

    // 1. 生成附言内容
    let msgText;
    try {
      const resp = await sendMsg({ type: 'GENERATE_MESSAGE', candidateInfo, isFriend: false });
      msgText = resp.text;
      if (!msgText) throw new Error('消息内容为空，请检查配置页加好友话术模板');
    } catch (err) {
      addLogLine(`❌ 生成话术失败：${err.message}`);
      log('error', `生成话术失败: ${err.message}`);
      return false;
    }

    // ── 可见性检测（兼容 position:fixed 弹窗——offsetParent 对 fixed 返回 null）──────
    const isVis = el => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    };

    // ── 辅助：检测是否已自动提交（按钮变"已申请"等）──────────────────────────────
    // 先拍点击前快照，避免把页面原有的"已申请"类文字误判为"提交成功"
    const APPLIED_KEYWORDS = ['已申请', '已发送', '已添加', '申请中', '好友请求已发出', '申请成功'];
    const _preAppliedEls = new Set(
      Array.from(document.querySelectorAll('button, [role="button"], div, span, a'))
        .filter(el => {
          const r = el.getBoundingClientRect();
          if (r.width === 0 || r.height === 0) return false;
          const t = el.textContent.trim();
          return t.length <= 30 && APPLIED_KEYWORDS.some(k => t.includes(k));
        })
    );
    const isAlreadyApplied = () => {
      // 情况1：原加好友按钮的文字本身变成了"已申请"等（React 原地复用 DOM 元素）
      if (APPLIED_KEYWORDS.some(k => addBtn.textContent.trim().includes(k))) return true;
      // 情况2：页面新出现了"已申请"类元素（弹窗关闭 or 状态变更）
      return Array.from(document.querySelectorAll('button, [role="button"], div, span, a'))
        .some(el => {
          if (_preAppliedEls.has(el)) return false; // 点击前已存在，跳过
          const r = el.getBoundingClientRect();
          if (r.width === 0 || r.height === 0) return false;
          const t = el.textContent.trim();
          return t.length <= 30 && APPLIED_KEYWORDS.some(k => t.includes(k));
        });
    };

    // ── 辅助：在元素及其祖先（最多 N 层）中找确认按钮 ──────────────────────────────
    const CONFIRM_TEXTS = ['确认', '发送', '确定', '申请', '提交', '同意', '发申请'];
    const findConfirmNear = (anchor) => {
      let el = anchor?.parentElement;
      for (let depth = 0; el && depth < 8; depth++, el = el.parentElement) {
        const all = Array.from(el.querySelectorAll('button, [role="button"], div, span, a, li'))
          .filter(isVis);
        for (const text of CONFIRM_TEXTS) {
          const found = all.find(b => {
            const t = b.textContent.trim();
            return t === text || (t.includes(text) && t.length <= 10);
          });
          if (found) return found;
        }
      }
      return null;
    };

    // 2. 找并点击「+加好友」或「加好友」按钮
    // 优先用已知 class（btn-secondary btn-block，蓝色加好友按钮）精确定位
    const addBtn = (() => {
      const byClass = Array.from(document.querySelectorAll('.btn-secondary.btn-block'))
        .find(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && el.textContent.trim().includes('加好友'); });
      return byClass || findVisibleBtn('＋加好友', '+加好友', '加好友', '+ 加好友', '申请好友', '打招呼', '添加好友');
    })();
    if (!addBtn) {
      const shortEls = Array.from(document.querySelectorAll('button, [role="button"], div, span, a'))
        .filter(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; })
        .map(el => el.textContent.trim()).filter(t => t.length > 0 && t.length <= 10)
        .filter((v, i, a) => a.indexOf(v) === i).slice(0, 15);
      addLogLine(`❌ 未找到加好友按钮。页面可见短文本：${shortEls.join(' | ')}`);
      return false;
    }

    // 点击前先记录当前页面所有「可见」输入框快照（不依赖 class，用于后续对比）
    // 注意：必须过滤 isVis()，避免把脉脉预渲染但隐藏的弹窗输入框收进快照；
    // 否则弹窗出现后快照对比永远 false，找不到附言输入框
    const snapInputEls = new Set(
      Array.from(document.querySelectorAll(
        'textarea, [contenteditable]:not([contenteditable="false"]), input[type="text"], input:not([type])'
      )).filter(isVis)
    );
    const preClickUrl = location.href;

    // 点击前保存上下文到 sessionStorage：若点击后触发全页跳转（content.js 销毁），
    // 新页面的 IIFE 会检测到此 key，接管加好友表单的填写和提交
    // 此处在存入前再做一次占位符替换兜底（防止 generateMessage 未能正确替换）
    const _afReKey = (key) => new RegExp('[\\[{｛【]' + key + '[\\]}｝】]', 'g');
    const _msgTextFinal = msgText
      .replace(_afReKey('name'), candidateInfo.name || '')
      .replace(_afReKey('jobTitle'), config?.jobTitle || '')
      .slice(0, 50);
    sessionStorage.setItem('__maimai_pending_addfriend', JSON.stringify({
      msgText: _msgTextFinal,
      candidateName: candidateInfo.name,
      candidateCompany: candidateInfo.company || '',
      candidateTitle: candidateInfo.title || '',
      candidateScore: rescueInfo.candidateScore || 0,
      candidateReason: rescueInfo.candidateReason || '',
      candidateHighlights: rescueInfo.candidateHighlights || '',
      profileUrl: rescueInfo.profileUrl || location.href,
      listUrl: rescueInfo.listUrl || location.href,
      keyword: rescueInfo.keyword || currentKeyword,
      nextCardIndex: rescueInfo.nextCardIndex || 0,
      jobName: getCurrentJobName(),
      savedAt: Date.now(),
    }));

    addLogLine(`🖱️ 点击「${addBtn.textContent.trim()}」按钮...`);
    await hoverThenClick(addBtn);
    // 等待足够时间让弹窗出现，不在此处提前检测自动提交：
    // 脉脉点击后可能先把按钮改为「申请中」（UI乐观更新），同时仍在加载附言弹窗；
    // 过早检测会误判为「自动提交」，跳过附言填写。交由下方弹窗等待循环处理。
    await sleep(1200);

    // 3b. 检测是否触发了 SPA 内页面跳转（URL 在同一 content.js 中变化）
    // 注意：若是全页刷新（content.js 被销毁），此分支不会执行，由 IIFE 中的
    // __maimai_pending_addfriend 救援机制处理
    if (location.href !== preClickUrl) {
      addLogLine(`🔄 检测到页面跳转（SPA），等待加好友页面加载...`);
      await sleep(2000);
      // SPA 内跳转：content.js 仍然存活，直接在新页面上操作
      const pageInput = Array.from(document.querySelectorAll(
        'textarea:not([readonly]), [contenteditable="true"], [contenteditable]:not([contenteditable="false"]), input[type="text"]:not([readonly]), input:not([type]):not([readonly])'
      )).find(el => isVis(el) && !(el.id + el.className).toLowerCase().includes('search'));
      if (pageInput) {
        const truncated = _msgTextFinal; // 已做占位符替换的版本
        addLogLine(`⌨️ 附言内容（${truncated.length}字）：「${truncated.slice(0, 25)}${truncated.length > 25 ? '...' : ''}」`);
        await hoverThenClick(pageInput);
        pageInput.focus();
        await sleep(300 + Math.random() * 200);
        if (pageInput.contentEditable === 'true') {
          document.execCommand('selectAll', false, null);
          await sleep(80);
          document.execCommand('delete', false, null);
        } else {
          pageInput.select();
          nativeSetter(pageInput, '');
          pageInput.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' }));
        }
        await sleep(150 + Math.random() * 100);
        await humanType(pageInput, truncated);
        // 验证写入
        const pv = pageInput.contentEditable === 'true' ? pageInput.textContent?.trim() : pageInput.value?.trim();
        if (!pv || pv.length < Math.floor(truncated.length * 0.8)) {
          if (pageInput.contentEditable === 'true') {
            document.execCommand('selectAll', false, null);
            document.execCommand('delete', false, null);
            document.execCommand('insertText', false, truncated);
          } else {
            nativeSetter(pageInput, truncated);
            pageInput.dispatchEvent(new InputEvent('input', { bubbles: true, data: truncated, inputType: 'insertText' }));
            pageInput.dispatchEvent(new Event('change', { bubbles: true }));
          }
          await sleep(200);
        }
        const confirmBtn = findConfirmNear(pageInput) || (() => {
          for (const t of CONFIRM_TEXTS) { const b = findVisibleBtn(t); if (b) return b; }
          return null;
        })();
        if (confirmBtn) {
          addLogLine(`🖱️ 点击「${confirmBtn.textContent.trim()}」提交...`);
          await hoverThenClick(confirmBtn);
          await sleep(1500);
        }
        sessionStorage.removeItem('__maimai_pending_addfriend');
        if (isAlreadyApplied() || location.href !== preClickUrl) {
          await sendMsg({ type: 'ACTION_DONE', action: 'added' });
          dailyContacts++;
          addLogLine(`✅ 已向 ${candidateInfo.name} 发送好友申请（跳转页面）`);
          // 返回资料页
          history.back();
          await waitForUrlChange(location.href, 5000);
          return true;
        }
      }
    }

    // 3c. 等待内联弹窗/输入框出现（不依赖 class 名，纯靠快照对比 + BoundingClientRect）
    addLogLine(`⏳ 等待好友申请弹窗...`);
    let remarkInput = null;
    const dlDeadline = Date.now() + 15000;

    // 辅助：快速扫一次附言输入框（供"已申请"确认等待中复查）
    const quickFindRemarkInput = () => {
      const allIn = Array.from(document.querySelectorAll(
        'textarea:not([readonly]), [contenteditable="true"], [contenteditable]:not([contenteditable="false"]), input[type="text"]:not([readonly]), input:not([type]):not([readonly])'
      ));
      return (isVis(document.querySelector('textarea[placeholder*="加好友的原因"]')) &&
              document.querySelector('textarea[placeholder*="加好友的原因"]')) ||
             Array.from(document.querySelectorAll('textarea.sc-hGoxap, textarea.dVMspX')).find(isVis) ||
             allIn.find(el => !snapInputEls.has(el) && isVis(el) && !(el.id + el.className).toLowerCase().includes('search')) ||
             allIn.find(el => isVis(el) && /附言|留言|消息|申请理由|验证|好友|原因/.test(el.placeholder || el.getAttribute('data-placeholder') || '') && !(el.id + el.className).toLowerCase().includes('search')) ||
             Array.from(document.querySelectorAll('textarea')).find(el => isVis(el) && !snapInputEls.has(el) && parseInt(el.getAttribute('maxlength') || '999') <= 60) ||
             null;
    };

    while (Date.now() < dlDeadline && !stopFlag) {
      const allInputs = Array.from(document.querySelectorAll(
        'textarea:not([readonly]), [contenteditable="true"], [contenteditable]:not([contenteditable="false"]), input[type="text"]:not([readonly]), input:not([type]):not([readonly])'
      ));

      // 优先：已知 placeholder / class 直接命中（最精准）
      remarkInput = (isVis(document.querySelector('textarea[placeholder*="加好友的原因"]')) &&
                     document.querySelector('textarea[placeholder*="加好友的原因"]')) ||
                    Array.from(document.querySelectorAll('textarea.sc-hGoxap, textarea.dVMspX')).find(isVis);
      if (remarkInput) { addLogLine(`✅ 找到附言输入框（已知class/placeholder）`); break; }

      // 次选：快照对比——点击后新出现的元素
      remarkInput = allInputs.find(el =>
        !snapInputEls.has(el) && isVis(el) &&
        !(el.id + el.className).toLowerCase().includes('search')
      );
      if (remarkInput) { addLogLine(`✅ 找到附言输入框（新出现）`); break; }

      // 三选：匹配附言/留言/验证相关 placeholder 的可见元素
      remarkInput = allInputs.find(el =>
        isVis(el) &&
        /附言|留言|消息|申请理由|验证|好友|原因/.test(el.placeholder || el.getAttribute('data-placeholder') || '') &&
        !(el.id + el.className).toLowerCase().includes('search')
      );
      if (remarkInput) { addLogLine(`✅ 找到附言输入框（placeholder匹配）`); break; }

      // 第三策略：在弹窗容器内找任意可编辑元素（按弹窗 z-index 层叠推断）
      const dialogEl = Array.from(document.querySelectorAll('[role="dialog"], .modal, .dialog, [class*="modal"], [class*="dialog"], [class*="popup"]'))
        .find(el => isVis(el));
      if (dialogEl) {
        const dlgInput = Array.from(dialogEl.querySelectorAll('textarea, [contenteditable]:not([contenteditable="false"]), input')).find(el => isVis(el));
        if (dlgInput && !snapInputEls.has(dlgInput)) {
          remarkInput = dlgInput;
          addLogLine(`✅ 找到附言输入框（弹窗容器内）`);
          break;
        }
      }

      // 第四策略：找 maxlength≤50 的 textarea（脉脉附言框特征）
      const shortTextarea = Array.from(document.querySelectorAll('textarea'))
        .find(el => isVis(el) && !snapInputEls.has(el) && parseInt(el.getAttribute('maxlength') || '999') <= 60);
      if (shortTextarea) {
        remarkInput = shortTextarea;
        addLogLine(`✅ 找到附言输入框（maxlength≤60特征）`);
        break;
      }

      // ★ 附言框未出现时才判断"已自动提交"（必须在弹窗搜索之后）
      // 脉脉点击加好友后会乐观更新按钮为"已申请"，同时弹窗仍在加载；
      // 因此需要先找弹窗，确实找不到才等额外 1.5s 再确认。
      if (isAlreadyApplied()) {
        await sleep(1500); // 给附言弹窗额外缓冲时间
        remarkInput = quickFindRemarkInput();
        if (remarkInput) { addLogLine(`✅ 找到附言输入框（等待后出现）`); break; }
        // 1.5s 后仍无弹窗，确认是真正的自动提交（无附言）
        sessionStorage.removeItem('__maimai_pending_addfriend');
        addLogLine(`✅ 已向 ${candidateInfo.name} 发送好友申请（自动完成，无附言弹窗）`);
        await sendMsg({ type: 'ACTION_DONE', action: 'added' });
        dailyContacts++;
        return true;
      }

      await sleep(300);
    }

    // 超时诊断（改用 isVis 而非 offsetParent，确保检测到 fixed 元素）
    if (!remarkInput) {
      const topEls = Array.from(document.querySelectorAll('body > *, #app > *, #root > *'))
        .filter(isVis)
        .map(el => `${el.tagName}[${(el.className || '').slice(0, 30)}]`);
      addLogLine(`🔍 弹窗超时，顶层: ${topEls.slice(0, 6).join(' | ')}`);
      // 同时输出当前所有可见 input，帮助人工排查
      const visInputs = Array.from(document.querySelectorAll('textarea, input, [contenteditable="true"]'))
        .filter(isVis)
        .map(el => `${el.tagName}[cls:${(el.className || '').slice(0, 20)}][ph:${(el.placeholder || '').slice(0, 20)}]`);
      addLogLine(`🔍 可见输入框: ${visInputs.join(' | ') || '无'}`);
      console.log('[脉脉助手] addFriend 超时，body HTML前800字:', document.body.innerHTML.slice(0, 800));
    }

    // 4. 填写附言
    if (remarkInput) {
      const truncated = _msgTextFinal; // 已做占位符替换的版本，限 50 字
      addLogLine(`⌨️ 附言内容（${truncated.length}字）：「${truncated.slice(0, 25)}${truncated.length > 25 ? '...' : ''}」`);

      // 像人一样：hover → 点击 → 聚焦 → 等一下再开始打字
      await hoverThenClick(remarkInput);
      remarkInput.focus();
      await sleep(300 + Math.random() * 200);

      // 清空已有内容（像人按全选后删除）
      if (remarkInput.contentEditable === 'true') {
        document.execCommand('selectAll', false, null);
        await sleep(80);
        document.execCommand('delete', false, null);
      } else {
        remarkInput.select();
        nativeSetter(remarkInput, '');
        remarkInput.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' }));
      }
      await sleep(150 + Math.random() * 100);

      // 逐字人工输入
      await humanType(remarkInput, truncated);

      // 输入完验证内容是否写入（React 有时需要多一次 change 触发）
      const typedVal = remarkInput.contentEditable === 'true'
        ? remarkInput.textContent?.trim()
        : remarkInput.value?.trim();
      if (!typedVal || typedVal.length < Math.floor(truncated.length * 0.8)) {
        addLogLine(`⚠️ 附言写入不完整（${typedVal?.length || 0}字），补全重写...`);
        if (remarkInput.contentEditable === 'true') {
          document.execCommand('selectAll', false, null);
          document.execCommand('delete', false, null);
          document.execCommand('insertText', false, truncated);
        } else {
          nativeSetter(remarkInput, truncated);
          remarkInput.dispatchEvent(new InputEvent('input', { bubbles: true, data: truncated, inputType: 'insertText' }));
          remarkInput.dispatchEvent(new Event('change', { bubbles: true }));
        }
        await sleep(300);
      }
    } else {
      // 找不到附言输入框 → 不发送（避免发出无附言的好友申请）
      addLogLine(`❌ 未找到附言输入框，取消发送好友申请（避免空附言）`);
      const cancelBtn = findVisibleBtn('取消', '关闭', '×', 'Cancel');
      if (cancelBtn) { cancelBtn.click(); await sleep(500); }
      sessionStorage.removeItem('__maimai_pending_addfriend');
      return false;
    }

    // 5. 找确认按钮
    //    策略1：从 remarkInput 向上找祖先容器，在容器内找确认按钮（最精准）
    //    策略2：全页 findVisibleBtn（兜底）
    //    策略3：位置坐标点击（最后手段）
    let confirmBtn = remarkInput ? findConfirmNear(remarkInput) : null;

    if (!confirmBtn) {
      if (isAlreadyApplied()) {
        sessionStorage.removeItem('__maimai_pending_addfriend');
        addLogLine(`✅ 已向 ${candidateInfo.name} 发送好友申请（已提交）`);
        await sendMsg({ type: 'ACTION_DONE', action: 'added' });
        dailyContacts++;
        return true;
      }
      // 全页搜索确认按钮
      for (const text of CONFIRM_TEXTS) {
        const btn = findVisibleBtn(text);
        if (btn) { confirmBtn = btn; break; }
      }
    }

    // 位置兜底：在页面中央偏下区域扫描（弹窗确认按钮通常在此区域）
    if (!confirmBtn) {
      for (const [cx, cy] of [
        [Math.round(window.innerWidth * 0.5), Math.round(window.innerHeight * 0.65)],
        [Math.round(window.innerWidth * 0.5), Math.round(window.innerHeight * 0.75)],
        [Math.round(window.innerWidth * 0.5), Math.round(window.innerHeight * 0.55)],
      ]) {
        const el = document.elementFromPoint(cx, cy);
        if (el && el !== document.body && el !== document.documentElement) {
          const txt = el.textContent.trim();
          if (CONFIRM_TEXTS.some(t => txt === t || (txt.includes(t) && txt.length <= 12))) {
            confirmBtn = el;
            addLogLine(`🖱️ 坐标找到确认按钮 (${cx},${cy}) [${el.tagName}:${txt}]`);
            break;
          }
          // 即使不是标准确认文字，也尝试点一次（看弹窗会不会关闭）
          addLogLine(`🖱️ 坐标兜底点击 (${cx},${cy}) [${el.tagName}.${(el.className || '').slice(0, 20)}:${txt.slice(0, 10)}]`);
          el.click();
          await sleep(1000);
          if (isAlreadyApplied()) {
            sessionStorage.removeItem('__maimai_pending_addfriend');
            await sendMsg({ type: 'ACTION_DONE', action: 'added' });
            dailyContacts++;
            addLogLine(`✅ 已向 ${candidateInfo.name} 发送好友申请（坐标兜底）`);
            return true;
          }
          break;
        }
      }

      if (!confirmBtn) {
        const allBtns = Array.from(document.querySelectorAll('button, [role="button"], div, span, a'))
          .filter(isVis)
          .map(b => b.textContent.trim()).filter(t => t.length > 0 && t.length <= 12)
          .filter((v, i, a) => a.indexOf(v) === i).slice(0, 20);
        addLogLine(`⚠️ 未找到确认按钮。可见短文本: ${allBtns.join(' | ')}`);
        sessionStorage.removeItem('__maimai_pending_addfriend');
        return false;
      }
    }

    addLogLine(`🖱️ 点击「${confirmBtn.textContent.trim()}」确认...`);
    await hoverThenClick(confirmBtn);

    // 6. 验证提交成功（等弹窗关闭 或 按钮状态变化）
    await sleep(800);
    for (let w = 0; w < 10; w++) {
      if (isAlreadyApplied()) break;
      // 如果点击后输入框消失，说明弹窗关闭了（视为成功）
      if (remarkInput && !isVis(remarkInput)) break;
      await sleep(400);
    }

    sessionStorage.removeItem('__maimai_pending_addfriend');
    await sendMsg({ type: 'ACTION_DONE', action: 'added' });
    dailyContacts++;
    addLogLine(`✅ 已向 ${candidateInfo.name} 发送好友申请`);
    return true;
  }

  // ─── 主流程：处理单张候选人卡片 ─────────────────────────────────────────────
  /**
   * 用轮询等待 URL 变化（比 MutationObserver 更可靠，因为 React Router pushState 不触发 DOM 变更）
   */
  async function waitForUrlChange(fromUrl, timeoutMs = 10000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      if (location.href !== fromUrl) return true;
      await sleep(200);
    }
    return false;
  }

  async function processCard(card, index, cardPos) {
    const bh = config.humanBehavior;
    log('info', `处理第 ${cardPos + 1} 位候选人...`);

    // 1. 卡片基础信息
    const basicInfo = extractCardInfo(card);
    const infoStr = [basicInfo.title, basicInfo.company].filter(Boolean).join(' @ ');
    const _socialLabel = basicInfo.name || `候选人${cardPos + 1}`;
    addLogLine(`👤 ${_socialLabel}${infoStr ? ' · ' + infoStr : ''}`);

    // ── 视觉指示：高亮当前卡片 + 更新 overlay ──
    _highlightRecruitCard(card, '👁 查阅中');
    updateOverlay(`👤 [${cardPos + 1}] ${_socialLabel}`);

    // 判断是否是详情页 URL
    const isProfileUrl = (url) =>
      url.includes('/profile/detail') || /maimai\.cn\/p\//.test(url) ||
      url.includes('/web/profile') || url.includes('/user/') ||
      url.includes('/talent/') || url.includes('/member/');

    // 2. 从卡片 DOM 中提取 dstu ID（最可靠，无需依赖点击）
    const dstuFromCard = (() => {
      // 方案2a：遍历所有元素所有属性，找 dstu=数字
      for (const el of [card, ...card.querySelectorAll('*')]) {
        for (const attr of el.attributes || []) {
          const m = attr.value.match(/dstu\D{0,5}?(\d{5,})/i);
          if (m) return m[1];
        }
        if (el.tagName === 'A' && el.href) {
          const m = el.href.match(/dstu=(\d+)/);
          if (m) return m[1];
        }
      }
      // 方案2b：从 React Fiber 中提取（适用于纯 onClick 路由、无 href 属性的脉脉卡片）
      // 脉脉人脉页的候选人卡片用 React onClick 处理导航，dstu 藏在组件 props 里而非 DOM 属性
      try {
        const fk = Object.keys(card).find(k => /^__react(Fiber|InternalInstance|Internals)/.test(k));
        if (fk) {
          let fiber = card[fk];
          for (let i = 0; i < 20 && fiber; i++) {
            const props = fiber.memoizedProps || fiber.pendingProps || {};
            for (const v of Object.values(props)) {
              if (typeof v === 'string') {
                const m = v.match(/[?&]dstu=(\d+)/);
                if (m) return m[1];
              }
            }
            fiber = fiber.return;
          }
        }
      } catch (_) {}
      return null;
    })();

    // 找可点击的元素（用于点击触发导航）
    const _cardIsVis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const nameEl = (() => {
      const RELATION_RE = /查看|共同好友|好友|同事|同学|校友|初识|LV\d|^\d+个|^50\+/;
      const candidates = Array.from(card.querySelectorAll('[class*="name"], strong, b, span, p'))
        .filter(el => {
          if (!_cardIsVis(el)) return false;
          const t = el.textContent.trim();
          return t.length >= 2 && t.length <= 12 && /[\u4e00-\u9fa5]/.test(t) && !RELATION_RE.test(t);
        });
      candidates.sort((a, b) => a.textContent.trim().length - b.textContent.trim().length);
      return candidates[0] || null;
    })();
    const avatarImg =
      card.querySelector('img[class*="avatar"], img[class*="head"], img[class*="photo"]') ||
      card.querySelector('img');
    // 找卡片内的 profile 链接：先精确匹配 profile URL 模式，没有就找任何非 javascript 链接
    const profileAnchor = (() => {
      const anchors = Array.from(card.querySelectorAll('a[href]'));
      return anchors.find(a => /\/p\/|\/web\/profile|\/user\/|\/profile\//.test(a.href))
        || anchors.find(a => a.href && !a.href.startsWith('javascript') && a.href.includes('maimai.cn') && !a.href.includes('search_center'));
    })();
    // "查看" 可能是 <a>, <button>, <div> 等各种标签
    const viewEl = Array.from(card.querySelectorAll('a, button, [role="button"], div, span'))
      .find(el => _cardIsVis(el) && el.textContent.trim() === '查看');

    // 移除卡片本身、父级、以及内部所有 <a> 的 target="_blank"
    // ★ 关键：Maimai 卡片外层通常是 <a target="_blank"> 包整张卡片，必须向上查祖先
    const _removeTarget = (el) => { if (el) { el.removeAttribute('target'); el.removeAttribute('rel'); } };
    _removeTarget(card.tagName === 'A' ? card : card.closest('a[target]'));
    card.querySelectorAll('a[target]').forEach(_removeTarget);

    console.log('[脉脉助手] 卡片: dstu=', dstuFromCard, '| anchor=', profileAnchor?.href?.slice(0,60), '| viewEl=', viewEl?.tagName, '| nameEl=', nameEl?.tagName);

    // ★ 早期已看检查：在滚动/hover 前判断，已看过则立即跳过（节省 1-2 秒等待）
    {
      const _earlyUrl = dstuFromCard
        ? `https://maimai.cn/profile/detail?dstu=${dstuFromCard}`
        : (profileAnchor?.href && isProfileUrl(profileAnchor.href) ? profileAnchor.href : null);
      const _earlyId = _earlyUrl ? extractCandidateId(_earlyUrl) : null;
      if (_earlyId && _seenCandidates.has(_earlyId)) {
        addLogLine(`⏭️ 已看过，跳过`);
        _clearRecruitCardHighlight();
        return false;
      }
    }

    // 3. 进入详情页：hover 停顿后点击
    const listUrl = location.href;
    addLogLine(`🔍 查看详情...`);
    _updateRecruitBadge('🔍 进入详情');
    updateOverlay(`🔍 查看详情：${_socialLabel}`);

    // 滚动至可视区域，避免卡片不在屏幕内导致点击失效
    card.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await sleep(500 + Math.random() * 300);

    const hoverTarget = viewEl || avatarImg || nameEl || card;
    hoverTarget.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true }));
    hoverTarget.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true, cancelable: true }));
    const hoverMs = (bh?.hoverMinMs ?? 400) + Math.random() * ((bh?.hoverMaxMs ?? 1000) - (bh?.hoverMinMs ?? 400));
    await sleep(hoverMs);

    // 4. 在点击前先保存任务状态（anchor 点击可能立即触发全页导航）
    sessionStorage.setItem('__maimai_pending_profile', JSON.stringify({
      listUrl,
      keyword: currentKeyword,
      candidateInfo: basicInfo,
      nextCardIndex: cardPos + 1,
      savedAt: Date.now()
    }));

    // ── 方案A：dstu 已知，直接构造 URL，无需任何点击 ──────────────────────────
    let profileUrl = dstuFromCard
      ? `https://maimai.cn/profile/detail?dstu=${dstuFromCard}`
      : null;

    // ── 方案B：从 <a href> 读取 URL ──────────────────────────────────────────
    // B1：卡片内部找到的 profileAnchor
    const anchorHref = profileAnchor?.href || '';
    if (!profileUrl && anchorHref && isProfileUrl(anchorHref)) profileUrl = anchorHref;
    // B2：卡片本身或父级 <a> 包着整张卡片（Maimai 常见结构）
    if (!profileUrl) {
      const wrapAnchor = card.tagName === 'A' ? card : card.closest('a[href]');
      if (wrapAnchor && isProfileUrl(wrapAnchor.href)) profileUrl = wrapAnchor.href;
    }
    // B3：点击候选元素（viewEl/nameEl/avatarImg）的祖先 <a> 里有 profile href
    if (!profileUrl) {
      for (const el of [viewEl, nameEl, avatarImg].filter(Boolean)) {
        const anc = el.closest('a[href]');
        if (anc && isProfileUrl(anc.href)) { profileUrl = anc.href; break; }
      }
    }

    // 方案C 前：方案A/B 已知 profileUrl，若已看过则直接跳过（避免点击触发SPA导航再回退）
    if (profileUrl) {
      const _preCId = extractCandidateId(profileUrl);
      if (_preCId && _seenCandidates.has(_preCId)) {
        sessionStorage.removeItem('__maimai_pending_profile');
        addLogLine(`⏭️ 已看过，跳过`);
        _clearRecruitCardHighlight();
        return false;
      }
    }

    // ── 方案C：点击触发 React onClick / pushState，等待 URL 变化 ─────────────
    // 关键：所有点击事件必须携带 clientX/clientY，否则 React 合成事件不响应；
    // 同时用 elementFromPoint 确保点击到坐标处最顶层的实际元素（而非被覆盖的底层元素）
    if (!profileUrl) {
      sessionStorage.removeItem('__maimai_intercepted_url');

      // 辅助：带坐标的点击（确保 React 能收到正确的 clientX/clientY）
      const clickWithCoords = async (target) => {
        const r = target.getBoundingClientRect();
        if (r.width === 0 && r.height === 0) return;
        const cx = Math.round(r.left + r.width / 2);
        const cy = Math.round(r.top + r.height / 2);
        const topEl = (cx >= 0 && cy >= 0 && cx < window.innerWidth && cy < window.innerHeight)
          ? (document.elementFromPoint(cx, cy) || target) : target;
        // 防止任何祖先 <a target="_blank"> 在点击后开新标签页
        [target, topEl].forEach(el => {
          const anc = el.tagName === 'A' ? el : el.closest('a[target]');
          if (anc) { anc.removeAttribute('target'); anc.removeAttribute('rel'); }
        });
        const ev = (extra = {}) => ({
          bubbles: true, cancelable: true, view: window,
          clientX: cx, clientY: cy, screenX: cx, screenY: cy, ...extra,
        });
        topEl.dispatchEvent(new PointerEvent('pointerdown', { ...ev(), isPrimary: true }));
        topEl.dispatchEvent(new MouseEvent('mousedown', ev({ buttons: 1 })));
        await sleep(50 + Math.random() * 60);
        topEl.dispatchEvent(new PointerEvent('pointerup', { ...ev(), isPrimary: true }));
        topEl.dispatchEvent(new MouseEvent('mouseup', ev({ buttons: 0 })));
        topEl.dispatchEvent(new MouseEvent('click', ev()));
        if (topEl !== target) target.dispatchEvent(new MouseEvent('click', ev()));
        try { target.click(); } catch(_) {}
      };

      // 辅助：点击后等待 URL 变化或 window.open 拦截（最多 3s）
      const waitNavigation = async () => {
        for (let w = 0; w < 12; w++) {
          await sleep(250);
          const intercepted = sessionStorage.getItem('__maimai_intercepted_url');
          if (intercepted && isProfileUrl(intercepted)) {
            sessionStorage.removeItem('__maimai_intercepted_url');
            return intercepted;
          }
          if (location.href !== listUrl && isProfileUrl(location.href)) return location.href;
        }
        return null;
      };

      // 按优先级逐一尝试点击目标
      const clickCandidates = [viewEl, avatarImg, nameEl, card].filter(Boolean);
      for (const target of clickCandidates) {
        if (profileUrl || stopFlag) break;
        await clickWithCoords(target);
        profileUrl = await waitNavigation();
      }

      // 方案C兜底：用坐标点击卡片中心（所有 target 均失败时的最后手段）
      if (!profileUrl && !stopFlag) {
        const r = card.getBoundingClientRect();
        const cx = Math.round(r.left + r.width / 2);
        const cy = Math.round(r.top + r.height / 2);
        const centerEl = document.elementFromPoint(cx, cy);
        if (centerEl && centerEl !== document.body) {
          await clickWithCoords(centerEl);
          profileUrl = await waitNavigation();
        }
      }
      log('info', `processCard方案C: profileUrl=${profileUrl?.slice(0,60)} | loc=${location.href.slice(0,60)}`);
    } else {
      log('info', `processCard方案A/B: profileUrl=${profileUrl?.slice(0,60)}`);
    }

    // ── 方案D：最后看 location 是否已经在详情页 ──────────────────────────────
    if (!profileUrl && location.href !== listUrl && isProfileUrl(location.href)) {
      profileUrl = location.href;
    }

    if (!profileUrl) {
      // 清除刚才保存的 localStorage，避免误触发
      sessionStorage.removeItem('__maimai_pending_profile');
      log('warn', `processCard: 无法获取详情页地址。anchor=${anchorHref.slice(0,60)} nameEl=${nameEl?.tagName}`);
      addLogLine(`⚠️ 无法获取详情页地址，跳过`);
      _clearRecruitCardHighlight();
      return false;
    }

    // 跳转前检查：是否已看过这位候选人
    const candidateId = extractCandidateId(profileUrl);
    if (candidateId && _seenCandidates.has(candidateId)) {
      sessionStorage.removeItem('__maimai_pending_profile');
      addLogLine(`⏭️ 已看过，跳过`);
      // 如果方案C已触发了 SPA 导航（URL 变成了详情页），需快速返回列表（不要延迟）
      if (location.href !== listUrl && isProfileUrl(location.href)) {
        const before = location.href;
        history.back();
        await waitForUrlChange(before, 3000);
        // 如果 history.back() 没回到列表，再用 goBackToList 兜底
        if (!location.href.includes('type=contact') && location.href !== listUrl) {
          await goBackToList(listUrl);
        } else {
          addLogLine(`↩️ 已快速返回列表`);
          await sleep(500); // 给 SPA 路由短暂渲染时间
        }
      }
      _clearRecruitCardHighlight();
      return false;
    }

    // 跳转前最后检查一次停止标志（用户在 hover 期间点了停止）
    if (stopFlag) {
      sessionStorage.removeItem('__maimai_pending_profile');
      addLogLine(`⏹ 已停止，取消跳转`);
      _clearRecruitCardHighlight();
      return false;
    }

    // 跳转前用已确认的 profileUrl 更新 pending_profile，
    // 供 profile IIFE 记录正确的候选人主页链接（避免 location.href 因 SPA 跳转被污染）
    // ★ 同时保存当前累计统计基准，detail IIFE 用于检测 Service Worker 重启后的统计归零问题
    const _baseStats = await sendMsg({ type: 'GET_STATUS' }).then(r => r?.status).catch(() => null);
    sessionStorage.setItem('__maimai_pending_profile', JSON.stringify({
      listUrl,
      keyword: currentKeyword,
      candidateInfo: basicInfo,
      nextCardIndex: cardPos + 1,
      profileUrl,
      savedAt: Date.now(),
      baseStats: _baseStats ? {
        processed: _baseStats.processed || 0, matched: _baseStats.matched || 0,
        messaged:  _baseStats.messaged  || 0, added:   _baseStats.added   || 0,
        failed:    _baseStats.failed    || 0,
      } : null,
    }));
    addLogLine(`⏳ 跳转详情页...`);
    // 若点击阶段已发生 SPA 导航（URL 已是详情页），直接强制全页刷新确保 rescue IIFE 接管
    if (location.href !== listUrl && isProfileUrl(location.href)) {
      window.location.reload();
      return;
    }
    navigateTo(profileUrl);
    // 等待导航；若 SPA 框架拦截了跳转（脚本未销毁），检测到 URL 变化后强制全页刷新
    // 全页刷新时脚本在首个 await 前即被销毁，循环不会执行
    for (let _si = 0; _si < 20; _si++) {
      await sleep(100);
      if (location.href !== listUrl) {
        window.location.reload(); // SPA 导航后强制刷新，让 rescue IIFE 正常接管
        break;
      }
    }
    return;
  }

  /**
   * 返回人脉列表：直接导航到 listUrl，确保只在当前标签页、不堆积历史
   * 无论当前在详情页还是聊天页，一步到位回到列表
   */
  async function goBackToList(listUrl) {
    // 返回前短暂停顿（真人看完后会有片刻停留，不是秒关页面）
    await sleep(600 + Math.random() * 1000);
    addLogLine(`↩️ 返回人脉列表...`);
    const currentUrl = location.href;
    if (currentUrl === listUrl) return;

    // 优先用 history.back() 逐步回退（保持 SPA pushState 链，脚本不中断）
    // 最多退 5 步，足够覆盖 详情页 → 聊天页 等中间跳转
    for (let i = 0; i < 5; i++) {
      if (location.href === listUrl || location.href.includes('type=contact')) break;
      const before = location.href;
      history.back();
      await waitForUrlChange(before, 3000);
    }

    // 如果还没回到列表，找页面上指向 listUrl 的链接点击（SPA 路由）
    if (!location.href.includes('type=contact')) {
      const backLink = document.querySelector(`a[href="${listUrl}"], a[href*="type=contact"]`);
      if (backLink) {
        backLink.removeAttribute('target');
        await hoverThenClick(backLink);
        await waitForUrlChange(location.href, 5000);
      } else {
        // 最后兜底：直接跳转（可能触发全页刷新，但至少回到正确页面）
        navigateTo(listUrl);
        await waitForUrlChange(currentUrl, 8000);
      }
    }

    // 等列表内容渲染
    await sleep(humanDelay(config.pageDelay, config.humanBehavior?.jitterPercent));
    addLogLine(`✅ 已回到列表`);
  }

  /**
   * 真人扫列表行为：在点击目标卡片前，先随机 hover 1-2 张相邻卡片（像眼睛在扫视），
   * 有时还往下滚了一段又滚回来（像在找某个人）
   */
  async function browseListNaturally(cards, targetIndex) {
    // 随机选 1-2 张相邻卡片先 hover（只发鼠标事件，不滚动页面）
    const adjacentCount = Math.floor(Math.random() * 2) + 1;
    const pool = cards
      .map((c, i) => i)
      .filter(i => i !== targetIndex && i < targetIndex + 4 && i >= Math.max(0, targetIndex - 2));

    for (let k = 0; k < Math.min(adjacentCount, pool.length); k++) {
      const adjIdx = pool[Math.floor(Math.random() * pool.length)];
      const adjCard = cards[adjIdx];
      if (!adjCard) continue;
      adjCard.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
      adjCard.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
      await sleep(300 + Math.random() * 600);
      adjCard.dispatchEvent(new MouseEvent('mouseleave', { bubbles: true }));
      await sleep(100 + Math.random() * 200);
    }
  }

  // ─── 主流程：人脉列表处理循环（支持无限滚动加载 + 翻页）──────────────────────
  async function runProcessingLoop(keyword, startFromIndex = 0, initialProcessed = 0) {
    currentKeyword = keyword;
    let processedCount = initialProcessed;
    _processedCount = processedCount;
    let page = 1;
    let nextCardStart = startFromIndex; // 每次进入 while 循环时从这个位置开始处理

    while (running && !stopFlag) {
      // 岗位时间到期：立即退出，让上层 runProfileCycle 切换到下一岗位
      if (isProfileTimeUp()) {
        const profileName = (_runProfiles || []).find(p => p.id === _currentProfileId)?.name || '当前岗位';
        addLogLine(`⏰ 「${profileName}」已满1小时，切换下一岗位`);
        break;
      }

      await checkWorkHours();
      if (stopFlag) break;

      while (paused && !stopFlag) await sleep(500);
      if (stopFlag) break;

      let cards = getProfileCards();
      if (cards.length === 0) {
        addLogLine(`⏳ 等待候选人列表加载...`);
        await sleep(3000);
        cards = getProfileCards();
      }
      if (cards.length === 0) {
        // 二次重试：滚回顶部，再等 5s
        addLogLine(`⚠️ 未找到候选人，回滚顶部再等待...`);
        (document.scrollingElement || document.body).scrollTo({ top: 0, behavior: 'smooth' });
        await sleep(5000);
        cards = getProfileCards();
      }
      if (cards.length === 0) {
        // 三次重试：检查当前 URL 是否仍在人脉搜索页，若偏离则重导航
        const onContactPage = location.href.includes('type=contact');
        if (!onContactPage) {
          addLogLine(`⚠️ 页面已偏离搜索结果，重新导航到「${keyword}」...`);
          navigateTo(contactsUrl(keyword));
          return; // IIFE 会接管
        }
        // 仍在正确页面但找不到卡片 → 很可能脉脉改版，给出明确提示
        log('warn', `未找到候选人卡片，疑似脉脉页面改版，当前 URL: ${location.href}`);
        addLogLine(`❌ 未找到候选人卡片（可能脉脉改版）。请尝试：①刷新页面后重新开始 ②手动搜索「${keyword}」后再点开始`);
        break;
      }

      // ── while 顶部超时检查：即使没有新卡片可处理也能及时触发关键词切换 ──
      {
        const _topGroupLastMs = Number(sessionStorage.getItem('__maimai_group_last_match_ms') || '0');
        if (_topGroupLastMs > 0 && Date.now() - _topGroupLastMs > 6 * 60 * 1000) {
          addLogLine(`⏭️ 已超过6分钟无匹配人选，跳出当前关键词切换下一组`);
          break;
        }
      }

      // 本轮只处理 nextCardStart 之后的卡片（已处理过的不重复）
      if (nextCardStart < cards.length) {
        log('info', `第 ${page} 批：发现 ${cards.length} 位候选人，从第 ${nextCardStart + 1} 位开始`);
      }

      let _groupTimedOut = false;
      for (let i = nextCardStart; i < cards.length; i++) {
        while (paused && !stopFlag) await sleep(500);
        if (stopFlag) break;

        _pauseCardIndex = i;

        // 点击前先自然扫视一下列表（hover 相邻卡片）
        await browseListNaturally(cards, i);

        // 重新获取卡片（DOM 引用可能因滚动失效）
        const freshCards = getProfileCards();
        let skipCard = false;
        let _cardResult;
        if (freshCards.length === 0) {
          await sleep(2500);
          const retry = getProfileCards();
          if (retry.length === 0 || i >= retry.length) break;
          _cardResult = await processCard(retry[i], processedCount, i);
        } else {
          if (i >= freshCards.length) break;
          _cardResult = await processCard(freshCards[i], processedCount, i);
        }
        // undefined = 导航已触发（脚本即将销毁或正在强制刷新）；立即终止循环，不再处理下一张卡片
        if (_cardResult === undefined) return;
        skipCard = _cardResult === false;

        if (!skipCard) { processedCount++; _processedCount = processedCount; }
        try {
          const statusResp = await sendMsg({ type: 'GET_STATUS' });
          if (statusResp?.status) updateStats(statusResp.status);
        } catch (_) {}

        // ── 关键词组超时检查：连续 6 分钟无匹配则退出当前关键词，切换下一组 ──
        const _groupLastMs = Number(sessionStorage.getItem('__maimai_group_last_match_ms') || '0');
        if (_groupLastMs > 0 && Date.now() - _groupLastMs > 6 * 60 * 1000) {
          addLogLine(`⏭️ 已超过6分钟无匹配人选，跳出当前关键词切换下一组`);
          _groupTimedOut = true;
          break;
        }

        await sessionManager.checkBreak();
        // 处理完一个人后停顿（像在记录或喝口水）：真人平均 2-4 秒
        await sleep(humanDelay(2000, 40));
      }

      if (stopFlag || _groupTimedOut) break;

      // ── 尝试下拉加载更多（脉脉人脉搜索是无限滚动）────────────────────────────
      const countBeforeScroll = getProfileCards().length;
      nextCardStart = countBeforeScroll; // 下次 while 从新加载的卡片开始

      addLogLine(`⬇️ 下拉加载更多候选人...`);
      const scrollEl = document.scrollingElement || document.body;
      // 模拟人类分步滚动到底部
      for (let s = 1; s <= 3; s++) {
        scrollEl.scrollTo({ top: (scrollEl.scrollHeight * s) / 3, behavior: 'smooth' });
        await sleep(600 + Math.random() * 500);
      }
      await sleep(humanDelay(2500, 30)); // 等待新卡片渲染

      const cardsAfterScroll = getProfileCards();
      if (cardsAfterScroll.length > countBeforeScroll) {
        log('info', `无限滚动：加载了 ${cardsAfterScroll.length - countBeforeScroll} 位新候选人`);
        page++;
        continue; // 继续处理新加载的卡片
      }

      // ── 无限滚动无新内容，尝试翻页按钮 ────────────────────────────────────────
      const nextBtn = findByText('button, a', '下一页') ||
        document.querySelector('[class*="next-page"], [class*="pagination-next"], [aria-label="下一页"]');

      if (!nextBtn || nextBtn.disabled) {
        log('info', '已到达最后一页（无更多候选人）');
        break;
      }

      addLogLine(`📄 下一页...`);
      await hoverThenClick(nextBtn);
      nextCardStart = 0; // 新页从头处理
      page++;
      await sleep(humanDelay(3000, 30)); // 等页面渲染：默认 3s
    }

    log('info', `关键词「${keyword}」处理完成`);
  }

  // ─── 关键词组：从当前位置继续处理后续关键词及后续所有组 ───────────────────────
  // 由各救援 IIFE 在完成一个关键词后调用，确保多组连续操作正常运转
  // ─── 岗位时间是否到期（1小时）────────────────────────────────────────────────
  const PROFILE_TIMEOUT_MS = 60 * 60 * 1000; // 1 小时
  function isProfileTimeUp() {
    const startMs = Number(sessionStorage.getItem('__maimai_profile_start_ms') || '0');
    return startMs > 0 && Date.now() - startMs >= PROFILE_TIMEOUT_MS;
  }
  function profileTimeRemainStr() {
    const startMs = Number(sessionStorage.getItem('__maimai_profile_start_ms') || '0');
    if (!startMs) return '';
    const remain = Math.max(0, PROFILE_TIMEOUT_MS - (Date.now() - startMs));
    return `（剩余 ${Math.ceil(remain / 60000)} 分钟）`;
  }

  // ─── 岗位轮换主循环：所有岗位各跑1小时，循环不止 ────────────────────────────
  async function runProfileCycle(profiles, startPi) {
    let roundNum = Number(sessionStorage.getItem('__maimai_profile_round') || '1');

    // 在 profiles 数组中从 startPi 开始，跑完本轮剩余岗位，然后无限循环
    let firstPass = true;
    while (running && !stopFlag) {
      const fromPi = firstPass ? startPi : 0;
      firstPass = false;

      if (fromPi === 0 && roundNum > 1) {
        if (profiles.length > 1) {
          addLogLine(`🔁 第 ${roundNum} 轮开始，共 ${profiles.length} 个岗位，每岗位最多 1 小时`);
        } else {
          addLogLine(`🔁 第 ${roundNum} 轮：${profiles[0]?.name || profiles[0]?.jobTitle || '岗位'}`);
        }
      }

      for (let pi = fromPi; pi < profiles.length; pi++) {
        if (!running || stopFlag) return;
        const profile = profiles[pi];
        _currentProfileId = profile.id;
        const profileStartMs = Date.now();
        sessionStorage.setItem('__maimai_profile_start_ms', String(profileStartMs));
        sessionStorage.setItem('__maimai_profile_round', String(roundNum));

        const prevStatus = (await sendMsg({ type: 'GET_STATUS' }).catch(() => null))?.status;
        const prevProcessed = prevStatus?.processed || 0;

        if (profiles.length > 1) {
          addLogLine(`🏢 第${roundNum}轮 · 岗位 ${pi + 1}/${profiles.length}：${profile.name || profile.jobTitle || '未命名'}（最多1小时）`);
        } else if (roundNum === 1 && pi === 0) {
          // 单岗位首次不额外 log，让 processKeyword 自己 log
        }

        await runProfileKeywords(profile, profileStartMs);

        if (running && !stopFlag) {
          const curStatus = (await sendMsg({ type: 'GET_STATUS' }).catch(() => null))?.status;
          if (curStatus && profiles.length > 1) {
            const jobProcessed = (curStatus.processed || 0) - prevProcessed;
            addLogLine(`✅ 「${profile.name || profile.jobTitle}」本轮处理 ${jobProcessed} 人`);
          }
          if (pi < profiles.length - 1) {
            await sleep(humanDelay(config?.pageDelay || 3000, 30));
          }
        }
      }

      if (!running || stopFlag) return;
      roundNum++;
    }
  }

  async function continueGroupsAfter(resumeStats) {
    const GROUP_TIMEOUT_MS = 6 * 60 * 1000;

    // 恢复当前岗位 profile ID（页面刷新后 content.js 全局变量丢失，从 sessionStorage 读取）
    if (!_currentProfileId) {
      _currentProfileId = sessionStorage.getItem('__maimai_current_profile_id') || null;
    }
    if (!_runProfiles.length) {
      try { _runProfiles = JSON.parse(sessionStorage.getItem('__maimai_run_profiles') || '[]'); } catch (_) {}
    }
    // 通知 background 恢复到正确的岗位（确保 EVALUATE_CANDIDATE 使用正确的 JD）
    if (_currentProfileId) {
      await sendMsg({ type: 'SET_ACTIVE_JOB', profileId: _currentProfileId }).catch(() => {});
    }

    while (!stopFlag && running && !isProfileTimeUp()) {
      const allGroups = JSON.parse(sessionStorage.getItem('__maimai_kw_groups') || 'null');
      if (!allGroups) break; // 无组信息（单关键词旧流程），不继续

      const gi = Number(sessionStorage.getItem('__maimai_group_idx') || '0');
      const ki = Number(sessionStorage.getItem('__maimai_group_kw_idx') || '0');
      const lastMatchMs = Number(sessionStorage.getItem('__maimai_group_last_match_ms') || '0');

      // 确定下一个关键词位置
      let nextGi = gi, nextKi = ki + 1;
      const groupTimedOut = lastMatchMs > 0 && Date.now() - lastMatchMs > GROUP_TIMEOUT_MS;
      const groupKwDone = nextKi >= (allGroups[gi]?.length || 0);

      if (groupTimedOut || groupKwDone) {
        nextGi = gi + 1;
        nextKi = 0;
      }

      if (nextGi >= allGroups.length || !allGroups[nextGi]?.[nextKi]) break; // 全部完成

      const nextKw = allGroups[nextGi][nextKi];
      sessionStorage.setItem('__maimai_group_idx', String(nextGi));
      sessionStorage.setItem('__maimai_group_kw_idx', String(nextKi));

      if (nextGi !== gi) {
        sessionStorage.setItem('__maimai_group_last_match_ms', String(Date.now()));
        if (groupTimedOut) {
          addLogLine(`⏭️ 当前组连续超过6分钟无匹配，切换到第 ${nextGi + 1} 组：${allGroups[nextGi].join('、')}`);
        } else {
          addLogLine(`🔄 切换到第 ${nextGi + 1} 组：${allGroups[nextGi].join('、')}`);
        }
      } else {
        // 同组内检查超时
        const latestLastMs = Number(sessionStorage.getItem('__maimai_group_last_match_ms') || '0');
        if (latestLastMs > 0 && Date.now() - latestLastMs > GROUP_TIMEOUT_MS) {
          addLogLine(`⏭️ 同组超时，跳到下一组`);
          sessionStorage.setItem('__maimai_group_idx', String(gi + 1));
          sessionStorage.setItem('__maimai_group_kw_idx', '0');
          sessionStorage.setItem('__maimai_group_last_match_ms', String(Date.now()));
          continue;
        }
        addLogLine(`🔄 同组下一关键词：${nextKw}`);
      }

      currentKeyword = nextKw;
      await sendMsg({ type: 'RESTORE_STATS', keyword: nextKw, stats: resumeStats, profileId: _currentProfileId }).catch(() => {});
      await loadSeenCandidates();
      await doSearch(nextKw);
      // 若 doSearch 是 SPA，继续本循环处理；若全页刷新，此处不会再执行（救援 IIFE 接管）
      await runProcessingLoop(nextKw, 0, resumeStats.processed);

      // 更新 resumeStats 供下次迭代
      try {
        const sr = await sendMsg({ type: 'GET_STATUS' });
        if (sr?.status) resumeStats = {
          processed: sr.status.processed || 0, matched: sr.status.matched || 0,
          messaged:  sr.status.messaged  || 0, added:   sr.status.added   || 0,
          failed:    sr.status.failed    || 0,
        };
      } catch (_) {}
    }
    if (isProfileTimeUp()) {
      const profileName = (_runProfiles || []).find(p => p.id === _currentProfileId)?.name || '当前岗位';
      addLogLine(`⏰ 「${profileName}」已满1小时，切换下一岗位`);
    }
  }

  // ─── 企业招聘端（脉脉招聘搜索页 /ent/v41/recruit/talents）自动化 ─────────────

  function isRecruitSearchPage() {
    // 搜索结果页：路径为 /ent/vXX/recruit/talents 且无子路径段
    return /\/ent\/v\d+\/recruit\/talents(\?|$)/.test(location.href);
  }

  function isRecruitProfilePage() {
    // 候选人详情页：路径含子段，或携带 dstu=/uid= 参数
    return /\/ent\/v\d+\/recruit\/talents\//.test(location.href) ||
      (/\/ent\/v\d+\/recruit\/talents/.test(location.href) &&
       (location.search.includes('dstu=') || location.search.includes('uid=')));
  }

  /** 在企业招聘端选择职位下拉框中的目标岗位 */
  async function selectRecruitJobFromDropdown(jobTitle) {
    if (!jobTitle) return;
    addLogLine(`🔽 选择招聘职位：${jobTitle}`);

    const _vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };

    // 找触发器：class 以 positionNameText___ 开头的 div（显示"不限职位"的文字区域）
    // 点击其父容器（包含下拉箭头的整行）
    const textEl =
      document.querySelector('[class^="positionNameText___"]') ||
      Array.from(document.querySelectorAll('div')).find(el =>
        el.textContent.trim() === '不限职位' && _vis(el)
      );

    if (!textEl) {
      addLogLine('⚠️ 未找到职位选择框，跳过');
      return;
    }

    // 点击父容器（整个可点击行，包含箭头图标）
    const trigger = textEl.parentElement || textEl;
    trigger.click();
    await sleep(600 + Math.random() * 300);

    // 等待下拉弹出（最多 5s，每 400ms 检查一次）
    // 每个岗位条目：外层 itemStyle___ 或内层 innerContent___
    let items = [];
    for (let i = 0; i < 12; i++) {
      // 优先找外层容器，找不到就找内层
      items = Array.from(document.querySelectorAll('[class^="itemStyle___"]')).filter(_vis);
      if (!items.length)
        items = Array.from(document.querySelectorAll('[class^="innerContent___"]')).filter(_vis);
      if (items.length) break;
      await sleep(400);
    }

    if (!items.length) {
      addLogLine('⚠️ 职位下拉列表未出现，跳过职位选择');
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      return;
    }

    // 从条目内取岗位名：优先读 ellipsis___ 的 title 属性（含括号地点等完整信息）
    const norm = s => s.replace(/[\s（(）)\-—–]/g, '').toLowerCase();
    const target = norm(jobTitle);

    const getItemName = item => {
      const el = item.querySelector('[class^="ellipsis___"]');
      return el?.getAttribute('title') || el?.textContent?.trim() || item.textContent?.trim() || '';
    };

    const matched =
      items.find(item => norm(getItemName(item)) === target) ||
      items.find(item => norm(getItemName(item)).includes(target)) ||
      items.find(item => target.includes(norm(getItemName(item))) && norm(getItemName(item)).length > 1);

    if (matched) {
      const displayName = getItemName(matched);
      addLogLine(`✅ 选中职位：${displayName}`);
      // 点击内层 innerContent___（如外层是 itemStyle___，需要点内层触发选中）
      const clickTarget = matched.querySelector('[class^="innerContent___"]') || matched;
      clickTarget.click();
      await sleep(800 + Math.random() * 400);
    } else {
      addLogLine(`⚠️ 未找到匹配职位「${jobTitle}」，使用默认（不限职位）`);
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      await sleep(300);
    }
  }

  /**
   * 企业招聘端：确保页面在「搜索」标签页
   * 搜索按钮 class 含 tabContent___；已选中时还含 tabContentSelected___
   */
  async function clickRecruitSearchTab() {
    const _vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };

    // 找「搜索」标签按钮（文字精确匹配，class 含 tabContent___）
    const findSearchTab = () =>
      Array.from(document.querySelectorAll('div, span, button'))
        .find(el => el.textContent.trim() === '搜索' &&
              (el.className.includes('tabContent___') || el.className.includes('tab-content')) && _vis(el));

    // 等待按钮出现（最多 5s）
    let tabBtn = null;
    for (let i = 0; i < 10; i++) {
      tabBtn = findSearchTab();
      if (tabBtn) break;
      await sleep(500);
    }
    if (!tabBtn) { addLogLine('⚠️ 未找到「搜索」标签按钮，跳过'); return; }

    // 已在搜索页则跳过
    if (tabBtn.className.includes('tabContentSelected___') || tabBtn.className.includes('selected')) {
      addLogLine('📍 已在搜索标签页');
      return;
    }

    tabBtn.click();
    addLogLine('🔍 点击「搜索」标签页');
    await sleep(1200 + Math.random() * 400); // 等待页面切换和筛选栏渲染
  }

  /**
   * 企业招聘端：点击「城市地区」筛选，选中「期望」+ 上海，取消选中「现居」
   */
  async function selectRecruitCity() {
    addLogLine('🌆 设置城市筛选：期望 · 上海');
    const _vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };

    // 辅助：等待筛选按钮出现（已选中状态文字会变成"城市地区：XX"，用 startsWith 匹配，最多等 8s）
    const _waitFilterBtn = async (text) => {
      for (let i = 0; i < 16; i++) {
        const btn = Array.from(document.querySelectorAll('span'))
          .find(el => el.textContent.trim().startsWith(text) &&
                (el.className.includes('title___') || el.className.includes('search-item-text')) && _vis(el));
        if (btn) return btn;
        await sleep(500);
      }
      return null;
    };

    // 1. 等待并点击「城市地区」按钮
    const cityBtn = await _waitFilterBtn('城市地区');
    if (!cityBtn) { addLogLine('⚠️ 未找到城市地区按钮，跳过'); return; }

    cityBtn.click();
    await sleep(700 + Math.random() * 300);

    // 2. 等待城市选择面板出现（最多 4s）
    let panel = null;
    for (let i = 0; i < 8; i++) {
      // 面板内包含 ant-checkbox-input，且可见
      const inputs = Array.from(document.querySelectorAll('input.ant-checkbox-input')).filter(_vis);
      if (inputs.length >= 2) { panel = inputs[0].closest('[class*="panel"], [class*="popup"], [class*="dropdown"], [class*="filter"]') || document; break; }
      await sleep(500);
    }
    if (!panel) { addLogLine('⚠️ 城市选择面板未出现，跳过'); return; }

    // 辅助：安全点击 Ant Design checkbox（点 wrapper label，再补 change 事件）
    const _clickCheckbox = async (input) => {
      if (!input) return;
      const wrapper = input.closest('label') || input.closest('.ant-checkbox-wrapper') || input.parentElement;
      (wrapper || input).click();
      await sleep(200);
    };

    // 3. 「期望」checkbox（value="0"）→ 确保选中
    const qiwangInput = Array.from(document.querySelectorAll('input.ant-checkbox-input[value="0"]')).find(_vis);
    if (qiwangInput) {
      if (!qiwangInput.checked) {
        await _clickCheckbox(qiwangInput);
        addLogLine('✅ 期望 已勾选');
      } else {
        addLogLine('✅ 期望 已是勾选状态');
      }
    } else {
      addLogLine('⚠️ 未找到「期望」checkbox');
    }
    await sleep(300);

    // 4. 「现居」checkbox（value="1"）→ 确保取消选中
    const xianjuInput = Array.from(document.querySelectorAll('input.ant-checkbox-input[value="1"]')).find(_vis);
    if (xianjuInput) {
      if (xianjuInput.checked) {
        await _clickCheckbox(xianjuInput);
        addLogLine('✅ 现居 已取消勾选');
      } else {
        addLogLine('✅ 现居 已是未勾选状态');
      }
    } else {
      addLogLine('⚠️ 未找到「现居」checkbox');
    }
    await sleep(300);

    // 5. 选中「上海」城市选项
    // 找 li[class^="option___"] 或 li[class*="option___"] 文字含「上海」的项
    const shanghaiLi =
      Array.from(document.querySelectorAll('li[class*="option___"]'))
        .find(el => el.textContent.trim().startsWith('上海') && _vis(el)) ||
      Array.from(document.querySelectorAll('li, [class*="city"], [class*="City"]'))
        .find(el => el.textContent.trim() === '上海' && _vis(el));

    if (shanghaiLi) {
      // 若已选中（带 activeOption___）则无需重复点击
      if (shanghaiLi.className.includes('activeOption___')) {
        addLogLine('✅ 上海 已是选中状态');
      } else {
        shanghaiLi.click();
        await sleep(300);
        addLogLine('✅ 上海 已选中');
      }
    } else {
      addLogLine('⚠️ 未找到上海选项');
    }
    await sleep(400);

    // 6. 找「确定」按钮关闭面板（如有）
    const confirmBtn = Array.from(document.querySelectorAll('button, [role="button"]'))
      .find(el => (el.textContent.trim() === '确定' || el.textContent.trim() === '确认') && _vis(el));
    if (confirmBtn) {
      confirmBtn.click();
      addLogLine('✅ 点击确定');
      await sleep(600);
    } else {
      // 点击页面其他区域关闭面板
      document.body.click();
      await sleep(500);
    }
  }

  /**
   * 企业招聘端：点击「工作年限」筛选，按岗位配置的 minExpYears/maxExpYears 设置
   * minExpYears=0 表示不限，maxExpYears=0 表示不限
   */
  async function selectRecruitExpYears(minExp, maxExp) {
    // 两个都是 0（不限）则跳过
    if (!minExp && !maxExp) return;
    addLogLine(`📅 设置工作年限：${minExp || '不限'} ~ ${maxExp || '不限'} 年`);
    const _vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };

    // 辅助：等待筛选按钮出现（startsWith 兼容已选状态文字变化，最多 8s）
    const _waitFilterBtn = async (text) => {
      for (let i = 0; i < 16; i++) {
        const btn = Array.from(document.querySelectorAll('span'))
          .find(el => el.textContent.trim().startsWith(text) &&
                (el.className.includes('title___') || el.className.includes('search-item-text')) && _vis(el));
        if (btn) return btn;
        await sleep(500);
      }
      return null;
    };

    // 1. 点击「工作年限」按钮
    const expBtn = await _waitFilterBtn('工作年限');
    if (!expBtn) { addLogLine('⚠️ 未找到工作年限按钮，跳过'); return; }

    expBtn.click();
    await sleep(800 + Math.random() * 300);

    // 2. 等待面板内「自定义」区的「最低年限」标签出现（最多 5s）
    let minLabel = null;
    for (let i = 0; i < 10; i++) {
      minLabel = Array.from(document.querySelectorAll('span, div, label'))
        .find(el => el.textContent.trim() === '最低年限' && _vis(el));
      if (minLabel) break;
      await sleep(500);
    }
    if (!minLabel) { addLogLine('⚠️ 工作年限自定义区未出现，跳过'); return; }

    // 3. 找「自定义」区容器（含"最低年限"+"最高年限"文字的最小可见 div）
    const customContainer = (() => {
      const candidates = Array.from(document.querySelectorAll('div'))
        .filter(el => _vis(el) &&
          el.textContent.includes('最低年限') &&
          el.textContent.includes('最高年限'));
      // 取面积最小的（最深层容器）
      return candidates.sort((a, b) => {
        const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
        return (ra.width * ra.height) - (rb.width * rb.height);
      })[0] || null;
    })();

    // 在容器内（或全页兜底）找两个 MUI select 触发器，按 left 排序
    const findMuiSelects = () => {
      const scope = customContainer || document;
      // 找 selection-item span 或 selector 容器
      const triggers = Array.from(scope.querySelectorAll(
        'span.mui-select-selection-item, [class*="mui-select-selection-item"], ' +
        '[class*="mui-select-selector"], [class*="muiSelectSelector"]'
      )).filter(_vis);
      if (triggers.length) return triggers.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
      // 最终兜底：找 scope 内文字含"不限"的小按钮
      return Array.from(scope.querySelectorAll('div, span'))
        .filter(el => _vis(el) && el.textContent.trim() === '不限' &&
               el.getBoundingClientRect().width < 120)
        .sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
    };

    // 4. 辅助：依次尝试点击 trigger 及其父元素，直到下拉选项出现
    //    下拉选项文字格式：不限 / 在校/应届 / 1年 / 2年 / … / 20年
    const _findDropdownOpts = () => {
      // 方式1：MUI dropdown portal（class 含 mui-select-dropdown）
      let opts = Array.from(document.querySelectorAll(
        '.mui-select-dropdown li, [class*="mui-select-dropdown"] li, ' +
        '.mui-select-dropdown [class*="mui-select-item"], [class*="mui-select-dropdown"] [class*="option"]'
      )).filter(_vis);
      // 方式2：在浮动容器（absolute/fixed定位）内查找，避免匹配页面上其他筛选控件的"不限"
      if (!opts.length) {
        const floaters = Array.from(document.querySelectorAll(
          'ul, [role="listbox"], [class*="Dropdown"], [class*="dropdown"], ' +
          '[class*="popover"], [class*="popup"], [class*="options"], [class*="MuiMenu"], [class*="select"]'
        )).filter(el => {
          if (!_vis(el)) return false;
          const s = window.getComputedStyle(el);
          return s.position === 'fixed' || s.position === 'absolute';
        });
        for (const f of floaters) {
          const items = Array.from(f.querySelectorAll('li, div, span'))
            .filter(el => _vis(el) && /^(不限|在校\/应届|\d+年?)$/.test(el.textContent.trim()));
          if (items.length >= 2) { opts = items; break; }
        }
      }
      // 方式3：全局兜底，仅匹配 li/role=option，且宽度合理
      if (!opts.length) {
        opts = Array.from(document.querySelectorAll('li, [role="option"]'))
          .filter(el => _vis(el) &&
            /^(不限|在校\/应届|\d+年)$/.test(el.textContent.trim()) &&
            el.getBoundingClientRect().width < 200);
      }
      return opts;
    };

    const _pickYear = async (trigger, yearValue, label) => {
      if (!yearValue) return; // 0 = 不限，保持默认

      // 逐级尝试点击（span → 父级 → 祖父级），直到下拉出现
      const clickTargets = [
        trigger,
        trigger.parentElement,
        trigger.closest('[class*="mui-select-selector"]') || trigger.parentElement?.parentElement,
        trigger.closest('[class*="mui-select"]') || trigger.parentElement?.parentElement?.parentElement,
      ].filter((el, i, arr) => el && arr.indexOf(el) === i); // 去重

      let opts = [];
      for (const el of clickTargets) {
        el.click();
        await sleep(600);
        opts = _findDropdownOpts();
        if (opts.length) break;
      }

      if (!opts.length) { addLogLine(`⚠️ ${label}下拉选项未出现`); return; }

      addLogLine(`📋 ${label}可选：${opts.slice(0, 6).map(o => o.textContent.trim()).join('、')}…`);

      const yearText = `${yearValue}年`;
      const matched =
        opts.find(el => el.textContent.trim() === yearText) ||
        opts.find(el => el.textContent.trim() === String(yearValue));

      if (matched) {
        matched.click();
        addLogLine(`✅ ${label}已选：${matched.textContent.trim()}`);
      } else {
        // 兜底：找最接近的年份选项（取数值最近的，不选"不限"）
        const numericOpts = opts.filter(el => /^\d+年?$/.test(el.textContent.trim()))
          .map(el => ({ el, n: parseInt(el.textContent) }))
          .filter(({ n }) => !isNaN(n));
        const closest = numericOpts.sort((a, b) => Math.abs(a.n - yearValue) - Math.abs(b.n - yearValue))[0];
        if (closest && Math.abs(closest.n - yearValue) <= 2) {
          closest.el.click();
          addLogLine(`✅ ${label}已选最近值：${closest.el.textContent.trim()}（目标${yearText}）`);
        } else {
          addLogLine(`⚠️ ${label}：下拉中无「${yearText}」，跳过`);
          document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
        }
      }
      await sleep(400);
    };

    // 5. 设置最低年限
    let selects = findMuiSelects();
    if (!selects.length) { addLogLine('⚠️ 未找到年限下拉框'); return; }
    if (minExp) await _pickYear(selects[0], minExp, '最低年限');
    await sleep(300);

    // 6. 设置最高年限（重新查找，首个下拉关闭后 DOM 可能更新）
    selects = findMuiSelects();
    if (maxExp) {
      if (selects.length >= 2) await _pickYear(selects[1], maxExp, '最高年限');
      else if (selects.length === 1) await _pickYear(selects[0], maxExp, '最高年限（兜底）');
      else addLogLine('⚠️ 只找到一个年限下拉框，最高年限未设置');
    }

    // 7. 点击「确定」
    await sleep(400);
    const confirmBtn = Array.from(document.querySelectorAll(
      'button, [role="button"], div[class*="mui-btn-primary"], div[class*="mui-btn"]'
    )).find(el => el.textContent.trim() === '确定' && _vis(el));
    if (confirmBtn) { confirmBtn.click(); addLogLine('✅ 工作年限确定'); await sleep(800); }
    else { document.body.click(); await sleep(400); }
  }

  /** 在企业招聘搜索框输入关键词并触发搜索 */
  async function typeRecruitKeywordAndSearch(keyword) {
    if (!keyword) return;
    addLogLine(`🔍 输入搜索关键词：${keyword}`);

    // 找搜索框：class 含 ant-input ant-input-borderless
    const input = document.querySelector('input.ant-input.ant-input-borderless') ||
      Array.from(document.querySelectorAll('input[type="text"]'))
        .find(el => el.placeholder && el.placeholder.includes('搜索提示'));

    if (!input) {
      addLogLine('⚠️ 未找到搜索框，跳过关键词输入');
      return;
    }

    // 清空并输入
    input.focus();
    await sleep(200);
    // 清空已有内容
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
    if (nativeInputValueSetter) {
      nativeInputValueSetter.call(input, '');
      input.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      input.value = '';
    }
    await sleep(150);

    // 逐字输入
    for (const ch of keyword) {
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      const cur = input.value;
      if (nativeSetter) {
        nativeSetter.call(input, cur + ch);
      } else {
        input.value = cur + ch;
      }
      input.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(60 + Math.random() * 80);
    }
    await sleep(300);

    // 触发搜索：找「搜索人才」div 按钮（class 含 w-146 bg-[#3b7aff]）或按 Enter 兜底
    const searchBtn =
      Array.from(document.querySelectorAll('div'))
        .find(el => {
          const cls = el.className || '';
          return el.textContent.trim() === '搜索人才' &&
                 (cls.includes('w-146') || cls.includes('bg-[#3b7aff]') || cls.includes('cursor-pointer'));
        }) ||
      Array.from(document.querySelectorAll('button, [role="button"]'))
        .find(el => el.textContent.trim().includes('搜索人才'));
    if (searchBtn) {
      searchBtn.click();
      addLogLine('✅ 点击搜索人才按钮');
    } else {
      input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
      input.dispatchEvent(new KeyboardEvent('keyup',  { key: 'Enter', keyCode: 13, bubbles: true }));
      addLogLine('✅ Enter 触发搜索');
    }

    // 等待搜索结果刷新
    await sleep(2000);
  }

  /** 从企业招聘搜索页抓取候选人卡片列表 */
  function getRecruitCards() {
    const _vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };

    // 策略0：已知 class 前缀（card___HASH，最外层卡片容器）
    const byCardPrefix = Array.from(document.querySelectorAll('div[class^="card___"]')).filter(_vis);
    if (byCardPrefix.length) return byCardPrefix;

    // 策略1：其他已知 class 关键词
    for (const sel of [
      '[class*="TalentItem"]', '[class*="talent-item"]', '[class*="candidate-item"]',
      '[class*="PersonCard"]', '[class*="person-card"]', '[class*="resumeCard"]',
    ]) {
      const found = Array.from(document.querySelectorAll(sel)).filter(_vis);
      if (found.length) return found;
    }

    // 策略2：以「立即沟通 / 沟通中 / 沟通」按钮为锚点，向上找卡片容器
    const talkBtns = Array.from(document.querySelectorAll('button, [role="button"]'))
      .filter(el => { const t = el.textContent.trim(); return (t === '立即沟通' || t === '沟通' || t.includes('沟通中')) && _vis(el); });
    const containers = talkBtns.map(btn =>
      btn.closest('[class*="item"]') || btn.closest('[class*="card"]') ||
      btn.closest('li') || btn.closest('[class*="row"]')
    ).filter(el => el && _vis(el));
    const unique = [...new Set(containers)];
    if (unique.length) return unique;

    // 策略3：头像图定位（兜底，复用社交侧 findAvatarImgs）
    const avatars = findAvatarImgs(document.body);
    const byAvatar = avatars.map(img =>
      img.closest('li') || img.closest('[class*="item"]') || img.closest('[class*="card"]')
    ).filter(el => el && _vis(el));
    return [...new Set(byAvatar)];
  }

  /** 从卡片提取基本信息（姓名/职位/公司/学历/年限/薪资/地点/标签/profileUrl） */
  function extractRecruitCardInfo(card) {
    const _vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };

    // 找到候选人的个人主页链接（含 dstu/uid 参数或 recruit/talents/ 路径）
    const profileLink = Array.from(card.querySelectorAll('a[href]'))
      .find(a => /recruit\/talents\//.test(a.href) || /dstu=/.test(a.href) || /uid=/.test(a.href));
    const profileUrl = profileLink?.href || '';

    // 提取候选人 ID（用于已查阅去重）
    let candidateId = null;
    if (profileUrl) {
      const m = profileUrl.match(/dstu=(\d+)/) || profileUrl.match(/uid=(\d+)/) ||
                profileUrl.match(/talents\/(\d+)/) || profileUrl.match(/[?&]id=(\d+)/);
      if (m) candidateId = m[1];
    }

    // 全部可见叶子文本（用于字段猜测）
    const leaves = Array.from(card.querySelectorAll('*'))
      .filter(el => el.children.length === 0 && _vis(el))
      .map(el => el.textContent.trim())
      .filter(t => t.length >= 1 && t.length <= 60)
      .filter((v, i, a) => a.indexOf(v) === i);

    // 候选人 ID：优先从按钮 id 属性 talentDiscover_..._CANDIDATEID_INDEX 提取
    if (!candidateId) {
      const idEl = card.querySelector('[id*="talentDiscover_"]');
      if (idEl) {
        const m = idEl.id.match(/talentDiscover_\w+_pc_(\d+)_\d+/);
        if (m) candidateId = m[1];
      }
    }

    // 姓名：优先 class^="name___" span，再从链接/h3/h4 取
    let name = '';
    const nameEl = card.querySelector('[class*="name___"], [class*="userName___"], [class*="user-name"], [class*="candidateName"], [class*="talent-name"]');
    if (nameEl) {
      name = nameEl.textContent.trim().split('\n')[0].trim();
    }
    if (!name) name = profileLink?.textContent?.trim()?.split('\n')[0]?.trim() || '';
    if (!name || name.length > 15) {
      const fallbackEl = card.querySelector('h3, h4, strong');
      name = fallbackEl ? fallbackEl.textContent.trim().split('\n')[0].split(/[·•]/)[0].trim() : '';
    }
    name = name.replace(/近期活跃|在线|活跃|刚刚|\d+天前|\d+小时前|\d+分钟前/g, '').trim();

    // 职位和公司：优先从 singleCompanyContent___（第一块=最近工作经历）提取
    let title = '', company = '';
    const workBlocks = Array.from(card.querySelectorAll('[class*="singleCompanyContent___"]'));
    // 找最近一份工作（有 afterJoinWrap 或排第一），跳过学校（有 schoolIcon___）
    const jobBlock = workBlocks.find(b => !b.querySelector('[class*="schoolIcon___"]')) || workBlocks[0];
    if (jobBlock) {
      const compSchool = jobBlock.querySelector('[class*="companySchoolContent___"]');
      if (compSchool) {
        // 取直接子节点 textContent，避免 querySelectorAll 把父子节点都收进来导致重复
        const parts = Array.from(compSchool.children)
          .map(el => el.textContent.trim())
          .filter(t => t && t !== '·' && !/^\s*$/.test(t));
        if (parts[0]) company = parts[0];
        if (parts[1]) title = parts[1];
      }
    }
    if (!title) title = leaves.find(t => /工程师|经理|总监|专家|架构师|研发|算法|产品|设计|运营|分析师/.test(t) && t.length <= 25) || '';
    if (!company) company = leaves.find(t => t !== name && t !== title && t.length >= 2 && t.length <= 20 &&
      !/\d+年|硕士|本科|博士|大专|[kK万]月|期望|上海|北京|深圳|广州|杭州|成都/.test(t)) || '';

    const education = leaves.find(t => /硕士|本科|博士|高中|大专|MBA|EMBA/.test(t) && t.length <= 10) || '';
    const expYears  = leaves.find(t => /^\d+年/.test(t)) || '';
    const salary    = leaves.find(t => /\d+[kK万]/.test(t)) || '';
    const location  = leaves.find(t => /上海|北京|深圳|广州|杭州|成都|武汉|南京|苏州/.test(t) && t.length <= 8) || '';
    const tags = Array.from(card.querySelectorAll('[class*="tag"], [class*="label"], [class*="badge"], [class*="skill"]'))
      .filter(_vis).map(el => el.textContent.trim()).filter(Boolean).join(', ');

    return { name, title, company, education, experience: expYears, salary, location, tags, candidateId, profileUrl };
  }

  /**
   * 点击「立即沟通」按钮，等待消息弹窗，填写邀请消息并发送
   * 适用于搜索结果列表页和候选人详情页
   * @param {object} profileInfo
   * @param {string} msgText
   * @param {Element|null} [card]  传入卡片元素时在卡片内查找按钮（列表页多卡片场景）
   */
  async function clickImmediateCommunicateAndSend(profileInfo, msgText, card) {
    const _vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };

    // 查找范围：有 card 时在卡片内找，否则全页
    const scope = card || document;
    // 精准匹配：class 含 mui-btn-primary 或 w-136，文本为"立即沟通"
    const talkBtn =
      Array.from(scope.querySelectorAll('div[class*="mui-btn-primary"], div[class*="w-136"]'))
        .find(el => el.textContent.trim() === '立即沟通' && _vis(el)) ||
      Array.from(scope.querySelectorAll('button, [role="button"], div'))
        .find(el => el.textContent.trim() === '立即沟通' && _vis(el));
    if (!talkBtn) { addLogLine('❌ 未找到「立即沟通」按钮'); return false; }

    // 点击前快照已有输入框
    const snapInputs = new Set(Array.from(document.querySelectorAll(
      'textarea, [contenteditable="true"], [contenteditable]:not([contenteditable="false"]), input[type="text"]'
    )).filter(_vis));

    addLogLine('🖱️ 点击「立即沟通」...');
    await hoverThenClick(talkBtn);
    await sleep(800 + Math.random() * 500);

    // 等待弹窗/输入框出现（最多 8s）
    let msgInput = null;
    const deadline = Date.now() + 8000;
    while (Date.now() < deadline && !stopFlag) {
      const allInputs = Array.from(document.querySelectorAll(
        'textarea, [contenteditable="true"], [contenteditable]:not([contenteditable="false"])'
      ));
      // 点击后新出现的输入框（非搜索框）
      msgInput = allInputs.find(el => !snapInputs.has(el) && _vis(el) &&
        !(el.id + el.className).toLowerCase().includes('search'));
      if (!msgInput) {
        // 在弹窗容器内查找
        const dialog = Array.from(document.querySelectorAll(
          '[role="dialog"], [class*="modal"], [class*="Modal"], [class*="dialog"], [class*="Dialog"], [class*="popup"], [class*="Popup"]'
        )).find(_vis);
        if (dialog) msgInput = Array.from(dialog.querySelectorAll(
          'textarea, [contenteditable="true"], [contenteditable]:not([contenteditable="false"])'
        )).find(_vis);
      }
      if (msgInput) break;
      await sleep(300);
    }

    if (!msgInput) {
      // 检查是否已自动进入「沟通中」状态
      const inTalk = Array.from(document.querySelectorAll('button, [role="button"]'))
        .some(el => el.textContent.trim().includes('沟通中') && _vis(el));
      if (inTalk) { addLogLine('✅ 已进入沟通状态（系统自动发送）'); return true; }
      addLogLine('⚠️ 未找到消息输入框，跳过');
      return false;
    }

    // 填写邀请消息
    addLogLine(`⌨️ 输入邀请消息（${msgText.length}字）...`);
    await hoverThenClick(msgInput);
    msgInput.focus();
    await sleep(300 + Math.random() * 200);

    if (msgInput.getAttribute('contenteditable') !== null) {
      document.execCommand('selectAll', false, null);
      await sleep(80);
      document.execCommand('delete', false, null);
    } else {
      msgInput.select();
      nativeSetter(msgInput, '');
      msgInput.dispatchEvent(new InputEvent('input', { bubbles: true }));
    }
    await sleep(150 + Math.random() * 100);
    await humanType(msgInput, msgText);
    await sleep(300 + Math.random() * 200);

    // 找「发送」按钮：优先在弹窗容器内查找
    const dialogContainer = msgInput.closest(
      '[role="dialog"], [class*="modal"], [class*="Modal"], [class*="dialog"], [class*="Dialog"], [class*="popup"]'
    );
    const _findSendBtn = (root) => {
      const candidates = Array.from((root || document).querySelectorAll('button, [role="button"]')).filter(_vis);
      // 1. 首选「发送后留在此页」（class 前缀 mbutton_m_fixed_blue450_l1___，留在列表页不跳转）
      return candidates.find(el => el.textContent.trim() === '发送后留在此页' ||
               (el.className || '').includes('mbutton_m_fixed_blue450_l1___')) ||
        // 2. 次选「发送 / 确认 / 确定 / 发起沟通」
        candidates.find(el => { const t = el.textContent.trim(); return (t === '发送' || t === '确认' || t === '确定' || t.includes('发起')) && t.length <= 8; });
    };
    const sendBtn = (dialogContainer && _findSendBtn(dialogContainer)) || _findSendBtn(null);

    if (sendBtn && _vis(sendBtn)) {
      addLogLine(`📤 点击「${sendBtn.textContent.trim()}」发送...`);
      await hoverThenClick(sendBtn);
      await sleep(1500 + Math.random() * 500);
    } else {
      // Enter 键兜底
      msgInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true, cancelable: true }));
      await sleep(1000);
    }

    // 发送冷却（防限速）
    const cooldown = 5000 + Math.random() * 8000;
    addLogLine(`⏳ 等待 ${Math.round(cooldown / 1000)}s 冷却...`);
    await sleep(cooldown);

    // 点击 X 关闭弹窗，回到搜索结果页继续
    await _closeRecruitDialog();
    return true;
  }

  /**
   * 点击候选人名字，等待侧边详情面板弹出，返回面板文本（用于 AI 评估）。
   * 若 URL 发生变化（跳转到详情页），返回 null 交由 IIFE 接管。
   */
  async function _openRecruitCandidatePanel(card) {
    const _vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };

    // 找候选人名字元素（like-link-button span 或 name___ span）
    const nameSpan =
      card.querySelector('[class*="like-link-button"]') ||
      card.querySelector('[class^="name___"] [class^="ellipsis___"]') ||
      card.querySelector('[class^="name___"]');
    if (!nameSpan) return '';

    const urlBefore = location.href;
    // 快照：点击前已有的大型面板/抽屉（排除自身 overlay）
    const panelsBefore = new Set(Array.from(document.querySelectorAll(
      '[class*="drawer___"], [class*="Drawer"], [class*="sidePanel"], [class*="detail___"], ' +
      '[class*="slidePanel"], [class*="rightPanel"], [class*="candidateDetail"]'
    )).filter(_vis));

    nameSpan.click();
    await sleep(1200 + Math.random() * 600);

    // URL 跳转？让 IIFE 接管
    if (location.href !== urlBefore && isRecruitProfilePage()) return null;

    // 检测新出现的侧边面板（最多等 4s）
    let panel = null;
    for (let i = 0; i < 8; i++) {
      const allPanels = Array.from(document.querySelectorAll(
        '[class*="drawer___"], [class*="Drawer"], [class*="sidePanel"], [class*="detail___"], ' +
        '[class*="slidePanel"], [class*="rightPanel"], [class*="candidateDetail"], ' +
        '[class*="ProfileDrawer"], [class*="resumeDrawer"]'
      )).filter(el => _vis(el) && !panelsBefore.has(el));
      if (allPanels.length) { panel = allPanels[0]; break; }

      // 兜底：屏幕右侧新出现的宽面板（x起点>45%视口，宽>300px）
      const vw = window.innerWidth;
      const sidePanels = Array.from(document.querySelectorAll('div'))
        .filter(el => {
          if (panelsBefore.has(el) || !_vis(el)) return false;
          const r = el.getBoundingClientRect();
          return r.left > vw * 0.4 && r.width > 300 && r.height > 400 &&
                 el.innerText && el.innerText.length > 100;
        });
      if (sidePanels.length) { panel = sidePanels[0]; break; }
      await sleep(500);
    }

    const panelText = panel ? (panel.innerText || '').slice(0, 3000) : '';

    // 读完后关闭侧面板（点 ✖️ 回到搜索结果页）
    if (panel) {
      await sleep(300);
      const closeUse = Array.from(document.querySelectorAll('use')).find(el =>
        (el.getAttribute('xlink:href') || el.getAttribute('href') || '') === '#icon-close'
      );
      if (closeUse) {
        // 向上找可点击父元素（button / svg / div）
        const clickable =
          closeUse.closest('button') ||
          closeUse.closest('[role="button"]') ||
          closeUse.parentElement?.closest('button, [role="button"]') ||
          closeUse.parentElement?.parentElement;
        if (clickable) { clickable.click(); await sleep(700); }
      }
    }

    return panelText;
  }

  // ─── 招聘端页面视觉指示器 ────────────────────────────────────────────────────

  let _recruitHighlightCard = null; // 当前高亮的卡片元素

  // 状态 → 颜色映射
  const _MMR_STATE_COLORS = {
    '👁':  '#3b7aff',   // 查阅中 — 蓝
    '📖': '#0891b2',   // 读取资料 — 青
    '🔍': '#0284c7',   // 进入详情 — 天蓝
    '🧠': '#7c3aed',   // 评估中 — 紫
    '💬': '#d97706',   // 发送中 — 琥珀
    '✅': '#059669',   // 已完成 — 绿
  };
  function _mmrStateColor(label) {
    for (const [emoji, color] of Object.entries(_MMR_STATE_COLORS)) {
      if (label && label.startsWith(emoji)) return color;
    }
    return '#3b7aff';
  }

  /** 注入高亮样式（只注入一次） */
  function _ensureRecruitHighlightStyle() {
    if (document.getElementById('__mmr_recruit_style')) return;
    const s = document.createElement('style');
    s.id = '__mmr_recruit_style';
    s.textContent = `
      .__mmr_card_active {
        position: relative !important;
        box-shadow: inset 4px 0 0 var(--mmr-color, #3b7aff),
                    0 4px 18px rgba(59,122,255,0.13) !important;
        background: linear-gradient(90deg,
          rgba(59,122,255,0.06) 0%, transparent 38%) !important;
        transition: box-shadow 0.22s ease, background 0.22s ease !important;
        z-index: 1 !important;
      }
      .__mmr_card_badge {
        position: absolute;
        top: 14px;
        left: 0;
        z-index: 10000;
        color: #fff;
        font-size: 11.5px;
        font-weight: 600;
        line-height: 1;
        padding: 5px 11px 5px 9px;
        border-radius: 0 14px 14px 0;
        pointer-events: none;
        white-space: nowrap;
        letter-spacing: 0.2px;
        box-shadow: 2px 2px 10px rgba(0,0,0,0.18);
        background: var(--mmr-color, #3b7aff);
        display: flex;
        align-items: center;
        gap: 5px;
        transition: background 0.2s ease;
      }
      .__mmr_card_badge::before {
        content: '';
        display: inline-block;
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: rgba(255,255,255,0.75);
        animation: __mmr_pulse 1.4s ease-in-out infinite;
        flex-shrink: 0;
      }
      @keyframes __mmr_pulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50%       { opacity: 0.4; transform: scale(0.7); }
      }
    `;
    document.head.appendChild(s);
  }

  /** 高亮当前处理的卡片并显示状态徽章 */
  function _highlightRecruitCard(card, label) {
    _ensureRecruitHighlightStyle();
    _clearRecruitCardHighlight();
    if (!card) return;
    const color = _mmrStateColor(label);
    card.style.setProperty('--mmr-color', color);
    card.classList.add('__mmr_card_active');
    if (!card.style.position || card.style.position === 'static') card.style.position = 'relative';
    const badge = document.createElement('div');
    badge.className = '__mmr_card_badge';
    badge.id = '__mmr_card_badge';
    badge.appendChild(document.createTextNode(label || '👁 查阅中'));
    card.appendChild(badge);
    _recruitHighlightCard = card;
  }

  /** 更新徽章文字和颜色 */
  function _updateRecruitBadge(label) {
    const badge = document.getElementById('__mmr_card_badge');
    if (!badge) return;
    // 更新文字（保留 ::before 伪元素脉冲点，只改文字节点）
    badge.childNodes.forEach(n => { if (n.nodeType === Node.TEXT_NODE) n.remove(); });
    badge.appendChild(document.createTextNode(label));
    const color = _mmrStateColor(label);
    badge.style.background = color;
    if (_recruitHighlightCard) _recruitHighlightCard.style.setProperty('--mmr-color', color);
  }

  /** 清除高亮 */
  function _clearRecruitCardHighlight() {
    if (_recruitHighlightCard) {
      _recruitHighlightCard.classList.remove('__mmr_card_active');
      const badge = _recruitHighlightCard.querySelector('#__mmr_card_badge');
      if (badge) badge.remove();
      _recruitHighlightCard = null;
    }
  }

  /** 关闭招聘沟通弹窗（点击含 #icon-close 的关闭按钮） */
  async function _closeRecruitDialog() {
    const _vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };

    // 找含 #icon-close SVG 的可点击父元素
    const closeBtn = Array.from(document.querySelectorAll('use'))
      .filter(u => (u.getAttribute('xlink:href') || u.getAttribute('href') || '') === '#icon-close')
      .map(u => {
        // 向上找最近的可点击容器（button / [role="button"] / cursor-pointer div）
        let el = u.parentElement;
        while (el && el !== document.body) {
          if (el.tagName === 'BUTTON' || el.getAttribute('role') === 'button' ||
              (el.className || '').includes('close') || (el.className || '').includes('Close') ||
              getComputedStyle(el).cursor === 'pointer') return el;
          el = el.parentElement;
        }
        return u.closest('svg')?.parentElement || null;
      })
      .find(el => el && _vis(el));

    if (closeBtn) {
      addLogLine('✖️ 关闭沟通弹窗...');
      await hoverThenClick(closeBtn);
      await sleep(600 + Math.random() * 300);
    } else {
      // 按 Escape 兜底
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      await sleep(400);
    }
  }

  /**
   * AI 评估 + 联系候选人（招聘端核心逻辑，供详情页和列表页共用）
   * profileInfo 可能来自完整详情页或仅卡片信息
   */
  async function _recruitEvaluateAndAct(profileInfo, cardPos, card) {
    if (!profileInfo.pageText) {
      profileInfo.pageText = [
        `姓名：${profileInfo.name}`, `职位：${profileInfo.title}`, `公司：${profileInfo.company}`,
        `学历：${profileInfo.education}`, `工作年限：${profileInfo.experience}`,
        `期望薪资：${profileInfo.salary}`, `地点：${profileInfo.location}`, `职业标签：${profileInfo.tags}`,
      ].filter(s => !s.endsWith('：')).join('\n');
    }

    // 快速排除猎头/HR 职位（与技术/业务岗无关）
    const QUICK_REJECT_RE = /猎头|招聘|hrbp|\bhr\b|人力资源|人事(经理|专员|总监|主管)/i;
    if (QUICK_REJECT_RE.test(profileInfo.title)) {
      addLogLine(`⏭️ 快速跳过：${profileInfo.title}`);
      return true;
    }

    addLogLine(`🧠 AI 评估中...`);
    let evaluation;
    try {
      const resp = await sendMsg({ type: 'EVALUATE_CANDIDATE', candidateInfo: profileInfo });
      evaluation = resp.result;
    } catch (e) { addLogLine(`❌ AI 评估失败：${e.message}`); return true; }

    addLogLine(`🧠 ${profileInfo.name}：${evaluation.score}分 ${evaluation.suitable ? '✓匹配' : '✗不匹配'} — ${evaluation.reason}`);
    if (evaluation.highlights) addLogLine(`⭐ ${evaluation.highlights}${evaluation.stability ? ' · ' + evaluation.stability : ''}`);

    const scoreNum  = Number(evaluation.score) || 0;
    const threshold = config.scoreThreshold > 0 ? Number(config.scoreThreshold) : 70;
    if (stopFlag || scoreNum < threshold || evaluation.suitable === false) return true;

    // 每日联系上限
    const dailyLimit = config?.humanBehavior?.dailyContactLimit || 50;
    let totalContacted = 0;
    try { const sr = await sendMsg({ type: 'GET_STATUS' }); totalContacted = (sr?.status?.messaged || 0) + (sr?.status?.added || 0); } catch (_) {}
    if (totalContacted >= dailyLimit) {
      addLogLine(`🚫 已达每日联系上限（${dailyLimit} 人），停止任务`);
      stopFlag = true; running = false;
      await sendMsg({ type: 'STOP_TASK' });
      removeOverlay();
      return undefined;
    }

    if (evaluation.interviewReason) { profileInfo.interviewReason = evaluation.interviewReason; addLogLine(`💡 邀面理由：${evaluation.interviewReason}`); }

    // 生成邀请消息（复用 friendMessage 模板）
    const msgResp = await sendMsg({ type: 'GENERATE_MESSAGE', candidateInfo: profileInfo, isFriend: true }).catch(() => ({}));
    const msgText = msgResp.message || '';
    if (!msgText) { addLogLine('⚠️ 消息生成失败，跳过'); return true; }

    addLogLine(`🔔 开始联系 ${profileInfo.name}...`);
    _updateRecruitBadge('💬 发送中');
    updateOverlay(`💬 联系：${profileInfo.name}`);
    // 发消息前重置关键词组超时计时器（有匹配不应超时退出）
    sessionStorage.setItem('__maimai_group_last_match_ms', String(Date.now()));

    const sent = await clickImmediateCommunicateAndSend(profileInfo, msgText, card || null);
    if (sent) {
      await sendMsg({ type: 'ACTION_DONE', action: 'messaged' }).catch(() => {});
      await sendMsg({
        type: 'SAVE_MATCHED_CANDIDATE',
        candidate: {
          name: profileInfo.name, company: profileInfo.company, title: profileInfo.title,
          score: scoreNum, reason: evaluation.reason || '', highlights: evaluation.highlights || '',
          action: 'messaged', timestamp: Date.now(),
          profileUrl: profileInfo.profileUrl || location.href,
          jobName: getCurrentJobName(),
        },
      }).catch(() => {});
      addLogLine(`✅ 已向 ${profileInfo.name} 发送邀请消息`);
    } else {
      await sendMsg({ type: 'ACTION_DONE', action: 'failed' }).catch(() => {});
    }
    return true;
  }

  /**
   * 处理单张招聘搜索结果卡片：
   * 有 profileUrl → 导航到详情页（IIFE 救援接管）
   * 无 profileUrl → 直接用卡片信息评估（兜底）
   */
  async function processRecruitCard(card, processedCount, cardPos) {
    const _vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const cardInfo = extractRecruitCardInfo(card);
    const label = cardInfo.name || '候选人';

    // ── 滚动卡片到视口中央，模拟真人浏览 ──
    card.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await sleep(300 + Math.random() * 200);

    // ── 高亮当前卡片，页面上可见"查阅中"徽章 ──
    _highlightRecruitCard(card, `👁 查阅中`);
    updateOverlay(`👤 [${cardPos + 1}] ${label}`);
    addLogLine(`👤 [${cardPos + 1}] ${label} | ${cardInfo.title || ''} @ ${cardInfo.company || ''}`);

    // ── 模拟真人阅读停顿（800–2200ms） ──
    await sleep(800 + Math.random() * 1400);

    // 已查阅跳过
    if (cardInfo.candidateId && _seenCandidates.has(cardInfo.candidateId)) {
      addLogLine(`⏭️ 已查阅过，跳过`);
      _clearRecruitCardHighlight();
      return false;
    }
    // 已在沟通中跳过
    const alreadyTalking = Array.from(card.querySelectorAll('button, [role="button"]'))
      .some(el => el.textContent.trim().includes('沟通中') && _vis(el));
    if (alreadyTalking) {
      addLogLine(`⏭️ 已在沟通中，跳过`);
      if (cardInfo.candidateId) await markCandidateSeen(cardInfo.candidateId);
      _clearRecruitCardHighlight();
      return false;
    }

    if (cardInfo.candidateId) await markCandidateSeen(cardInfo.candidateId);

    // ── 点击候选人名字，获取侧边详情面板的完整资料 ──
    _updateRecruitBadge('📖 读取资料');
    updateOverlay(`📖 读取资料：${label}`);
    const panelText = await _openRecruitCandidatePanel(card);

    // panelText === null 表示页面已跳转，由 IIFE 接管
    if (panelText === null) {
      // 若有 profileUrl 则走正常跳转流程
      if (cardInfo.profileUrl) {
        const listUrl = location.href;
        sessionStorage.setItem('__maimai_recruit_pending_profile', JSON.stringify({
          listUrl, profileUrl: cardInfo.profileUrl,
          cardPos, nextCardIndex: cardPos + 1,
          candidateInfo: cardInfo, savedAt: Date.now(),
        }));
      }
      _clearRecruitCardHighlight();
      return undefined; // IIFE 接管
    }

    // 有 profileUrl 且未跳转（不常见，保留原路径作兜底）
    if (cardInfo.profileUrl && !panelText) {
      const listUrl = location.href;
      sessionStorage.setItem('__maimai_recruit_pending_profile', JSON.stringify({
        listUrl, profileUrl: cardInfo.profileUrl,
        cardPos, nextCardIndex: cardPos + 1,
        candidateInfo: cardInfo, savedAt: Date.now(),
      }));
      addLogLine(`📄 前往详情页：${label}...`);
      await sleep(400 + Math.random() * 400);
      _clearRecruitCardHighlight();
      navigateTo(cardInfo.profileUrl);
      return undefined;
    }

    // 把面板文字补充进 cardInfo，让 AI 看到完整简历
    if (panelText) {
      cardInfo.pageText = panelText;
      addLogLine(`📋 已获取 ${label} 详细资料（${panelText.length}字）`);
    } else {
      addLogLine(`⚠️ 未获取到详细资料，从卡片信息评估`);
    }

    // ── AI 评估 ──
    _updateRecruitBadge('🧠 评估中');
    updateOverlay(`🧠 AI评估：${label}`);

    const result = await _recruitEvaluateAndAct(cardInfo, cardPos, card);
    _clearRecruitCardHighlight();
    return result;
  }

  /** 招聘搜索结果页主循环 */
  async function runRecruitLoop(startFromIndex, baseProcessed) {
    let processedCount = baseProcessed || 0;
    let page = 1;
    let nextCardStart = startFromIndex || 0;

    while (!stopFlag && running) {
      while (paused && !stopFlag) await sleep(500);
      if (stopFlag) break;

      // 等待卡片加载
      await waitForEl(() => { const c = getRecruitCards(); return c.length > 0 ? c[0] : null; }, 8000);
      let cards = getRecruitCards();
      if (!cards.length) { addLogLine('⚠️ 未找到候选人卡片，任务结束'); break; }

      log('info', `第 ${page} 批：发现 ${cards.length} 位候选人，从第 ${nextCardStart + 1} 位开始`);

      for (let i = nextCardStart; i < cards.length; i++) {
        while (paused && !stopFlag) await sleep(500);
        if (stopFlag) break;
        _pauseCardIndex = i;

        const freshCards = getRecruitCards();
        if (i >= freshCards.length) break;

        const result = await processRecruitCard(freshCards[i], processedCount, i);
        if (result === undefined) return; // 导航已触发，退出循环
        if (result !== false) { processedCount++; _processedCount = processedCount; }

        try { const sr = await sendMsg({ type: 'GET_STATUS' }); if (sr?.status) updateStats(sr.status); } catch (_) {}
        updateOverlay(`浏览中（第 ${i + 1} / ${freshCards.length} 位）`);
        await sessionManager.checkBreak();
        // 真人翻看下一个前的自然停顿：1.5–4s
        await sleep(1500 + Math.random() * 2500);
      }

      if (stopFlag) break;

      // 下拉加载更多
      const countBefore = getRecruitCards().length;
      nextCardStart = countBefore;
      addLogLine('⬇️ 下拉加载更多...');
      const scrollEl = document.scrollingElement || document.body;
      for (let s = 1; s <= 3; s++) {
        scrollEl.scrollTo({ top: (scrollEl.scrollHeight * s) / 3, behavior: 'smooth' });
        await sleep(600 + Math.random() * 500);
      }
      await sleep(humanDelay(2500, 30));

      const cardsAfter = getRecruitCards();
      if (cardsAfter.length > countBefore) { page++; continue; }

      // 翻页按钮
      const nextPageBtn = findByText('button, a', '下一页') ||
        document.querySelector('[class*="next-page"], [class*="pagination-next"], [aria-label="下一页"]');
      if (nextPageBtn && nextPageBtn.getBoundingClientRect().width > 0) {
        addLogLine('📄 翻到下一页...');
        simulateClick(nextPageBtn);
        await sleep(humanDelay(3000, 20));
        nextCardStart = 0; page++;
        continue;
      }

      addLogLine('✅ 已处理所有候选人');
      break;
    }
  }

  // ─── 主流程：处理单个关键词 ──────────────────────────────────────────────────
  async function processKeyword(keyword) {
    // 切换到当前岗位（SET_ACTIVE_JOB 必须在 START_TASK 之前调用，使 background 保留 activeProfileId）
    if (_currentProfileId) {
      await sendMsg({ type: 'SET_ACTIVE_JOB', profileId: _currentProfileId }).catch(() => {});
    }
    await sendMsg({ type: 'START_TASK', profiles: _runProfiles });
    config = (await sendMsg({ type: 'GET_CONFIG' })).config;

    sessionManager.count = 0;
    dailyContacts = 0;

    createOverlay();
    updateOverlay(`搜索：${keyword}`);

    // doSearch 直接导航到人脉 URL：
    // - SPA 导航：脚本存活，doSearch 返回，继续 runProcessingLoop
    // - 全页刷新：脚本销毁，恢复 IIFE 在新页面接管
    await loadSeenCandidates();
    await doSearch(keyword);
    await runProcessingLoop(keyword);
  }

  // ─── 岗位内关键词循环（可复用的逻辑，对单个岗位的所有关键词执行搜索）──────────
  async function runProfileKeywords(profile, profileStartMs) {
    const GROUP_TIMEOUT_MS = 6 * 60 * 1000;
    // 记录本岗位时间槽开始时刻（跨页刷新后 isProfileTimeUp() 仍能正确判断）
    sessionStorage.setItem('__maimai_profile_start_ms', String(profileStartMs || Date.now()));

    // 解析关键词组：每行一个搜索词
    const keywordGroups = (profile.keywords || '').split(/\n/)
      .map(line => line.trim())
      .filter(line => line.length > 0)
      .map(line => [line]);

    if (!keywordGroups.length) {
      addLogLine(`⚠️ 岗位「${profile.name || profile.jobTitle}」无关键词，跳过`);
      return;
    }

    sessionStorage.setItem('__maimai_kw_groups', JSON.stringify(keywordGroups));
    sessionStorage.setItem('__maimai_group_idx', '0');
    sessionStorage.setItem('__maimai_group_kw_idx', '0');
    sessionStorage.setItem('__maimai_group_last_match_ms', String(Date.now()));
    sessionStorage.setItem('__maimai_current_profile_id', profile.id);

    for (let gi = 0; gi < keywordGroups.length; gi++) {
      if (!running || stopFlag) break;
      if (isProfileTimeUp()) {
        addLogLine(`⏰ 岗位已满1小时，停止当前关键词组${profileTimeRemainStr()}，切换下一岗位`);
        break;
      }
      const group = keywordGroups[gi];
      sessionStorage.setItem('__maimai_group_idx', String(gi));
      if (gi > 0) {
        sessionStorage.setItem('__maimai_group_last_match_ms', String(Date.now()));
        addLogLine(`🔄 第 ${gi + 1} 组关键词：${group.join('、')}`);
      }

      for (let ki = 0; ki < group.length; ki++) {
        if (!running || stopFlag || isProfileTimeUp()) break;
        sessionStorage.setItem('__maimai_group_kw_idx', String(ki));

        if (ki > 0) {
          const _lm = Number(sessionStorage.getItem('__maimai_group_last_match_ms') || '0');
          if (_lm > 0 && Date.now() - _lm > GROUP_TIMEOUT_MS) {
            addLogLine(`⏭️ 当前组已超过6分钟无匹配，提前切换下一组`);
            break;
          }
        }

        await processKeyword(group[ki]).catch(err => {
          log('error', `关键词 "${group[ki]}" 处理出错: ${err.message}`);
          chrome.storage.local.remove('__maimaiPendingTask').catch(() => {});
        });

        if (!running || stopFlag) break;

        const _lm = Number(sessionStorage.getItem('__maimai_group_last_match_ms') || '0');
        if (ki < group.length - 1 && _lm > 0 && Date.now() - _lm > GROUP_TIMEOUT_MS) {
          addLogLine(`⏭️ 当前组已超过6分钟无匹配，切换下一组`);
          break;
        }

        if (ki < group.length - 1) {
          await sleep(humanDelay(config?.pageDelay || 3000, config?.humanBehavior?.jitterPercent));
        }
      }

      if (running && !stopFlag && gi < keywordGroups.length - 1) {
        await sleep(humanDelay(config?.pageDelay || 3000, config?.humanBehavior?.jitterPercent));
      }
    }
  }

  // ─── 主入口：接收 popup/options 发来的启动指令 ───────────────────────────────
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'RUN_TASK') {
      if (running) { sendResponse({ success: false, error: '任务已在运行中' }); return; }

      running = true;
      stopFlag = false;
      sessionStorage.removeItem('__maimai_task_stopped');

      const profiles = msg.profiles || [];
      if (!profiles.length) {
        sendResponse({ success: false, error: '请至少配置一个岗位' });
        return;
      }
      _runProfiles = profiles;
      // 把全部岗位存入 sessionStorage 供全页刷新后的救援 IIFE 读取
      sessionStorage.setItem('__maimai_run_profiles', JSON.stringify(profiles));

      (async () => {
        // 初始化轮次计数，runProfileCycle 从第1轮第0个岗位开始无限循环
        sessionStorage.setItem('__maimai_profile_round', '1');
        if (profiles.length > 1) {
          addLogLine(`🔁 多岗位轮转模式：${profiles.length} 个岗位，每个最多1小时后切换，循环不止`);
        }
        await runProfileCycle(profiles, 0);

        running = false;
        sessionStorage.removeItem('__maimai_task_paused');
        sessionStorage.removeItem('__maimai_pending_profile');
        sessionStorage.removeItem('__maimai_pending_task_resume');
        sessionStorage.removeItem('__maimai_kw_groups');
        sessionStorage.removeItem('__maimai_group_idx');
        sessionStorage.removeItem('__maimai_group_kw_idx');
        sessionStorage.removeItem('__maimai_group_last_match_ms');
        sessionStorage.removeItem('__maimai_current_profile_id');
        sessionStorage.removeItem('__maimai_run_profiles');
        sessionStorage.removeItem('__maimai_profile_start_ms');
        sessionStorage.removeItem('__maimai_profile_round');
        await sendMsg({ type: 'STOP_TASK' });
        removeOverlay();
        addLogLine('⏹ 任务已停止');
      })();

      sendResponse({ success: true });
      return true;
    }

    // ── 企业招聘端任务启动 ───────────────────────────────────────────────────────
    if (msg.type === 'RUN_RECRUIT_TASK') {
      if (running) { sendResponse({ success: false, error: '任务已在运行中' }); return; }

      running = true;
      stopFlag = false;
      sessionStorage.removeItem('__maimai_task_stopped');

      const profiles = msg.profiles || [];
      _runProfiles = profiles;
      sessionStorage.setItem('__maimai_run_profiles', JSON.stringify(profiles));

      const firstProfile = profiles[0];
      if (!firstProfile) { running = false; sendResponse({ success: false, error: '无有效岗位' }); return; }

      _currentProfileId = firstProfile.id;
      sessionStorage.setItem('__maimai_current_profile_id', firstProfile.id);
      sessionStorage.setItem('__maimai_recruiter_active', '1');

      (async () => {
        config = (await sendMsg({ type: 'GET_CONFIG' })).config;
        sessionManager.count = 0;
        await sendMsg({ type: 'START_TASK', profiles: _runProfiles });
        await sendMsg({ type: 'SET_ACTIVE_JOB', profileId: firstProfile.id }).catch(() => {});
        createOverlay();
        await loadSeenCandidates();
        addLogLine(`🚀 招聘搜索页模式：「${firstProfile.name || firstProfile.jobTitle || ''}」`);
        // 选择职位下拉
        const _jt = firstProfile.jobTitle || firstProfile.name || '';
        await selectRecruitJobFromDropdown(_jt);
        // 切换到「搜索」标签页（筛选栏只在搜索页可用）
        await clickRecruitSearchTab();
        // 设置城市筛选：期望·上海，取消现居
        await selectRecruitCity();
        // 设置工作年限筛选（按岗位配置）
        const _fc = firstProfile.filterCriteria || {};
        await selectRecruitExpYears(Number(_fc.minExpYears) || 0, Number(_fc.maxExpYears) || 0);
        await runRecruitLoop(0, 0);
        running = false;
        sessionStorage.removeItem('__maimai_recruiter_active');
        sessionStorage.removeItem('__maimai_recruit_pending_profile');
        sessionStorage.removeItem('__maimai_recruit_task_resume');
        await sendMsg({ type: 'STOP_TASK' });
        removeOverlay();
        addLogLine('⏹ 招聘搜索任务已停止');
      })();

      sendResponse({ success: true });
      return true;
    }

    if (msg.type === 'SET_PAUSED') {
      paused = !!msg.paused;
      if (paused) {
        sessionStorage.setItem('__maimai_task_paused', '1');
        // 保存断点：关键词 + 当前列表页 URL + 卡片位置，页面刷新后可从此处续跑
        if (running && currentKeyword && location.href.includes('type=contact')) {
          sessionStorage.setItem('__maimai_pause_checkpoint', JSON.stringify({
            keyword: currentKeyword,
            listUrl: location.href,
            cardIndex: _pauseCardIndex,
            processed: _processedCount,
            savedAt: Date.now()
          }));
        }
      } else {
        sessionStorage.removeItem('__maimai_task_paused');
        sessionStorage.removeItem('__maimai_pause_checkpoint');
      }
      sendResponse({ success: true });
      return;
    }

    if (msg.type === 'STOP_TASK_CONTENT') {
      stopFlag = true;
      running = false;
      // 写入 localStorage，确保页面跳转中的新实例也能检测到停止信号
      sessionStorage.setItem('__maimai_task_stopped', '1');
      sessionStorage.removeItem('__maimai_pending_profile');
      sessionStorage.removeItem('__maimai_pending_task_resume');
      sessionStorage.removeItem('__maimai_pending_sendmsg');
      sessionStorage.removeItem('__maimai_task_paused');
      sessionStorage.removeItem('__maimai_pause_checkpoint');
      sessionStorage.removeItem('__maimai_recruit_pending_profile');
      sessionStorage.removeItem('__maimai_recruit_task_resume');
      removeOverlay();
      sendResponse({ success: true });
      return;
    }

    if (msg.type === 'PING') {
      sendResponse({ success: true, loaded: true });
      return;
    }

    if (msg.type === 'STATUS_UPDATE' && msg.status) {
      updateStats(msg.status);
      return;
    }

    // 胶囊 ↔ 操作台 互斥切换
    if (msg.type === 'HIDE_OVERLAY') {
      const panel = overlay?.querySelector('.mmr-panel');
      if (panel) panel.style.display = 'none';
      return;
    }
    if (msg.type === 'SHOW_OVERLAY') {
      const panel = overlay?.querySelector('.mmr-panel');
      if (panel) panel.style.display = '';
      return;
    }

    // background.js 截获新标签后把目标 URL 发过来，我们在当前标签做 SPA 导航
    if (msg.type === 'NAVIGATE_TO' && msg.url) {
      try {
        const u = new URL(msg.url);
        if (u.hostname.includes('maimai.cn')) {
          history.pushState({}, '', u.pathname + u.search + u.hash);
          window.dispatchEvent(new PopStateEvent('popstate', { state: history.state }));
        }
      } catch (_) {}
      return;
    }
  });

  console.log('[脉脉招聘助手] Content script 已加载');

  // ─── 跨页导航任务恢复 ────────────────────────────────────────────────────────
  (async () => {
    await sleep(2000);
    if (running) return;

    // ★ 安全门：只有招聘助手明确处于运行状态时才自动恢复
    // __maimai_recruiter_active 由 createOverlay() 写入、removeOverlay() 清除；
    // 普通打开脉脉网页时此 key 不存在，IIFE 直接退出，不做任何自动化操作
    if (!sessionStorage.getItem('__maimai_recruiter_active')) {
      console.log('[脉脉助手] 非自动化会话，跳过任务恢复');
      return;
    }

    // 用户点了停止：清除所有挂起状态，不恢复
    if (sessionStorage.getItem('__maimai_task_stopped')) {
      sessionStorage.removeItem('__maimai_task_stopped');
      sessionStorage.removeItem('__maimai_pending_profile');
      sessionStorage.removeItem('__maimai_pending_task_resume');
      sessionStorage.removeItem('__maimai_pending_sendmsg');
      sessionStorage.removeItem('__maimai_pending_addfriend');
      sessionStorage.removeItem('__maimai_task_paused');
      console.log('[脉脉助手] 检测到停止信号，不恢复任务');
      return;
    }

    console.log('[脉脉助手] 恢复IIFE运行, URL:', location.href,
      '| pending_profile:', sessionStorage.getItem('__maimai_pending_profile')?.slice(0, 80),
      '| pending_addfriend:', sessionStorage.getItem('__maimai_pending_addfriend')?.slice(0, 60),
      '| task_resume:', sessionStorage.getItem('__maimai_pending_task_resume')?.slice(0, 80));

    // ── 聊天页救援：发消息点击后全页跳转到 /chat 的情况 ──────────────────────
    const _isChatPage = location.href.includes('/chat') || location.href.includes('/im/') || location.href.includes('/message/');
    const readPendingSendMsg = () => { try { return JSON.parse(sessionStorage.getItem('__maimai_pending_sendmsg') || 'null'); } catch(_){ return null; } };
    let _pendingSendMsg = _isChatPage ? readPendingSendMsg() : null;
    // 额外等待 1s：主流程找到输入框后会立即清除此 key；若 1s 后 key 还在，说明主流程确实中断了
    if (_pendingSendMsg) { await sleep(1000); _pendingSendMsg = readPendingSendMsg(); }
    if (_pendingSendMsg && _pendingSendMsg.savedAt && Date.now() - _pendingSendMsg.savedAt < 180000 && _isChatPage) {
      sessionStorage.removeItem('__maimai_pending_sendmsg');
      running = true; stopFlag = false;
      config = (await sendMsg({ type: 'GET_CONFIG' })).config;
      createOverlay();
      addLogLine(`💬 聊天页救援：向 ${_pendingSendMsg.candidateName || '候选人'} 发送消息...`);

      // 等待聊天页渲染（/chat?target=USER_ID 需要时间打开对应会话和渲染输入框）
      await sleep(3500);
      let chatInput = null;

      // 先直接找（发消息后通常直接打开对应会话，输入框已可见）
      chatInput = findChatInput();
      if (chatInput && !isValidMsgInput(chatInput)) chatInput = null;

      // 未找到：主动在左侧对话列表按候选人姓名点击对应条目
      if (!chatInput) {
        const _targetName = (_pendingSendMsg.candidateName || '').split('(')[0].trim();
        if (_targetName) {
          const _namedConv = Array.from(document.querySelectorAll('*')).find(el => {
            const r = el.getBoundingClientRect();
            return r.width > 0 && r.height > 10 && r.height < 100
              && r.left < window.innerWidth * 0.45 && r.top > 80
              && el.textContent.trim().includes(_targetName)
              && !el.querySelector('input, textarea, [contenteditable]');
          });
          if (_namedConv) {
            addLogLine(`🖱️ 按名字点击「${_targetName}」对话条目`);
            _namedConv.click();
            await sleep(1500);
            chatInput = findChatInput();
            if (chatInput && !isValidMsgInput(chatInput)) chatInput = null;
          }
        }
      }

      // 未找到：坐标法点击左侧对话列表（跳过 y<180 的顶部导航，只跳过资料页链接）
      if (!chatInput) {
        const _cx = Math.round(window.innerWidth * 0.2);
        for (let _dy = 180; _dy <= 450; _dy += 50) {
          const _el = document.elementFromPoint(_cx, _dy);
          if (!_el || _el === document.body) continue;
          const _txt = _el.textContent.trim();
          if (_txt.length === 0 || _txt.length > 40) continue;
          const _anc = _el.closest('a[href]');
          if (_anc && /\/profile|\/detail/.test(_anc.getAttribute('href') || '')) continue;
          addLogLine(`🖱️ 坐标点击对话(${_cx},${_dy}) [${_el.tagName}]`);
          _el.click();
          await sleep(1500);
          chatInput = findChatInput();
          if (chatInput && !isValidMsgInput(chatInput)) chatInput = null;
          if (chatInput) break;
        }
      }

      // 兜底：点击右下角激活区
      if (!chatInput) {
        const _rx = Math.round(window.innerWidth * 0.65);
        const _ry = Math.round(window.innerHeight * 0.88);
        const _rel = document.elementFromPoint(_rx, _ry);
        if (_rel && _rel !== document.body) { _rel.click(); await sleep(800); }
        chatInput = findChatInput();
        if (chatInput && !isValidMsgInput(chatInput)) chatInput = null;
      }

      // 最终轮询等待（最多再等 8s）
      const chatDeadline = Date.now() + 8000;
      while (!chatInput && Date.now() < chatDeadline && !stopFlag) {
        chatInput = findChatInput();
        if (chatInput && !isValidMsgInput(chatInput)) chatInput = null;
        if (!chatInput) await sleep(600);
      }
      if (chatInput && !stopFlag) {
        chatInput.click(); chatInput.focus();
        await sleep(300);
        await humanType(chatInput, _pendingSendMsg.msgText);
        await sleep(1200);
        const sendBtn = Array.from(document.querySelectorAll('a[data-radium="true"], button[data-radium="true"]'))
          .find(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && el.textContent.trim() === '发送'; }) ||
          findVisibleBtn('发送', '送出', 'Send');
        if (!sendBtn) {
          chatInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
          chatInput.dispatchEvent(new KeyboardEvent('keyup',  { key: 'Enter', keyCode: 13, bubbles: true }));
        } else {
          await hoverThenClick(sendBtn);
        }
        // 发送后冷却（防止脉脉频率限制）
        const _chatCoolMs = 6000 + Math.random() * 4000;
        addLogLine(`⏱️ 冷却中 ${(_chatCoolMs / 1000).toFixed(0)}s，防频率限制...`);
        const _chatCoolEnd = Date.now() + _chatCoolMs;
        while (Date.now() < _chatCoolEnd) await sleep(1000);
        await sendMsg({ type: 'ACTION_DONE', action: 'messaged' }).catch(() => {});
        // 保存人选到「人选」tab（已是好友通过救援路径发消息的也要汇总）
        await sendMsg({
          type: 'SAVE_MATCHED_CANDIDATE',
          candidate: {
            name: _pendingSendMsg.candidateName || '',
            company: _pendingSendMsg.candidateCompany || '',
            title: _pendingSendMsg.candidateTitle || '',
            score: _pendingSendMsg.candidateScore || 0,
            reason: _pendingSendMsg.candidateReason || '',
            highlights: _pendingSendMsg.candidateHighlights || '',
            action: 'messaged',
            timestamp: Date.now(),
            profileUrl: _pendingSendMsg.profileUrl || '',
            jobName: _pendingSendMsg.jobName || getCurrentJobName(),
          },
        }).catch(() => {});
        addLogLine(`✅ 聊天页已发消息给 ${_pendingSendMsg.candidateName || '候选人'}`);
      } else {
        const _dbgEls = Array.from(document.querySelectorAll(
          'textarea, [contenteditable="true"], input[type="text"], [class*="input"], [class*="editor"]'
        )).filter(el => el.offsetParent !== null)
          .map(el => `${el.tagName}[${el.className.slice(0, 20) || el.type || ''}]`);
        addLogLine(`⚠️ 聊天页救援未找到输入框，跳过`);
        addLogLine(`   URL: ${location.href.slice(0, 80)}`);
        addLogLine(`   可见元素: ${_dbgEls.slice(0, 8).join(' | ') || '无'}`);
      }

      // 返回列表继续任务
      const chatResumeStats = await sendMsg({ type: 'GET_STATUS' }).then(r => r?.status || {}).catch(() => ({}));
      sessionStorage.setItem('__maimai_pending_task_resume', JSON.stringify({
        keyword: _pendingSendMsg.keyword,
        step: 'contacts',
        startFromIndex: _pendingSendMsg.nextCardIndex || 0,
        stats: { processed: chatResumeStats.processed || 0, matched: chatResumeStats.matched || 0,
                 messaged: chatResumeStats.messaged || 0, added: chatResumeStats.added || 0 },
        paused: false,
        savedAt: Date.now(),
      }));
      navigateTo(_pendingSendMsg.listUrl);
      return;
    }

    // ── 加好友页面救援：点击「加好友」后全页跳转到申请表单页 ──────────────────
    // 场景：addAsFriend 在 profile 页点击按钮 → 全页导航到加好友表单页（content.js 销毁）
    // → 新 content.js IIFE 在此接管：填写附言、点发送、返回列表
    const _pendingAddFriend = (() => {
      try { return JSON.parse(sessionStorage.getItem('__maimai_pending_addfriend') || 'null'); } catch(_){ return null; }
    })();
    const _isAddFriendFormPage = _pendingAddFriend &&
      _pendingAddFriend.savedAt && (Date.now() - _pendingAddFriend.savedAt) < 30000 &&
      !_isChatPage &&
      !location.href.includes('type=contact');

    if (_isAddFriendFormPage) {
      sessionStorage.removeItem('__maimai_pending_addfriend');
      sessionStorage.removeItem('__maimai_pending_profile'); // 防止跳回资料页后 IIFE 重复处理同一候选人
      running = true; stopFlag = false;
      config = (await sendMsg({ type: 'GET_CONFIG' })).config;
      createOverlay();
      addLogLine(`📬 加好友表单页：向 ${_pendingAddFriend.candidateName || '候选人'} 发送好友申请...`);

      await sleep(2000); // 等页面渲染完成

      // 可见性辅助（position:fixed 元素也能检测到）
      const _afIsVis = el => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && r.top < window.innerHeight && r.bottom > 0;
      };

      // 找附言输入框（验证信息 textarea / contenteditable / input）
      // 用宽泛 selector，涵盖 contenteditable 无显式 ="true" 的情况
      const _afDeadline = Date.now() + 10000;
      let _afInput = null;
      while (!_afInput && Date.now() < _afDeadline) {
        // 优先：已知 placeholder（最稳定）或已知 class（sc-hGoxap / dVMspX）
        _afInput =
          document.querySelector('textarea[placeholder*="加好友的原因"]') ||
          Array.from(document.querySelectorAll('textarea.sc-hGoxap, textarea.dVMspX')).find(_afIsVis) ||
          Array.from(document.querySelectorAll(
            'textarea:not([readonly]), [contenteditable="true"], [contenteditable]:not([contenteditable="false"]), input[type="text"]:not([readonly]), input:not([type]):not([readonly])'
          )).find(el => _afIsVis(el) && !(el.id + el.className).toLowerCase().includes('search'));
        if (!_afInput) await sleep(400);
      }

      if (_afInput) {
        // 兜底替换：支持半角 {var}、方括号 [var]、全角 ｛var｝ 三种占位符
        const _afRe = (key) => new RegExp('[\\[{｛【]' + key + '[\\]}｝】]', 'g');
        let _afMsgText = _pendingAddFriend.msgText
          .replace(_afRe('name'), _pendingAddFriend.candidateName || '')
          .replace(_afRe('jobTitle'), config.jobTitle || '')
          .slice(0, 50);
        addLogLine(`⌨️ 附言内容（${_afMsgText.length}字）：「${_afMsgText.slice(0, 25)}${_afMsgText.length > 25 ? '...' : ''}」`);

        // hover → 点击 → 聚焦（和主流程保持一致）
        await hoverThenClick(_afInput);
        _afInput.focus();
        await sleep(250 + Math.random() * 200);

        // 清空已有内容
        if (_afInput.contentEditable === 'true') {
          document.execCommand('selectAll', false, null);
          await sleep(80);
          document.execCommand('delete', false, null);
        } else {
          _afInput.select();
          nativeSetter(_afInput, '');
          _afInput.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' }));
        }
        await sleep(150 + Math.random() * 100);

        // 逐字人工输入（React 可正确感知每次按键）
        await humanType(_afInput, _afMsgText);

        // 验证写入是否成功
        const _afTypedVal = _afInput.contentEditable === 'true'
          ? _afInput.textContent?.trim() : _afInput.value?.trim();
        if (!_afTypedVal || _afTypedVal.length < Math.floor(_afMsgText.length * 0.8)) {
          addLogLine(`⚠️ 附言写入不完整（${_afTypedVal?.length || 0}字），补全重写...`);
          if (_afInput.contentEditable === 'true') {
            document.execCommand('selectAll', false, null);
            document.execCommand('delete', false, null);
            document.execCommand('insertText', false, _afMsgText);
          } else {
            nativeSetter(_afInput, _afMsgText);
            _afInput.dispatchEvent(new InputEvent('input', { bubbles: true, data: _afMsgText, inputType: 'insertText' }));
            _afInput.dispatchEvent(new Event('change', { bubbles: true }));
          }
          await sleep(300);
        }
        await sleep(300);
      } else {
        addLogLine(`❌ 未找到附言输入框，取消发送好友申请（避免空附言）`);
        // 仍需写入 resume，确保列表页 IIFE 能继续下一位候选人（不中断任务）
        const _afErrStats = await sendMsg({ type: 'GET_STATUS' }).then(r => r?.status || {}).catch(() => ({}));
        sessionStorage.setItem('__maimai_pending_task_resume', JSON.stringify({
          keyword: _pendingAddFriend.keyword,
          step: 'contacts',
          startFromIndex: _pendingAddFriend.nextCardIndex || 0,
          stats: {
            processed: _afErrStats.processed || 0, matched: _afErrStats.matched || 0,
            messaged: _afErrStats.messaged || 0, added: _afErrStats.added || 0,
          },
          paused: false,
          savedAt: Date.now(),
        }));
        navigateTo(_pendingAddFriend.listUrl);
        return;
      }

      // 找「发送」按钮：优先已知 class（mui-mobile-web-button-black），兜底文字匹配
      let _afConfirmBtn =
        Array.from(document.querySelectorAll('button.mui-mobile-web-button-black')).find(_afIsVis) ||
        Array.from(document.querySelectorAll('button.mui-mobile-web-button-clickable')).find(el => _afIsVis(el) && el.textContent.trim() === '发送');
      if (!_afConfirmBtn) {
        const _afConfirmTexts = ['发送', '确认', '确定', '申请', '提交'];
        for (const text of _afConfirmTexts) {
          const cands = Array.from(document.querySelectorAll('button, [role="button"], div, span, a'))
            .filter(_afIsVis)
            .filter(el => {
              const t = el.textContent.trim();
              return (t === text || (t.includes(text) && t.length <= 6)) &&
                !t.includes('同时') && !t.includes('立即') && !t.includes('关注');
            });
          if (cands.length > 0) {
            cands.sort((a, b) => a.textContent.trim().length - b.textContent.trim().length);
            _afConfirmBtn = cands[0];
            break;
          }
        }
      }

      if (_afConfirmBtn) {
        addLogLine(`🖱️ 点击「${_afConfirmBtn.textContent.trim()}」发送申请...`);

        // ⚠️ 关键：点击"发送"后表单页立即跳转，content.js 被销毁。
        // ACTION_DONE / SAVE_MATCHED_CANDIDATE / pending_task_resume 必须全部在点击前完成，
        // 否则页面销毁后这些调用永远执行不到。
        const _afStatsNow = await sendMsg({ type: 'GET_STATUS' }).then(r => r?.status || {}).catch(() => ({}));

        // 1. 先通知后台统计 +1（点击前，确保不丢失）
        await sendMsg({ type: 'ACTION_DONE', action: 'added' }).catch(() => {});

        // 2. 保存人选到「人选」tab（点击前，确保不丢失）
        await sendMsg({
          type: 'SAVE_MATCHED_CANDIDATE',
          candidate: {
            name: _pendingAddFriend.candidateName || '',
            company: _pendingAddFriend.candidateCompany || '',
            title: _pendingAddFriend.candidateTitle || '',
            score: _pendingAddFriend.candidateScore || 0,
            reason: _pendingAddFriend.candidateReason || '',
            highlights: _pendingAddFriend.candidateHighlights || '',
            action: 'added',
            timestamp: Date.now(),
            profileUrl: _pendingAddFriend.profileUrl || '',
            jobName: _pendingAddFriend.jobName || getCurrentJobName(),
          },
        }).catch(() => {});

        // 3. 写入 resume（点击前，跳转后新页面靠此继续任务）
        sessionStorage.setItem('__maimai_pending_task_resume', JSON.stringify({
          keyword: _pendingAddFriend.keyword,
          step: 'contacts',
          startFromIndex: _pendingAddFriend.nextCardIndex || 0,
          stats: {
            processed: _afStatsNow.processed || 0, matched: _afStatsNow.matched || 0,
            messaged: _afStatsNow.messaged || 0, added: (_afStatsNow.added || 0) + 1,
          },
          paused: false,
          savedAt: Date.now(),
        }));

        addLogLine(`✅ 已向 ${_pendingAddFriend.candidateName || '候选人'} 发送好友申请`);

        // 4. 点击发送（此后页面可能立即跳转，以上所有操作已完成）
        const _afR = _afConfirmBtn.getBoundingClientRect();
        const _afCx = Math.round(_afR.left + _afR.width / 2);
        const _afCy = Math.round(_afR.top + _afR.height / 2);
        const _afTopEl = document.elementFromPoint(_afCx, _afCy) || _afConfirmBtn;
        const _afEv = (extra = {}) => ({ bubbles: true, cancelable: true, view: window, clientX: _afCx, clientY: _afCy, ...extra });
        _afTopEl.dispatchEvent(new PointerEvent('pointerdown', { ..._afEv(), isPrimary: true }));
        _afTopEl.dispatchEvent(new MouseEvent('mousedown', _afEv({ buttons: 1 })));
        await sleep(50);
        _afTopEl.dispatchEvent(new PointerEvent('pointerup', { ..._afEv(), isPrimary: true }));
        _afTopEl.dispatchEvent(new MouseEvent('mouseup', _afEv({ buttons: 0 })));
        _afTopEl.dispatchEvent(new MouseEvent('click', _afEv()));
        try { _afConfirmBtn.click(); } catch(_) {}

        // 点击后等待跳转；若页面未跳转（停留在表单页），主动导航到列表
        await sleep(2500);
      } else {
        const _afVisTexts = Array.from(document.querySelectorAll('button, [role="button"], div, span'))
          .filter(_afIsVis).map(el => el.textContent.trim())
          .filter(t => t.length > 0 && t.length <= 10).filter((v, i, a) => a.indexOf(v) === i).slice(0, 15);
        addLogLine(`⚠️ 未找到发送按钮，可见短文本：${_afVisTexts.join(' | ')}`);
      }

      // 若页面还在（未跳转），主动导航到列表（resume 已在上面写好，跳转后会自动接管）
      navigateTo(_pendingAddFriend.listUrl);
      return;
    }

    // ── 企业招聘端：候选人详情页救援 ────────────────────────────────────────────
    const _recruitPp = (() => { try { return JSON.parse(sessionStorage.getItem('__maimai_recruit_pending_profile') || 'null'); } catch(_){ return null; } })();
    if (_recruitPp && _recruitPp.savedAt && Date.now() - _recruitPp.savedAt < 120000 &&
        /\/ent\/v\d+\/recruit\//.test(location.href)) {
      sessionStorage.removeItem('__maimai_recruit_pending_profile');
      running = true; stopFlag = false;
      if (!_runProfiles.length) { try { _runProfiles = JSON.parse(sessionStorage.getItem('__maimai_run_profiles') || '[]'); } catch (_) {} }
      _currentProfileId = sessionStorage.getItem('__maimai_current_profile_id') || null;
      if (_currentProfileId) await sendMsg({ type: 'SET_ACTIVE_JOB', profileId: _currentProfileId }).catch(() => {});
      config = (await sendMsg({ type: 'GET_CONFIG' })).config;
      createOverlay();
      addLogLine(`📄 招聘详情页：${_recruitPp.candidateInfo?.name || '候选人'}...`);

      // 等「立即沟通」按钮出现（最多 20s）
      await waitForEl(() => {
        if (stopFlag) return document.body;
        return Array.from(document.querySelectorAll('button, [role="button"], div, span'))
          .find(el => { const t = el.textContent.trim(); const r = el.getBoundingClientRect(); return t === '立即沟通' && r.width > 0 && r.height > 0; }) || null;
      }, 20000);

      if (!stopFlag) {
        await sleep(600 + Math.random() * 600);
        // 抓取完整资料（复用社交侧的 extractProfileDetail）
        const _rppProfile = extractProfileDetail();
        const _rppCi = _recruitPp.candidateInfo || {};
        if (!_rppProfile.name)    _rppProfile.name    = _rppCi.name    || '';
        if (!_rppProfile.title)   _rppProfile.title   = _rppCi.title   || '';
        if (!_rppProfile.company) _rppProfile.company = _rppCi.company || '';
        _rppProfile.profileUrl = _recruitPp.profileUrl || location.href;
        addLogLine(`📋 资料：${_rppProfile.name} / ${_rppProfile.title} @ ${_rppProfile.company}`);
        await _recruitEvaluateAndAct(_rppProfile, _recruitPp.cardPos);
      }

      // 保存续点信息，导航回列表
      const _rppStats = await sendMsg({ type: 'GET_STATUS' }).then(r => r?.status || {}).catch(() => ({}));
      sessionStorage.setItem('__maimai_recruit_task_resume', JSON.stringify({
        listUrl: _recruitPp.listUrl,
        startFromIndex: _recruitPp.nextCardIndex || 0,
        stats: _rppStats,
        savedAt: Date.now(),
      }));
      if (!stopFlag) {
        navigateTo(_recruitPp.listUrl);
      } else {
        running = false; sessionStorage.removeItem('__maimai_recruiter_active'); removeOverlay();
      }
      return;
    }

    // ── 企业招聘端：搜索列表恢复（从详情页返回后） ─────────────────────────────
    const _recruitResume = (() => { try { return JSON.parse(sessionStorage.getItem('__maimai_recruit_task_resume') || 'null'); } catch(_){ return null; } })();
    if (_recruitResume && _recruitResume.savedAt && Date.now() - _recruitResume.savedAt < 120000 &&
        isRecruitSearchPage()) {
      sessionStorage.removeItem('__maimai_recruit_task_resume');
      running = true; stopFlag = false;
      if (!_runProfiles.length) { try { _runProfiles = JSON.parse(sessionStorage.getItem('__maimai_run_profiles') || '[]'); } catch (_) {} }
      _currentProfileId = sessionStorage.getItem('__maimai_current_profile_id') || null;
      if (_currentProfileId) await sendMsg({ type: 'SET_ACTIVE_JOB', profileId: _currentProfileId }).catch(() => {});
      config = (await sendMsg({ type: 'GET_CONFIG' })).config;
      createOverlay();
      if (_recruitResume.stats) {
        await sendMsg({ type: 'RESTORE_STATS', stats: _recruitResume.stats, profileId: _currentProfileId }).catch(() => {});
      }
      await loadSeenCandidates();
      addLogLine(`📍 继续招聘搜索（从第 ${(_recruitResume.startFromIndex || 0) + 1} 位候选人）`);
      await runRecruitLoop(_recruitResume.startFromIndex || 0, _recruitResume.stats?.processed || 0);
      running = false;
      sessionStorage.removeItem('__maimai_recruiter_active');
      await sendMsg({ type: 'STOP_TASK' });
      removeOverlay();
      return;
    }

    // ── 优先：详情页处理（processCard 跳转过来的）────────────────────────────
    const pp = (() => { try { return JSON.parse(sessionStorage.getItem('__maimai_pending_profile') || 'null'); } catch(_){ return null; } })();
    const _isProfilePage = location.href.includes('/profile/detail') || /maimai\.cn\/p\//.test(location.href) ||
      location.href.includes('/web/profile') || location.href.includes('/user/') ||
      location.href.includes('/talent/') || location.href.includes('/member/');
    console.log('[脉脉助手] IIFE: pp=', !!pp, '_isProfilePage=', _isProfilePage, 'URL=', location.href);
    // 若有 pending_task_resume（加好友表单提交后跳回），跳过资料页 IIFE，让 resume 逻辑接管导航
    const _hasTaskResume = !!sessionStorage.getItem('__maimai_pending_task_resume');
    if (pp && pp.savedAt && Date.now() - pp.savedAt < 120000 && _isProfilePage && !_hasTaskResume) {
      sessionStorage.removeItem('__maimai_pending_profile');
      running = true;
      stopFlag = false;
      config = (await sendMsg({ type: 'GET_CONFIG' })).config;
      currentKeyword = pp.keyword || '';
      createOverlay();

      // 处理前先查后台是否已暂停（导航时 SET_PAUSED 可能未来得及送达当前页面）
      const _ppRunSt = await sendMsg({ type: 'IS_RUNNING' }).catch(() => ({}));
      if (_ppRunSt?.paused) {
        paused = true;
        sessionStorage.setItem('__maimai_task_paused', '1');
        // 写回 resume 让列表页 IIFE 从正确位置继续（含暂停标记）
        const _ppStats = await sendMsg({ type: 'GET_STATUS' }).then(r => r?.status || {}).catch(() => ({}));
        const _ppBase = pp.baseStats || {};
        const _ppMerge = (f) => { const s = _ppStats[f]||0, b = _ppBase[f]||0; return s >= b ? s : b + s; };
        sessionStorage.setItem('__maimai_pending_task_resume', JSON.stringify({
          keyword: pp.keyword, step: 'contacts',
          startFromIndex: pp.nextCardIndex || 0,
          stats: { processed: _ppMerge('processed'), matched: _ppMerge('matched'),
                   messaged: _ppMerge('messaged'), added: _ppMerge('added'), failed: _ppMerge('failed') },
          paused: true, savedAt: Date.now(),
        }));
        navigateTo(pp.listUrl);
        return;
      }

      addLogLine(`📄 加载详情页：${pp.candidateInfo?.name || '候选人'}...`);

      // 等待操作按钮出现（真正的详情页）
      // 注意：脉脉操作按钮在 position:fixed 侧边栏，必须用 getBoundingClientRect 而非 offsetParent
      const ACTION_KEYWORDS = ['发消息', '加好友', '打招呼', '私信', '联系', '发私信', '沟通', '邀请', '招呼'];
      const profileReady = await waitForEl(() => {
        if (stopFlag) return document.body; // 停止时立即结束等待
        const els = Array.from(document.querySelectorAll('button, [role="button"], div, span, a'))
          .filter(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; });
        return els.some(el => {
          const t = el.textContent.trim();
          return t.length < 15 && ACTION_KEYWORDS.some(k => t.includes(k));
        }) ? document.body : null;
      }, 30000);

      if (!stopFlag) {
        if (!profileReady) {
          const allShortEls = Array.from(document.querySelectorAll('button, [role="button"], div, span, a'))
            .filter(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && el.textContent.trim().length > 0 && el.textContent.trim().length < 20; })
            .map(el => `${el.tagName}:${el.textContent.trim()}`).slice(0, 30);
          log('warn', `详情页操作按钮未出现。可见短文本元素：${allShortEls.join(' | ')}  URL: ${location.href}`);
          addLogLine(`⚠️ 详情页按钮未出现，跳过`);
        } else {
          await sleep(800 + Math.random() * 700);
          if (!stopFlag) addLogLine(`📄 详情页已加载`);
          await markCandidateSeen(extractCandidateId(location.href));

          // ── 暂停检查（AI评估前）──
          if (paused && !stopFlag) {
            const _pStats0 = await sendMsg({ type: 'GET_STATUS' }).then(r => r?.status || {}).catch(() => ({}));
            sessionStorage.setItem('__maimai_pending_task_resume', JSON.stringify({
              keyword: pp.keyword, step: 'contacts', startFromIndex: pp.nextCardIndex || 0,
              stats: { processed: _pStats0.processed||0, matched: _pStats0.matched||0, messaged: _pStats0.messaged||0, added: _pStats0.added||0 },
              paused: true, savedAt: Date.now(),
            }));
            addLogLine(`⏸ 已暂停，返回列表等待恢复...`);
            navigateTo(pp.listUrl);
            return;
          }

          const isFriend = stopFlag ? false : detectIsFriend();
          if (!stopFlag) addLogLine(`🤝 好友关系：${isFriend ? '已是好友' : '非好友'}`);

          if (!stopFlag) await scrollProfile();

          if (!stopFlag) {
            const profileInfo = extractProfileDetail();
            // 用卡片数据兜底（防止 extractProfileDetail 抓到搜索词）
            const kwList = (config.searchKeywords || '').split(',').map(s => s.trim()).filter(Boolean);
            if (!profileInfo.name || kwList.some(kw => profileInfo.name.includes(kw))) profileInfo.name = pp.candidateInfo?.name || '';
            if (!profileInfo.title) profileInfo.title = pp.candidateInfo?.title || '';
            if (!profileInfo.company) profileInfo.company = pp.candidateInfo?.company || '';
            addLogLine(`📋 资料：${profileInfo.name} / ${profileInfo.title} @ ${profileInfo.company}`);

            // ── 快速规则筛选（在调 AI 之前，过滤明显不相关的职位）──────────────
            // 无论搜什么关键词，这些职位方向与技术/业务岗位完全无关
            const QUICK_REJECT_RE = /猎头|招聘|hrbp|\bhr\b|人力资源|人事(经理|专员|总监|主管)|培训讲师|培训师|职业规划|career\s*coach/i;
            if (QUICK_REJECT_RE.test(profileInfo.title)) {
              addLogLine(`⏭️ 快速跳过：${profileInfo.title}（与目标岗位无关）`);
            } else {
            addLogLine(`🧠 AI 评估中...`);
            try {
              const resp = await sendMsg({ type: 'EVALUATE_CANDIDATE', candidateInfo: profileInfo });
              const evaluation = resp.result;
              addLogLine(`🧠 ${profileInfo.name}：${evaluation.score}分 ${evaluation.suitable ? '✓ 匹配' : '✗ 不匹配'} — ${evaluation.reason}`);
              if (evaluation.highlights) addLogLine(`⭐ ${evaluation.highlights}${evaluation.stability ? ' · ' + evaluation.stability : ''}`);

              // 双重门槛：分数达标 且 AI 判断匹配（suitable !== false）才联系；
              // 防止 config.scoreThreshold 配置异常或 AI 明确不匹配仍被联系
              const _scoreNum = Number(evaluation.score) || 0;
              const _thresholdNum = config.scoreThreshold > 0 ? Number(config.scoreThreshold) : 70;

              // ── 暂停检查（联系前）──
              if (paused && !stopFlag) {
                const _pStats1 = await sendMsg({ type: 'GET_STATUS' }).then(r => r?.status || {}).catch(() => ({}));
                sessionStorage.setItem('__maimai_pending_task_resume', JSON.stringify({
                  keyword: pp.keyword, step: 'contacts', startFromIndex: pp.nextCardIndex || 0,
                  stats: { processed: _pStats1.processed||0, matched: _pStats1.matched||0, messaged: _pStats1.messaged||0, added: _pStats1.added||0 },
                  paused: true, savedAt: Date.now(),
                }));
                addLogLine(`⏸ 已暂停，返回列表等待恢复...`);
                navigateTo(pp.listUrl);
                return;
              }

              if (!stopFlag && _scoreNum >= _thresholdNum && evaluation.suitable !== false) {
                if (evaluation.interviewReason) {
                  profileInfo.interviewReason = evaluation.interviewReason;
                  addLogLine(`💡 邀面理由：${evaluation.interviewReason}`);
                }

                // 每日联系上限检查
                const dailyLimit = config.humanBehavior?.dailyContactLimit || 50;
                let totalContacted = 0;
                try {
                  const sr = await sendMsg({ type: 'GET_STATUS' });
                  totalContacted = (sr?.status?.messaged || 0) + (sr?.status?.added || 0);
                } catch (_) {}
                if (totalContacted >= dailyLimit) {
                  addLogLine(`🚫 已达每日联系上限（${dailyLimit} 人），停止任务`);
                  log('warn', `每日联系上限 ${dailyLimit} 人已达，任务自动停止`);
                  stopFlag = true;
                  running = false;
                  sessionStorage.setItem('__maimai_task_stopped', '1');
                  sessionStorage.removeItem('__maimai_pending_profile');
                  sessionStorage.removeItem('__maimai_pending_task_resume');
                  await sendMsg({ type: 'STOP_TASK' });
                  removeOverlay();
                  return;
                }

                // 通过阈值的候选人直接联系，不随机跳过
                {
                  for (let w = 0; w < 4; w++) { await sleep(250 + Math.random() * 250); if (stopFlag) break; }
                  if (!stopFlag) {
                    // 发现匹配人选，重置关键词组超时计时器
                    sessionStorage.setItem('__maimai_group_last_match_ms', String(Date.now()));
                    addLogLine(`🔔 开始联系 ${profileInfo.name}（${isFriend ? '发消息' : '加好友'}）...`);
                    const _matchedUrl = pp.profileUrl || location.href;
                    // rescueInfo 供 sendMessageToFriend 保存到 localStorage，
                    // 若点「发消息」后触发全页跳转到聊天页，新 IIFE 会接管完成发送
                    const rescueInfo = {
                      listUrl: pp.listUrl,
                      keyword: pp.keyword,
                      nextCardIndex: pp.nextCardIndex || 0,
                      // 供救援 IIFE 保存人选明细到「人选」tab
                      candidateScore: _scoreNum,
                      candidateReason: evaluation?.reason || '',
                      candidateHighlights: (evaluation?.highlights || '') + (evaluation?.stability ? ' · ' + evaluation.stability : ''),
                      profileUrl: _matchedUrl,
                    };
                    let result = isFriend
                      ? await sendMessageToFriend(profileInfo, rescueInfo)
                      : await addAsFriend(profileInfo, rescueInfo);
                    // 'navigating'：sendMessageToFriend 已触发跳转到聊天页，救援 IIFE 将接管发送；
                    // 此处必须立即 return，不能再执行任何 location 导航，否则会覆盖聊天页跳转
                    if (result === 'navigating') return;
                    let success = !!result;
                    if (!success && !stopFlag) {
                      addLogLine(`⚠️ 操作失败，3s 后重试...`);
                      for (let w = 0; w < 6; w++) { await sleep(500); if (stopFlag) break; }
                      if (!stopFlag) {
                        result = isFriend
                          ? await sendMessageToFriend(profileInfo, rescueInfo)
                          : await addAsFriend(profileInfo, rescueInfo);
                        if (result === 'navigating') return;
                        success = !!result;
                        if (!success) {
                          addLogLine(`❌ 重试仍然失败，跳过该候选人`);
                          sendMsg({ type: 'ACTION_DONE', action: 'failed' }).catch(() => {});
                        }
                      }
                    }
                    // 保存人选明细（无论成功失败都记录）
                    sendMsg({
                      type: 'SAVE_MATCHED_CANDIDATE',
                      candidate: {
                        name: profileInfo.name || '',
                        company: profileInfo.company || '',
                        title: profileInfo.title || '',
                        score: _scoreNum,
                        reason: evaluation.reason || '',
                        highlights: (evaluation.highlights || '') + (evaluation.stability ? ' · ' + evaluation.stability : ''),
                        action: success ? (isFriend ? 'messaged' : 'added') : 'failed',
                        timestamp: Date.now(),
                        profileUrl: _matchedUrl,
                        jobName: getCurrentJobName(),
                      },
                    }).catch(() => {});
                  }
                }
              }
            } catch (err) {
              addLogLine(`❌ AI 评估失败：${err.message}`);
            }
            } // end quick reject else
          }
        }
      }

      // 停止信号：不返回列表，清理状态直接结束
      if (stopFlag) {
        sessionStorage.setItem('__maimai_task_stopped', '1');
        sessionStorage.removeItem('__maimai_pending_profile');
        sessionStorage.removeItem('__maimai_pending_task_resume');
        await sendMsg({ type: 'STOP_TASK' }).catch(() => {});
        removeOverlay();
        return;
      }

      // 返回列表，保存任务状态让列表页继续
      addLogLine(`↩️ 返回人脉列表...`);
      // 把当前累计统计数据存进 sessionStorage，列表页恢复时用（不归零）
      // ★ SW 重启检测：若 SW 计数 < 进入详情页前的基准值，说明 SW 已重启归零，
      //   此时用「基准 + SW 当前增量」得出正确累计值，防止统计数据倒退。
      let resumeStats = { processed: 0, matched: 0, messaged: 0, added: 0, failed: 0 };
      try {
        const sr = await sendMsg({ type: 'GET_STATUS' });
        if (sr?.status) {
          const sw = sr.status;
          const base = pp.baseStats || {};
          const _merge = (field) => {
            const swVal = sw[field] || 0;
            const baseVal = base[field] || 0;
            // SW 重启时 swVal < baseVal，正确值 = baseVal + swVal（当次增量）
            return swVal >= baseVal ? swVal : baseVal + swVal;
          };
          resumeStats = {
            processed: _merge('processed'), matched: _merge('matched'),
            messaged:  _merge('messaged'),  added:   _merge('added'),
            failed:    _merge('failed'),
          };
        }
      } catch (_) {}
      // 把当前暂停状态一并保存，列表页 IIFE 直接用这个值，不依赖 localStorage 标志
      if (!paused) sessionStorage.removeItem('__maimai_task_paused');
      sessionStorage.setItem('__maimai_pending_task_resume', JSON.stringify({
        keyword: pp.keyword,
        step: 'contacts',
        startFromIndex: pp.nextCardIndex || 0,
        stats: resumeStats,
        paused: paused,
        savedAt: Date.now()
      }));
      navigateTo(pp.listUrl);
      return;
    }

    // ── 常规：搜索跳转恢复 ───────────────────────────────────────────────────
    // 先检查从详情页返回的 localStorage 恢复信息
    const lsResume = (() => { try { return JSON.parse(sessionStorage.getItem('__maimai_pending_task_resume') || 'null'); } catch(_){ return null; } })();
    if (lsResume && lsResume.savedAt && Date.now() - lsResume.savedAt < 300000) {

      // ── 验证当前页面是否是正确的搜索结果人脉页 ──────────────────────────────
      const kwEncoded = encodeURIComponent(lsResume.keyword);
      const onCorrectPage = location.href.includes('type=contact') &&
        (location.href.includes(kwEncoded) || decodeURIComponent(location.href).includes(lsResume.keyword));

      if (!onCorrectPage) {
        // 页面不对：直接导航回搜索结果页（不清除 lsResume，让新页面的 IIFE 继续处理）
        addLogLine(`⚠️ 页面不正确，重新导航到「${lsResume.keyword}」人脉搜索结果...`);
        navigateTo(contactsUrl(lsResume.keyword));
        return;
      }

      sessionStorage.removeItem('__maimai_pending_task_resume');
      // 清除 chrome.storage.local 中可能残留的 pendingTask（防止本路径完成后被二次触发）
      await chrome.storage.local.remove('__maimaiPendingTask').catch(() => {});
      running = true; stopFlag = false;
      // 恢复岗位上下文（页面刷新后全局变量丢失）
      _currentProfileId = lsResume.profileId || sessionStorage.getItem('__maimai_current_profile_id') || null;
      if (!_runProfiles.length) {
        try { _runProfiles = JSON.parse(sessionStorage.getItem('__maimai_run_profiles') || '[]'); } catch (_) {}
      }
      if (_currentProfileId) {
        await sendMsg({ type: 'SET_ACTIVE_JOB', profileId: _currentProfileId }).catch(() => {});
      }
      config = (await sendMsg({ type: 'GET_CONFIG' })).config;
      currentKeyword = lsResume.keyword;
      createOverlay();
      // 用 RESTORE_STATS 代替 START_TASK，保留已累计的统计数据不归零
      let _restoreResp = { paused: false };
      if (lsResume.stats) {
        _restoreResp = await sendMsg({ type: 'RESTORE_STATS', keyword: lsResume.keyword, stats: lsResume.stats, profileId: _currentProfileId }).catch(() => ({}));
      } else {
        await sendMsg({ type: 'START_TASK', profiles: _runProfiles });
      }
      addLogLine(`📍 继续：处理「${lsResume.keyword}」人脉列表（从第 ${lsResume.startFromIndex + 1} 位候选人）`);
      await loadSeenCandidates();

      // 恢复暂停状态：以后台返回的 paused 为主（最准确，SET_PAUSED 导航丢失时也能兜底），
      // 再以 sessionStorage 标志 / lsResume.paused 作备选
      const shouldResumePaused = _restoreResp?.paused || lsResume.paused || !!sessionStorage.getItem('__maimai_task_paused');
      if (shouldResumePaused) {
        paused = true;
        sessionStorage.setItem('__maimai_task_paused', '1'); // 确保后续导航也能感知
        addLogLine(`⏸ 任务已暂停，请在操作面板点击「▶ 继续」恢复`);
        while (paused && !stopFlag) await sleep(500);
        if (stopFlag) { running = false; await sendMsg({ type: 'STOP_TASK' }); return; }
      }

      // 等待候选人卡片加载；若超时说明页面没有搜索结果，重新用搜索框搜索
      const firstCard = await waitForEl(() => { const c = getProfileCards(); return c.length > 0 ? c[0] : null; }, 8000);
      if (!firstCard) {
        addLogLine(`⚠️ 人脉列表未加载，重新搜索「${lsResume.keyword}」...`);
        await doSearch(lsResume.keyword);
      }

      await runProcessingLoop(lsResume.keyword, lsResume.startFromIndex || 0, lsResume.stats?.processed || 0);
      // 当前关键词处理完，尝试继续同组/下一组（受时间限制）
      let _resumeStats = lsResume.stats || {};
      try { const sr = await sendMsg({ type: 'GET_STATUS' }); if (sr?.status) _resumeStats = sr.status; } catch(_) {}
      await continueGroupsAfter(_resumeStats);
      // 当前岗位完成（时间到 or 候选人耗尽），继续循环其余岗位
      if (running && !stopFlag && _runProfiles.length > 0) {
        const curPi = _runProfiles.findIndex(p => p.id === _currentProfileId);
        await runProfileCycle(_runProfiles, curPi + 1);
      }
      running = false;
      await sendMsg({ type: 'STOP_TASK' });
      removeOverlay();
      return;
    }

    // ── 暂停断点恢复：页面刷新后仍在搜索结果页，直接续跑，无需重新搜索 ────────
    const pauseCheckpoint = (() => {
      try { return JSON.parse(sessionStorage.getItem('__maimai_pause_checkpoint') || 'null'); } catch(_){ return null; }
    })();
    if (pauseCheckpoint && Date.now() - pauseCheckpoint.savedAt < 7200000 &&
        location.href.includes('type=contact')) {
      sessionStorage.removeItem('__maimai_pause_checkpoint');
      sessionStorage.removeItem('__maimai_task_paused');
      running = true; stopFlag = false;
      _currentProfileId = sessionStorage.getItem('__maimai_current_profile_id') || null;
      if (!_runProfiles.length) {
        try { _runProfiles = JSON.parse(sessionStorage.getItem('__maimai_run_profiles') || '[]'); } catch (_) {}
      }
      if (_currentProfileId) {
        await sendMsg({ type: 'SET_ACTIVE_JOB', profileId: _currentProfileId }).catch(() => {});
      }
      config = (await sendMsg({ type: 'GET_CONFIG' })).config;
      currentKeyword = pauseCheckpoint.keyword;
      createOverlay();
      await sendMsg({ type: 'RESTORE_STATS', keyword: pauseCheckpoint.keyword, stats: {}, profileId: _currentProfileId }).catch(
        () => sendMsg({ type: 'START_TASK', profiles: _runProfiles }).catch(() => {})
      );
      addLogLine(`📍 从暂停断点续跑：「${pauseCheckpoint.keyword}」（从第 ${pauseCheckpoint.cardIndex + 1} 位候选人）`);
      await loadSeenCandidates();
      await waitForEl(() => { const c = getProfileCards(); return c.length > 0 ? c[0] : null; }, 10000);
      await runProcessingLoop(pauseCheckpoint.keyword, pauseCheckpoint.cardIndex, pauseCheckpoint.processed || 0);
      let _cpStats = {};
      try { const sr = await sendMsg({ type: 'GET_STATUS' }); if (sr?.status) _cpStats = sr.status; } catch(_) {}
      await continueGroupsAfter(_cpStats);
      if (running && !stopFlag && _runProfiles.length > 0) {
        const curPi = _runProfiles.findIndex(p => p.id === _currentProfileId);
        await runProfileCycle(_runProfiles, curPi + 1);
      }
      running = false;
      await sendMsg({ type: 'STOP_TASK' }).catch(() => {});
      removeOverlay();
      return;
    }

    const { __maimaiPendingTask: pending } = await chrome.storage.local.get('__maimaiPendingTask');

    // 优先从 pending task 获取关键词；
    // 若 storage 写入在导航前未完成，退而从当前 URL 提取（兜底）
    let keyword = pending?.keyword;
    if (!keyword && location.href.includes('search_center')) {
      try {
        keyword = new URLSearchParams(location.search).get('query') || '';
      } catch (_) {}
    }

    if (!keyword) return; // 无 pending task 且非搜索结果页，不恢复

    // pending task 超过 5 分钟则认为是历史残留，丢弃
    if (pending && Date.now() - pending.savedAt > 300000) {
      await chrome.storage.local.remove('__maimaiPendingTask');
      return;
    }

    // 立刻清除，防止刷新时重复触发
    await chrome.storage.local.remove('__maimaiPendingTask');
    // 清除可能残留的 lsResume（防止后续详情页跳转时以旧关键词二次触发"继续"路径）
    sessionStorage.removeItem('__maimai_pending_task_resume');

    console.log('[脉脉招聘助手] 检测到跨页任务，自动恢复...', keyword, 'step:', pending?.step);
    running = true;
    stopFlag = false;

    // 恢复 _runProfiles（若尚未恢复）
    if (!_runProfiles.length) {
      try { _runProfiles = JSON.parse(sessionStorage.getItem('__maimai_run_profiles') || '[]'); } catch (_) {}
    }
    _currentProfileId = sessionStorage.getItem('__maimai_current_profile_id') || null;

    config = (await sendMsg({ type: 'GET_CONFIG' })).config;
    sessionManager.count = 0;
    dailyContacts = 0;

    createOverlay();

    await sendMsg({ type: 'START_TASK', keyword });

    if (pending?.step === 'contacts' || location.href.includes('type=contact')) {
      // 已在人脉搜索结果页，直接开始处理
      updateOverlay(`处理人脉候选人：${keyword}`);
      addLogLine(`📍 恢复：处理「${keyword}」人脉列表`);
      await loadSeenCandidates();
      // 等待候选人卡片加载
      await waitForEl(() => {
        const cards = getProfileCards();
        return cards.length > 0 ? cards[0] : null;
      }, 10000);
      await runProcessingLoop(keyword, pending?.startFromIndex || 0);
    } else {
      // 还没到人脉页，重新导航
      updateOverlay(`恢复任务：${keyword}`);
      addLogLine(`📍 恢复任务：${keyword}`);
      await loadSeenCandidates();
      await doSearch(keyword);
      await runProcessingLoop(keyword);
    }

    // 当前关键词处理完，尝试继续同组/下一组（受时间限制）
    let _pendingStats = {};
    try { const sr = await sendMsg({ type: 'GET_STATUS' }); if (sr?.status) _pendingStats = sr.status; } catch(_) {}
    await continueGroupsAfter(_pendingStats);
    if (running && !stopFlag && _runProfiles.length > 0) {
      const curPi = _runProfiles.findIndex(p => p.id === _currentProfileId);
      await runProfileCycle(_runProfiles, curPi + 1);
    }
    running = false;
    await sendMsg({ type: 'STOP_TASK' });
    removeOverlay();
    addLogLine('⏹ 任务已停止');
  })();

})();

// ─── AI 聊天沟通助手（独立于自动化，常驻监控聊天页） ──────────────────────────
(function () {
  'use strict';
  let _lastTriggerText = '';
  let _panelEl = null;
  let _observer = null;
  let _enabled = true;
  let _generating = false;

  // 读取开关配置
  chrome.storage.local.get('config', ({ config = {} }) => {
    _enabled = config.chatAssistEnabled !== false;
    if (_enabled) _startMonitor();
  });

  // 实时监听配置变更（popup 保存后立即生效）
  chrome.storage.onChanged.addListener((changes) => {
    if (!changes.config) return;
    const c = changes.config.newValue || {};
    const was = _enabled;
    _enabled = c.chatAssistEnabled !== false;
    if (_enabled && !was) _startMonitor();
    if (!_enabled && was) { _stopMonitor(); _hidePanel(); }
  });

  function _isChatPage() {
    return /\/chat|\/im\/|\/message\//.test(location.href);
  }

  function _startMonitor() {
    if (_observer) return;
    _observer = new MutationObserver(_debounce(_onDom, 900));
    _observer.observe(document.body, { childList: true, subtree: true });
  }

  function _stopMonitor() {
    if (_observer) { _observer.disconnect(); _observer = null; }
  }

  function _onDom() {
    if (!_isChatPage()) return;
    const msgs = _extractMsgs();
    if (!msgs.length) return;
    const last = msgs[msgs.length - 1];
    if (last.isMe || last.text === _lastTriggerText || _generating) return;
    _lastTriggerText = last.text;
    _trigger(msgs);
  }

  async function _trigger(msgs) {
    _generating = true;
    const name = _getName();
    _showPanel(name, msgs[msgs.length - 1].text, '', true);
    try {
      const r = await chrome.runtime.sendMessage({
        type: 'GENERATE_CHAT_REPLY',
        history: msgs.slice(-8),
        candidateName: name,
      });
      _showPanel(name, msgs[msgs.length - 1].text, r?.reply || '（生成失败，请手动回复）', false);
    } catch (e) {
      _showPanel(name, msgs[msgs.length - 1].text, '（调用失败：' + (e.message || '') + '）', false);
    } finally {
      _generating = false;
    }
  }

  function _extractMsgs() {
    // 类名法：覆盖主流 maimai 版本
    const els = Array.from(document.querySelectorAll(
      '[class*="message-item"],[class*="msg-item"],[class*="chat-message"],' +
      '[class*="MessageItem"],[class*="MsgItem"],[class*="ChatMessage"],[class*="conversation-item"]'
    )).filter(el => { const r = el.getBoundingClientRect(); return r.width > 10 && r.height > 4; });

    const msgs = [];
    for (const el of els) {
      const cls = (el.className || '').toLowerCase();
      const isMe = /self|right|\bsend\b|mine|\bout\b/.test(cls);
      const bubble = el.querySelector('[class*="content"],[class*="text"],[class*="bubble"]') || el;
      const text = (bubble.innerText || bubble.textContent || '').trim().replace(/\s+/g, ' ');
      if (text && text.length >= 1 && text.length < 800) msgs.push({ isMe, text });
    }
    if (msgs.length) return msgs;

    // 兜底：位置启发式（消息中心 > 55% 屏宽 = 我发的）
    Array.from(document.querySelectorAll('div,p'))
      .filter(el => {
        if (el.children.length > 2) return false;
        const t = (el.innerText || '').trim();
        if (!t || t.length < 1 || t.length > 600) return false;
        const r = el.getBoundingClientRect();
        return r.width > 40 && r.width < 400 && r.height > 10 && r.height < 200;
      })
      .forEach(el => {
        const r = el.getBoundingClientRect();
        const text = (el.innerText || '').trim();
        if (text) msgs.push({ isMe: (r.left + r.width / 2) > window.innerWidth * 0.55, text });
      });
    return msgs;
  }

  function _getName() {
    // 从聊天标题区域提取对方姓名
    const hdr = document.querySelector(
      '[class*="chat-header"] [class*="name"],[class*="conv-header"] [class*="name"],' +
      '[class*="ChatHeader"] [class*="Name"],[class*="contact-name"],[class*="ContactName"]'
    );
    if (hdr) {
      const n = (hdr.innerText || '').trim().split('\n')[0].trim();
      if (n && n.length < 20) return n;
    }
    // 从 document.title 提取（如"脉脉 - 与XXX的对话"）
    const m = document.title.match(/与(.{1,10}?)的/) || document.title.match(/^([^\s\-]{1,10})\s*[\-|]/);
    return m ? m[1] : '候选人';
  }

  function _showPanel(name, theirMsg, aiReply, loading) {
    _hidePanel();
    const el = document.createElement('div');
    el.id = '__maimai_chat_assist';
    el.innerHTML =
      '<div class="mca-header" id="mca-hdr">' +
        '<span class="mca-icon">💬</span>' +
        '<span class="mca-title">AI 沟通助手</span>' +
        '<button class="mca-regen" id="mca-regen" title="重新生成"' + (loading ? ' disabled' : '') + '>⟳</button>' +
        '<button class="mca-close" id="mca-close">✕</button>' +
      '</div>' +
      '<div class="mca-their-msg">' +
        '<span class="mca-their-name">' + escHtml(name) + '</span> 说：' +
        '<div class="mca-their-text">' + escHtml((theirMsg || '').slice(0, 200)) + '</div>' +
      '</div>' +
      '<div class="mca-reply-wrap">' +
        '<div class="mca-reply-label">AI 建议回复' + (loading ? '（生成中…）' : '：') + '</div>' +
        '<textarea class="mca-reply-input" id="mca-input" rows="4"' +
          (loading ? ' readonly placeholder="正在生成..."' : '') + '>' +
          escHtml(aiReply || '') +
        '</textarea>' +
      '</div>' +
      '<div class="mca-actions">' +
        '<button class="mca-btn-send" id="mca-send"' + (loading || !aiReply ? ' disabled' : '') + '>✉ 发送</button>' +
      '</div>';
    document.body.appendChild(el);
    _panelEl = el;

    el.querySelector('#mca-close').onclick = () => { _hidePanel(); _lastTriggerText = ''; };
    el.querySelector('#mca-regen').onclick = () => {
      if (_generating) return;
      const ms = _extractMsgs();
      if (ms.length) _trigger(ms);
    };
    el.querySelector('#mca-send').onclick = () => {
      const txt = el.querySelector('#mca-input').value.trim();
      if (txt) _sendReply(txt);
    };
    _makeDraggable(el, el.querySelector('#mca-hdr'));
  }

  function _hidePanel() {
    if (_panelEl) { _panelEl.remove(); _panelEl = null; }
  }

  async function _sendReply(text) {
    _hidePanel();
    const box = findChatInput();
    if (!box) {
      console.warn('[AI聊天助手] 未找到聊天输入框');
      return;
    }
    if (box.contentEditable === 'true') {
      document.execCommand('selectAll', false, null);
      document.execCommand('delete', false, null);
      await new Promise(r => setTimeout(r, 150));
      document.execCommand('insertText', false, text);
    } else {
      const setter = Object.getOwnPropertyDescriptor(
        box.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype, 'value'
      )?.set;
      if (setter) setter.call(box, text);
      box.dispatchEvent(new Event('input', { bubbles: true }));
    }
    box.dispatchEvent(new Event('change', { bubbles: true }));
    await new Promise(r => setTimeout(r, 500));

    // 点击发送按钮（优先匹配文字"发送"，兼容 data-radium 属性）
    const sendBtn = Array.from(document.querySelectorAll('a[data-radium],button[data-radium],button'))
      .find(btn => {
        const r = btn.getBoundingClientRect();
        return r.width > 0 && /^(发送|Send)$/.test(btn.textContent.trim());
      });
    if (sendBtn) {
      sendBtn.click();
    } else {
      box.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
    }
  }

  function _makeDraggable(el, handle) {
    let ox = 0, oy = 0;
    handle.style.cursor = 'move';
    handle.onmousedown = e => {
      e.preventDefault();
      const rect = el.getBoundingClientRect();
      ox = e.clientX - rect.left;
      oy = e.clientY - rect.top;
      const mv = e2 => {
        el.style.left   = (e2.clientX - ox) + 'px';
        el.style.top    = (e2.clientY - oy) + 'px';
        el.style.bottom = 'auto';
        el.style.right  = 'auto';
      };
      document.addEventListener('mousemove', mv);
      document.onmouseup = () => document.removeEventListener('mousemove', mv);
    };
  }

  function _debounce(fn, ms) {
    let t;
    return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
  }
})();
