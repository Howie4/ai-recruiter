/**
 * background.js — Service Worker
 * 负责：Claude API 调用 | 任务状态管理 | 消息路由 | 日志记录
 */

// ─── 默认配置 ────────────────────────────────────────────────────────────────
const DEFAULT_CONFIG = {
  claudeApiKey: '',
  claudeApiBase: 'https://llm-proxy.tapsvc.com',
  claudeModel: 'claude-opus-4-6',
  claudeMaxTokens: 1024,

  searchKeywords: '',          // 搜索关键词，逗号分隔
  jobTitle: '',                // 岗位名称
  jobDescription: '',          // 岗位描述与要求
  filterCriteria: {
    // 公司/岗位（优先级1）
    companyTier: 'any',        // any | bigtech | listed | unicorn | top
    targetCompanies: '',       // 具体公司名，逗号分隔
    // 学历（优先级2）
    minEducation: 'any',       // any | bachelor | master | phd
    school: 'any',             // any | 985 | 211 | top
    // 工作年限（优先级3）
    minExpYears: 0,            // 最少工作年限，0=不限
    maxExpYears: 0,            // 最多工作年限，0=不限
    // 稳定性（优先级4）
    minAvgTenure: 0,           // 平均每家公司最少任职年数，0=不限
    minLastTenure: 0,          // 最近一份工作最少年数，0=不限
    // 技术关键词（优先级5）
    keywords: [],
    keywordsLogic: 'any',
    // 其他
    gender: 'any',
    notes: '',
  },

  friendMessage: '{name}，你好！我们正在招聘{jobTitle}，您在{company}的经历很符合需求，方便聊聊吗？',
  addFriendMessage: '{name}，你好！我们正在招聘{jobTitle}，您的背景经历很匹配，期待加好友交流！',

  maxCandidates: 30,           // 最多处理候选人数
  actionDelay: 2500,           // 每步操作间隔 ms（避免频繁）
  pageDelay: 3000,             // 页面加载等待 ms
  scoreThreshold: 70,          // AI 匹配分 ≥ 此值才操作

  // DOM 选择器（基于脉脉真实页面截图校准，可在 options 里覆盖应对改版）
  selectors: {
    // 首页右上角搜索框，placeholder="搜索"
    searchInput: 'input[placeholder="搜索"]',

    // 搜索结果页的 tab：实名动态 | 职言交流 | 人脉
    connectionsTab: 'span, a, div, li',   // 宽泛选择器，配合 connectionsTabText 定位
    connectionsTabText: '人脉',            // tab 文字精确匹配

    // 人脉列表中每条候选人行
    profileCard: '[class*="contact-item"], [class*="person-item"], [class*="search-item"], [class*="people-item"]',

    // 卡片内元素
    cardName: '[class*="name"]',
    cardTitle: '[class*="title"], [class*="position"], [class*="job"]',
    cardCompany: '[class*="company"], [class*="corp"]',

    // 搜索结果列表中的蓝色「查看」按钮（非好友才有）
    // 好友（初识好友 LV1 / 共同好友）无查看按钮，直接点头像/姓名进详情
    viewBtnText: '查看',                   // 用 findByText 精确匹配按钮文字

    // 详情页右侧边栏：非好友显示「+加好友」
    addFriendBtnText: '+加好友',           // 精确文字匹配

    // 详情页右侧边栏：好友显示「发消息」
    messageBtnText: '发消息',             // 精确文字匹配

    // 加好友弹窗中的附言输入框
    friendRequestInput: 'textarea, input[type="text"]',

    // 加好友弹窗确认按钮
    sendConfirmBtnText: '确认',           // 弹窗确认按钮文字

    // 详情页 — 个人信息
    profileName: 'h1, [class*="name"][class*="user"], [class*="profile-name"]',
    profileTitle: '[class*="title"], [class*="position"], [class*="job-name"]',
    profileCompany: '[class*="company"], [class*="corp"]',
    profileExp: '[class*="work"], [class*="career"], [class*="experience"]',
    profileEdu: '[class*="edu"], [class*="school"]',
    profileSkills: '[class*="skill"], [class*="tag"]',

    // 消息对话框输入区（点「发消息」后弹出的对话窗）
    messageInputBox: '[contenteditable="true"], textarea, [class*="input"][class*="msg"]',
    messageSendBtn: 'button',             // 发送按钮，配合文字"发送"匹配
    messageSendBtnText: '发送',
  },

  debugMode: false,

  humanBehavior: {
    // 打字速度
    typingSpeedMin: 80,    // 最慢：ms/字符
    typingSpeedMax: 200,   // 最快：ms/字符
    typingErrorRate: 0.03, // 偶尔"打错字再删除"的概率

    // 阅读停顿（查看候选人资料时）
    readingSpeedCharsPerSec: 8,  // 按资料字数估算阅读时间
    readingMinMs: 5000,          // 最短阅读时间
    readingMaxMs: 25000,         // 最长阅读时间

    // 操作前随机 hover 停留
    hoverMinMs: 300,
    hoverMaxMs: 1200,

    // 消息审阅停顿（生成消息后"看一眼"再发）
    reviewMinMs: 1500,
    reviewMaxMs: 5000,

    // 周期性休息（连续操作 N 人后）
    breakAfterN: 8,          // 每处理 N 位候选人后休息
    breakMinMs: 15000,       // 短休息最短
    breakMaxMs: 40000,       // 短休息最长
    longBreakAfterN: 25,     // 每 N 人后长休息
    longBreakMinMs: 120000,  // 2分钟
    longBreakMaxMs: 300000,  // 5分钟

    // 随机跳过（匹配分达标时，有概率不操作，表现"犹豫"）
    skipProbability: 0.08,   // 8% 概率随机跳过一个匹配候选人

    // 工作时间限制（不在此区间内不操作）
    workHoursEnabled: false,
    workHoursStart: 9,       // 9:00
    workHoursEnd: 18,        // 18:00

    // 每日操作上限（单次任务最多主动联系人数）
    dailyContactLimit: 50,

    // 滚动行为
    scrollProfileEnabled: true,   // 进入详情页后是否滚动阅读
    scrollSteps: 3,               // 分几步滚动到底

    // 操作间隔随机化（在 actionDelay 基础上加 ±jitter 抖动）
    jitterPercent: 30,   // ±30% 随机抖动
  },
};

// ─── 运行时状态 ───────────────────────────────────────────────────────────────
let taskState = {
  running: false,
  paused: false,
  processed: 0,
  matched: 0,
  messaged: 0,
  added: 0,
  failed: 0,
  currentKeyword: '',
  startTime: null,
  logs: [],                 // 共享日志（两种模式合用，每条带 mode 字段）
  automationTabId: null,    // 运行自动化任务的后台 tab ID（人脉搜索模式）
  automationWindowId: null, // 对应的独立最小化窗口 ID
  panelWindowId: null,      // 操作台悬浮窗 ID（点击胶囊弹出）
  jobProfiles: [],          // 本次运行的岗位列表（enabled 的）
  activeProfileId: null,    // 当前正在跑的岗位 ID
};

// 招聘搜索页模式独立状态（与人脉搜索并行运行，互不干扰）
let recruitTaskState = {
  running: false,
  paused: false,
  processed: 0,
  matched: 0,
  messaged: 0,
  failed: 0,
  currentKeyword: '',
  startTime: null,
  automationTabId: null,    // 招聘搜索页的 tab ID（用户自己打开的，不创建新窗口）
  automationWindowId: null,
  jobProfiles: [],
  activeProfileId: null,
};

// 通过 sender tab ID 判断属于哪种模式
function getModeForTab(senderTabId) {
  if (senderTabId && recruitTaskState.automationTabId === senderTabId) return 'recruit';
  return 'social';
}
function getStateForMode(mode) {
  return mode === 'recruit' ? recruitTaskState : taskState;
}

// ─── 工具函数 ─────────────────────────────────────────────────────────────────
function timestamp() {
  return new Date().toLocaleTimeString('zh-CN');
}

function addLog(level, message, data = null, mode = 'social') {
  const entry = { time: timestamp(), level, message, data, mode };
  taskState.logs.unshift(entry); // 共享日志数组，两种模式合用
  if (taskState.logs.length > 200) taskState.logs.pop();
  // 持久化最近日志
  chrome.storage.local.set({ taskLogs: taskState.logs.slice(0, 100) });
  // 广播给 popup
  broadcastStatus();
}

function broadcastStatus() {
  const social = {
    running: taskState.running,
    paused: taskState.paused,
    processed: taskState.processed,
    matched: taskState.matched,
    messaged: taskState.messaged,
    added: taskState.added,
    failed: taskState.failed,
    currentKeyword: taskState.currentKeyword,
    activeProfileId: taskState.activeProfileId,
  };
  const recruit = {
    running: recruitTaskState.running,
    paused: recruitTaskState.paused,
    processed: recruitTaskState.processed,
    matched: recruitTaskState.matched,
    messaged: recruitTaskState.messaged,
    failed: recruitTaskState.failed,
    currentKeyword: recruitTaskState.currentKeyword,
    activeProfileId: recruitTaskState.activeProfileId,
  };
  const status = { social, recruit, recentLogs: taskState.logs.slice(0, 50) };
  chrome.runtime.sendMessage({ type: 'STATUS_UPDATE', status }).catch(() => {});
  // 推送给各自的自动化 tab
  if (taskState.automationTabId) {
    chrome.tabs.sendMessage(taskState.automationTabId, { type: 'STATUS_UPDATE', status }).catch(() => {});
  }
  if (recruitTaskState.automationTabId && recruitTaskState.automationTabId !== taskState.automationTabId) {
    chrome.tabs.sendMessage(recruitTaskState.automationTabId, { type: 'STATUS_UPDATE', status }).catch(() => {});
  }
  // 持久化运行中的统计数据，用于 SW 重启后恢复
  if (taskState.running || recruitTaskState.running) {
    chrome.storage.local.set({ __mmr_live_stats: { ...status, savedAt: Date.now() } }).catch(() => {});
  }
}

// ─── 大模型 API 调用（Claude / OpenAI 兼容） ─────────────────────────────────
function isClaudeModel(model) {
  return model && String(model).startsWith('claude-');
}

async function callLLM(prompt, config) {
  const apiKey = config.claudeApiKey;
  const model  = config.claudeModel;
  const maxTokens = config.claudeMaxTokens || 1024;
  if (!apiKey) throw new Error('未配置 API Key');

  const base = (config.claudeApiBase || 'https://llm-proxy.tapsvc.com').replace(/\/$/, '');
  const TIMEOUT_MS = 60000;
  const MAX_RETRIES = 1;
  let response;
  let requestUrl = '';

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
      if (isClaudeModel(model)) {
        // Anthropic Messages API
        requestUrl = `${base}/v1/messages`;
        response = await fetch(requestUrl, {
          signal: controller.signal,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': apiKey,
            'anthropic-version': '2023-06-01',
          },
          body: JSON.stringify({
            model,
            max_tokens: maxTokens,
            messages: [{ role: 'user', content: prompt }],
          }),
        });
      } else {
        // OpenAI-compatible API（GPT / Gemini / 千问 / 豆包 / DeepSeek 等均支持）
        // 若 base 不含版本路径（/v1、/v2、/v3、/v1beta 等），自动补 /v1
        const oaiBase = /\/v\d|\/openai/.test(base) ? base : base + '/v1';
        requestUrl = `${oaiBase}/chat/completions`;
        response = await fetch(requestUrl, {
          signal: controller.signal,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            model,
            ...(/^o\d/.test(model)
              ? { max_completion_tokens: maxTokens }
              : { max_tokens: maxTokens }),
            messages: [{ role: 'user', content: prompt }],
          }),
        });
      }
      clearTimeout(timeoutId);
      break; // 请求成功，跳出重试循环
    } catch (e) {
      clearTimeout(timeoutId);
      if (e.name === 'AbortError') {
        if (attempt < MAX_RETRIES) {
          await new Promise(r => setTimeout(r, 3000)); // 等 3s 后重试
          continue;
        }
        throw new Error('API 请求超时（60s），已重试 1 次');
      }
      throw e;
    }
  }

  if (!response.ok) {
    const rawText = await response.text().catch(() => '');
    let msg = response.statusText || '';
    try {
      const err = JSON.parse(rawText);
      msg = err.error?.message || err.message || msg;
    } catch (_) {
      if (rawText) msg = rawText.slice(0, 300);
    }
    throw new Error(`API 错误 ${response.status}: ${msg || '(空)'} [模型:${model} 地址:${requestUrl}]`);
  }

  const data = await response.json();
  if (isClaudeModel(model)) {
    if (!data.content?.[0]?.text) throw new Error(`API 返回格式异常: ${JSON.stringify(data).slice(0, 200)}`);
    return data.content[0].text;
  } else {
    const text = data.choices?.[0]?.message?.content;
    if (text === undefined || text === null) throw new Error(`API 返回格式异常: ${JSON.stringify(data).slice(0, 200)}`);
    return text;
  }
}

// ─── 将结构化筛选条件转为 prompt 文本 ────────────────────────────────────────
function buildCriteriaText(config) {
  const fc = config.filterCriteria || {};
  const hard = []; // 硬性要求：不满足即淘汰
  const soft = []; // 软性偏好：满足则加分

  const tierMap = { bigtech: 'BAT/字节/美团等互联网大厂', listed: '上市公司', unicorn: '独角兽或知名创业公司', top: '行业头部公司' };
  const eduMap  = { bachelor: '本科及以上', master: '硕士及以上', phd: '博士' };
  const schoolMap = { '985': '985高校', '211': '211及以上高校', top: '双一流高校' };

  // ── 硬性要求 ──
  if (fc.minExpYears > 0 || fc.maxExpYears > 0) {
    const min = fc.minExpYears > 0 ? `${fc.minExpYears}年以上` : '';
    const max = fc.maxExpYears > 0 ? `${fc.maxExpYears}年以下` : '';
    hard.push(`工作年限：正式工作年限 ${[min, max].filter(Boolean).join('且')}（计算方法：以最高学历毕业年份→2026年；实习不计入，≤4个月或与在校期重叠的短期经历均视为实习；超出范围直接淘汰）`);
  }
  if (fc.minEducation && fc.minEducation !== 'any') {
    hard.push(`最低学历：${eduMap[fc.minEducation]}（低于此学历直接淘汰）`);
  }
  if (fc.school && fc.school !== 'any') {
    hard.push(`院校要求：必须毕业于${schoolMap[fc.school]}（不符合直接淘汰）`);
  }
  if (fc.keywords?.length && fc.keywordsLogic === 'all') {
    hard.push(`技术关键词（必须全部具备）：${fc.keywords.join('、')}（任意一项缺失直接淘汰）`);
  }
  if (fc.gender && fc.gender !== 'any') {
    hard.push(`性别：${fc.gender === 'male' ? '男性' : '女性'}（不符合直接淘汰）`);
  }
  if (fc.minAvgTenure > 0) {
    const t = fc.minAvgTenure >= 1 ? fc.minAvgTenure + '年' : (fc.minAvgTenure * 12) + '个月';
    hard.push(`稳定性：平均每家公司任职时长 ≥ ${t}（低于此值直接淘汰）`);
  }
  if (fc.minLastTenure > 0) {
    const t = fc.minLastTenure >= 1 ? fc.minLastTenure + '年' : (fc.minLastTenure * 12) + '个月';
    hard.push(`近期稳定性：最近一份工作任职时长 ≥ ${t}（低于此值直接淘汰）`);
  }

  // ── 软性偏好 ──
  if (fc.companyTier && fc.companyTier !== 'any') {
    soft.push(`优先来自${tierMap[fc.companyTier]}的候选人（大幅加分）`);
  }
  if (fc.targetCompanies) {
    soft.push(`来自以下公司大幅加分：${fc.targetCompanies}`);
  }
  if (fc.keywords?.length && fc.keywordsLogic !== 'all') {
    soft.push(`技术关键词（至少满足一项）：${fc.keywords.join('、')}（加分项）`);
  }
  if (fc.notes) soft.push(`补充说明：${fc.notes}`);

  const parts = [];
  if (hard.length) {
    parts.push('【硬性要求 — 不满足则 suitable=false，score≤40，在reason中说明哪项不达标】\n' +
      hard.map((l, i) => `${i + 1}. ${l}`).join('\n'));
  }
  if (soft.length) {
    parts.push('【软性偏好 — 满足则加分，不满足不扣分】\n' +
      soft.map((l, i) => `${i + 1}. ${l}`).join('\n'));
  }
  return parts.length ? parts.join('\n\n') : '无特殊筛选条件，根据岗位要求综合评估。';
}

// ─── 候选人评估 ───────────────────────────────────────────────────────────────
async function evaluateCandidate(candidateInfo, config) {
  const prompt = `你是一位资深猎头顾问，正在为客户寻找适合邀请面试的候选人。请根据岗位要求和筛选条件，综合评估该候选人是否值得主动联系。

## 招聘岗位
岗位名称：${config.jobTitle}
岗位要求：
${config.jobDescription}

筛选条件：
${buildCriteriaText(config)}

## 候选人资料
姓名：${candidateInfo.name || '未知'}
现任职位：${candidateInfo.title || '未知'}
所在公司：${candidateInfo.company || '未知'}
工作经历：${candidateInfo.experience || '（见下方完整资料）'}
教育背景：${candidateInfo.education || '（见下方完整资料）'}
技能标签：${candidateInfo.skills || ''}

候选人资料页完整文本：
---
${(candidateInfo.extra || '').slice(0, 3500)}
---

## 评估流程（必须按顺序执行）

**第一步：硬性要求逐项核查（一票否决）**
筛选条件中标注"硬性要求"的每一项都必须逐一核查：
- 若候选人不满足任意一项硬性要求 → suitable=false，score≤40，reason中说明哪项不达标
- 若简历信息不足以判断某项硬性要求 → 按不满足处理（宁可漏过，不可错放）
- 工作年限计算规则（严格按以下优先级执行）：
  1. **优先**：找最高学历的毕业年份，以"毕业年份 → 2026"计算正式工作年限（最准确，不受履历缺失影响）
  2. **兜底**：若简历完全没有毕业年份，再从最早的正式工作起算
  3. **实习判定**（以下任一条件满足即视为实习，不计入年限）：
     - 简历中明确标注"实习""intern""internship"等字样
     - 在职时长 ≤ 6 个月且时间节点与在校阶段（本科/硕士/博士学习期间）重叠
     - 在职时长 ≤ 4 个月（无论是否标注实习，极短期工作按实习处理）

**第二步：软性偏好评估（加分项）**
- 只有通过第一步的候选人才进行本步骤
- 根据软性偏好和岗位匹配度综合打分（60-100分）
- 公司背景、岗位相关性、职业发展路径是核心加分维度

**第三步：综合判断**
- 通过硬性要求 + 综合评分 ≥ 配置阈值 → suitable=true
- 任意硬性要求不满足 → suitable=false（不论其他条件多优秀）

## 请以 JSON 格式输出（不要有其他内容）：
{
  "suitable": true或false,
  "score": 0到100的整数,
  "reason": "按优先级说明匹配或不匹配的核心原因，50字内",
  "highlights": "候选人最突出的1-2个亮点（公司/学历/经验/稳定性），30字内",
  "stability": "稳定/较稳定/一般/频繁跳槽",
  "interviewReason": "邀请面试的个性化理由，结合公司背景或工作经历具体写，40字内，suitable为false时留空"
}`;

  const raw = await callLLM(prompt, config);

  // 解析 JSON，兼容 markdown 代码块
  const jsonMatch = raw.match(/```(?:json)?\s*([\s\S]*?)\s*```/) || raw.match(/(\{[\s\S]*\})/);
  if (!jsonMatch) throw new Error('Claude 返回格式无法解析');

  const jsonStr = jsonMatch[1];
  // 尝试直接解析
  try { return JSON.parse(jsonStr); } catch (_) {}

  // 容错：Claude 的 reason 字段可能包含候选人简介中未转义的引号（如 "不看机会勿扰"）
  // 用字段名作为边界逐个提取，避免因内嵌引号整体解析失败
  const getBool = key => {
    const m = jsonStr.match(new RegExp(`"${key}"\\s*:\\s*(true|false)`));
    return m ? m[1] === 'true' : false;
  };
  const getNum = key => {
    const m = jsonStr.match(new RegExp(`"${key}"\\s*:\\s*(\\d+)`));
    return m ? parseInt(m[1]) : 0;
  };
  const getStrBetween = (startKey, endKey) => {
    const re = endKey
      ? new RegExp(`"${startKey}"\\s*:\\s*"([\\s\\S]*?)",\\s*"${endKey}"`)
      : new RegExp(`"${startKey}"\\s*:\\s*"([\\s\\S]*?)"\\s*[,}]`);
    const m = jsonStr.match(re);
    return m ? m[1] : '';
  };

  const suitable = getBool('suitable');
  const score    = getNum('score');
  if (score === 0 && !jsonStr.includes('"score": 0') && !jsonStr.includes('"score":0')) {
    throw new Error(`Claude 返回 JSON 解析失败 | 原文: ${jsonStr.slice(0, 150)}`);
  }
  return {
    suitable,
    score,
    reason:          getStrBetween('reason', 'stability'),
    stability:       getStrBetween('stability', 'interviewReason'),
    interviewReason: getStrBetween('interviewReason', null),
  };
}

// ─── 生成招聘消息 ─────────────────────────────────────────────────────────────
async function generateMessage(candidateInfo, messageTemplate, config, isFriend = true) {
  // 公共变量替换（无论是否调 AI，先把固定变量填好）
  function fillVars(tpl) {
    // 同时支持半角 {var}/{var}、方括号 [var]、全角 ｛var｝ 三种占位符语法
    const re = (key) => new RegExp('[\\[{｛【]' + key + '[\\]}｝】]', 'g');
    const company = candidateInfo.company || '';
    let result = tpl
      .replace(re('name'), candidateInfo.name || '')
      .replace(re('title'), candidateInfo.title || '')
      .replace(re('company'), company)
      .replace(re('jobTitle'), config.jobTitle || '')
      .replace(re('reason'), candidateInfo.interviewReason || '');
    // company 为空时，清理"在 的"/"在的" 之类残留破损语句
    if (!company) {
      result = result
        .replace(/在\s*的/g, '的')        // "在 的经历" → "的经历"
        .replace(/，您在[的，。！？\s]/g, '，您'); // "，您在的经历" → "，您的经历"
    }
    return result;
  }

  if (!messageTemplate.includes('{ai}')) {
    return fillVars(messageTemplate);
  }

  // 先填充固定变量，让 AI 只需生成 {ai} 部分
  const templateWithVars = fillVars(messageTemplate);

  // 加好友附言受脉脉 50 字限制，需特别提醒 AI 控制总长度
  const lengthNote = !isFriend
    ? '\n【重要】脉脉加好友附言最多50字，请确保生成后整条消息（含模板固定文字）总字数 ≤ 50字，宁可精简也不要超字数。'
    : '';

  const prompt = `你是招聘专员，请根据模板和候选人信息，生成一条自然、真诚的面试邀请消息。
在模板中，{ai} 是你需要创作的个性化内容，请将 {ai} 替换为针对该候选人的个性化邀面理由（${isFriend ? '30-60字' : '10-20字，因总消息有50字上限'}），其他部分保持不变。${lengthNote}

模板：${templateWithVars}
岗位：${config.jobTitle || ''}
候选人职位：${candidateInfo.title || '未知'}
候选人公司：${candidateInfo.company || '未知'}
${candidateInfo.interviewReason ? `邀面核心理由（请围绕此展开）：${candidateInfo.interviewReason}` : ''}

要求：直接输出最终消息文本，不要说明，不要引号，不要{ai}占位符。`;

  return await callLLM(prompt, config);
}

// ─── AI 聊天回复生成 ──────────────────────────────────────────────────────────
async function generateChatReply(history, candidateName, config) {
  const conv = history.map(m =>
    `${m.isMe ? '我（招聘方）' : candidateName}: ${m.text}`
  ).join('\n');
  const prompt = `你是一位专业热情的招聘专员，正在通过脉脉和候选人沟通。
目标：真诚回答问题、消除顾虑、强调岗位亮点，引导候选人同意参加面试。
语气：自然、专业，50-120字，不要过于正式，不要AI感。

岗位：${config.jobTitle || '（未设置）'}
岗位要求：${(config.jobDescription || '').slice(0, 500)}

最近对话：
${conv}

直接输出回复文本，不要任何解释：`;
  return await callLLM(prompt, config);
}

// ─── 消息处理 ─────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handleMessage(msg, sender).then(sendResponse).catch(err => {
    addLog('error', err.message);
    sendResponse({ success: false, error: err.message });
  });
  return true; // 保持异步通道
});

async function handleMessage(msg, sender) {
  switch (msg.type) {

    case 'EVALUATE_CANDIDATE': {
      const mode = getModeForTab(sender?.tab?.id);
      const state = getStateForMode(mode);
      const config = await getConfig(mode);
      const result = await evaluateCandidate(msg.candidateInfo, config);
      const modeTag = mode === 'recruit' ? '[招聘页] ' : '';
      addLog('info', `${modeTag}评估 ${msg.candidateInfo.name}：${result.score}分 ${result.suitable ? '✓ 匹配' : '✗ 不匹配'}`, result, mode);
      state.processed++;
      const threshold = config.scoreThreshold || 70;
      if (result.score >= threshold) state.matched++;
      broadcastStatus();
      return { success: true, result };
    }

    case 'GENERATE_MESSAGE': {
      const mode = getModeForTab(sender?.tab?.id);
      const config = await getConfig(mode);
      const template = msg.isFriend ? config.friendMessage : config.addFriendMessage;
      // 未开启 AI 消息时，直接用模板变量替换（不调用 Claude）
      // 未开启 AI 消息时，移除 {ai} 占位符并清理多余空格/标点
      const effectiveTemplate = config.useAIMessage ? template : template.replace(/\{ai\}/g, '').replace(/[ \t]{2,}/g, ' ').trim();
      const text = await generateMessage(msg.candidateInfo, effectiveTemplate, config, msg.isFriend);
      return { success: true, text };
    }

    case 'GENERATE_CHAT_REPLY': {
      const config = await getConfig(getModeForTab(sender?.tab?.id));
      const reply = await generateChatReply(msg.history, msg.candidateName, config);
      return { success: true, reply };
    }

    case 'SET_AUTOMATION_TAB': {
      if (msg.mode === 'recruit') {
        recruitTaskState.automationTabId = msg.tabId;
        recruitTaskState.automationWindowId = msg.windowId || null;
      } else {
        taskState.automationTabId = msg.tabId;
        taskState.automationWindowId = msg.windowId || null;
      }
      return { success: true };
    }

    // content.js 发来的跨页导航请求：由 SW 用 chrome.tabs.update 发起，
    // 避免在网页进程内调用 window.location.href 触发 macOS 窗口关注/抢焦点
    case 'NAVIGATE_BACKGROUND': {
      // 始终用 sender 自身的 tab 导航，避免跨模式混淆
      const navTabId = sender?.tab?.id;
      if (navTabId && msg.url) {
        chrome.tabs.update(navTabId, { url: msg.url, active: false }).catch(() => {});
      }
      return { success: true };
    }

    case 'START_TASK': {
      const mode = getModeForTab(sender?.tab?.id);
      const profiles = msg.profiles || [];

      if (mode === 'recruit') {
        // 招聘搜索页模式：初始化 recruitTaskState
        const prevActiveId = recruitTaskState.activeProfileId;
        const newProfiles = profiles.length ? profiles : recruitTaskState.jobProfiles;
        const newActiveId = prevActiveId && newProfiles.find(p => p.id === prevActiveId)
          ? prevActiveId : newProfiles[0]?.id || null;
        recruitTaskState = {
          running: true, paused: false,
          processed: 0, matched: 0, messaged: 0, failed: 0,
          currentKeyword: '',
          startTime: Date.now(),
          automationTabId: sender?.tab?.id || recruitTaskState.automationTabId,
          automationWindowId: recruitTaskState.automationWindowId,
          jobProfiles: newProfiles,
          activeProfileId: newActiveId,
        };
        if (profiles.length) {
          const jobNames = profiles.map(p => p.name || p.jobTitle || '未命名').join('、');
          addLog('info', `[招聘页] 任务启动，共 ${profiles.length} 个岗位：${jobNames}`, null, 'recruit');
        }
      } else {
        // 人脉搜索模式：清除"用户主动停止"标记，初始化 taskState
        chrome.storage.local.remove('__mmr_explicitly_stopped').catch(() => {});
        const startCfg = await getConfig('social');
        const prevActiveId = taskState.activeProfileId;
        const newProfiles = profiles.length ? profiles : taskState.jobProfiles;
        const newActiveId = prevActiveId && newProfiles.find(p => p.id === prevActiveId)
          ? prevActiveId : newProfiles[0]?.id || null;
        taskState = {
          running: true, paused: false,
          processed: 0, matched: 0, messaged: 0, added: 0, failed: 0,
          currentKeyword: '',
          startTime: Date.now(),
          logs: taskState.logs,          // 保留共享日志
          maxCandidates: startCfg.maxCandidates || 30,
          automationTabId: sender?.tab?.id || taskState.automationTabId,
          automationWindowId: taskState.automationWindowId,
          panelWindowId: taskState.panelWindowId,
          jobProfiles: newProfiles,
          activeProfileId: newActiveId,
        };
        if (profiles.length) {
          const jobNames = profiles.map(p => p.name || p.jobTitle || '未命名').join('、');
          addLog('info', `任务启动，共 ${profiles.length} 个岗位：${jobNames}`, null, 'social');
        }
      }
      return { success: true };
    }

    case 'SET_ACTIVE_JOB': {
      const mode = getModeForTab(sender?.tab?.id);
      const state = getStateForMode(mode);
      state.activeProfileId = msg.profileId;
      const profile = state.jobProfiles.find(p => p.id === msg.profileId);
      if (profile) {
        state.currentKeyword = '';
        addLog('info', `🏢 切换到岗位：${profile.name || profile.jobTitle || '未命名'}`, null, mode);
      }
      broadcastStatus();
      return { success: true };
    }

    case 'STOP_TASK': {
      const stopMode = msg.mode || 'social';
      if (stopMode === 'recruit') {
        recruitTaskState.running = false;
        const rs = `共处理 ${recruitTaskState.processed} 人，匹配 ${recruitTaskState.matched} 人，沟通 ${recruitTaskState.messaged}${recruitTaskState.failed ? `，失败 ${recruitTaskState.failed}` : ''}`;
        addLog('info', `[招聘页] 任务结束。${rs}`, null, 'recruit');
        if (recruitTaskState.automationTabId) {
          chrome.tabs.sendMessage(recruitTaskState.automationTabId, { type: 'STOP_TASK_CONTENT' }).catch(() => {});
          recruitTaskState.automationTabId = null;
        }
        // 招聘页模式：不关闭用户自己的标签页，没有独立窗口
      } else {
        taskState.running = false;
        // 标记"用户主动停止"，区分 SW 重启
        chrome.storage.local.set({ __mmr_explicitly_stopped: true }).catch(() => {});
        const socialAnyRunning = recruitTaskState.running;
        if (!socialAnyRunning) chrome.storage.local.remove('__mmr_live_stats').catch(() => {});
        const stopSummary = `共处理 ${taskState.processed} 人，匹配 ${taskState.matched} 人，发消息 ${taskState.messaged}，加好友 ${taskState.added}${taskState.failed ? `，失败 ${taskState.failed}` : ''}`;
        addLog('info', `任务结束。${stopSummary}`, null, 'social');
        if (taskState.processed > 0) {
          chrome.notifications.create('maimai-task-done', {
            type: 'basic',
            iconUrl: 'icons/icon48.png',
            title: '脉脉招聘助手',
            message: stopSummary,
          }).catch(() => {});
        }
        if (taskState.automationTabId) {
          const tabToStop = taskState.automationTabId;
          taskState.automationTabId = null;
          chrome.tabs.sendMessage(tabToStop, { type: 'STOP_TASK_CONTENT' }).catch(() => {});
          // 关闭后台自动化标签页（不关闭整个窗口，避免触发 OS 焦点事件）
          chrome.tabs.remove(tabToStop).catch(() => {});
        }
        taskState.automationWindowId = null;
      }
      return { success: true };
    }

    case 'PAUSE_TASK': {
      const pauseMode = msg.mode || 'social';
      const pauseState = getStateForMode(pauseMode);
      pauseState.paused = !pauseState.paused;
      const modeTag = pauseMode === 'recruit' ? '[招聘页] ' : '';
      addLog('info', `${modeTag}${pauseState.paused ? '任务已暂停' : '任务已恢复'}`, null, pauseMode);
      broadcastStatus();
      if (pauseState.automationTabId) {
        chrome.tabs.sendMessage(pauseState.automationTabId, { type: 'SET_PAUSED', paused: pauseState.paused }).catch(() => {});
      }
      return { success: true, paused: pauseState.paused };
    }

    case 'LOG': {
      const logMode = getModeForTab(sender?.tab?.id);
      addLog(msg.level || 'info', msg.message, msg.data, logMode);
      return { success: true };
    }

    case 'ACTION_DONE': {
      const actionMode = getModeForTab(sender?.tab?.id);
      const actionState = getStateForMode(actionMode);
      if (msg.action === 'messaged') actionState.messaged++;
      if (msg.action === 'added' && actionMode === 'social') taskState.added++;
      if (msg.action === 'failed') actionState.failed++;
      broadcastStatus();
      return { success: true };
    }

    case 'RESTORE_STATS': {
      // 从详情页返回列表页时调用，恢复已累计的统计数据（不归零）
      const restoreMode = getModeForTab(sender?.tab?.id);
      const restoreState = getStateForMode(restoreMode);

      if (!restoreState.running) {
        if (restoreMode === 'social') {
          // running=false 有两种原因：用户主动停止 or SW 重启归零
          const stored = await chrome.storage.local.get(['__mmr_explicitly_stopped', 'config']);
          if (stored.__mmr_explicitly_stopped) {
            return { success: true, stopped: true };
          }
          // SW 重启：从 storage 恢复
          const cfg = stored.config || {};
          taskState.running = true;
          taskState.paused = false;
          taskState.startTime = taskState.startTime || Date.now();
          taskState.jobProfiles = cfg.jobProfiles || taskState.jobProfiles;
          taskState.activeProfileId = taskState.activeProfileId || cfg.activeProfileId || null;
          taskState.maxCandidates = taskState.maxCandidates || cfg.maxCandidates || 30;
        } else {
          // recruit 模式：SW 重启后恢复
          recruitTaskState.running = true;
          recruitTaskState.paused = false;
          recruitTaskState.startTime = recruitTaskState.startTime || Date.now();
        }
      }
      if (sender?.tab?.id) restoreState.automationTabId = sender.tab.id;
      restoreState.currentKeyword = msg.keyword || restoreState.currentKeyword;
      if (msg.stats) {
        restoreState.processed = msg.stats.processed ?? restoreState.processed;
        restoreState.matched   = msg.stats.matched   ?? restoreState.matched;
        restoreState.messaged  = msg.stats.messaged  ?? restoreState.messaged;
        if (restoreMode === 'social') taskState.added = msg.stats.added ?? taskState.added;
        restoreState.failed    = msg.stats.failed    ?? restoreState.failed;
      }
      if (msg.profileId && restoreState.jobProfiles.length) {
        restoreState.activeProfileId = msg.profileId;
      }
      if (!restoreState.startTime) restoreState.startTime = Date.now();
      broadcastStatus();
      return { success: true, paused: restoreState.paused, activeProfileId: restoreState.activeProfileId };
    }

    case 'GET_STATUS': {
      const social = {
        running: taskState.running,
        paused: taskState.paused,
        processed: taskState.processed,
        matched: taskState.matched,
        messaged: taskState.messaged,
        added: taskState.added,
        failed: taskState.failed,
        currentKeyword: taskState.currentKeyword,
        activeProfileId: taskState.activeProfileId,
      };
      const recruit = {
        running: recruitTaskState.running,
        paused: recruitTaskState.paused,
        processed: recruitTaskState.processed,
        matched: recruitTaskState.matched,
        messaged: recruitTaskState.messaged,
        failed: recruitTaskState.failed,
        currentKeyword: recruitTaskState.currentKeyword,
        activeProfileId: recruitTaskState.activeProfileId,
      };
      let statusResult = { social, recruit, recentLogs: taskState.logs.slice(0, 50) };
      // SW 重启后归零：若有持久化的运行中统计，先显示
      if (!taskState.running && !recruitTaskState.running) {
        const stored = await chrome.storage.local.get(['__mmr_live_stats', '__mmr_explicitly_stopped']);
        const live = stored.__mmr_live_stats;
        if (!stored.__mmr_explicitly_stopped && (live?.social?.running || live?.recruit?.running)
            && Date.now() - (live?.savedAt || 0) < 5 * 60 * 1000) {
          statusResult = { ...statusResult, social: live.social || social, recruit: live.recruit || recruit };
        }
      }
      return { success: true, status: statusResult };
    }

    case 'TEST_API': {
      const config = await getConfig();
      const base = (config.claudeApiBase || 'https://llm-proxy.tapsvc.com').replace(/\/$/, '');
      const key  = config.claudeApiKey;
      const model = config.claudeModel || 'claude-sonnet-4-6';
      const oaiBase = /\/v\d|\/openai/.test(base) ? base : base + '/v1';
      const testUrl = isClaudeModel(model) ? `${base}/v1/messages` : `${oaiBase}/chat/completions`;
      try {
        const text = await callLLM('hi', { ...config, claudeMaxTokens: 5 });
        return { success: true, model, message: `✅ Key 有效，模型：${model}` };
      } catch (e) {
        // 如果是 Claude 模型，再多尝试一次 Bearer 认证（兼容代理）
        if (isClaudeModel(model)) {
          try {
            const resp = await fetch(`${base}/v1/messages`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` },
              body: JSON.stringify({ model, max_tokens: 5, messages: [{ role: 'user', content: 'hi' }] }),
            });
            if (resp.ok) return { success: true, model, message: `✅ Key 有效，模型：${model}` };
            const body = await resp.text();
            return { success: false, error: `${resp.status}: ${body.slice(0, 200)}` };
          } catch (e2) {
            return { success: false, error: e2.message };
          }
        }
        return { success: false, error: `${e.message}（请求地址：${testUrl}，模型：${model}）` };
      }
    }

    case 'SAVE_MATCHED_CANDIDATE': {
      const { candidate } = msg;
      if (!candidate) return { success: false };
      // 自动标记来源模式（基于 sender tab ID，content.js 无需感知）
      const savedMode = getModeForTab(sender?.tab?.id);
      const candidateWithMode = { ...candidate, sourceMode: savedMode };
      const stored = await chrome.storage.local.get('matchedCandidates');
      const list = stored.matchedCandidates || [];
      // 去重：同一 profileUrl 在 5 分钟内重复保存则跳过（防止重试/救援路径双写）
      if (candidateWithMode.profileUrl) {
        const cutoff = Date.now() - 5 * 60 * 1000;
        const dup = list.some(c => c.profileUrl === candidateWithMode.profileUrl && c.timestamp >= cutoff);
        if (dup) return { success: true, duplicate: true };
      }
      list.push(candidateWithMode);
      await chrome.storage.local.set({ matchedCandidates: list });
      return { success: true };
    }

    case 'GET_MATCHED_CANDIDATES': {
      const stored = await chrome.storage.local.get('matchedCandidates');
      return { candidates: stored.matchedCandidates || [] };
    }

    case 'CLEAR_MATCHED_CANDIDATES': {
      await chrome.storage.local.set({ matchedCandidates: [] });
      return { success: true };
    }

    case 'OPEN_POPUP': {
      // 找已有的 panel 窗口，激活它；没有则在当前窗口右下角新建
      const popupUrl = chrome.runtime.getURL('popup.html');
      const wins = await chrome.windows.getAll({ populate: true });
      for (const w of wins) {
        const tab = w.tabs?.find(t => t.url?.startsWith(popupUrl));
        if (tab) {
          await chrome.windows.update(w.id, { focused: true });
          taskState.panelWindowId = w.id;
          // 通知胶囊隐藏（操作台已打开）
          if (taskState.automationTabId) {
            chrome.tabs.sendMessage(taskState.automationTabId, { type: 'HIDE_OVERLAY' }).catch(() => {});
          }
          return { success: true };
        }
      }
      const panelW = 400, panelH = 560;
      let left, top;
      try {
        const cur = await chrome.windows.getLastFocused();
        left = cur.left + cur.width  - panelW - 16;
        top  = cur.top  + cur.height - panelH - 80;
      } catch (_) {
        left = 900; top = 300;
      }
      const newWin = await chrome.windows.create({
        url: popupUrl + '?panel=1',
        type: 'popup',
        left: Math.max(0, left),
        top:  Math.max(0, top),
        width: panelW,
        height: panelH,
        focused: true,
      });
      taskState.panelWindowId = newWin?.id ?? null;
      // 通知胶囊隐藏
      if (taskState.automationTabId) {
        chrome.tabs.sendMessage(taskState.automationTabId, { type: 'HIDE_OVERLAY' }).catch(() => {});
      }
      return { success: true };
    }

    case 'GET_CONFIG': {
      const config = await getConfig();
      return { success: true, config };
    }

    case 'SAVE_CONFIG': {
      await chrome.storage.local.set({ config: msg.config });
      addLog('info', '配置已保存');
      return { success: true };
    }

    case 'IS_RUNNING': {
      return {
        success: true,
        social: { running: taskState.running, paused: taskState.paused },
        recruit: { running: recruitTaskState.running, paused: recruitTaskState.paused },
        running: taskState.running || recruitTaskState.running,
        paused: taskState.paused,
      };
    }

    // ── 简历筛选 ──────────────────────────────────────────────────────────────
    case 'EVALUATE_RESUME': {
      const cfg = await getConfig();
      const result = await evaluateResume(msg.resumeText, cfg);
      return { success: true, result };
    }

    case 'GET_RESUME_RESULTS': {
      const { resumeResults = [] } = await chrome.storage.local.get('resumeResults');
      return { success: true, results: resumeResults };
    }

    case 'SAVE_RESUME_RESULTS': {
      await chrome.storage.local.set({ resumeResults: msg.results });
      return { success: true };
    }

    default:
      return { success: false, error: `未知消息类型: ${msg.type}` };
  }
}

// ─── 简历评估（AI筛选Tab专用）────────────────────────────────────────────────
async function evaluateResume(resumeText, config) {
  const fc = config.filterCriteria || {};

  // ── 构建筛选条件描述 ──────────────────────────────────────────────────────
  const hard = [];  // 硬性条件（不符合则 suitable: false）
  const soft = [];  // 软性偏好（影响评分）

  const eduMap = { bachelor: '本科及以上', master: '硕士及以上', phd: '博士' };
  if (fc.minEducation && fc.minEducation !== 'any')
    hard.push(`学历：${eduMap[fc.minEducation]}`);

  if (fc.minExpYears > 0 || fc.maxExpYears > 0) {
    const min = fc.minExpYears > 0 ? `${fc.minExpYears}年以上` : '';
    const max = fc.maxExpYears > 0 ? `${fc.maxExpYears}年以下` : '';
    hard.push(`工作年限：${(min && max) ? `${fc.minExpYears}～${fc.maxExpYears}年` : (min || max)}`);
  }

  if (fc.keywords && fc.keywords.length > 0) {
    const logic = fc.keywordsLogic === 'all' ? '以下技术关键词必须全部出现' : '以下技术关键词至少满足一个';
    hard.push(`${logic}：${fc.keywords.join('、')}`);
  }

  if (fc.gender && fc.gender !== 'any')
    hard.push(`性别：${fc.gender === 'male' ? '男' : '女'}`);

  const schoolMap = { '985': '985院校', '211': '211及以上', top: '双一流' };
  if (fc.school && fc.school !== 'any')
    soft.push(`院校：${schoolMap[fc.school]}（不满足扣10分）`);

  const tierMap = { bigtech: '大厂（BAT/字节等）', listed: '上市公司', unicorn: '独角兽/知名创业', top: '行业头部' };
  if (fc.companyTier && fc.companyTier !== 'any')
    soft.push(`公司类型偏好：${tierMap[fc.companyTier]}（不满足扣5~10分）`);

  if (fc.targetCompanies)
    soft.push(`目标公司加分项：${fc.targetCompanies}（有经历额外加5分）`);

  if (fc.minAvgTenure > 0)
    soft.push(`平均任职时长：${fc.minAvgTenure}年以上（不满足扣5分）`);

  if (fc.minLastTenure > 0)
    soft.push(`最近工作时长：${fc.minLastTenure}年以上（不满足扣5分）`);

  if (fc.notes)
    soft.push(`补充说明：${fc.notes}`);

  let filterSection = '';
  if (hard.length || soft.length) {
    filterSection = '\n【候选人筛选条件】\n';
    if (hard.length) filterSection +=
      `硬性要求（任意一条不满足则 suitable: false，分数上限55）：\n${hard.map(l => '• ' + l).join('\n')}\n`;
    if (soft.length) filterSection +=
      `软性偏好（影响评分）：\n${soft.map(l => '• ' + l).join('\n')}\n`;
  }

  const prompt = `你是一位专业HR助理，请根据岗位要求和筛选条件，全面评估候选人简历是否适合邀请面试。

【岗位名称】
${config.jobTitle || '（未填写）'}

【岗位职责与要求】
${config.jobDescription || '（未填写，请根据岗位名称做合理评估）'}
${filterSection}
【候选人简历】
${resumeText.slice(0, 4000)}

评分说明：
1. 先依据「岗位职责与要求」对技能、经验、背景进行匹配评分（0-100）
2. 逐一核查所有「硬性要求」，任意一条不满足：suitable 置为 false，分数上限 55
3. 再按「软性偏好」逐项调整分数
4. 综合得出最终 score 和 suitable

请严格以 JSON 格式回复，不要有任何其他文字：
{
  "name": "候选人姓名（从简历提取，无法提取填'未知'）",
  "score": 0到100的整数,
  "suitable": true或false,
  "reason": "评估核心理由（含筛选条件核查结论），80字以内",
  "highlights": "主要亮点1-2条，30字以内",
  "weaknesses": "主要不足1-2条，30字以内，无明显不足填'暂无'",
  "interviewReason": "建议面试的个性化理由，40字以内；不推荐时留空"
}`;

  const raw = await callLLM(prompt, config);
  const jsonMatch = raw.match(/```(?:json)?\s*([\s\S]*?)\s*```/) || raw.match(/(\{[\s\S]*\})/);
  if (!jsonMatch) throw new Error('AI 返回格式无法解析');
  try {
    return JSON.parse(jsonMatch[1]);
  } catch (_) {
    const s = jsonMatch[1];
    const get = k => { const m = s.match(new RegExp(`"${k}"\\s*:\\s*"([^"]*?)"`)); return m ? m[1] : ''; };
    const getNum = k => { const m = s.match(new RegExp(`"${k}"\\s*:\\s*(\\d+)`)); return m ? parseInt(m[1], 10) : 50; };
    const getBool = k => { const m = s.match(new RegExp(`"${k}"\\s*:\\s*(true|false)`)); return m ? m[1] === 'true' : false; };
    return { name: get('name') || '未知', score: getNum('score'), suitable: getBool('suitable'),
      reason: get('reason'), highlights: get('highlights'), weaknesses: get('weaknesses'), interviewReason: get('interviewReason') };
  }
}

// ─── 获取配置（合并默认值 + 活跃岗位 profile 字段）─────────────────────────
// mode: 'social' | 'recruit' | null（null=优先用 taskState）
async function getConfig(mode = null) {
  let { config = {} } = await chrome.storage.local.get('config');

  // 迁移：若 local 为空，尝试从 sync 搬运（storage.sync → storage.local 升级）
  if (!config.claudeApiKey && !config.jobProfiles && !config.jobDescription) {
    try {
      const { config: syncCfg = {} } = await chrome.storage.sync.get('config');
      if (syncCfg.claudeApiKey || syncCfg.jobDescription) {
        config = syncCfg;
        await chrome.storage.local.set({ config });
      }
    } catch (_) {}
  }

  const base = {
    ...DEFAULT_CONFIG,
    ...config,
    selectors: { ...DEFAULT_CONFIG.selectors, ...(config.selectors || {}) },
    humanBehavior: { ...DEFAULT_CONFIG.humanBehavior, ...(config.humanBehavior || {}) },
    filterCriteria: { ...DEFAULT_CONFIG.filterCriteria, ...(config.filterCriteria || {}) },
  };

  // 根据 mode 选择对应的 state，使用其活跃 profile
  const state = mode === 'recruit' ? recruitTaskState : taskState;
  if (state.activeProfileId && state.jobProfiles.length) {
    const profile = state.jobProfiles.find(p => p.id === state.activeProfileId);
    if (profile) {
      return {
        ...base,
        jobTitle:        profile.jobTitle        || base.jobTitle,
        jobDescription:  profile.jobDescription  || base.jobDescription,
        scoreThreshold:  profile.scoreThreshold  ?? base.scoreThreshold,
        friendMessage:   profile.friendMessage   || base.friendMessage,
        addFriendMessage: profile.addFriendMessage || base.addFriendMessage,
        useAIMessage:    profile.useAiMsg        ?? base.useAIMessage,
        filterCriteria: {
          ...base.filterCriteria,
          ...(profile.filterCriteria || {}),
        },
      };
    }
  }

  return base;
}

// 注：自动化改为后台标签页方案（chrome.tabs.create({ active:false })），
// 不再创建独立窗口，无需监听窗口状态。

// ─── 操作台窗口关闭时恢复胶囊 ──────────────────────────────────────────────────
chrome.windows.onRemoved.addListener((windowId) => {
  if (taskState.panelWindowId && windowId === taskState.panelWindowId) {
    taskState.panelWindowId = null;
    // 操作台关闭 → 通知自动化页面重新显示胶囊
    if (taskState.running && taskState.automationTabId) {
      chrome.tabs.sendMessage(taskState.automationTabId, { type: 'SHOW_OVERLAY' }).catch(() => {});
    }
  }
});

// ─── 兜底：任务运行时自动关闭脉脉产生的新标签 ──────────────────────────────────
// content.js 已通过覆盖 window.open 阻止新标签，此处作双重保险
let maimaiTabId = null; // 记录当前运行任务的标签ID

chrome.tabs.onCreated.addListener(async (newTab) => {
  if (!taskState.running && !recruitTaskState.running) return;
  // 等待 URL 解析（onCreated 触发时 pendingUrl 可能还是空）
  await new Promise(r => setTimeout(r, 200));
  const tab = await chrome.tabs.get(newTab.id).catch(() => null);
  if (!tab) return;

  const url = tab.pendingUrl || tab.url || '';
  if (!url || !url.includes('maimai.cn')) return;

  // 情况1：有 opener（window.open 产生）→ 通知 opener 做 SPA 导航后关闭新 tab
  if (tab.openerTabId) {
    chrome.tabs.sendMessage(tab.openerTabId, { type: 'NAVIGATE_TO', url }).catch(() => {});
    await chrome.tabs.remove(newTab.id).catch(() => {});
    return;
  }

  // 情况2：新 tab 由自动化 tab 内的 target="_blank" 产生（opener 为 null 但 opener tab 可知）
  // 检查是否来自已知的自动化 tab 所在窗口，若是则转发并关闭
  const autoTabId = taskState.automationTabId || recruitTaskState.automationTabId;
  if (autoTabId && newTab.id !== autoTabId) {
    const autoTab = await chrome.tabs.get(autoTabId).catch(() => null);
    if (autoTab && tab.windowId === autoTab.windowId) {
      chrome.tabs.sendMessage(autoTabId, { type: 'NAVIGATE_TO', url }).catch(() => {});
      await chrome.tabs.remove(newTab.id).catch(() => {});
    }
  }
});

// ─── 点击扩展图标：打开/聚焦操作台标签页 ────────────────────────────────────
chrome.action.onClicked.addListener(async () => {
  const panelUrl = chrome.runtime.getURL('popup.html') + '?standalone=1';
  // 查找已经打开的操作台标签页
  const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL('popup.html') + '*' });
  if (tabs.length > 0) {
    // 已有操作台标签页，直接聚焦
    const t = tabs[0];
    await chrome.windows.update(t.windowId, { focused: true }).catch(() => {});
    await chrome.tabs.update(t.id, { active: true });
  } else {
    // 新建操作台标签页
    chrome.tabs.create({ url: panelUrl });
  }
});

// ─── 扩展安装时写入默认配置 ───────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  if (reason === 'install') {
    const { config } = await chrome.storage.local.get('config');
    if (!config) {
      await chrome.storage.local.set({ config: DEFAULT_CONFIG });
    }
  }
});
