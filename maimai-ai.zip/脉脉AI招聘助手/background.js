/**
 * background.js — Service Worker
 * 负责：Claude API 调用 | 任务状态管理 | 消息路由 | 日志记录
 */

// ─── 默认配置 ────────────────────────────────────────────────────────────────
const DEFAULT_CONFIG = {
  claudeApiKey: '',
  claudeApiBase: 'https://llm-proxy.tapsvc.com',
  claudeModel: 'claude-opus-4-6',
  claudeMaxTokens: 1024,

  searchKeywords: '',          // 搜索关键词，逗号分隔
  jobTitle: '',                // 岗位名称
  jobDescription: '',          // 岗位描述与要求
  filterCriteria: {
    // 公司/岗位（优先级1）
    companyTier: 'any',        // any | bigtech | listed | unicorn | top
    targetCompanies: '',       // 具体公司名，逗号分隔
    // 学历（优先级2）
    minEducation: 'any',       // any | bachelor | master | phd
    school: 'any',             // any | 985 | 211 | top
    // 工作年限（优先级3）
    minExpYears: 0,            // 最少工作年限，0=不限
    maxExpYears: 0,            // 最多工作年限，0=不限
    // 稳定性（优先级4）
    minAvgTenure: 0,           // 平均每家公司最少任职年数，0=不限
    minLastTenure: 0,          // 最近一份工作最少年数，0=不限
    // 技术关键词（优先级5）
    keywords: [],
    keywordsLogic: 'any',
    // 其他
    gender: 'any',
    notes: '',
  },

  friendMessage: '你好{name}，我们正在招聘{jobTitle}，您在{company}的经历很符合需求，方便聊聊吗？',
  addFriendMessage: '你好{name}！我们招聘{jobTitle}，您的背景很匹配，期待加好友交流！',

  maxCandidates: 30,           // 最多处理候选人数
  actionDelay: 2500,           // 每步操作间隔 ms（避免频繁）
  pageDelay: 3000,             // 页面加载等待 ms
  scoreThreshold: 70,          // AI 匹配分 ≥ 此值才操作

  // DOM 选择器（基于脉脉真实页面截图校准，可在 options 里覆盖应对改版）
  selectors: {
    // 首页右上角搜索框，placeholder="搜索"
    searchInput: 'input[placeholder="搜索"]',

    // 搜索结果页的 tab：实名动态 | 职言交流 | 人脉
    connectionsTab: 'span, a, div, li',   // 宽泛选择器，配合 connectionsTabText 定位
    connectionsTabText: '人脉',            // tab 文字精确匹配

    // 人脉列表中每条候选人行
    profileCard: '[class*="contact-item"], [class*="person-item"], [class*="search-item"], [class*="people-item"]',

    // 卡片内元素
    cardName: '[class*="name"]',
    cardTitle: '[class*="title"], [class*="position"], [class*="job"]',
    cardCompany: '[class*="company"], [class*="corp"]',

    // 搜索结果列表中的蓝色「查看」按钮（非好友才有）
    // 好友（初识好友 LV1 / 共同好友）无查看按钮，直接点头像/姓名进详情
    viewBtnText: '查看',                   // 用 findByText 精确匹配按钮文字

    // 详情页右侧边栏：非好友显示「+加好友」
    addFriendBtnText: '+加好友',           // 精确文字匹配

    // 详情页右侧边栏：好友显示「发消息」
    messageBtnText: '发消息',             // 精确文字匹配

    // 加好友弹窗中的附言输入框
    friendRequestInput: 'textarea, input[type="text"]',

    // 加好友弹窗确认按钮
    sendConfirmBtnText: '确认',           // 弹窗确认按钮文字

    // 详情页 — 个人信息
    profileName: 'h1, [class*="name"][class*="user"], [class*="profile-name"]',
    profileTitle: '[class*="title"], [class*="position"], [class*="job-name"]',
    profileCompany: '[class*="company"], [class*="corp"]',
    profileExp: '[class*="work"], [class*="career"], [class*="experience"]',
    profileEdu: '[class*="edu"], [class*="school"]',
    profileSkills: '[class*="skill"], [class*="tag"]',

    // 消息对话框输入区（点「发消息」后弹出的对话窗）
    messageInputBox: '[contenteditable="true"], textarea, [class*="input"][class*="msg"]',
    messageSendBtn: 'button',             // 发送按钮，配合文字"发送"匹配
    messageSendBtnText: '发送',
  },

  debugMode: false,

  humanBehavior: {
    // 打字速度
    typingSpeedMin: 80,    // 最慢：ms/字符
    typingSpeedMax: 200,   // 最快：ms/字符
    typingErrorRate: 0.03, // 偶尔"打错字再删除"的概率

    // 阅读停顿（查看候选人资料时）
    readingSpeedCharsPerSec: 8,  // 按资料字数估算阅读时间
    readingMinMs: 5000,          // 最短阅读时间
    readingMaxMs: 25000,         // 最长阅读时间

    // 操作前随机 hover 停留
    hoverMinMs: 300,
    hoverMaxMs: 1200,

    // 消息审阅停顿（生成消息后"看一眼"再发）
    reviewMinMs: 1500,
    reviewMaxMs: 5000,

    // 周期性休息（连续操作 N 人后）
    breakAfterN: 8,          // 每处理 N 位候选人后休息
    breakMinMs: 15000,       // 短休息最短
    breakMaxMs: 40000,       // 短休息最长
    longBreakAfterN: 25,     // 每 N 人后长休息
    longBreakMinMs: 120000,  // 2分钟
    longBreakMaxMs: 300000,  // 5分钟

    // 随机跳过（匹配分达标时，有概率不操作，表现"犹豫"）
    skipProbability: 0.08,   // 8% 概率随机跳过一个匹配候选人

    // 工作时间限制（不在此区间内不操作）
    workHoursEnabled: false,
    workHoursStart: 9,       // 9:00
    workHoursEnd: 18,        // 18:00

    // 每日操作上限（单次任务最多主动联系人数）
    dailyContactLimit: 50,

    // 滚动行为
    scrollProfileEnabled: true,   // 进入详情页后是否滚动阅读
    scrollSteps: 3,               // 分几步滚动到底

    // 操作间隔随机化（在 actionDelay 基础上加 ±jitter 抖动）
    jitterPercent: 30,   // ±30% 随机抖动
  },
};

// ─── 运行时状态 ───────────────────────────────────────────────────────────────
let taskState = {
  running: false,
  paused: false,
  processed: 0,
  matched: 0,
  messaged: 0,
  added: 0,
  failed: 0,
  currentKeyword: '',
  startTime: null,
  logs: [],
  automationTabId: null,    // 运行自动化任务的后台 tab ID
  automationWindowId: null, // 对应的独立最小化窗口 ID
  panelWindowId: null,      // 操作台悬浮窗 ID（点击胶囊弹出）
  jobProfiles: [],          // 本次运行的岗位列表（enabled 的）
  activeProfileId: null,    // 当前正在跑的岗位 ID
};

// ─── 工具函数 ─────────────────────────────────────────────────────────────────
function timestamp() {
  return new Date().toLocaleTimeString('zh-CN');
}

function addLog(level, message, data = null) {
  const entry = { time: timestamp(), level, message, data };
  taskState.logs.unshift(entry);
  if (taskState.logs.length > 200) taskState.logs.pop();
  // 持久化最近日志
  chrome.storage.local.set({ taskLogs: taskState.logs.slice(0, 100) });
  // 广播给 popup
  broadcastStatus();
}

function broadcastStatus() {
  const status = {
    running: taskState.running,
    paused: taskState.paused,
    processed: taskState.processed,
    matched: taskState.matched,
    messaged: taskState.messaged,
    added: taskState.added,
    failed: taskState.failed,
    currentKeyword: taskState.currentKeyword,
    activeProfileId: taskState.activeProfileId,
    recentLogs: taskState.logs.slice(0, 50),
  };
  chrome.runtime.sendMessage({ type: 'STATUS_UPDATE', status }).catch(() => {});
  // 同时推送给自动化标签页的 content script（runtime.sendMessage 不会到达 content script）
  if (taskState.automationTabId) {
    chrome.tabs.sendMessage(taskState.automationTabId, { type: 'STATUS_UPDATE', status }).catch(() => {});
  }
  // 持久化运行中的统计数据，用于 SW 重启后恢复（Chrome 约 30s 无消息就终止 SW）
  if (taskState.running) {
    chrome.storage.local.set({ __mmr_live_stats: { ...status, savedAt: Date.now() } }).catch(() => {});
  }
}

// ─── 大模型 API 调用（Claude / OpenAI 兼容） ─────────────────────────────────
function isClaudeModel(model) {
  return model && String(model).startsWith('claude-');
}

async function callLLM(prompt, config) {
  const apiKey = config.claudeApiKey;
  const model  = config.claudeModel;
  const maxTokens = config.claudeMaxTokens || 1024;
  if (!apiKey) throw new Error('未配置 API Key');

  const base = (config.claudeApiBase || 'https://llm-proxy.tapsvc.com').replace(/\/$/, '');
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 30000);
  let response;
  let requestUrl = '';
  try {
    if (isClaudeModel(model)) {
      // Anthropic Messages API
      requestUrl = `${base}/v1/messages`;
      response = await fetch(requestUrl, {
        signal: controller.signal,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model,
          max_tokens: maxTokens,
          messages: [{ role: 'user', content: prompt }],
        }),
      });
    } else {
      // OpenAI-compatible API（GPT / Gemini / 千问 / 豆包 / DeepSeek 等均支持）
      // 若 base 不含版本路径（/v1、/v2、/v3、/v1beta 等），自动补 /v1
      const oaiBase = /\/v\d|\/openai/.test(base) ? base : base + '/v1';
      requestUrl = `${oaiBase}/chat/completions`;
      response = await fetch(requestUrl, {
        signal: controller.signal,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model,
          max_tokens: maxTokens,              // 旧版 OpenAI 兼容
          max_completion_tokens: maxTokens,   // gpt-5.x / o系列新参数名
          messages: [{ role: 'user', content: prompt }],
        }),
      });
    }
  } catch (e) {
    clearTimeout(timeoutId);
    if (e.name === 'AbortError') throw new Error('API 请求超时（30s）');
    throw e;
  }
  clearTimeout(timeoutId);

  if (!response.ok) {
    const rawText = await response.text().catch(() => '');
    let msg = response.statusText || '';
    try {
      const err = JSON.parse(rawText);
      msg = err.error?.message || err.message || msg;
    } catch (_) {
      if (rawText) msg = rawText.slice(0, 300);
    }
    throw new Error(`API 错误 ${response.status}: ${msg || '(空)'} [模型:${model} 地址:${requestUrl}]`);
  }

  const data = await response.json();
  if (isClaudeModel(model)) {
    if (!data.content?.[0]?.text) throw new Error(`API 返回格式异常: ${JSON.stringify(data).slice(0, 200)}`);
    return data.content[0].text;
  } else {
    const text = data.choices?.[0]?.message?.content;
    if (text === undefined || text === null) throw new Error(`API 返回格式异常: ${JSON.stringify(data).slice(0, 200)}`);
    return text;
  }
}

// ─── 将结构化筛选条件转为 prompt 文本 ────────────────────────────────────────
function buildCriteriaText(config) {
  const fc = config.filterCriteria || {};
  const hard = []; // 硬性要求：不满足即淘汰
  const soft = []; // 软性偏好：满足则加分

  const tierMap = { bigtech: 'BAT/字节/美团等互联网大厂', listed: '上市公司', unicorn: '独角兽或知名创业公司', top: '行业头部公司' };
  const eduMap  = { bachelor: '本科及以上', master: '硕士及以上', phd: '博士' };
  const schoolMap = { '985': '985高校', '211': '211及以上高校', top: '双一流高校' };

  // ── 硬性要求 ──
  if (fc.minExpYears > 0 || fc.maxExpYears > 0) {
    const min = fc.minExpYears > 0 ? `${fc.minExpYears}年以上` : '';
    const max = fc.maxExpYears > 0 ? `${fc.maxExpYears}年以下` : '';
    hard.push(`工作年限：正式工作年限 ${[min, max].filter(Boolean).join('且')}（计算方法：以最高学历毕业年份→2026年；实习不计入，≤4个月或与在校期重叠的短期经历均视为实习；超出范围直接淘汰）`);
  }
  if (fc.minEducation && fc.minEducation !== 'any') {
    hard.push(`最低学历：${eduMap[fc.minEducation]}（低于此学历直接淘汰）`);
  }
  if (fc.school && fc.school !== 'any') {
    hard.push(`院校要求：必须毕业于${schoolMap[fc.school]}（不符合直接淘汰）`);
  }
  if (fc.keywords?.length && fc.keywordsLogic === 'all') {
    hard.push(`技术关键词（必须全部具备）：${fc.keywords.join('、')}（任意一项缺失直接淘汰）`);
  }
  if (fc.gender && fc.gender !== 'any') {
    hard.push(`性别：${fc.gender === 'male' ? '男性' : '女性'}（不符合直接淘汰）`);
  }
  if (fc.minAvgTenure > 0) {
    const t = fc.minAvgTenure >= 1 ? fc.minAvgTenure + '年' : (fc.minAvgTenure * 12) + '个月';
    hard.push(`稳定性：平均每家公司任职时长 ≥ ${t}（低于此值直接淘汰）`);
  }
  if (fc.minLastTenure > 0) {
    const t = fc.minLastTenure >= 1 ? fc.minLastTenure + '年' : (fc.minLastTenure * 12) + '个月';
    hard.push(`近期稳定性：最近一份工作任职时长 ≥ ${t}（低于此值直接淘汰）`);
  }

  // ── 软性偏好 ──
  if (fc.companyTier && fc.companyTier !== 'any') {
    soft.push(`优先来自${tierMap[fc.companyTier]}的候选人（大幅加分）`);
  }
  if (fc.targetCompanies) {
    soft.push(`来自以下公司大幅加分：${fc.targetCompanies}`);
  }
  if (fc.keywords?.length && fc.keywordsLogic !== 'all') {
    soft.push(`技术关键词（至少满足一项）：${fc.keywords.join('、')}（加分项）`);
  }
  if (fc.notes) soft.push(`补充说明：${fc.notes}`);

  const parts = [];
  if (hard.length) {
    parts.push('【硬性要求 — 不满足则 suitable=false，score≤40，在reason中说明哪项不达标】\n' +
      hard.map((l, i) => `${i + 1}. ${l}`).join('\n'));
  }
  if (soft.length) {
    parts.push('【软性偏好 — 满足则加分，不满足不扣分】\n' +
      soft.map((l, i) => `${i + 1}. ${l}`).join('\n'));
  }
  return parts.length ? parts.join('\n\n') : '无特殊筛选条件，根据岗位要求综合评估。';
}

// ─── 候选人评估 ───────────────────────────────────────────────────────────────
async function evaluateCandidate(candidateInfo, config) {
  const prompt = `你是一位资深猎头顾问，正在为客户寻找适合邀请面试的候选人。请根据岗位要求和筛选条件，综合评估该候选人是否值得主动联系。

## 招聘岗位
岗位名称：${config.jobTitle}
岗位要求：
${config.jobDescription}

筛选条件：
${buildCriteriaText(config)}

## 候选人资料
姓名：${candidateInfo.name || '未知'}
现任职位：${candidateInfo.title || '未知'}
所在公司：${candidateInfo.company || '未知'}
工作经历：${candidateInfo.experience || '（见下方完整资料）'}
教育背景：${candidateInfo.education || '（见下方完整资料）'}
技能标签：${candidateInfo.skills || ''}

候选人资料页完整文本：
---
${(candidateInfo.extra || '').slice(0, 3500)}
---

## 评估流程（必须按顺序执行）

**第一步：硬性要求逐项核查（一票否决）**
筛选条件中标注"硬性要求"的每一项都必须逐一核查：
- 若候选人不满足任意一项硬性要求 → suitable=false，score≤40，reason中说明哪项不达标
- 若简历信息不足以判断某项硬性要求 → 按不满足处理（宁可漏过，不可错放）
- 工作年限计算规则（严格按以下优先级执行）：
  1. **优先**：找最高学历的毕业年份，以"毕业年份 → 2026"计算正式工作年限（最准确，不受履历缺失影响）
  2. **兜底**：若简历完全没有毕业年份，再从最早的正式工作起算
  3. **实习判定**（以下任一条件满足即视为实习，不计入年限）：
     - 简历中明确标注"实习""intern""internship"等字样
     - 在职时长 ≤ 6 个月且时间节点与在校阶段（本科/硕士/博士学习期间）重叠
     - 在职时长 ≤ 4 个月（无论是否标注实习，极短期工作按实习处理）

**第二步：软性偏好评估（加分项）**
- 只有通过第一步的候选人才进行本步骤
- 根据软性偏好和岗位匹配度综合打分（60-100分）
- 公司背景、岗位相关性、职业发展路径是核心加分维度

**第三步：综合判断**
- 通过硬性要求 + 综合评分 ≥ 配置阈值 → suitable=true
- 任意硬性要求不满足 → suitable=false（不论其他条件多优秀）

## 请以 JSON 格式输出（不要有其他内容）：
{
  "suitable": true或false,
  "score": 0到100的整数,
  "reason": "按优先级说明匹配或不匹配的核心原因，50字内",
  "highlights": "候选人最突出的1-2个亮点（公司/学历/经验/稳定性），30字内",
  "stability": "稳定/较稳定/一般/频繁跳槽",
  "interviewReason": "邀请面试的个性化理由，结合公司背景或工作经历具体写，40字内，suitable为false时留空"
}`;

  const raw = await callLLM(prompt, config);

  // 解析 JSON，兼容 markdown 代码块
  const jsonMatch = raw.match(/```(?:json)?\s*([\s\S]*?)\s*```/) || raw.match(/(\{[\s\S]*\})/);
  if (!jsonMatch) throw new Error('Claude 返回格式无法解析');

  const jsonStr = jsonMatch[1];
  // 尝试直接解析
  try { return JSON.parse(jsonStr); } catch (_) {}

  // 容错：Claude 的 reason 字段可能包含候选人简介中未转义的引号（如 "不看机会勿扰"）
  // 用字段名作为边界逐个提取，避免因内嵌引号整体解析失败
  const getBool = key => {
    const m = jsonStr.match(new RegExp(`"${key}"\\s*:\\s*(true|false)`));
    return m ? m[1] === 'true' : false;
  };
  const getNum = key => {
    const m = jsonStr.match(new RegExp(`"${key}"\\s*:\\s*(\\d+)`));
    return m ? parseInt(m[1]) : 0;
  };
  const getStrBetween = (startKey, endKey) => {
    const re = endKey
      ? new RegExp(`"${startKey}"\\s*:\\s*"([\\s\\S]*?)",\\s*"${endKey}"`)
      : new RegExp(`"${startKey}"\\s*:\\s*"([\\s\\S]*?)"\\s*[,}]`);
    const m = jsonStr.match(re);
    return m ? m[1] : '';
  };

  const suitable = getBool('suitable');
  const score    = getNum('score');
  if (score === 0 && !jsonStr.includes('"score": 0') && !jsonStr.includes('"score":0')) {
    throw new Error(`Claude 返回 JSON 解析失败 | 原文: ${jsonStr.slice(0, 150)}`);
  }
  return {
    suitable,
    score,
    reason:          getStrBetween('reason', 'stability'),
    stability:       getStrBetween('stability', 'interviewReason'),
    interviewReason: getStrBetween('interviewReason', null),
  };
}

// ─── 生成招聘消息 ─────────────────────────────────────────────────────────────
async function generateMessage(candidateInfo, messageTemplate, config, isFriend = true) {
  // 公共变量替换（无论是否调 AI，先把固定变量填好）
  function fillVars(tpl) {
    // 同时支持半角 {var}/{var}、方括号 [var]、全角 ｛var｝ 三种占位符语法
    const re = (key) => new RegExp('[\\[{｛【]' + key + '[\\]}｝】]', 'g');
    const company = candidateInfo.company || '';
    let result = tpl
      .replace(re('name'), candidateInfo.name || '')
      .replace(re('title'), candidateInfo.title || '')
      .replace(re('company'), company)
      .replace(re('jobTitle'), config.jobTitle || '')
      .replace(re('reason'), candidateInfo.interviewReason || '');
    // company 为空时，清理"在 的"/"在的" 之类残留破损语句
    if (!company) {
      result = result
        .replace(/在\s*的/g, '的')        // "在 的经历" → "的经历"
        .replace(/，您在[的，。！？\s]/g, '，您'); // "，您在的经历" → "，您的经历"
    }
    return result;
  }

  if (!messageTemplate.includes('{ai}')) {
    return fillVars(messageTemplate);
  }

  // 先填充固定变量，让 AI 只需生成 {ai} 部分
  const templateWithVars = fillVars(messageTemplate);

  // 加好友附言受脉脉 50 字限制，需特别提醒 AI 控制总长度
  const lengthNote = !isFriend
    ? '\n【重要】脉脉加好友附言最多50字，请确保生成后整条消息（含模板固定文字）总字数 ≤ 50字，宁可精简也不要超字数。'
    : '';

  const prompt = `你是招聘专员，请根据模板和候选人信息，生成一条自然、真诚的面试邀请消息。
在模板中，{ai} 是你需要创作的个性化内容，请将 {ai} 替换为针对该候选人的个性化邀面理由（${isFriend ? '30-60字' : '10-20字，因总消息有50字上限'}），其他部分保持不变。${lengthNote}

模板：${templateWithVars}
岗位：${config.jobTitle || ''}
候选人职位：${candidateInfo.title || '未知'}
候选人公司：${candidateInfo.company || '未知'}
${candidateInfo.interviewReason ? `邀面核心理由（请围绕此展开）：${candidateInfo.interviewReason}` : ''}

要求：直接输出最终消息文本，不要说明，不要引号，不要{ai}占位符。`;

  return await callLLM(prompt, config);
}

// ─── 消息处理 ─────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handleMessage(msg, sender).then(sendResponse).catch(err => {
    addLog('error', err.message);
    sendResponse({ success: false, error: err.message });
  });
  return true; // 保持异步通道
});

async function handleMessage(msg, sender) {
  switch (msg.type) {

    case 'EVALUATE_CANDIDATE': {
      const config = await getConfig();
      const result = await evaluateCandidate(msg.candidateInfo, config);
      addLog('info', `评估 ${msg.candidateInfo.name}：${result.score}分 ${result.suitable ? '✓ 匹配' : '✗ 不匹配'}`, result);
      taskState.processed++;
      const threshold = (await getConfig()).scoreThreshold || 70;
      if (result.score >= threshold) taskState.matched++;
      broadcastStatus();
      return { success: true, result };
    }

    case 'GENERATE_MESSAGE': {
      const config = await getConfig();
      const template = msg.isFriend ? config.friendMessage : config.addFriendMessage;
      // 未开启 AI 消息时，直接用模板变量替换（不调用 Claude）
      // 未开启 AI 消息时，移除 {ai} 占位符并清理多余空格/标点
      const effectiveTemplate = config.useAIMessage ? template : template.replace(/\{ai\}/g, '').replace(/[ \t]{2,}/g, ' ').trim();
      const text = await generateMessage(msg.candidateInfo, effectiveTemplate, config, msg.isFriend);
      return { success: true, text };
    }

    case 'SET_AUTOMATION_TAB': {
      taskState.automationTabId = msg.tabId;
      taskState.automationWindowId = msg.windowId || null;
      return { success: true };
    }

    case 'START_TASK': {
      // 新任务启动：清除"用户主动停止"标记，避免 RESTORE_STATS 误判为用户停止
      chrome.storage.local.remove('__mmr_explicitly_stopped').catch(() => {});
      const startCfg = await getConfig();
      const profiles = msg.profiles || [];
      // 若 SET_ACTIVE_JOB 在 START_TASK 之前已调用，保留已设置的 activeProfileId（不重置）
      const prevActiveId = taskState.activeProfileId;
      const newProfiles = profiles.length ? profiles : taskState.jobProfiles;
      const newActiveId = prevActiveId && newProfiles.find(p => p.id === prevActiveId)
        ? prevActiveId
        : newProfiles[0]?.id || null;
      taskState = {
        running: true, paused: false,
        processed: 0, matched: 0, messaged: 0, added: 0, failed: 0,
        currentKeyword: '',
        startTime: Date.now(),
        logs: [],
        maxCandidates: startCfg.maxCandidates || 30,
        // 优先用发送方 tab（页面刷新后 ID 可能变化），其次保留之前记录的 ID
        automationTabId: sender?.tab?.id || taskState.automationTabId,
        automationWindowId: taskState.automationWindowId, // 必须保留，否则停止时无法关闭窗口
        jobProfiles: newProfiles,
        activeProfileId: newActiveId,
      };
      if (profiles.length) {
        const jobNames = profiles.map(p => p.name || p.jobTitle || '未命名').join('、');
        addLog('info', `任务启动，共 ${profiles.length} 个岗位：${jobNames}`);
      }
      return { success: true };
    }

    case 'SET_ACTIVE_JOB': {
      taskState.activeProfileId = msg.profileId;
      const profile = taskState.jobProfiles.find(p => p.id === msg.profileId);
      if (profile) {
        taskState.currentKeyword = '';
        addLog('info', `🏢 切换到岗位：${profile.name || profile.jobTitle || '未命名'}`);
      }
      broadcastStatus();
      return { success: true };
    }

    case 'STOP_TASK': {
      taskState.running = false;
      // 标记"用户主动停止"，区分 SW 重启（SW 重启不会调用此 handler）
      chrome.storage.local.set({ __mmr_explicitly_stopped: true }).catch(() => {});
      chrome.storage.local.remove('__mmr_live_stats').catch(() => {});
      const stopSummary = `共处理 ${taskState.processed} 人，匹配 ${taskState.matched} 人，发消息 ${taskState.messaged}，加好友 ${taskState.added}${taskState.failed ? `，失败 ${taskState.failed}` : ''}`;
      addLog('info', `任务结束。${stopSummary}`);
      // 桌面通知（处理了至少1人时才显示，告知招聘员工任务已完成）
      if (taskState.processed > 0) {
        chrome.notifications.create('maimai-task-done', {
          type: 'basic',
          iconUrl: 'icons/icon48.png',
          title: '脉脉招聘助手',
          message: `${stopSummary}`,
        }).catch(() => {});
      }
      // 通知自动化 tab 停止
      if (taskState.automationTabId) {
        chrome.tabs.sendMessage(taskState.automationTabId, { type: 'STOP_TASK_CONTENT' }).catch(() => {});
        taskState.automationTabId = null;
      }
      // 关闭独立的自动化窗口（直接关闭，不主动 focus 任何窗口，让 OS 自然处理焦点）
      if (taskState.automationWindowId) {
        const winIdToRemove = taskState.automationWindowId;
        taskState.automationWindowId = null;
        chrome.windows.remove(winIdToRemove).catch(() => {});
      }
      return { success: true };
    }

    case 'PAUSE_TASK': {
      taskState.paused = !taskState.paused;
      addLog('info', taskState.paused ? '任务已暂停' : '任务已恢复');
      broadcastStatus();
      // 通知自动化 tab（不是当前活跃 tab，因为用户可能已切换到其他 tab）
      if (taskState.automationTabId) {
        chrome.tabs.sendMessage(taskState.automationTabId, { type: 'SET_PAUSED', paused: taskState.paused }).catch(() => {});
      }
      return { success: true, paused: taskState.paused };
    }

    case 'LOG': {
      addLog(msg.level || 'info', msg.message, msg.data);
      return { success: true };
    }

    case 'ACTION_DONE': {
      if (msg.action === 'messaged') taskState.messaged++;
      if (msg.action === 'added') taskState.added++;
      if (msg.action === 'failed') taskState.failed++;
      broadcastStatus();
      return { success: true };
    }

    case 'RESTORE_STATS': {
      // 从详情页返回列表页时调用，恢复已累计的统计数据（不归零）
      if (!taskState.running) {
        // running=false 有两种原因：用户主动停止 or SW 重启归零
        const stored = await chrome.storage.local.get(['__mmr_explicitly_stopped', 'config']);
        if (stored.__mmr_explicitly_stopped) {
          // 用户主动点了停止 → 告知 content script 停止
          return { success: true, stopped: true };
        }
        // SW 重启：content.js 发 RESTORE_STATS 前会检查 __maimai_task_stopped，发送则说明任务仍在运行
        // 从 storage 恢复 jobProfiles/activeProfileId，重新标记为运行中
        const cfg = stored.config || {};
        taskState.running = true;
        taskState.paused = false;
        taskState.startTime = taskState.startTime || Date.now();
        taskState.jobProfiles = cfg.jobProfiles || taskState.jobProfiles;
        taskState.activeProfileId = taskState.activeProfileId || cfg.activeProfileId || null;
        taskState.maxCandidates = taskState.maxCandidates || cfg.maxCandidates || 30;
      }
      // automationTabId 由发送方（sender.tab.id）更新，确保页面刷新后仍追踪正确 tab
      if (sender?.tab?.id) taskState.automationTabId = sender.tab.id;
      // ⚠️ 不在此处修改 paused —— 用户点暂停后的状态必须保留，
      // 否则每次候选人处理完返回列表都会把暂停强行清零，导致无法暂停。
      taskState.currentKeyword = msg.keyword || taskState.currentKeyword;
      if (msg.stats) {
        taskState.processed = msg.stats.processed ?? taskState.processed;
        taskState.matched   = msg.stats.matched   ?? taskState.matched;
        taskState.messaged  = msg.stats.messaged  ?? taskState.messaged;
        taskState.added     = msg.stats.added     ?? taskState.added;
        taskState.failed    = msg.stats.failed    ?? taskState.failed;
      }
      // 跨页恢复时，若 content 传来当前岗位 ID，更新 activeProfileId
      if (msg.profileId && taskState.jobProfiles.length) {
        taskState.activeProfileId = msg.profileId;
      }
      if (!taskState.startTime) taskState.startTime = Date.now();
      broadcastStatus();
      return { success: true, paused: taskState.paused, activeProfileId: taskState.activeProfileId };
    }

    case 'GET_STATUS': {
      let statusResult = {
        running: taskState.running,
        paused: taskState.paused,
        processed: taskState.processed,
        matched: taskState.matched,
        messaged: taskState.messaged,
        added: taskState.added,
        failed: taskState.failed,
        currentKeyword: taskState.currentKeyword,
        maxCandidates: taskState.maxCandidates || 30,
        recentLogs: taskState.logs.slice(0, 50),
      };
      // SW 重启后 taskState 归零：若有持久化的运行中统计，先显示它（直到 RESTORE_STATS 真正恢复）
      if (!taskState.running) {
        const stored = await chrome.storage.local.get(['__mmr_live_stats', '__mmr_explicitly_stopped']);
        const live = stored.__mmr_live_stats;
        if (!stored.__mmr_explicitly_stopped && live?.running && Date.now() - live.savedAt < 5 * 60 * 1000) {
          statusResult = { ...statusResult, ...live, recentLogs: taskState.logs.slice(0, 50) };
        }
      }
      return { success: true, status: statusResult };
    }

    case 'TEST_API': {
      const config = await getConfig();
      const base = (config.claudeApiBase || 'https://llm-proxy.tapsvc.com').replace(/\/$/, '');
      const key  = config.claudeApiKey;
      const model = config.claudeModel || 'claude-sonnet-4-6';
      const oaiBase = /\/v\d|\/openai/.test(base) ? base : base + '/v1';
      const testUrl = isClaudeModel(model) ? `${base}/v1/messages` : `${oaiBase}/chat/completions`;
      try {
        const text = await callLLM('hi', { ...config, claudeMaxTokens: 5 });
        return { success: true, model, message: `✅ Key 有效，模型：${model}` };
      } catch (e) {
        // 如果是 Claude 模型，再多尝试一次 Bearer 认证（兼容代理）
        if (isClaudeModel(model)) {
          try {
            const resp = await fetch(`${base}/v1/messages`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` },
              body: JSON.stringify({ model, max_tokens: 5, messages: [{ role: 'user', content: 'hi' }] }),
            });
            if (resp.ok) return { success: true, model, message: `✅ Key 有效，模型：${model}` };
            const body = await resp.text();
            return { success: false, error: `${resp.status}: ${body.slice(0, 200)}` };
          } catch (e2) {
            return { success: false, error: e2.message };
          }
        }
        return { success: false, error: `${e.message}（请求地址：${testUrl}，模型：${model}）` };
      }
    }

    case 'SAVE_MATCHED_CANDIDATE': {
      const { candidate } = msg;
      if (!candidate) return { success: false };
      const stored = await chrome.storage.local.get('matchedCandidates');
      const list = stored.matchedCandidates || [];
      // 去重：同一 profileUrl 在 5 分钟内重复保存则跳过（防止重试/救援路径双写）
      if (candidate.profileUrl) {
        const cutoff = Date.now() - 5 * 60 * 1000;
        const dup = list.some(c => c.profileUrl === candidate.profileUrl && c.timestamp >= cutoff);
        if (dup) return { success: true, duplicate: true };
      }
      list.push(candidate);
      await chrome.storage.local.set({ matchedCandidates: list });
      return { success: true };
    }

    case 'GET_MATCHED_CANDIDATES': {
      const stored = await chrome.storage.local.get('matchedCandidates');
      return { candidates: stored.matchedCandidates || [] };
    }

    case 'CLEAR_MATCHED_CANDIDATES': {
      await chrome.storage.local.set({ matchedCandidates: [] });
      return { success: true };
    }

    case 'OPEN_POPUP': {
      // 找已有的 panel 窗口，激活它；没有则在当前窗口右下角新建
      const popupUrl = chrome.runtime.getURL('popup.html');
      const wins = await chrome.windows.getAll({ populate: true });
      for (const w of wins) {
        const tab = w.tabs?.find(t => t.url?.startsWith(popupUrl));
        if (tab) {
          await chrome.windows.update(w.id, { focused: true });
          taskState.panelWindowId = w.id;
          // 通知胶囊隐藏（操作台已打开）
          if (taskState.automationTabId) {
            chrome.tabs.sendMessage(taskState.automationTabId, { type: 'HIDE_OVERLAY' }).catch(() => {});
          }
          return { success: true };
        }
      }
      const panelW = 400, panelH = 560;
      let left, top;
      try {
        const cur = await chrome.windows.getLastFocused();
        left = cur.left + cur.width  - panelW - 16;
        top  = cur.top  + cur.height - panelH - 80;
      } catch (_) {
        left = 900; top = 300;
      }
      const newWin = await chrome.windows.create({
        url: popupUrl + '?panel=1',
        type: 'popup',
        left: Math.max(0, left),
        top:  Math.max(0, top),
        width: panelW,
        height: panelH,
        focused: true,
      });
      taskState.panelWindowId = newWin?.id ?? null;
      // 通知胶囊隐藏
      if (taskState.automationTabId) {
        chrome.tabs.sendMessage(taskState.automationTabId, { type: 'HIDE_OVERLAY' }).catch(() => {});
      }
      return { success: true };
    }

    case 'GET_CONFIG': {
      const config = await getConfig();
      return { success: true, config };
    }

    case 'SAVE_CONFIG': {
      await chrome.storage.local.set({ config: msg.config });
      addLog('info', '配置已保存');
      return { success: true };
    }

    case 'IS_RUNNING': {
      return { success: true, running: taskState.running, paused: taskState.paused };
    }

    default:
      return { success: false, error: `未知消息类型: ${msg.type}` };
  }
}

// ─── 获取配置（合并默认值 + 活跃岗位 profile 字段）─────────────────────────
async function getConfig() {
  let { config = {} } = await chrome.storage.local.get('config');

  // 迁移：若 local 为空，尝试从 sync 搬运（storage.sync → storage.local 升级）
  if (!config.claudeApiKey && !config.jobProfiles && !config.jobDescription) {
    try {
      const { config: syncCfg = {} } = await chrome.storage.sync.get('config');
      if (syncCfg.claudeApiKey || syncCfg.jobDescription) {
        config = syncCfg;
        await chrome.storage.local.set({ config });
      }
    } catch (_) {}
  }

  const base = {
    ...DEFAULT_CONFIG,
    ...config,
    selectors: { ...DEFAULT_CONFIG.selectors, ...(config.selectors || {}) },
    humanBehavior: { ...DEFAULT_CONFIG.humanBehavior, ...(config.humanBehavior || {}) },
    filterCriteria: { ...DEFAULT_CONFIG.filterCriteria, ...(config.filterCriteria || {}) },
  };

  // 若任务正在运行且有活跃 profile，用 profile 的岗位字段覆盖 base config
  if (taskState.activeProfileId && taskState.jobProfiles.length) {
    const profile = taskState.jobProfiles.find(p => p.id === taskState.activeProfileId);
    if (profile) {
      return {
        ...base,
        jobTitle:        profile.jobTitle        || base.jobTitle,
        jobDescription:  profile.jobDescription  || base.jobDescription,
        scoreThreshold:  profile.scoreThreshold  ?? base.scoreThreshold,
        friendMessage:   profile.friendMessage   || base.friendMessage,
        addFriendMessage: profile.addFriendMessage || base.addFriendMessage,
        useAIMessage:    profile.useAiMsg        ?? base.useAIMessage,
        filterCriteria: {
          ...base.filterCriteria,
          ...(profile.filterCriteria || {}),
        },
      };
    }
  }

  return base;
}

// ─── 保持自动化窗口最小化，防止任何情况下抢焦点 ─────────────────────────────────
// 自动化窗口以 state:'minimized' 创建，但若用户误点 Dock 图标恢复了窗口，
// 此处监听到页面完成后重新最小化，确保始终在后台静默运行。
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (
    taskState.running &&
    taskState.automationWindowId &&
    tabId === taskState.automationTabId &&
    changeInfo.status === 'complete'
  ) {
    chrome.windows.get(taskState.automationWindowId).then(win => {
      if (win && win.state !== 'minimized') {
        chrome.windows.update(taskState.automationWindowId, { state: 'minimized' }).catch(() => {});
      }
    }).catch(() => {});
  }
});

// ─── 操作台窗口关闭时恢复胶囊 ──────────────────────────────────────────────────
chrome.windows.onRemoved.addListener((windowId) => {
  if (taskState.panelWindowId && windowId === taskState.panelWindowId) {
    taskState.panelWindowId = null;
    // 操作台关闭 → 通知自动化页面重新显示胶囊
    if (taskState.running && taskState.automationTabId) {
      chrome.tabs.sendMessage(taskState.automationTabId, { type: 'SHOW_OVERLAY' }).catch(() => {});
    }
  }
});

// ─── 兜底：任务运行时自动关闭脉脉产生的新标签 ──────────────────────────────────
// content.js 已通过覆盖 window.open 阻止新标签，此处作双重保险
let maimaiTabId = null; // 记录当前运行任务的标签ID

chrome.tabs.onCreated.addListener(async (newTab) => {
  if (!taskState.running) return;
  // 等待 URL 解析（onCreated 触发时 pendingUrl 可能还是空）
  await new Promise(r => setTimeout(r, 200));
  const tab = await chrome.tabs.get(newTab.id).catch(() => null);
  if (!tab) return;

  const url = tab.pendingUrl || tab.url || '';
  if (!url || !url.includes('maimai.cn')) return;

  // 情况1：有 opener（window.open 产生）→ 通知 opener 做 SPA 导航后关闭新 tab
  if (tab.openerTabId) {
    chrome.tabs.sendMessage(tab.openerTabId, { type: 'NAVIGATE_TO', url }).catch(() => {});
    await chrome.tabs.remove(newTab.id).catch(() => {});
    return;
  }

  // 情况2：新 tab 在自动化窗口内（target="_blank" 点击产生，opener 为 null）→ 直接关闭
  if (taskState.automationWindowId && tab.windowId === taskState.automationWindowId
      && newTab.id !== taskState.automationTabId) {
    // 把目标 URL 转发给自动化 tab，再关闭多余 tab
    if (taskState.automationTabId) {
      chrome.tabs.sendMessage(taskState.automationTabId, { type: 'NAVIGATE_TO', url }).catch(() => {});
    }
    await chrome.tabs.remove(newTab.id).catch(() => {});
  }
});

// ─── 点击扩展图标：打开/聚焦操作台标签页 ────────────────────────────────────
chrome.action.onClicked.addListener(async () => {
  const panelUrl = chrome.runtime.getURL('popup.html') + '?standalone=1';
  // 查找已经打开的操作台标签页
  const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL('popup.html') + '*' });
  if (tabs.length > 0) {
    // 已有操作台标签页，直接聚焦
    const t = tabs[0];
    await chrome.windows.update(t.windowId, { focused: true }).catch(() => {});
    await chrome.tabs.update(t.id, { active: true });
  } else {
    // 新建操作台标签页
    chrome.tabs.create({ url: panelUrl });
  }
});

// ─── 扩展安装时写入默认配置 ───────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  if (reason === 'install') {
    const { config } = await chrome.storage.local.get('config');
    if (!config) {
      await chrome.storage.local.set({ config: DEFAULT_CONFIG });
    }
  }
});
