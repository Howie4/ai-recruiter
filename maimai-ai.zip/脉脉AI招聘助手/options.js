/**
 * options.js — 完整配置页面逻辑
 */

const $ = id => document.getElementById(id);

// ─── Tab 导航 ────────────────────────────────────────────────────────────────
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    item.classList.add('active');
    const target = item.dataset.tab;
    document.getElementById(target)?.classList.add('active');
  });
});

// ─── 范围滑块实时显示 ─────────────────────────────────────────────────────────
function bindRange(inputId, displayId, formatter) {
  const input = $(inputId);
  const display = $(displayId);
  if (!input || !display) return;
  input.addEventListener('input', () => {
    display.textContent = formatter ? formatter(input.value) : input.value;
  });
}

bindRange('scoreThreshold', 'scoreThresholdVal', v => v);
bindRange('actionDelay', 'actionDelayVal', v => `${v} ms`);
bindRange('pageDelay', 'pageDelayVal', v => `${v} ms`);

// 行为模拟滑块
bindRange('typingSpeedMin', 'typingSpeedMinVal', v => `${v} ms`);
bindRange('typingSpeedMax', 'typingSpeedMaxVal', v => `${v} ms`);
bindRange('typingErrorRate', 'typingErrorRateVal', v => `${Math.round(v * 100)}%`);
bindRange('readingSpeedCharsPerSec', 'readingSpeedCharsPerSecVal', v => `${v} 字/秒`);
bindRange('readingMinMs', 'readingMinMsVal', v => `${(v / 1000).toFixed(1)} 秒`);
bindRange('readingMaxMs', 'readingMaxMsVal', v => `${(v / 1000).toFixed(1)} 秒`);
bindRange('hoverMinMs', 'hoverMinMsVal', v => `${v} ms`);
bindRange('hoverMaxMs', 'hoverMaxMsVal', v => `${v} ms`);
bindRange('reviewMinMs', 'reviewMinMsVal', v => `${(v / 1000).toFixed(1)} 秒`);
bindRange('reviewMaxMs', 'reviewMaxMsVal', v => `${(v / 1000).toFixed(1)} 秒`);
bindRange('breakAfterN', 'breakAfterNVal', v => `${v} 人`);
bindRange('breakMinMs', 'breakMinMsVal', v => `${Math.round(v / 1000)} 秒`);
bindRange('breakMaxMs', 'breakMaxMsVal', v => `${Math.round(v / 1000)} 秒`);
bindRange('longBreakAfterN', 'longBreakAfterNVal', v => `${v} 人`);
bindRange('longBreakMinMs', 'longBreakMinMsVal', v => `${Math.round(v / 60000)} 分钟`);
bindRange('longBreakMaxMs', 'longBreakMaxMsVal', v => `${Math.round(v / 60000)} 分钟`);
bindRange('skipProbability', 'skipProbabilityVal', v => `${Math.round(v * 100)}%`);
bindRange('jitterPercent', 'jitterPercentVal', v => `±${v}%`);
bindRange('scrollSteps', 'scrollStepsVal', v => `${v} 步`);

// ─── 加载配置 ────────────────────────────────────────────────────────────────
async function loadConfig() {
  const { config = {} } = await chrome.storage.sync.get('config');

  // Claude AI
  setValue('claudeApiKey', config.claudeApiKey);
  setValue('claudeApiBase', config.claudeApiBase || '');
  setValue('claudeModel', config.claudeModel || 'claude-opus-4-6');
  setValue('claudeMaxTokens', config.claudeMaxTokens || 1024);
  setValue('scoreThreshold', config.scoreThreshold ?? 70);
  $('scoreThresholdVal').textContent = config.scoreThreshold ?? 70;
  setCheck('debugMode', config.debugMode);

  // 岗位
  setValue('jobTitle', config.jobTitle);
  setValue('searchKeywords', config.searchKeywords);
  setValue('jobDescription', config.jobDescription);
  setValue('maxCandidates', config.maxCandidates || 30);

  // 结构化筛选条件
  const fc = config.filterCriteria || {};
  // 公司/岗位
  setRadio('companyTier', fc.companyTier || 'any');
  setValue('targetCompanies', fc.targetCompanies);
  setRadio('positionLevel', fc.positionLevel || 'any');
  // 学历
  setRadio('minEducation', fc.minEducation || 'any');
  setRadio('school', fc.school || 'any');
  // 工作年限
  setValue('minExpYears', fc.minExpYears ?? 0);
  setValue('maxExpYears', fc.maxExpYears ?? 0);
  // 稳定性
  setRadio('minAvgTenure', String(fc.minAvgTenure ?? 0));
  setRadio('minLastTenure', String(fc.minLastTenure ?? 0));
  // 关键词
  filterKeywords = Array.isArray(fc.keywords) ? [...fc.keywords] : [];
  renderKeywordTags();
  setRadio('keywordsLogic', fc.keywordsLogic || 'any');
  // 其他
  setRadio('gender', fc.gender || 'any');
  setValue('criteriaNote', fc.notes);

  // 消息
  setValue('friendMessage', config.friendMessage);
  setValue('addFriendMessage', config.addFriendMessage);
  setCheck('useAIMessage', config.useAIMessage);

  // 任务参数
  setValue('actionDelay', config.actionDelay || 2500);
  $('actionDelayVal').textContent = `${config.actionDelay || 2500} ms`;
  setValue('pageDelay', config.pageDelay || 3000);
  $('pageDelayVal').textContent = `${config.pageDelay || 3000} ms`;

  // 行为模拟
  const bh = config.humanBehavior || {};
  setValue('typingSpeedMin', bh.typingSpeedMin ?? 80);
  $('typingSpeedMinVal').textContent = `${bh.typingSpeedMin ?? 80} ms`;
  setValue('typingSpeedMax', bh.typingSpeedMax ?? 200);
  $('typingSpeedMaxVal').textContent = `${bh.typingSpeedMax ?? 200} ms`;
  setValue('typingErrorRate', bh.typingErrorRate ?? 0.03);
  $('typingErrorRateVal').textContent = `${Math.round((bh.typingErrorRate ?? 0.03) * 100)}%`;
  setValue('readingSpeedCharsPerSec', bh.readingSpeedCharsPerSec ?? 8);
  $('readingSpeedCharsPerSecVal').textContent = `${bh.readingSpeedCharsPerSec ?? 8} 字/秒`;
  setValue('readingMinMs', bh.readingMinMs ?? 5000);
  $('readingMinMsVal').textContent = `${((bh.readingMinMs ?? 5000) / 1000).toFixed(1)} 秒`;
  setValue('readingMaxMs', bh.readingMaxMs ?? 25000);
  $('readingMaxMsVal').textContent = `${((bh.readingMaxMs ?? 25000) / 1000).toFixed(1)} 秒`;
  setValue('hoverMinMs', bh.hoverMinMs ?? 300);
  $('hoverMinMsVal').textContent = `${bh.hoverMinMs ?? 300} ms`;
  setValue('hoverMaxMs', bh.hoverMaxMs ?? 1200);
  $('hoverMaxMsVal').textContent = `${bh.hoverMaxMs ?? 1200} ms`;
  setValue('reviewMinMs', bh.reviewMinMs ?? 1500);
  $('reviewMinMsVal').textContent = `${((bh.reviewMinMs ?? 1500) / 1000).toFixed(1)} 秒`;
  setValue('reviewMaxMs', bh.reviewMaxMs ?? 5000);
  $('reviewMaxMsVal').textContent = `${((bh.reviewMaxMs ?? 5000) / 1000).toFixed(1)} 秒`;
  setValue('breakAfterN', bh.breakAfterN ?? 8);
  $('breakAfterNVal').textContent = `${bh.breakAfterN ?? 8} 人`;
  setValue('breakMinMs', bh.breakMinMs ?? 15000);
  $('breakMinMsVal').textContent = `${Math.round((bh.breakMinMs ?? 15000) / 1000)} 秒`;
  setValue('breakMaxMs', bh.breakMaxMs ?? 40000);
  $('breakMaxMsVal').textContent = `${Math.round((bh.breakMaxMs ?? 40000) / 1000)} 秒`;
  setValue('longBreakAfterN', bh.longBreakAfterN ?? 25);
  $('longBreakAfterNVal').textContent = `${bh.longBreakAfterN ?? 25} 人`;
  setValue('longBreakMinMs', bh.longBreakMinMs ?? 120000);
  $('longBreakMinMsVal').textContent = `${Math.round((bh.longBreakMinMs ?? 120000) / 60000)} 分钟`;
  setValue('longBreakMaxMs', bh.longBreakMaxMs ?? 300000);
  $('longBreakMaxMsVal').textContent = `${Math.round((bh.longBreakMaxMs ?? 300000) / 60000)} 分钟`;
  setValue('skipProbability', bh.skipProbability ?? 0.08);
  $('skipProbabilityVal').textContent = `${Math.round((bh.skipProbability ?? 0.08) * 100)}%`;
  setValue('jitterPercent', bh.jitterPercent ?? 30);
  $('jitterPercentVal').textContent = `±${bh.jitterPercent ?? 30}%`;
  setValue('dailyContactLimit', bh.dailyContactLimit ?? 50);
  setCheck('workHoursEnabled', bh.workHoursEnabled);
  setValue('workHoursStart', bh.workHoursStart ?? 9);
  setValue('workHoursEnd', bh.workHoursEnd ?? 18);
  setCheck('scrollProfileEnabled', bh.scrollProfileEnabled !== false);
  setValue('scrollSteps', bh.scrollSteps ?? 3);
  $('scrollStepsVal').textContent = `${bh.scrollSteps ?? 3} 步`;

  // 选择器
  const sel = config.selectors || {};
  setValue('sel-searchInput', sel.searchInput);
  setValue('sel-connectionsTab', sel.connectionsTab);
  setValue('sel-connectionsTabText', sel.connectionsTabText);
  setValue('sel-profileCard', sel.profileCard);
  setValue('sel-cardName', sel.cardName);
  setValue('sel-cardTitle', sel.cardTitle);
  setValue('sel-cardCompany', sel.cardCompany);
  setValue('sel-viewBtn', sel.viewBtnText);
  setValue('sel-addFriendBtn', sel.addFriendBtnText);
  setValue('sel-messageBtn', sel.messageBtnText);
  setValue('sel-friendRequestInput', sel.friendRequestInput);
  setValue('sel-sendConfirmBtn', sel.sendConfirmBtnText);
  setValue('sel-profileName', sel.profileName);
  setValue('sel-profileTitle', sel.profileTitle);
  setValue('sel-profileCompany', sel.profileCompany);
  setValue('sel-profileExp', sel.profileExp);
  setValue('sel-profileEdu', sel.profileEdu);
  setValue('sel-profileSkills', sel.profileSkills);
  setValue('sel-messageInputBox', sel.messageInputBox);
  setValue('sel-messageSendBtn', sel.messageSendBtnText);
}

function setValue(id, value) {
  const el = $(id);
  if (!el) return;
  el.value = (value != null && value !== '') ? String(value) : '';
}

function setCheck(id, value) {
  const el = $(id);
  if (el) el.checked = !!value;
}

// ─── 收集配置 ────────────────────────────────────────────────────────────────
function collectConfig() {
  return {
    claudeApiKey: $('claudeApiKey').value.trim(),
    claudeApiBase: $('claudeApiBase').value.trim(),
    claudeModel: $('claudeModel').value,
    claudeMaxTokens: parseInt($('claudeMaxTokens').value) || 1024,
    scoreThreshold: parseInt($('scoreThreshold').value) || 70,
    debugMode: $('debugMode').checked,

    jobTitle: $('jobTitle').value.trim(),
    searchKeywords: $('searchKeywords').value.trim(),
    jobDescription: $('jobDescription').value.trim(),
    maxCandidates: parseInt($('maxCandidates').value) || 30,

    filterCriteria: {
      // 公司/岗位
      companyTier:     getRadio('companyTier'),
      targetCompanies: $('targetCompanies')?.value.trim() || '',
      positionLevel:   getRadio('positionLevel'),
      // 学历
      minEducation:    getRadio('minEducation'),
      school:          getRadio('school'),
      // 工作年限
      minExpYears:     parseInt($('minExpYears')?.value) || 0,
      maxExpYears:     parseInt($('maxExpYears')?.value) || 0,
      // 稳定性
      minAvgTenure:    parseFloat(getRadio('minAvgTenure')) || 0,
      minLastTenure:   parseFloat(getRadio('minLastTenure')) || 0,
      // 关键词
      keywords:        [...filterKeywords],
      keywordsLogic:   getRadio('keywordsLogic'),
      // 其他
      gender:          getRadio('gender'),
      notes:           $('criteriaNote')?.value.trim() || '',
    },

    friendMessage: $('friendMessage').value.trim(),
    addFriendMessage: $('addFriendMessage').value.trim(),
    useAIMessage: $('useAIMessage').checked,

    actionDelay: parseInt($('actionDelay').value) || 2500,
    pageDelay: parseInt($('pageDelay').value) || 3000,

    humanBehavior: {
      typingSpeedMin: parseInt($('typingSpeedMin').value) || 80,
      typingSpeedMax: parseInt($('typingSpeedMax').value) || 200,
      typingErrorRate: parseFloat($('typingErrorRate').value) || 0.03,
      readingSpeedCharsPerSec: parseInt($('readingSpeedCharsPerSec').value) || 8,
      readingMinMs: parseInt($('readingMinMs').value) || 5000,
      readingMaxMs: parseInt($('readingMaxMs').value) || 25000,
      hoverMinMs: parseInt($('hoverMinMs').value) || 300,
      hoverMaxMs: parseInt($('hoverMaxMs').value) || 1200,
      reviewMinMs: parseInt($('reviewMinMs').value) || 1500,
      reviewMaxMs: parseInt($('reviewMaxMs').value) || 5000,
      breakAfterN: parseInt($('breakAfterN').value) || 8,
      breakMinMs: parseInt($('breakMinMs').value) || 15000,
      breakMaxMs: parseInt($('breakMaxMs').value) || 40000,
      longBreakAfterN: parseInt($('longBreakAfterN').value) || 25,
      longBreakMinMs: parseInt($('longBreakMinMs').value) || 120000,
      longBreakMaxMs: parseInt($('longBreakMaxMs').value) || 300000,
      skipProbability: parseFloat($('skipProbability').value) || 0.08,
      jitterPercent: parseInt($('jitterPercent').value) || 30,
      dailyContactLimit: parseInt($('dailyContactLimit').value) || 50,
      workHoursEnabled: $('workHoursEnabled').checked,
      workHoursStart: parseInt($('workHoursStart').value) || 9,
      workHoursEnd: parseInt($('workHoursEnd').value) || 18,
      scrollProfileEnabled: $('scrollProfileEnabled').checked,
      scrollSteps: parseInt($('scrollSteps').value) || 3,
    },

    selectors: {
      searchInput: $('sel-searchInput').value || 'input[placeholder="搜索"]',
      connectionsTab: $('sel-connectionsTab').value || 'span, div, a, li',
      connectionsTabText: $('sel-connectionsTabText').value || '人脉',
      profileCard: $('sel-profileCard').value || '[class*="contact-item"]',
      cardName: $('sel-cardName').value || '[class*="name"]',
      cardTitle: $('sel-cardTitle').value || '[class*="title"]',
      cardCompany: $('sel-cardCompany').value || '[class*="company"]',
      viewBtnText: $('sel-viewBtn').value || '查看',
      addFriendBtnText: $('sel-addFriendBtn').value || '+加好友',
      messageBtnText: $('sel-messageBtn').value || '发消息',
      friendRequestInput: $('sel-friendRequestInput').value || 'textarea',
      sendConfirmBtnText: $('sel-sendConfirmBtn').value || '确认',
      profileName: $('sel-profileName').value || 'h1',
      profileTitle: $('sel-profileTitle').value || '[class*="title"]',
      profileCompany: $('sel-profileCompany').value || '[class*="company"]',
      profileExp: $('sel-profileExp').value || '[class*="work"]',
      profileEdu: $('sel-profileEdu').value || '[class*="edu"]',
      profileSkills: $('sel-profileSkills').value || '[class*="skill"]',
      messageInputBox: $('sel-messageInputBox').value || '[contenteditable="true"]',
      messageSendBtnText: $('sel-messageSendBtn').value || '发送',
    },
  };
}

// ─── 保存配置 ────────────────────────────────────────────────────────────────
$('btn-save').addEventListener('click', async () => {
  const config = collectConfig();

  // 简单校验
  if (!config.claudeApiKey) {
    showStatus('⚠️ 请填写 Claude API Key', 'warn');
    document.querySelector('[data-tab="tab-claude"]').click();
    return;
  }
  if (!config.jobDescription) {
    showStatus('⚠️ 请填写岗位要求', 'warn');
    document.querySelector('[data-tab="tab-job"]').click();
    return;
  }
  if (!config.friendMessage || !config.addFriendMessage) {
    showStatus('⚠️ 请填写消息话术', 'warn');
    document.querySelector('[data-tab="tab-message"]').click();
    return;
  }

  await chrome.storage.sync.set({ config });
  showStatus('✅ 配置已保存', 'success');
});

function showStatus(msg, type = 'success') {
  const el = $('save-status');
  el.textContent = msg;
  el.className = `save-status ${type}`;
  setTimeout(() => { el.textContent = ''; el.className = 'save-status'; }, 3000);
}

// ─── 恢复默认选择器 ───────────────────────────────────────────────────────────
$('btn-reset-selectors')?.addEventListener('click', async () => {
  const { config = {} } = await chrome.storage.sync.get('config');
  // 清空选择器，重新加载时会用 background.js 默认值
  delete config.selectors;
  await chrome.storage.sync.set({ config });
  location.reload();
});

// ─── 日志面板 ────────────────────────────────────────────────────────────────
async function loadLogs() {
  const { taskLogs = [] } = await chrome.storage.local.get('taskLogs');
  const container = $('log-container');
  if (!taskLogs.length) {
    container.innerHTML = '<div class="log-empty">暂无日志</div>';
    return;
  }
  container.innerHTML = taskLogs.map(l => `
    <div class="log-row log-${l.level || 'info'}">
      <span class="log-time">${l.time}</span>
      <span class="log-level">${l.level?.toUpperCase() || 'INFO'}</span>
      <span class="log-msg">${escHtml(l.message)}</span>
    </div>`).join('');
}

$('btn-refresh-log')?.addEventListener('click', loadLogs);
$('btn-clear-log')?.addEventListener('click', async () => {
  await chrome.storage.local.remove('taskLogs');
  loadLogs();
});

function escHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// ─── 操作风格预设 ─────────────────────────────────────────────────────────────
const BEHAVIOR_PRESETS = {
  gentle: {
    typingSpeedMin: 120, typingSpeedMax: 350, typingErrorRate: 0.05,
    readingSpeedCharsPerSec: 6, readingMinMs: 8000, readingMaxMs: 35000,
    hoverMinMs: 500, hoverMaxMs: 2000,
    reviewMinMs: 2000, reviewMaxMs: 8000,
    breakAfterN: 5, breakMinMs: 20000, breakMaxMs: 60000,
    longBreakAfterN: 15, longBreakMinMs: 180000, longBreakMaxMs: 420000,
    skipProbability: 0.12, jitterPercent: 40,
    dailyContactLimit: 30,
    workHoursEnabled: false, workHoursStart: 9, workHoursEnd: 18,
    scrollProfileEnabled: true, scrollSteps: 4,
  },
  normal: {
    typingSpeedMin: 80, typingSpeedMax: 200, typingErrorRate: 0.03,
    readingSpeedCharsPerSec: 8, readingMinMs: 5000, readingMaxMs: 25000,
    hoverMinMs: 300, hoverMaxMs: 1200,
    reviewMinMs: 1500, reviewMaxMs: 5000,
    breakAfterN: 8, breakMinMs: 15000, breakMaxMs: 40000,
    longBreakAfterN: 25, longBreakMinMs: 120000, longBreakMaxMs: 300000,
    skipProbability: 0.08, jitterPercent: 30,
    dailyContactLimit: 50,
    workHoursEnabled: false, workHoursStart: 9, workHoursEnd: 18,
    scrollProfileEnabled: true, scrollSteps: 3,
  },
  fast: {
    typingSpeedMin: 40, typingSpeedMax: 100, typingErrorRate: 0.01,
    readingSpeedCharsPerSec: 15, readingMinMs: 2000, readingMaxMs: 10000,
    hoverMinMs: 150, hoverMaxMs: 500,
    reviewMinMs: 800, reviewMaxMs: 2000,
    breakAfterN: 15, breakMinMs: 8000, breakMaxMs: 20000,
    longBreakAfterN: 50, longBreakMinMs: 60000, longBreakMaxMs: 120000,
    skipProbability: 0.03, jitterPercent: 15,
    dailyContactLimit: 80,
    workHoursEnabled: false, workHoursStart: 9, workHoursEnd: 18,
    scrollProfileEnabled: false, scrollSteps: 2,
  },
};

function applyBehaviorPreset(preset) {
  const p = BEHAVIOR_PRESETS[preset];
  if (!p) return;
  Object.entries(p).forEach(([key, val]) => {
    const el = $(key);
    if (!el) return;
    if (el.type === 'checkbox') {
      el.checked = !!val;
    } else {
      el.value = val;
      // Trigger display update
      el.dispatchEvent(new Event('input'));
    }
  });
  showStatus(`✅ 已应用${preset === 'gentle' ? '温和' : preset === 'normal' ? '标准' : '效率'}模式预设`, 'success');
}

$('preset-gentle')?.addEventListener('click', () => applyBehaviorPreset('gentle'));
$('preset-normal')?.addEventListener('click', () => applyBehaviorPreset('normal'));
$('preset-fast')?.addEventListener('click', () => applyBehaviorPreset('fast'));

// ─── 关键词标签管理 ───────────────────────────────────────────────────────────
let filterKeywords = [];

function renderKeywordTags() {
  const list = $('keyword-tags');
  if (!list) return;
  list.innerHTML = filterKeywords.map((kw, i) => `
    <span class="tag-item">
      ${kw}
      <span class="tag-del" data-index="${i}" title="删除">×</span>
    </span>`).join('');
  list.querySelectorAll('.tag-del').forEach(btn => {
    btn.addEventListener('click', () => {
      filterKeywords.splice(parseInt(btn.dataset.index), 1);
      renderKeywordTags();
    });
  });
}

function addKeyword() {
  const input = $('keyword-input');
  const val = input.value.trim();
  if (val && !filterKeywords.includes(val)) {
    filterKeywords.push(val);
    renderKeywordTags();
  }
  input.value = '';
  input.focus();
}

$('keyword-add-btn')?.addEventListener('click', addKeyword);
$('keyword-input')?.addEventListener('keydown', e => {
  if (e.key === 'Enter') { e.preventDefault(); addKeyword(); }
});

// ─── 单选组读写工具 ───────────────────────────────────────────────────────────
function getRadio(name) {
  const checked = document.querySelector(`input[name="${name}"]:checked`);
  return checked ? checked.value : 'any';
}
function setRadio(name, value) {
  const el = document.querySelector(`input[name="${name}"][value="${value || 'any'}"]`);
  if (el) el.checked = true;
}

// ─── 初始化 ──────────────────────────────────────────────────────────────────
loadConfig().catch(console.error);

// 默认显示日志时加载
document.querySelector('[data-tab="tab-log"]')?.addEventListener('click', loadLogs);
