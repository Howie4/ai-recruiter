/**
 * 运行此脚本生成扩展图标 PNG
 * 需要: node >= 18
 * 运行: node generate-icons.js
 *
 * 如果不想运行脚本，也可以直接把任意 PNG 图片
 * 分别改名为 icon16.png / icon48.png / icon128.png 放到 icons/ 目录下
 */

const { createCanvas } = require('canvas');   // npm install canvas
const fs = require('fs');
const path = require('path');

function generateIcon(size) {
  const canvas = createCanvas(size, size);
  const ctx = canvas.getContext('2d');

  // 背景渐变
  const grad = ctx.createLinearGradient(0, 0, size, size);
  grad.addColorStop(0, '#6c63ff');
  grad.addColorStop(1, '#3b82f6');

  ctx.beginPath();
  ctx.roundRect(0, 0, size, size, size * 0.2);
  ctx.fillStyle = grad;
  ctx.fill();

  // 机器人图标
  ctx.fillStyle = '#fff';
  ctx.font = `${size * 0.6}px serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('🤖', size / 2, size / 2);

  return canvas.toBuffer('image/png');
}

const sizes = [16, 48, 128];
const dir = path.join(__dirname, 'icons');
if (!fs.existsSync(dir)) fs.mkdirSync(dir);

for (const size of sizes) {
  const buf = generateIcon(size);
  fs.writeFileSync(path.join(dir, `icon${size}.png`), buf);
  console.log(`✓ icon${size}.png 已生成`);
}

console.log('\n图标生成完毕！');
